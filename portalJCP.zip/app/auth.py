"""Authentication module supporting LDAP, SAML, and Dummy authentication."""
import os
import hashlib
import secrets
from datetime import datetime, timedelta
from functools import wraps

import jwt
from flask import Blueprint, request, redirect, url_for, render_template, flash, session, current_app, jsonify, make_response
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from onelogin.saml2.auth import OneLogin_Saml2_Auth
from onelogin.saml2.utils import OneLogin_Saml2_Utils

from models import db, User
from saml import prepare_flask_request, get_saml_settings

auth_bp = Blueprint('auth', __name__)
login_manager = LoginManager()


@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login."""
    return User.query.get(int(user_id))


@login_manager.unauthorized_handler
def unauthorized():
    """Handle unauthorized access."""
    if request.is_json:
        return jsonify({'error': 'Authentication required'}), 401
    return redirect(url_for('auth.login'))


def hash_password(password):
    """Hash password using SHA-256 with salt."""
    salt = os.environ.get('PASSWORD_SALT', 'default-salt')
    return hashlib.sha256(f"{salt}{password}".encode()).hexdigest()


def verify_password(password, password_hash):
    """Verify password against hash."""
    return hash_password(password) == password_hash


def generate_jwt_token(user):
    """Generate JWT token for JupyterHub authentication."""
    payload = {
        'uid': user.uid,
        'email': user.email,
        'name': user.full_name,
        'role': user.role,
        'exp': datetime.utcnow() + timedelta(hours=current_app.config.get('JWT_EXPIRATION_HOURS', 8))
    }
    return jwt.encode(payload, current_app.config['JWT_SECRET_KEY'], algorithm='HS256')


def admin_required(f):
    """Decorator to require admin role."""
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin:
            if request.is_json:
                return jsonify({'error': 'Admin access required'}), 403
            flash('Admin access required', 'error')
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated_function


# ============ DUMMY AUTHENTICATION ============

def authenticate_dummy(username, password):
    """Authenticate using dummy/local credentials."""
    user = User.query.filter_by(uid=username).first()
    if user and user.password_hash and verify_password(password, user.password_hash):
        return user
    return None


# ============ LDAP AUTHENTICATION ============

def authenticate_ldap(username, password):
    """Authenticate using LDAP."""
    try:
        from ldap3 import Server, Connection, ALL, SUBTREE
        
        ldap_host = current_app.config['LDAP_HOST']
        base_dn = current_app.config['LDAP_BASE_DN']
        user_dn = current_app.config['LDAP_USER_DN']
        search_filter = current_app.config['LDAP_USER_SEARCH_FILTER'].format(username=username)
        
        server = Server(ldap_host, get_info=ALL)
        
        # First bind with service account if configured
        bind_dn = current_app.config.get('LDAP_BIND_DN')
        bind_password = current_app.config.get('LDAP_BIND_PASSWORD')
        
        if bind_dn:
            conn = Connection(server, bind_dn, bind_password, auto_bind=True)
        else:
            # Anonymous bind
            conn = Connection(server, auto_bind=True)
        
        # Search for user
        search_base = f"{user_dn},{base_dn}" if user_dn else base_dn
        conn.search(search_base, search_filter, SUBTREE, attributes=current_app.config['LDAP_ATTRIBUTES'])
        
        if not conn.entries:
            return None
        
        user_entry = conn.entries[0]
        user_full_dn = user_entry.entry_dn
        
        # Bind as user to verify password
        user_conn = Connection(server, user_full_dn, password)
        if not user_conn.bind():
            return None
        
        # Get or create user in database
        user = User.query.filter_by(uid=username).first()
        if not user:
            user = User(
                uid=username,
                name=str(user_entry.cn) if hasattr(user_entry, 'cn') else username,
                last_name=str(user_entry.sn) if hasattr(user_entry, 'sn') else None,
                email=str(user_entry.mail) if hasattr(user_entry, 'mail') else None,
                manager_uid=str(user_entry.manager) if hasattr(user_entry, 'manager') else None,
                role='dev',
                date_creation=datetime.utcnow()
            )
            db.session.add(user)
            db.session.commit()
        
        return user
        
    except ImportError:
        current_app.logger.error("ldap3 library not installed")
        return None
    except Exception as e:
        current_app.logger.error(f"LDAP authentication error: {e}")
        return None


# ============ SAML ROUTES ============

@auth_bp.route('/saml/metadata')
def saml_metadata():
    """Expose SP metadata XML."""
    req = prepare_flask_request(request)
    auth = OneLogin_Saml2_Auth(req, get_saml_settings())
    settings = auth.get_settings()
    metadata = settings.get_sp_metadata()
    errors = settings.validate_metadata(metadata)

    if len(errors) == 0:
        resp = make_response(metadata, 200)
        resp.headers['Content-Type'] = 'text/xml'
    else:
        resp = make_response(', '.join(errors), 500)
    return resp


@auth_bp.route('/saml/login')
def saml_login():
    """Initiate SAML SSO login."""
    req = prepare_flask_request(request)
    auth = OneLogin_Saml2_Auth(req, get_saml_settings())
    # Redirect to Next URL after login
    return_to = request.args.get('next') or url_for('main.dashboard', _external=True)
    return redirect(auth.login(return_to))


@auth_bp.route('/saml/acs', methods=['POST'])
def saml_acs():
    """Handle SAML Assertion Consumer Service response."""
    req = prepare_flask_request(request)
    auth = OneLogin_Saml2_Auth(req, get_saml_settings())
    auth.process_response()
    errors = auth.get_errors()
    
    if not errors:
        if auth.is_authenticated():
            attributes = auth.get_attributes()
            
            # Map attributes
            # Based on spec.jpeg, username is 'uid' or 'username'
            uid = attributes.get('uid', [None])[0] or attributes.get('username', [None])[0]
            email = attributes.get('email', [None])[0] or attributes.get('mail', [None])[0]
            first_name = attributes.get('firstname', [None])[0] or attributes.get('givenName', [None])[0] or uid
            last_name = attributes.get('lastname', [None])[0] or attributes.get('sn', [None])[0]
            
            if not uid:
                flash('SAML Error: No UID found in attributes', 'error')
                return redirect(url_for('auth.login'))
            
            user = User.query.filter_by(uid=uid).first()
            
            # JIT Provisioning
            if not user:
                user = User(
                    uid=uid,
                    email=email,
                    name=first_name,
                    last_name=last_name,
                    role='dev', # Default role
                    date_creation=datetime.utcnow(),
                    interface='jupyterlab', # Default
                    auto_connect=False
                )
                db.session.add(user)
                db.session.commit()
                current_app.logger.info(f"JIT Provisioned user: {uid}")
            else:
                # Update attributes
                if email and user.email != email:
                    user.email = email
                if first_name and user.name != first_name:
                    user.name = first_name
                db.session.commit()
            
            login_user(user, remember=True)
            session['samlUserdata'] = attributes
            session['samlNameId'] = auth.get_nameid()
            session['samlSessionIndex'] = auth.get_session_index()
            
            # Auto-redirect check
            if user.auto_connect and user.machine and user.machine.url:
                flash(f'Auto-connecting to {user.machine.name}...', 'success')
                return redirect(url_for('main.redirect_to_jupyter'))

            # Redirect to originally requested page
            relay_state = request.form.get('RelayState')
            if relay_state and relay_state != OneLogin_Saml2_Utils.get_self_url(req) and not relay_state.endswith('/saml/login'):
                 return redirect(relay_state)

            return redirect(url_for('main.dashboard'))
        else:
            flash('SAML Authentication failed (not authenticated)', 'error')
    else:
        flash(f'SAML Error: {", ".join(errors)}', 'error')
        current_app.logger.error(f'SAML Errors: {errors}')
        if auth.get_last_error_reason():
             current_app.logger.error(f'SAML Reason: {auth.get_last_error_reason()}')
    
    return redirect(url_for('auth.login'))


@auth_bp.route('/saml/sls')
def saml_sls():
    """Handle SAML Single Logout (optional)."""
    req = prepare_flask_request(request)
    auth = OneLogin_Saml2_Auth(req, get_saml_settings())
    url = auth.process_slo()
    errors = auth.get_errors()
    if len(errors) == 0:
        logout_user()
        session.clear()
        if url:
            return redirect(url)
    else:
        flash(f'SLS Error: {", ".join(errors)}', 'error')
    return redirect(url_for('auth.login'))


# ============ ROUTES ============

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Login page and authentication handler."""
    if current_user.is_authenticated:
        # Check if user has auto-connect enabled
        if current_user.auto_connect and current_user.machine and current_user.machine.url:
            return redirect(url_for('main.redirect_to_jupyter'))
        return redirect(url_for('main.dashboard'))
    
    auth_mode = current_app.config.get('AUTH_MODE', 'dummy')
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        user = None
        
        if auth_mode == 'ldap':
            user = authenticate_ldap(username, password)
        elif auth_mode == 'dummy':
            user = authenticate_dummy(username, password)
        # SAML is handled via /saml/login routes, but we keep this for fallback/admin login
        
        if user:
            login_user(user, remember=True)
            session['jwt_token'] = generate_jwt_token(user)
            
            # Auto-redirect if enabled
            if user.auto_connect and user.machine and user.machine.url:
                flash(f'Auto-connecting to {user.machine.name}...', 'success')
                return redirect(url_for('main.redirect_to_jupyter'))
            
            next_page = request.args.get('next')
            if next_page and next_page.startswith('/'):
                return redirect(next_page)
            return redirect(url_for('main.dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html', auth_mode=auth_mode)


@auth_bp.route('/login/sso')
def login_sso():
    """Initiate SSO authentication."""
    auth_mode = current_app.config.get('AUTH_MODE')
    if auth_mode == 'saml':
         return redirect(url_for('auth.saml_login', next=request.args.get('next')))
    
    # Fallback or other SSO modes
    flash('SSO authentication not configured', 'warning')
    return redirect(url_for('auth.login'))


@auth_bp.route('/logout')
def logout():
    """Logout user."""
    # If SAML, we might want to trigger SLO?
    # For now, just local logout is safer unless SLO is fully tested
    logout_user()
    session.clear()
    resp = redirect(url_for('auth.login'))
    # Prevent caching of logout/login transition
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    resp.headers['Expires'] = '0'
    
    # Explicitly clear cookies
    resp.delete_cookie('session')
    resp.delete_cookie('remember_token')
    
    flash('You have been logged out', 'info')
    return resp


@auth_bp.route('/api/token')
@login_required
def get_token():
    """Get current user's JWT token."""
    token = session.get('jwt_token') or generate_jwt_token(current_user)
    return jsonify({'token': token})
