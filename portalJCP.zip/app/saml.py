
import os
from urllib.parse import urlparse

def get_saml_settings():
    """
    Load SAML settings from environment variables.
    This allows flexibility for production deployment.
    """
    base_url = os.environ.get('SAML_BASE_URL', 'http://localhost:5000')
    
    settings = {
        'strict': True,
        'debug': os.environ.get('FLASK_DEBUG', 'False').lower() == 'true',
        'sp': {
            'entityId': base_url + '/saml/metadata',
            'assertionConsumerService': {
                'url': base_url + '/saml/acs',
                'binding': 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST'
            },
            'singleLogoutService': {
                'url': base_url + '/saml/sls',
                'binding': 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect'
            },
            'NameIDFormat': 'urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified',
            'x509cert': '',
            'privateKey': ''
        },
        'idp': {
            'entityId': os.environ.get('SAML_IDP_ENTITY_ID', 'https://idp.example.com/metadata'),
            'singleSignOnService': {
                'url': os.environ.get('SAML_IDP_SSO_URL', 'https://idp.example.com/sso'),
                'binding': 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect'
            },
            'singleLogoutService': {
                'url': os.environ.get('SAML_IDP_SLS_URL', 'https://idp.example.com/sls'),
                'binding': 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect'
            },
            'x509cert': os.environ.get('SAML_IDP_CERT', '')
        }
    }
    return settings

def prepare_flask_request(request):
    """
    Convert Flask request to the dict structure required by python3-saml.
    """
    url_data = urlparse(request.url)
    return {
        'https': 'on' if request.scheme == 'https' else 'off',
        'http_host': request.host,
        'server_port': url_data.port or ('443' if request.scheme == 'https' else '80'),
        'script_name': request.path,
        'get_data': request.args.copy(),
        'post_data': request.form.copy() if request.method == 'POST' else {}
    }
