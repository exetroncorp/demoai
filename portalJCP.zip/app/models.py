from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()


class Entity(db.Model):
    """Entity/Organization table - represents different quotas/groups."""
    __tablename__ = 'Entities'
    
    identity = db.Column('Identity', db.Integer, primary_key=True, autoincrement=True)
    name = db.Column('Name', db.String(45), nullable=True)
    quota = db.Column('Quota', db.Integer, nullable=True)
    
    # Relationships
    machines = db.relationship('Machine', backref='entity', lazy='dynamic')
    users = db.relationship('User', backref='entity', lazy='dynamic')
    
    # Unique index on name
    __table_args__ = (
        db.Index('Name_UNIQUE', 'Name', unique=True),
    )
    
    def to_dict(self):
        return {
            'identity': self.identity,
            'name': self.name,
            'quota': self.quota
        }


class Machine(db.Model):
    """Machine/JupyterHub instance table."""
    __tablename__ = 'Machines'
    
    id_machine = db.Column('IdMachine', db.Integer, primary_key=True, autoincrement=True)
    url = db.Column('Url', db.String(200), nullable=True)
    ram_total = db.Column('Ram_total', db.Integer, nullable=True)
    ram_available = db.Column('Ram_available', db.Integer, nullable=True)
    cpu_total = db.Column('Cpu_total', db.Integer, nullable=True)
    cpu_available = db.Column('Cpu_available', db.Integer, nullable=True)
    storage_total = db.Column('Storage_total', db.Integer, nullable=True)
    storage_available = db.Column('Storage_available', db.Integer, nullable=True)
    cluster = db.Column('Cluster', db.String(45), nullable=True)
    namespace = db.Column('Namespace', db.String(45), nullable=True)
    name = db.Column('Name', db.String(45), nullable=True)
    identity = db.Column('Identity', db.Integer, db.ForeignKey('Entities.Identity'), nullable=True)
    
    # Relationships
    users = db.relationship('User', backref='machine', lazy='dynamic')
    
    # Indexes
    __table_args__ = (
        db.Index('MachinesEntity_idx', 'Identity'),
    )
    
    def to_dict(self):
        return {
            'id_machine': self.id_machine,
            'url': self.url,
            'ram_total': self.ram_total,
            'ram_available': self.ram_available,
            'cpu_total': self.cpu_total,
            'cpu_available': self.cpu_available,
            'storage_total': self.storage_total,
            'storage_available': self.storage_available,
            'cluster': self.cluster,
            'namespace': self.namespace,
            'name': self.name,
            'identity': self.identity
        }
    
    @property
    def resource_score(self):
        """Calculate a score based on available resources (higher is better)."""
        ram_score = (self.ram_available or 0) / max(self.ram_total or 1, 1) * 100
        cpu_score = (self.cpu_available or 0) / max(self.cpu_total or 1, 1) * 100
        storage_score = (self.storage_available or 0) / max(self.storage_total or 1, 1) * 100
        return (ram_score + cpu_score + storage_score) / 3


class User(db.Model, UserMixin):
    """User table - stores authenticated users and their assignments."""
    __tablename__ = 'Users'
    
    id_utilisateur = db.Column('IdUtilisateur', db.Integer, primary_key=True, autoincrement=True)
    uid = db.Column('UID', db.String(45), nullable=True, unique=True)
    name = db.Column('Name', db.String(45), nullable=True)
    last_name = db.Column('Last_name', db.String(45), nullable=True)
    email = db.Column('email', db.String(45), nullable=True)
    manager_uid = db.Column('Manager_UID', db.String(45), nullable=True)
    identity = db.Column('Identity', db.Integer, db.ForeignKey('Entities.Identity'), nullable=True)
    date_creation = db.Column('Date_creation', db.Date, nullable=True, default=datetime.utcnow)
    date_cleanup = db.Column('Date_cleanup', db.Date, nullable=True)
    cpu = db.Column('Cpu', db.Integer, nullable=True)
    ram = db.Column('Ram', db.Integer, nullable=True)
    stockage = db.Column('Stockage', db.Integer, nullable=True)
    role = db.Column('Role', db.String(45), nullable=True, default='dev')
    id_machine = db.Column('IdMachine', db.Integer, db.ForeignKey('Machines.IdMachine'), nullable=True)
    
    # New fields for Code-Server support
    interface = db.Column('Interface', db.String(20), nullable=True, default='jupyterlab')  # 'jupyterlab' or 'codeserver'
    auto_connect = db.Column('AutoConnect', db.Boolean, nullable=True, default=False)
    
    # Password hash for dummy auth mode
    password_hash = db.Column('PasswordHash', db.String(255), nullable=True)
    
    # Indexes
    __table_args__ = (
        db.Index('UsersMachines_idx', 'IdMachine'),
        db.Index('UsersEntity_idx', 'Identity'),
    )
    
    def get_id(self):
        """Required by Flask-Login."""
        return str(self.id_utilisateur)
    
    @property
    def is_admin(self):
        return self.role == 'admin'
    
    @property
    def full_name(self):
        parts = [self.name, self.last_name]
        return ' '.join(p for p in parts if p) or self.uid
    
    def to_dict(self):
        return {
            'id_utilisateur': self.id_utilisateur,
            'uid': self.uid,
            'name': self.name,
            'last_name': self.last_name,
            'email': self.email,
            'manager_uid': self.manager_uid,
            'identity': self.identity,
            'date_creation': self.date_creation.isoformat() if self.date_creation else None,
            'date_cleanup': self.date_cleanup.isoformat() if self.date_cleanup else None,
            'cpu': self.cpu,
            'ram': self.ram,
            'stockage': self.stockage,
            'role': self.role,
            'interface': self.interface,
            'auto_connect': self.auto_connect,
            'id_machine': self.id_machine,
            'machine_url': self.machine.url if self.machine else None
        }
