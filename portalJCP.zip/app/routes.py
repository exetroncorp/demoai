"""Main routes for the JupyterHub Management Portal."""
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, jsonify, flash, current_app
from flask_login import login_required, current_user

from models import db, Entity, Machine, User
from auth import admin_required, hash_password
from balancer import get_balancer
from jupyterhub_client import get_jupyterhub_client

main_bp = Blueprint('main', __name__)


# ============ PAGE ROUTES ============

@main_bp.route('/')
def index():
    """Landing page - redirect to login or dashboard."""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('auth.login'))


@main_bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard page."""
    return render_template('dashboard.html', user=current_user)


@main_bp.route('/admin')
@admin_required
def admin():
    """Admin panel page."""
    users = User.query.all()
    machines = Machine.query.all()
    entities = Entity.query.all()
    return render_template('admin.html', users=users, machines=machines, entities=entities)


@main_bp.route('/redirect-to-jupyter')
@login_required
def redirect_to_jupyter():
    """Redirect user to their assigned JupyterHub instance."""
    if not current_user.machine:
        flash('No JupyterHub instance assigned. Please contact an administrator.', 'warning')
        return redirect(url_for('main.dashboard'))
    
    # Build redirect URL with token
    base_url = current_user.machine.url.rstrip('/')
    if not base_url:
        flash('JupyterHub URL not configured for your instance.', 'error')
        return redirect(url_for('main.dashboard'))
        
    target_url = base_url
    
    # Check interface preference
    if current_user.interface == 'codeserver':
        # If it's a VS Code Mock (e.g. mock server), just go there
        if 'vscode.dev' in base_url or 'github.dev' in base_url:
            target_url = base_url
            return redirect(target_url)
        else:
            # Code-Server Container - use auto-submit form for authentication
            # Ensure trailing slash for the target URL so it hits /login correctly if needed,
            # but template appends 'login'. If base_url is http://localhost:8080/, target is http://localhost:8080/
            target_url = base_url.rstrip('/') + '/'
            return render_template('proxy_login.html', target_url=target_url, password='password')
    else:
        # Default to JupyterLab
        # If it's a binder/jupyter demo, don't append /lab if not needed
        if 'mybinder' not in base_url and 'colab' not in base_url and 'jupyter.org' not in base_url:
             target_url = f"{base_url}/user/{current_user.uid}/lab"
    
    return redirect(target_url)


# ============ API ROUTES ============

@main_bp.route('/api/users', methods=['GET'])
@admin_required
def api_get_users():
    """Get all users."""
    users = User.query.all()
    return jsonify([u.to_dict() for u in users])


@main_bp.route('/api/users', methods=['POST'])
@admin_required
def api_create_user():
    """Create a new user."""
    data = request.get_json()
    
    if not data.get('uid'):
        return jsonify({'error': 'UID is required'}), 400
    
    if User.query.filter_by(uid=data['uid']).first():
        return jsonify({'error': 'User with this UID already exists'}), 400
    
    user = User(
        uid=data['uid'],
        name=data.get('name'),
        last_name=data.get('last_name'),
        email=data.get('email'),
        manager_uid=data.get('manager_uid'),
        identity=data.get('identity'),
        role=data.get('role', 'dev'),
        interface=data.get('interface', 'jupyterlab'),
        auto_connect=data.get('auto_connect', False),
        date_creation=datetime.utcnow()
    )
    
    # Set password if provided (for dummy auth)
    if data.get('password'):
        user.password_hash = hash_password(data['password'])
    
    # Auto-assign to machine if requested
    if data.get('auto_assign', True):
        balancer = get_balancer(user.identity)
        balancer.assign_user(
            user,
            required_cpu=data.get('cpu', 1),
            required_ram=data.get('ram', 1024),
            required_storage=data.get('storage', 10)
        )
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify(user.to_dict()), 201


@main_bp.route('/api/users/<int:user_id>', methods=['GET'])
@admin_required
def api_get_user(user_id):
    """Get a specific user."""
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())


@main_bp.route('/api/users/<int:user_id>', methods=['PUT'])
@admin_required
def api_update_user(user_id):
    """Update a user."""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if 'name' in data:
        user.name = data['name']
    if 'last_name' in data:
        user.last_name = data['last_name']
    if 'email' in data:
        user.email = data['email']
    if 'manager_uid' in data:
        user.manager_uid = data['manager_uid']
    if 'identity' in data:
        user.identity = data['identity']
    if 'role' in data:
        user.role = data['role']
    if 'interface' in data:
        user.interface = data['interface']
    if 'auto_connect' in data:
        user.auto_connect = data['auto_connect']
    if 'id_machine' in data:
        user.id_machine = data['id_machine']
    if 'password' in data and data['password']:
        user.password_hash = hash_password(data['password'])
    
    db.session.commit()
    return jsonify(user.to_dict())


@main_bp.route('/api/users/<int:user_id>', methods=['DELETE'])
@admin_required
def api_delete_user(user_id):
    """Delete a user."""
    user = User.query.get_or_404(user_id)
    
    # Release resources before deleting
    balancer = get_balancer()
    balancer.release_user(user)
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': 'User deleted'})


@main_bp.route('/api/users/<int:user_id>/assign', methods=['POST'])
@admin_required
def api_assign_user(user_id):
    """Assign a user to a machine using smart balancer."""
    user = User.query.get_or_404(user_id)
    data = request.get_json() or {}
    
    balancer = get_balancer(user.identity)
    machine = balancer.assign_user(
        user,
        required_cpu=data.get('cpu', 1),
        required_ram=data.get('ram', 1024),
        required_storage=data.get('storage', 10)
    )
    
    if machine:
        return jsonify({'message': 'User assigned', 'machine': machine.to_dict()})
    return jsonify({'error': 'No suitable machine found'}), 400


# ============ MACHINE API ============

@main_bp.route('/api/machines', methods=['GET'])
@admin_required
def api_get_machines():
    """Get all machines."""
    machines = Machine.query.all()
    return jsonify([m.to_dict() for m in machines])


@main_bp.route('/api/machines', methods=['POST'])
@admin_required
def api_create_machine():
    """Create a new machine."""
    data = request.get_json()
    
    machine = Machine(
        url=data.get('url'),
        name=data.get('name'),
        cluster=data.get('cluster'),
        namespace=data.get('namespace'),
        ram_total=data.get('ram_total', 0),
        ram_available=data.get('ram_available', data.get('ram_total', 0)),
        cpu_total=data.get('cpu_total', 0),
        cpu_available=data.get('cpu_available', data.get('cpu_total', 0)),
        storage_total=data.get('storage_total', 0),
        storage_available=data.get('storage_available', data.get('storage_total', 0)),
        identity=data.get('identity')
    )
    
    db.session.add(machine)
    db.session.commit()
    
    return jsonify(machine.to_dict()), 201


@main_bp.route('/api/machines/<int:machine_id>', methods=['PUT'])
@admin_required
def api_update_machine(machine_id):
    """Update a machine."""
    machine = Machine.query.get_or_404(machine_id)
    data = request.get_json()
    
    for field in ['url', 'name', 'cluster', 'namespace', 'ram_total', 'ram_available',
                  'cpu_total', 'cpu_available', 'storage_total', 'storage_available', 'identity']:
        if field in data:
            setattr(machine, field, data[field])
    
    db.session.commit()
    return jsonify(machine.to_dict())


@main_bp.route('/api/machines/<int:machine_id>', methods=['DELETE'])
@admin_required
def api_delete_machine(machine_id):
    """Delete a machine."""
    machine = Machine.query.get_or_404(machine_id)
    
    # Check if any users are assigned
    if machine.users.count() > 0:
        return jsonify({'error': 'Cannot delete machine with assigned users'}), 400
    
    db.session.delete(machine)
    db.session.commit()
    
    return jsonify({'message': 'Machine deleted'})


# ============ ENTITY API ============

@main_bp.route('/api/entities', methods=['GET'])
@admin_required
def api_get_entities():
    """Get all entities."""
    entities = Entity.query.all()
    return jsonify([e.to_dict() for e in entities])


@main_bp.route('/api/entities', methods=['POST'])
@admin_required
def api_create_entity():
    """Create a new entity."""
    data = request.get_json()
    
    entity = Entity(
        name=data.get('name'),
        quota=data.get('quota')
    )
    
    db.session.add(entity)
    db.session.commit()
    
    return jsonify(entity.to_dict()), 201
