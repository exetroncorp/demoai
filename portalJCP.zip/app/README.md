# JupyterHub Management Portal

A centralized Flask application for managing multiple JupyterHub instances.

## Quick Start

```bash
docker-compose up --build
```

Access at: http://localhost:5000

## Features

- LDAP/SAML/Dummy authentication
- Smart machine load balancing
- User and machine management
- JupyterHub API integration

## Default Credentials (Dev Mode)

- Admin: `admin` / `admin123`
- User: `user` / `user123`
