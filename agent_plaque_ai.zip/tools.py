import easyocr
import sqlite3
import smtplib
from email.message import EmailMessage

def tool_extract_plate(image_path):
    reader = easyocr.Reader(['fr'])
    result = reader.readtext(image_path)
    for _, text, _ in result:
        if len(text) >= 6:
            return text.strip()
    return "UNKNOWN"

def tool_lookup_owner(plate):
    conn = sqlite3.connect("owners.db")
    cur = conn.cursor()
    cur.execute("SELECT name, email FROM owners WHERE plate = ?", (plate,))
    result = cur.fetchone()
    conn.close()
    return {"name": result[0], "email": result[1]} if result else None

def tool_send_email(to_address):
    msg = EmailMessage()
    msg.set_content("Avertissement : votre véhicule est mal garé.")
    msg["Subject"] = "Avertissement - Plaque détectée"
    msg["From"] = "noreply@system.com"
    msg["To"] = to_address

    with smtplib.SMTP("smtp.example.com") as server:
        server.send_message(msg)