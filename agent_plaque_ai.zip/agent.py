from tools import tool_extract_plate, tool_lookup_owner, tool_send_email

def agent_main(image_path):
    plate = tool_extract_plate(image_path)
    if plate == "UNKNOWN":
        print("Plaque non détectée.")
        return

    print(f"Plaque détectée : {plate}")
    owner = tool_lookup_owner(plate)
    if not owner:
        print(f"Plaque {plate} inconnue dans la base de données.")
        return

    tool_send_email(owner["email"])
    print(f"Email envoyé à {owner['name']} ({owner['email']}).")