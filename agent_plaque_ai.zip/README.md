# Agent IA - Détection de Plaque et Notification

## Prérequis
- Python 3.8+
- pip

## Installation
```bash
pip install -r requirements.txt
```

## Base de données
Une base `owners.db` est déjà fournie avec un exemple.
Pour ajouter d'autres personnes :
```sql
INSERT INTO owners (name, plate, email) VALUES ("Jean Martin", "XY789ZT", "jean@example.com");
```

## Utilisation
Place une image dans le dossier courant nommée `plaque_test.jpg` (ou modifie `run.py`)
```bash
python run.py
```

## Fonctionnement
1. L'image est analysée pour extraire une plaque via OCR (EasyOCR)
2. La plaque est utilisée pour rechercher un propriétaire dans SQLite
3. Un email d'avertissement est envoyé

## Note
Le serveur SMTP utilisé est fictif. Modifie `tool_send_email` pour pointer vers un vrai serveur (Gmail, Mailtrap, etc.)