from agent import agent_main

# Remplacer par le chemin de l'image test
image_path = "plaque_test.jpg"

agent_main(image_path)