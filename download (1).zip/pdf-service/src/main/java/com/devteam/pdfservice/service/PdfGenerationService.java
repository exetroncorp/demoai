package com.devteam.pdfservice.service;

import com.devteam.pdfservice.model.Developer;
import com.devteam.pdfservice.model.Team;
import com.devteam.pdfservice.model.Project;
import com.devteam.pdfservice.model.Task;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
public class PdfGenerationService {

    private static final DeviceRgb HEADER_BACKGROUND_COLOR = new DeviceRgb(70, 107, 255); // Primary color
    private static final DeviceRgb HEADER_TEXT_COLOR = new DeviceRgb(255, 255, 255); // White
    private static final DeviceRgb TITLE_COLOR = new DeviceRgb(42, 75, 208); // Primary dark color

    /**
     * Generates a PDF document containing a list of developers
     *
     * @param developers the list of developers to include in the PDF
     * @return the PDF document as a byte array
     * @throws IOException if there's an error generating the PDF
     */
    public byte[] generateDeveloperListPdf(List<Developer> developers) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf, PageSize.A4);

        try {
            // Set up fonts
            PdfFont titleFont = PdfFontFactory.createFont();
            PdfFont regularFont = PdfFontFactory.createFont();

            // Add title
            Paragraph title = new Paragraph("Developer List")
                    .setFont(titleFont)
                    .setFontSize(24)
                    .setFontColor(TITLE_COLOR)
                    .setBold()
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(title);

            // Add generation timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            Paragraph timestampParagraph = new Paragraph("Generated on: " + timestamp)
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.RIGHT)
                    .setMarginBottom(20);
            document.add(timestampParagraph);

            // Create table
            Table table = new Table(UnitValue.createPercentArray(new float[]{1, 2, 2, 3, 2, 2}))
                    .useAllAvailableWidth();

            // Add table headers
            addTableHeader(table, new String[]{"ID", "Name", "Role", "Email", "Skill Level", "Team"});

            // Add table rows
            for (Developer developer : developers) {
                addDeveloperRow(table, developer);
            }

            document.add(table);

            // Add footer
            Paragraph footer = new Paragraph("Dev Team Manager - Developer List Report")
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(20);
            document.add(footer);

            document.close();
            return outputStream.toByteArray();
        } catch (Exception e) {
            try {
                if (document != null) {
                    document.close();
                }
            } catch (Exception closeException) {
                // Already closed or other issue, ignore
            }
            throw e;
        }
    }

    private void addTableHeader(Table table, String[] headers) {
        for (String header : headers) {
            Cell cell = new Cell()
                    .add(new Paragraph(header).setBold())
                    .setBackgroundColor(HEADER_BACKGROUND_COLOR)
                    .setFontColor(HEADER_TEXT_COLOR)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setPadding(5);
            table.addHeaderCell(cell);
        }
    }

    private void addDeveloperRow(Table table, Developer developer) {
        table.addCell(new Cell().add(new Paragraph(developer.getId().toString())));
        table.addCell(new Cell().add(new Paragraph(developer.getName())));
        table.addCell(new Cell().add(new Paragraph(developer.getRole() != null ? developer.getRole() : "")));
        table.addCell(new Cell().add(new Paragraph(developer.getEmail() != null ? developer.getEmail() : "")));
        table.addCell(new Cell().add(new Paragraph(developer.getSkillLevel() != null ? developer.getSkillLevel() : "")));
        table.addCell(new Cell().add(new Paragraph(developer.getTeam() != null ? developer.getTeam().getName() : "Not Assigned")));
    }

    /**
     * Generates a PDF document containing a list of teams
     *
     * @param teams the list of teams to include in the PDF
     * @return the PDF document as a byte array
     * @throws IOException if there's an error generating the PDF
     */
    public byte[] generateTeamListPdf(List<Team> teams) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf, PageSize.A4);

        try {
            // Set up fonts
            PdfFont titleFont = PdfFontFactory.createFont();
            PdfFont regularFont = PdfFontFactory.createFont();

            // Add title
            Paragraph title = new Paragraph("Team List")
                    .setFont(titleFont)
                    .setFontSize(24)
                    .setFontColor(TITLE_COLOR)
                    .setBold()
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(title);

            // Add generation timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            Paragraph timestampParagraph = new Paragraph("Generated on: " + timestamp)
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.RIGHT)
                    .setMarginBottom(20);
            document.add(timestampParagraph);

            // Create table
            Table table = new Table(UnitValue.createPercentArray(new float[]{1, 2, 2, 2}))
                    .useAllAvailableWidth();

            // Add table headers
            addTableHeader(table, new String[]{"ID", "Name", "Department", "Members"});

            // Add table rows
            for (Team team : teams) {
                addTeamRow(table, team);
            }

            document.add(table);

            // Add footer
            Paragraph footer = new Paragraph("Dev Team Manager - Team List Report")
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(20);
            document.add(footer);

            document.close();
            return outputStream.toByteArray();
        } catch (Exception e) {
            try {
                if (document != null) {
                    document.close();
                }
            } catch (Exception closeException) {
                // Already closed or other issue, ignore
            }
            throw e;
        }
    }

    private void addTeamRow(Table table, Team team) {
        table.addCell(new Cell().add(new Paragraph(team.getId().toString())));
        table.addCell(new Cell().add(new Paragraph(team.getName())));
        table.addCell(new Cell().add(new Paragraph(team.getDepartment() != null ? team.getDepartment() : "Not specified")));

        // Count of developers would be added here if available
        table.addCell(new Cell().add(new Paragraph("N/A")));
    }

    /**
     * Generates a PDF document containing a list of projects
     *
     * @param projects the list of projects to include in the PDF
     * @return the PDF document as a byte array
     * @throws IOException if there's an error generating the PDF
     */
    public byte[] generateProjectListPdf(List<Project> projects) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf, PageSize.A4);

        try {
            // Set up fonts
            PdfFont titleFont = PdfFontFactory.createFont();
            PdfFont regularFont = PdfFontFactory.createFont();

            // Add title
            Paragraph title = new Paragraph("Project List")
                    .setFont(titleFont)
                    .setFontSize(24)
                    .setFontColor(TITLE_COLOR)
                    .setBold()
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(title);

            // Add generation timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            Paragraph timestampParagraph = new Paragraph("Generated on: " + timestamp)
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.RIGHT)
                    .setMarginBottom(20);
            document.add(timestampParagraph);

            // Create table
            Table table = new Table(UnitValue.createPercentArray(new float[]{1, 2, 3, 2, 2, 2}))
                    .useAllAvailableWidth();

            // Add table headers
            addTableHeader(table, new String[]{"ID", "Name", "Description", "Start Date", "End Date", "Team"});

            // Add table rows
            for (Project project : projects) {
                addProjectRow(table, project);
            }

            document.add(table);

            // Add footer
            Paragraph footer = new Paragraph("Dev Team Manager - Project List Report")
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(20);
            document.add(footer);

            document.close();
            return outputStream.toByteArray();
        } catch (Exception e) {
            try {
                if (document != null) {
                    document.close();
                }
            } catch (Exception closeException) {
                // Already closed or other issue, ignore
            }
            throw e;
        }
    }

    private void addProjectRow(Table table, Project project) {
        table.addCell(new Cell().add(new Paragraph(project.getId().toString())));
        table.addCell(new Cell().add(new Paragraph(project.getName())));
        table.addCell(new Cell().add(new Paragraph(project.getDescription() != null ? project.getDescription() : "No description")));

        String startDate = project.getStartDate() != null ? project.getStartDate().toString() : "Not set";
        String endDate = project.getEndDate() != null ? project.getEndDate().toString() : "Not set";

        table.addCell(new Cell().add(new Paragraph(startDate)));
        table.addCell(new Cell().add(new Paragraph(endDate)));

        String teamName = "Not Assigned";
        if (project.getTeam() != null) {
            teamName = project.getTeam().getName();
        }
        table.addCell(new Cell().add(new Paragraph(teamName)));
    }

    /**
     * Generates a PDF document containing a list of tasks
     *
     * @param tasks the list of tasks to include in the PDF
     * @return the PDF document as a byte array
     * @throws IOException if there's an error generating the PDF
     */
    public byte[] generateTaskListPdf(List<Task> tasks) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf, PageSize.A4);

        try {
            // Set up fonts
            PdfFont titleFont = PdfFontFactory.createFont();
            PdfFont regularFont = PdfFontFactory.createFont();

            // Add title
            Paragraph title = new Paragraph("Task List")
                    .setFont(titleFont)
                    .setFontSize(24)
                    .setFontColor(TITLE_COLOR)
                    .setBold()
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(title);

            // Add generation timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            Paragraph timestampParagraph = new Paragraph("Generated on: " + timestamp)
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.RIGHT)
                    .setMarginBottom(20);
            document.add(timestampParagraph);

            // Create table
            Table table = new Table(UnitValue.createPercentArray(new float[]{1, 2, 3, 1.5f, 1.5f, 2, 2}))
                    .useAllAvailableWidth();

            // Add table headers
            addTableHeader(table, new String[]{"ID", "Title", "Description", "Status", "Due Date", "Project", "Assignee"});

            // Add table rows
            for (Task task : tasks) {
                addTaskRow(table, task);
            }

            document.add(table);

            // Add footer
            Paragraph footer = new Paragraph("Dev Team Manager - Task List Report")
                    .setFont(regularFont)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(20);
            document.add(footer);

            document.close();
            return outputStream.toByteArray();
        } catch (Exception e) {
            try {
                if (document != null) {
                    document.close();
                }
            } catch (Exception closeException) {
                // Already closed or other issue, ignore
            }
            throw e;
        }
    }

    private void addTaskRow(Table table, Task task) {
        table.addCell(new Cell().add(new Paragraph(task.getId().toString())));
        table.addCell(new Cell().add(new Paragraph(task.getTitle())));
        table.addCell(new Cell().add(new Paragraph(task.getDescription() != null ? task.getDescription() : "No description")));
        table.addCell(new Cell().add(new Paragraph(task.getStatus())));

        String dueDate = task.getDueDate() != null ? task.getDueDate().toString() : "Not set";
        table.addCell(new Cell().add(new Paragraph(dueDate)));

        String projectName = "Not Assigned";
        if (task.getProject() != null) {
            projectName = task.getProject().getName();
        }
        table.addCell(new Cell().add(new Paragraph(projectName)));

        String assigneeName = "Unassigned";
        if (task.getAssignee() != null) {
            assigneeName = task.getAssignee().getName();
        }
        table.addCell(new Cell().add(new Paragraph(assigneeName)));
    }
}
