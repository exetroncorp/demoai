package com.devteam.pdfservice.controller;

import com.devteam.pdfservice.model.Developer;
import com.devteam.pdfservice.model.Team;
import com.devteam.pdfservice.model.Project;
import com.devteam.pdfservice.model.Task;
import com.devteam.pdfservice.service.PdfGenerationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/pdf")
public class PdfController {

    private final PdfGenerationService pdfGenerationService;
    private final RestTemplate restTemplate;

    @Autowired
    public PdfController(PdfGenerationService pdfGenerationService, RestTemplate restTemplate) {
        this.pdfGenerationService = pdfGenerationService;
        this.restTemplate = restTemplate;
    }

    /**
     * Generates a PDF containing a list of all developers
     *
     * @return the PDF document as a response entity
     */
    @GetMapping("/developers")
    public ResponseEntity<byte[]> generateDeveloperListPdf() {
        try {
            // Fetch developers from the core service
            Developer[] developers = restTemplate.getForObject("http://localhost:8080/api/developers", Developer[].class);

            if (developers == null || developers.length == 0) {
                return ResponseEntity.noContent().build();
            }

            byte[] pdfBytes = pdfGenerationService.generateDeveloperListPdf(Arrays.asList(developers));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "developers.pdf");

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Generates a PDF containing a list of developers in a specific team
     *
     * @param teamId the ID of the team
     * @return the PDF document as a response entity
     */
    @GetMapping("/teams/{teamId}/developers")
    public ResponseEntity<byte[]> generateTeamDeveloperListPdf(@PathVariable Long teamId) {
        try {
            // Fetch developers from the core service for a specific team
            Developer[] developers = restTemplate.getForObject(
                    "http://localhost:8080/api/teams/{teamId}/developers",
                    Developer[].class,
                    teamId
            );

            if (developers == null || developers.length == 0) {
                return ResponseEntity.noContent().build();
            }

            byte[] pdfBytes = pdfGenerationService.generateDeveloperListPdf(Arrays.asList(developers));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "team_" + teamId + "_developers.pdf");

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Generates a PDF containing a list of all teams
     *
     * @return the PDF document as a response entity
     */
    @GetMapping("/teams")
    public ResponseEntity<byte[]> generateTeamListPdf() {
        try {
            // Fetch teams from the core service
            Team[] teams = restTemplate.getForObject("http://localhost:8080/api/teams", Team[].class);

            if (teams == null || teams.length == 0) {
                return ResponseEntity.noContent().build();
            }

            byte[] pdfBytes = pdfGenerationService.generateTeamListPdf(Arrays.asList(teams));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "teams.pdf");

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Generates a PDF containing a list of all projects
     *
     * @return the PDF document as a response entity
     */
    @GetMapping("/projects")
    public ResponseEntity<byte[]> generateProjectListPdf() {
        try {
            // Fetch projects from the core service
            Project[] projects = restTemplate.getForObject("http://localhost:8080/api/projects", Project[].class);

            if (projects == null || projects.length == 0) {
                return ResponseEntity.noContent().build();
            }

            byte[] pdfBytes = pdfGenerationService.generateProjectListPdf(Arrays.asList(projects));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "projects.pdf");

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Generates a PDF containing a list of projects for a specific team
     *
     * @param teamId the ID of the team
     * @return the PDF document as a response entity
     */
    @GetMapping("/teams/{teamId}/projects")
    public ResponseEntity<byte[]> generateTeamProjectListPdf(@PathVariable Long teamId) {
        try {
            // Fetch projects from the core service for a specific team
            Project[] projects = restTemplate.getForObject(
                    "http://localhost:8080/api/teams/{teamId}/projects",
                    Project[].class,
                    teamId
            );

            if (projects == null || projects.length == 0) {
                return ResponseEntity.noContent().build();
            }

            byte[] pdfBytes = pdfGenerationService.generateProjectListPdf(Arrays.asList(projects));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "team_" + teamId + "_projects.pdf");

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Generates a PDF containing a list of all tasks
     *
     * @return the PDF document as a response entity
     */
    @GetMapping("/tasks")
    public ResponseEntity<byte[]> generateTaskListPdf() {
        try {
            // Fetch tasks from the core service
            Task[] tasks = restTemplate.getForObject("http://localhost:8080/api/tasks", Task[].class);

            if (tasks == null || tasks.length == 0) {
                return ResponseEntity.noContent().build();
            }

            byte[] pdfBytes = pdfGenerationService.generateTaskListPdf(Arrays.asList(tasks));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "tasks.pdf");

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Generates a PDF containing a list of tasks for a specific project
     *
     * @param projectId the ID of the project
     * @return the PDF document as a response entity
     */
    @GetMapping("/projects/{projectId}/tasks")
    public ResponseEntity<byte[]> generateProjectTaskListPdf(@PathVariable Long projectId) {
        try {
            // Fetch tasks from the core service for a specific project
            Task[] tasks = restTemplate.getForObject(
                    "http://localhost:8080/api/projects/{projectId}/tasks",
                    Task[].class,
                    projectId
            );

            if (tasks == null || tasks.length == 0) {
                return ResponseEntity.noContent().build();
            }

            byte[] pdfBytes = pdfGenerationService.generateTaskListPdf(Arrays.asList(tasks));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "project_" + projectId + "_tasks.pdf");

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
