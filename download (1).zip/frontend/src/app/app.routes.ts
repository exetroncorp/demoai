import { Routes } from '@angular/router';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { TeamListComponent } from './features/teams/team-list/team-list.component';
import { TeamFormComponent } from './features/teams/team-form/team-form.component';
import { TeamDetailComponent } from './features/teams/team-detail/team-detail.component';
import { DeveloperListComponent } from './features/developers/developer-list/developer-list.component';
import { DeveloperFormComponent } from './features/developers/developer-form/developer-form.component';
import { DeveloperDetailComponent } from './features/developers/developer-detail/developer-detail.component';
import { ProjectListComponent } from './features/projects/project-list/project-list.component';
import { ProjectFormComponent } from './features/projects/project-form/project-form.component';
import { ProjectDetailComponent } from './features/projects/project-detail/project-detail.component';
import { TaskListComponent } from './features/tasks/task-list/task-list.component';
import { TaskFormComponent } from './features/tasks/task-form/task-form.component';
import { TaskDetailComponent } from './features/tasks/task-detail/task-detail.component';
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { ProfileComponent } from './features/auth/profile/profile.component';
import { TestLoginComponent } from './features/auth/test-login/test-login.component';
import { SimpleLoginComponent } from './features/auth/simple-login/simple-login.component';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: '', component: DashboardComponent, canActivate: [authGuard] },
  { path: 'teams', component: TeamListComponent, canActivate: [authGuard] },
  { path: 'teams/new', component: TeamFormComponent, canActivate: [authGuard] },
  { path: 'teams/:id', component: TeamDetailComponent, canActivate: [authGuard] },
  { path: 'teams/:id/edit', component: TeamFormComponent, canActivate: [authGuard] },
  { path: 'developers', component: DeveloperListComponent, canActivate: [authGuard] },
  { path: 'developers/new', component: DeveloperFormComponent, canActivate: [authGuard] },
  { path: 'developers/:id', component: DeveloperDetailComponent, canActivate: [authGuard] },
  { path: 'developers/:id/edit', component: DeveloperFormComponent, canActivate: [authGuard] },
  { path: 'projects', component: ProjectListComponent, canActivate: [authGuard] },
  { path: 'projects/new', component: ProjectFormComponent, canActivate: [authGuard] },
  { path: 'projects/:id', component: ProjectDetailComponent, canActivate: [authGuard] },
  { path: 'projects/:id/edit', component: ProjectFormComponent, canActivate: [authGuard] },
  { path: 'tasks', component: TaskListComponent, canActivate: [authGuard] },
  { path: 'tasks/new', component: TaskFormComponent, canActivate: [authGuard] },
  { path: 'tasks/:id', component: TaskDetailComponent, canActivate: [authGuard] },
  { path: 'tasks/:id/edit', component: TaskFormComponent, canActivate: [authGuard] },
  { path: 'login', component: SimpleLoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
  { path: 'test-login', component: TestLoginComponent },
  { path: '**', redirectTo: '' }
];
