import { Component, OnInit, OnDestroy } from '@angular/core';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ThemeSwitcherComponent } from '../../components/theme-switcher/theme-switcher.component';
import { TokenStorageService } from '../../../core/services/token-storage.service';
import { AuthEventService } from '../../../core/services/auth-event.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, ThemeSwitcherComponent, CommonModule],
  template: `
    <header class="header">
      <div class="container">
        <div class="logo">
          <a routerLink="/" class="logo-link">
            <span class="logo-icon">👨‍💻</span>
            <h1>Dev Team Manager</h1>
          </a>
        </div>
        <nav class="navigation" *ngIf="isLoggedIn">
          <ul>
            <li><a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">Dashboard</a></li>
            <li><a routerLink="/teams" routerLinkActive="active">Teams</a></li>
            <li><a routerLink="/developers" routerLinkActive="active">Developers</a></li>
            <li><a routerLink="/projects" routerLinkActive="active">Projects</a></li>
            <li><a routerLink="/tasks" routerLinkActive="active">Tasks</a></li>
          </ul>
        </nav>
        <div class="header-actions">
          <div class="auth-actions" *ngIf="!isLoggedIn">
            <a routerLink="/login" class="auth-button login-button">Login</a>
            <a routerLink="/register" class="auth-button register-button">Sign Up</a>
          </div>
          <div class="auth-actions" *ngIf="isLoggedIn">
            <a routerLink="/profile" class="auth-button profile-button">{{ username }}</a>
            <button class="auth-button logout-button" (click)="logout()">
              <span class="logout-icon">🚪</span> Logout
            </button>
          </div>
          <app-theme-switcher></app-theme-switcher>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .header {
      background-color: var(--primary);
      color: white;
      padding: 1rem 0;
      box-shadow: var(--shadow);
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1rem;
    }

    .header-actions {
      display: flex;
      align-items: center;
      margin-left: 1.5rem;
      gap: 1rem;
    }

    .auth-actions {
      display: flex;
      gap: 0.75rem;
    }

    .auth-button {
      padding: 0.5rem 1rem;
      border-radius: var(--radius);
      font-weight: 500;
      text-decoration: none;
      transition: var(--transition);
      font-size: 0.9rem;
    }

    .login-button {
      background-color: transparent;
      color: white;
      border: 1px solid rgba(255, 255, 255, 0.5);
    }

    .login-button:hover {
      background-color: rgba(255, 255, 255, 0.1);
      border-color: white;
      text-decoration: none;
    }

    .register-button {
      background-color: var(--secondary);
      color: var(--dark);
      border: none;
    }

    .register-button:hover {
      background-color: var(--secondary-dark);
      transform: translateY(-2px);
      text-decoration: none;
    }

    .logout-button {
      background-color: #e74c3c;
      color: white;
      border: none;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      cursor: pointer;
    }

    .logout-button:hover {
      background-color: #c0392b;
      transform: translateY(-2px);
      text-decoration: none;
    }

    .logout-icon {
      font-size: 1.1rem;
    }

    .profile-button {
      background-color: rgba(255, 255, 255, 0.2);
      color: white;
      border: none;
    }

    .profile-button:hover {
      background-color: rgba(255, 255, 255, 0.3);
      transform: translateY(-2px);
      text-decoration: none;
    }

    .logo {
      display: flex;
      align-items: center;
    }

    .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      color: white;
      transition: var(--transition);
    }

    .logo-link:hover {
      transform: scale(1.05);
      text-decoration: none;
    }

    .logo-icon {
      font-size: 1.8rem;
      margin-right: 0.75rem;
    }

    .logo h1 {
      margin: 0;
      font-size: 1.5rem;
      font-weight: 700;
      color: white;
      letter-spacing: 0.5px;
    }

    .navigation ul {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .navigation li {
      margin-left: 1.5rem;
      position: relative;
    }

    .navigation a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      padding: 0.5rem 0;
      transition: var(--transition);
      position: relative;
    }

    .navigation a::after {
      content: '';
      position: absolute;
      bottom: -2px;
      left: 0;
      width: 0;
      height: 3px;
      background-color: var(--secondary);
      transition: var(--transition);
      border-radius: 3px;
    }

    .navigation a:hover::after,
    .navigation a.active::after {
      width: 100%;
    }

    .navigation a:hover, .navigation a.active {
      color: white;
    }

    @media (max-width: 768px) {
      .container {
        flex-wrap: wrap;
      }

      .logo h1 {
        font-size: 1.2rem;
      }

      .navigation {
        order: 3;
        width: 100%;
        margin-top: 1rem;
      }

      .navigation ul {
        justify-content: space-between;
      }

      .navigation li {
        margin-left: 0;
      }

      .header-actions {
        margin-left: 1rem;
      }
    }
  `]
})
export class HeaderComponent implements OnInit, OnDestroy {
  isLoggedIn = false;
  username?: string;
  private authSubscription: Subscription;

  constructor(
    private tokenStorageService: TokenStorageService,
    private authEventService: AuthEventService,
    private router: Router
  ) {
    // Subscribe to authentication events
    this.authSubscription = this.authEventService.authChange$.subscribe(isLoggedIn => {
      this.isLoggedIn = isLoggedIn;
      if (isLoggedIn) {
        const user = this.tokenStorageService.getUser();
        this.username = user.username;
      } else {
        this.username = undefined;
      }
    });
  }

  ngOnInit(): void {
    this.updateLoginStatus();
  }

  updateLoginStatus(): void {
    this.isLoggedIn = !!this.tokenStorageService.getToken();
    if (this.isLoggedIn) {
      const user = this.tokenStorageService.getUser();
      this.username = user.username;
    }
  }

  logout(): void {
    this.tokenStorageService.signOut();
    this.router.navigate(['/login']);
    // Show a confirmation message
    setTimeout(() => {
      alert('You have been successfully logged out.');
    }, 100);
  }

  ngOnDestroy(): void {
    // Unsubscribe to prevent memory leaks
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }
}
