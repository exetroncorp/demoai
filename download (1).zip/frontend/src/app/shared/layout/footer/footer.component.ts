import { Component, OnInit, OnDestroy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { TokenStorageService } from '../../../core/services/token-storage.service';
import { AuthEventService } from '../../../core/services/auth-event.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink, CommonModule],
  template: `
    <footer class="footer">
      <div class="container">
        <div class="footer-content">
          <div class="footer-section">
            <h3>Dev Team Manager</h3>
            <p>Manage your development teams efficiently with our powerful platform.</p>
          </div>
          <div class="footer-section" *ngIf="isLoggedIn">
            <h3>Quick Links</h3>
            <ul class="footer-links">
              <li><a routerLink="/">Dashboard</a></li>
              <li><a routerLink="/teams">Teams</a></li>
              <li><a routerLink="/developers">Developers</a></li>
              <li><a routerLink="/projects">Projects</a></li>
              <li><a routerLink="/tasks">Tasks</a></li>
            </ul>
          </div>
          <div class="footer-section">
            <h3>Contact</h3>
            <p>Email: support&#64;devteammanager.com</p>
            <p>Phone: +1 (555) 123-4567</p>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; 2025 Dev Team Manager. All rights reserved.</p>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background-color: var(--dark);
      color: var(--light);
      padding: 3rem 0 1.5rem;
      margin-top: 3rem;
      font-size: 0.95rem;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1rem;
    }

    .footer-content {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 2rem;
      margin-bottom: 2rem;
    }

    .footer-section h3 {
      color: var(--secondary);
      margin-bottom: 1rem;
      font-size: 1.2rem;
      font-weight: 600;
    }

    .footer-section p {
      color: var(--gray-light);
      margin-bottom: 0.5rem;
      line-height: 1.6;
    }

    .footer-links {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links li {
      margin-bottom: 0.5rem;
    }

    .footer-links a {
      color: var(--gray-light);
      text-decoration: none;
      transition: var(--transition);
    }

    .footer-links a:hover {
      color: var(--secondary);
      text-decoration: none;
    }

    .footer-bottom {
      text-align: center;
      padding-top: 1.5rem;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      color: var(--gray-light);
      font-size: 0.9rem;
    }

    @media (max-width: 768px) {
      .footer {
        padding: 2rem 0 1rem;
      }

      .footer-content {
        grid-template-columns: 1fr;
        gap: 1.5rem;
      }
    }
  `]
})
export class FooterComponent implements OnInit, OnDestroy {
  isLoggedIn = false;
  private authSubscription: Subscription;

  constructor(
    private tokenStorageService: TokenStorageService,
    private authEventService: AuthEventService
  ) {
    // Subscribe to authentication events
    this.authSubscription = this.authEventService.authChange$.subscribe(isLoggedIn => {
      this.isLoggedIn = isLoggedIn;
    });
  }

  ngOnInit(): void {
    this.updateLoginStatus();
  }

  updateLoginStatus(): void {
    this.isLoggedIn = !!this.tokenStorageService.getToken();
  }

  ngOnDestroy(): void {
    // Unsubscribe to prevent memory leaks
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }
}
