import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeService, Theme } from '../../../core/services/theme.service';

@Component({
  selector: 'app-theme-switcher',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="theme-switcher" (click)="toggleTheme()">
      <span class="theme-icon" [class.active]="currentTheme === 'light'">☀️</span>
      <div class="theme-switcher-toggle"></div>
      <span class="theme-icon" [class.active]="currentTheme === 'dark'">🌙</span>
    </div>
  `,
  styles: [`
    .theme-switcher {
      display: inline-flex;
      align-items: center;
      cursor: pointer;
      padding: 8px;
      border-radius: var(--radius);
      transition: var(--transition);
      background-color: var(--surface);
      border: 1px solid var(--border);
      box-shadow: var(--shadow);
    }

    .theme-icon {
      font-size: 16px;
      opacity: 0.5;
      transition: var(--transition);
    }

    .theme-icon.active {
      opacity: 1;
      transform: scale(1.2);
    }

    .theme-switcher:hover {
      transform: translateY(-2px);
    }
  `]
})
export class ThemeSwitcherComponent implements OnInit {
  currentTheme: Theme = 'light';

  constructor(private themeService: ThemeService) {}

  ngOnInit(): void {
    this.themeService.getTheme$().subscribe(theme => {
      this.currentTheme = theme;
    });
  }

  toggleTheme(): void {
    this.themeService.toggleTheme();
  }
}
