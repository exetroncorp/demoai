import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Developer, DeveloperRequest, DeveloperResponse } from '../models/developer.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DeveloperService {
  private apiUrl = `${environment.apiUrl}/developers`;

  constructor(private http: HttpClient) { }

  getAllDevelopers(): Observable<DeveloperResponse[]> {
    return this.http.get<DeveloperResponse[]>(this.apiUrl);
  }

  getDeveloperById(id: number): Observable<DeveloperResponse> {
    return this.http.get<DeveloperResponse>(`${this.apiUrl}/${id}`);
  }

  getDevelopersByTeam(teamId: number): Observable<DeveloperResponse[]> {
    return this.http.get<DeveloperResponse[]>(`${this.apiUrl}/team/${teamId}`);
  }

  createDeveloper(developer: DeveloperRequest): Observable<DeveloperResponse> {
    return this.http.post<DeveloperResponse>(this.apiUrl, developer);
  }

  updateDeveloper(id: number, developer: DeveloperRequest): Observable<DeveloperResponse> {
    return this.http.put<DeveloperResponse>(`${this.apiUrl}/${id}`, developer);
  }

  deleteDeveloper(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
