import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthEventService {
  private authChangeSource = new Subject<boolean>();
  
  // Observable that components can subscribe to
  authChange$ = this.authChangeSource.asObservable();
  
  // Method to emit authentication change events
  emitAuthChange(isLoggedIn: boolean) {
    this.authChangeSource.next(isLoggedIn);
  }
}
