import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Team, TeamRequest, TeamResponse } from '../models/team.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TeamService {
  private apiUrl = `${environment.apiUrl}/teams`;

  constructor(private http: HttpClient) { }

  getAllTeams(): Observable<TeamResponse[]> {
    return this.http.get<TeamResponse[]>(this.apiUrl);
  }

  getTeamById(id: number): Observable<TeamResponse> {
    return this.http.get<TeamResponse>(`${this.apiUrl}/${id}`);
  }

  createTeam(team: TeamRequest): Observable<TeamResponse> {
    return this.http.post<TeamResponse>(this.apiUrl, team);
  }

  updateTeam(id: number, team: TeamRequest): Observable<TeamResponse> {
    return this.http.put<TeamResponse>(`${this.apiUrl}/${id}`, team);
  }

  deleteTeam(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  assignDeveloperToTeam(teamId: number, developerId: number): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/${teamId}/developers/${developerId}`, {});
  }

  removeDeveloperFromTeam(teamId: number, developerId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${teamId}/developers/${developerId}`);
  }
}
