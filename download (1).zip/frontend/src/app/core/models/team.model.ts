import { Developer } from './developer.model';
import { Project } from './project.model';

export interface Team {
  id?: number;
  name: string;
  department: string;
  developers?: Developer[];
  projects?: Project[];
}

export interface TeamRequest {
  name: string;
  department: string;
}

export interface TeamResponse {
  id: number;
  name: string;
  department: string;
  developers?: {
    id: number;
    name: string;
    role: string;
  }[];
  projects?: {
    id: number;
    name: string;
    status: string;
  }[];
}
