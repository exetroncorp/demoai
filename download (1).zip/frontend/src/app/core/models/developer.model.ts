import { Team } from './team.model';
import { Task } from './task.model';

export interface Developer {
  id?: number;
  name: string;
  role: string;
  email: string;
  skillLevel: string;
  pictureUrl?: string;
  team?: Team;
  tasks?: Task[];
}

export interface DeveloperRequest {
  name: string;
  role: string;
  email: string;
  skillLevel: string;
  pictureUrl?: string;
}

export interface DeveloperResponse {
  id: number;
  name: string;
  role: string;
  email: string;
  skillLevel: string;
  pictureUrl?: string;
  team?: {
    id: number;
    name: string;
  };
  tasks?: {
    id: number;
    title: string;
    status: string;
  }[];
}
