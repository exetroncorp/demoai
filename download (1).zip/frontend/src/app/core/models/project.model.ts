import { Team } from './team.model';
import { Task } from './task.model';

export enum ProjectStatus {
  PLANNED = 'PLANNED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  ON_HOLD = 'ON_HOLD',
  CANCELLED = 'CANCELLED'
}

export interface Project {
  id?: number;
  name: string;
  description: string;
  startDate?: string;
  endDate?: string;
  status: ProjectStatus;
  teamId?: number;
  team?: Team;
  tasks?: Task[];
}

export interface ProjectRequest {
  name: string;
  description: string;
  startDate?: string;
  endDate?: string;
  status: ProjectStatus;
  teamId?: number;
}

export interface ProjectResponse {
  id: number;
  name: string;
  description: string;
  startDate?: string;
  endDate?: string;
  status: ProjectStatus;
  team?: {
    id: number;
    name: string;
  };
  tasks?: {
    id: number;
    title: string;
    status: string;
  }[];
}
