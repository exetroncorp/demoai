import { Developer } from './developer.model';
import { Project } from './project.model';

export enum TaskStatus {
  TODO = 'TODO',
  IN_PROGRESS = 'IN_PROGRESS',
  REVIEW = 'REVIEW',
  DONE = 'DONE',
  BLOCKED = 'BLOCKED'
}

export interface Task {
  id?: number;
  title: string;
  description: string;
  status: TaskStatus;
  dueDate?: string;
  priority?: number;
  projectId?: number;
  project?: Project;
  assigneeId?: number;
  assignee?: Developer;
}

export interface TaskRequest {
  title: string;
  description: string;
  status: TaskStatus;
  dueDate?: string;
  priority?: number;
  projectId?: number;
  assigneeId?: number;
}

export interface TaskResponse {
  id: number;
  title: string;
  description: string;
  status: TaskStatus;
  dueDate?: string;
  priority?: number;
  project?: {
    id: number;
    name: string;
  };
  assignee?: {
    id: number;
    name: string;
    role: string;
  };
}
