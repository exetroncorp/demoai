import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TaskService } from '../../../core/services/task.service';
import { TaskResponse, TaskStatus } from '../../../core/models/task.model';
import { TaskPdfComponent } from '../task-pdf/task-pdf.component';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, RouterLink, TaskPdfComponent],
  template: `
    <div class="task-list-container">
      <div class="header">
        <h1>Tasks</h1>
        <a routerLink="/tasks/new" class="add-button">Add Task</a>
      </div>

      <app-task-pdf></app-task-pdf>

      <div class="content">
        <div *ngIf="loading" class="loading">
          <p>Loading tasks...</p>
        </div>

        <div *ngIf="!loading && tasks.length === 0" class="empty-state">
          <p>No tasks found. Create your first task to get started.</p>
          <a routerLink="/tasks/new" class="add-button">Add Task</a>
        </div>

        <table *ngIf="!loading && tasks.length > 0">
          <thead>
            <tr>
              <th>Title</th>
              <th>Status</th>
              <th>Project</th>
              <th>Assignee</th>
              <th>Due Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let task of tasks">
              <td>{{ task.title }}</td>
              <td>
                <span class="status-badge" [ngClass]="getStatusClass(task.status)">
                  {{ task.status }}
                </span>
              </td>
              <td>{{ task.project ? task.project.name : 'Not Assigned' }}</td>
              <td>{{ task.assignee ? task.assignee.name : 'Unassigned' }}</td>
              <td>{{ task.dueDate ? (task.dueDate | date:'mediumDate') : 'No due date' }}</td>
              <td class="actions">
                <a [routerLink]="['/tasks', task.id]" class="view-button">View</a>
                <a [routerLink]="['/tasks', task.id, 'edit']" class="edit-button">Edit</a>
                <button class="delete-button" (click)="deleteTask(task.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .task-list-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    h1 {
      margin: 0;
      color: var(--text-primary);
    }

    .add-button {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .add-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
      text-decoration: none;
    }

    .loading {
      text-align: center;
      padding: 3rem;
      font-size: 1.2rem;
      color: var(--text-secondary);
    }

    .empty-state {
      text-align: center;
      padding: 3rem;
      background-color: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
    }

    .empty-state p {
      margin-bottom: 1.5rem;
      font-size: 1.2rem;
      color: var(--text-secondary);
    }

    table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      background-color: var(--surface);
      border-radius: var(--radius);
      overflow: hidden;
      box-shadow: var(--shadow);
    }

    th, td {
      padding: 1rem;
      text-align: left;
    }

    th {
      background-color: rgba(var(--primary-rgb), 0.05);
      font-weight: 500;
      color: var(--primary-dark);
      border-bottom: 2px solid var(--primary-light);
    }

    tr:nth-child(even) {
      background-color: rgba(0, 0, 0, 0.03);
    }

    .dark-theme tr:nth-child(even) {
      background-color: rgba(255, 255, 255, 0.03);
    }

    tr:hover {
      background-color: rgba(var(--primary-rgb), 0.05);
    }

    .status-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .status-todo {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .status-in-progress {
      background-color: #fff8e1;
      color: #ff8f00;
    }

    .status-review {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .status-done {
      background-color: #e0f2f1;
      color: #00796b;
    }

    .status-blocked {
      background-color: #ffebee;
      color: #c62828;
    }

    .actions {
      display: flex;
      gap: 0.5rem;
    }

    .view-button, .edit-button, .delete-button {
      padding: 0.5rem 0.75rem;
      border-radius: var(--radius);
      font-size: 0.85rem;
      text-decoration: none;
      cursor: pointer;
      transition: var(--transition);
    }

    .view-button {
      background-color: var(--light);
      color: var(--primary);
    }

    .view-button:hover {
      background-color: var(--primary-light);
      color: white;
      text-decoration: none;
    }

    .edit-button {
      background-color: var(--secondary-light);
      color: var(--dark);
    }

    .edit-button:hover {
      background-color: var(--secondary);
      text-decoration: none;
    }

    .delete-button {
      background-color: var(--light);
      color: var(--danger);
      border: none;
    }

    .delete-button:hover {
      background-color: var(--danger);
      color: white;
    }

    @media (max-width: 768px) {
      .actions {
        flex-direction: column;
      }
    }
  `]
})
export class TaskListComponent implements OnInit {
  tasks: TaskResponse[] = [];
  loading = true;

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks(): void {
    this.loading = true;
    this.taskService.getAllTasks().subscribe({
      next: (tasks) => {
        this.tasks = tasks;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading tasks', error);
        this.loading = false;
      }
    });
  }

  deleteTask(id: number): void {
    if (confirm('Are you sure you want to delete this task?')) {
      this.taskService.deleteTask(id).subscribe({
        next: () => {
          this.tasks = this.tasks.filter(task => task.id !== id);
        },
        error: (error) => {
          console.error('Error deleting task', error);
        }
      });
    }
  }

  getStatusClass(status: TaskStatus): string {
    switch (status) {
      case TaskStatus.TODO:
        return 'status-todo';
      case TaskStatus.IN_PROGRESS:
        return 'status-in-progress';
      case TaskStatus.REVIEW:
        return 'status-review';
      case TaskStatus.DONE:
        return 'status-done';
      case TaskStatus.BLOCKED:
        return 'status-blocked';
      default:
        return '';
    }
  }
}
