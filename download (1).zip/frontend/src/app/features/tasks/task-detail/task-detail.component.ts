import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { TaskService } from '../../../core/services/task.service';
import { TaskResponse, TaskStatus } from '../../../core/models/task.model';
import { TaskPdfComponent } from '../task-pdf/task-pdf.component';

@Component({
  selector: 'app-task-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, TaskPdfComponent],
  template: `
    <div class="task-detail-container" *ngIf="task">
      <div class="header">
        <div class="title-section">
          <h1>{{ task.title }}</h1>
          <span class="status-badge" [ngClass]="getStatusClass(task.status)">
            {{ task.status }}
          </span>
        </div>
        <div class="actions">
          <a [routerLink]="['/tasks', task.id, 'edit']" class="edit-button">Edit Task</a>
          <button class="delete-button" (click)="deleteTask()">Delete Task</button>
        </div>
      </div>

      <div class="task-content">
        <div class="task-info">
          <app-task-pdf #pdfComponent></app-task-pdf>
          <div class="info-card">
            <h2>Details</h2>
            <div class="info-row">
              <div class="info-item">
                <span class="label">Status:</span>
                <span class="value">{{ task.status }}</span>
              </div>
              <div class="info-item">
                <span class="label">Priority:</span>
                <span class="value">{{ task.priority || 'Not set' }}</span>
              </div>
              <div class="info-item">
                <span class="label">Due Date:</span>
                <span class="value">{{ task.dueDate ? (task.dueDate | date:'mediumDate') : 'Not set' }}</span>
              </div>
            </div>
          </div>

          <div class="info-card">
            <h2>Description</h2>
            <p class="description">{{ task.description }}</p>
          </div>

          <div class="info-card">
            <h2>Assignment</h2>
            <div class="info-row">
              <div class="info-item">
                <span class="label">Project:</span>
                <span class="value" *ngIf="task.project">
                  <a [routerLink]="['/projects', task.project.id]">{{ task.project.name }}</a>
                </span>
                <span class="value" *ngIf="!task.project">Not assigned to a project</span>
              </div>
              <div class="info-item">
                <span class="label">Assignee:</span>
                <span class="value" *ngIf="task.assignee">
                  <a [routerLink]="['/developers', task.assignee.id]">{{ task.assignee.name }}</a>
                </span>
                <span class="value" *ngIf="!task.assignee">Unassigned</span>
              </div>
            </div>
          </div>
        </div>

        <div class="task-actions-panel">
          <h2>Actions</h2>
          <div class="action-buttons">
            <button
              *ngIf="task.status === 'TODO'"
              class="action-button start-button"
              (click)="startTask()">
              Start Task
            </button>
            <button
              *ngIf="task.status === 'IN_PROGRESS'"
              class="action-button complete-button"
              (click)="completeTask()">
              Complete Task
            </button>
            <button
              *ngIf="task.status === 'DONE'"
              class="action-button reopen-button"
              (click)="reopenTask()">
              Reopen Task
            </button>
            <button
              *ngIf="task.status !== 'BLOCKED' && task.status !== 'DONE'"
              class="action-button block-button"
              (click)="blockTask()">
              Block Task
            </button>
            <button
              *ngIf="task.status === 'BLOCKED'"
              class="action-button unblock-button"
              (click)="unblockTask()">
              Unblock Task
            </button>
          </div>
        </div>
      </div>
    </div>

    <div *ngIf="loading" class="loading">
      <p>Loading task...</p>
    </div>
  `,
  styles: [`
    .task-detail-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    .title-section {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    h1 {
      margin: 0;
      color: var(--text-primary);
    }

    .status-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 1rem;
      font-size: 0.85rem;
      font-weight: 500;
    }

    .status-todo {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .status-in-progress {
      background-color: #fff8e1;
      color: #ff8f00;
    }

    .status-review {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .status-done {
      background-color: #e0f2f1;
      color: #00796b;
    }

    .status-blocked {
      background-color: #ffebee;
      color: #c62828;
    }

    .actions {
      display: flex;
      gap: 1rem;
    }

    .edit-button, .delete-button {
      padding: 0.75rem 1.5rem;
      border-radius: var(--radius);
      font-weight: 500;
      text-decoration: none;
      cursor: pointer;
      transition: var(--transition);
    }

    .edit-button {
      background-color: var(--secondary);
      color: var(--dark);
    }

    .edit-button:hover {
      background-color: var(--secondary-dark);
      text-decoration: none;
    }

    .delete-button {
      background-color: var(--light);
      color: var(--danger);
      border: 1px solid var(--danger);
    }

    .delete-button:hover {
      background-color: var(--danger);
      color: white;
    }

    .task-content {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 2rem;
    }

    .task-info {
      display: flex;
      flex-direction: column;
      gap: 2rem;
    }

    .info-card {
      background-color: var(--surface);
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
    }

    .info-card h2 {
      margin-top: 0;
      margin-bottom: 1rem;
      color: var(--text-primary);
      font-size: 1.5rem;
    }

    .info-row {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 1.5rem;
    }

    .info-item {
      margin-bottom: 1rem;
    }

    .label {
      display: block;
      font-weight: 500;
      color: var(--text-secondary);
      margin-bottom: 0.25rem;
    }

    .value {
      color: var(--text-primary);
    }

    .description {
      white-space: pre-line;
      color: var(--text-primary);
      line-height: 1.6;
    }

    .task-actions-panel {
      background-color: var(--surface);
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
      height: fit-content;
    }

    .task-actions-panel h2 {
      margin-top: 0;
      margin-bottom: 1.5rem;
      color: var(--text-primary);
      font-size: 1.5rem;
    }

    .action-buttons {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .action-button {
      padding: 0.75rem 1rem;
      border-radius: var(--radius);
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
      border: none;
      text-align: center;
    }

    .start-button {
      background-color: var(--primary);
      color: white;
    }

    .start-button:hover {
      background-color: var(--primary-dark);
    }

    .complete-button {
      background-color: var(--success);
      color: white;
    }

    .complete-button:hover {
      background-color: #00a040;
    }

    .reopen-button {
      background-color: var(--warning);
      color: white;
    }

    .reopen-button:hover {
      background-color: #f57c00;
    }

    .block-button {
      background-color: var(--danger);
      color: white;
    }

    .block-button:hover {
      background-color: #c62828;
    }

    .unblock-button {
      background-color: var(--primary);
      color: white;
    }

    .unblock-button:hover {
      background-color: var(--primary-dark);
    }

    .loading {
      text-align: center;
      padding: 3rem;
      font-size: 1.2rem;
      color: var(--text-secondary);
    }

    @media (max-width: 768px) {
      .header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .actions {
        width: 100%;
      }

      .edit-button, .delete-button {
        flex: 1;
        text-align: center;
      }

      .task-content {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class TaskDetailComponent implements OnInit, AfterViewInit {
  @ViewChild('pdfComponent') pdfComponent?: TaskPdfComponent;
  task?: TaskResponse;
  loading = true;

  constructor(
    private taskService: TaskService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.loadTask(+id);
      }
    });
  }

  ngAfterViewInit(): void {
    if (this.task && this.pdfComponent) {
      this.pdfComponent.setTaskId(this.task.id);
    }
  }

  loadTask(id: number): void {
    this.loading = true;
    this.taskService.getTaskById(id).subscribe({
      next: (task) => {
        this.task = task;
        if (this.pdfComponent) {
          this.pdfComponent.setTaskId(task.id);
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading task', error);
        this.loading = false;
        this.router.navigate(['/tasks']);
      }
    });
  }

  deleteTask(): void {
    if (!this.task) return;

    if (confirm(`Are you sure you want to delete the task "${this.task.title}"?`)) {
      this.taskService.deleteTask(this.task.id).subscribe({
        next: () => {
          this.router.navigate(['/tasks']);
        },
        error: (error) => {
          console.error('Error deleting task', error);
        }
      });
    }
  }

  startTask(): void {
    if (!this.task) return;

    this.taskService.startTask(this.task.id).subscribe({
      next: (updatedTask) => {
        this.task = updatedTask;
      },
      error: (error) => {
        console.error('Error starting task', error);
      }
    });
  }

  completeTask(): void {
    if (!this.task) return;

    this.taskService.completeTask(this.task.id).subscribe({
      next: (updatedTask) => {
        this.task = updatedTask;
      },
      error: (error) => {
        console.error('Error completing task', error);
      }
    });
  }

  reopenTask(): void {
    if (!this.task) return;

    this.taskService.reopenTask(this.task.id).subscribe({
      next: (updatedTask) => {
        this.task = updatedTask;
      },
      error: (error) => {
        console.error('Error reopening task', error);
      }
    });
  }

  blockTask(): void {
    if (!this.task) return;

    this.taskService.blockTask(this.task.id).subscribe({
      next: (updatedTask) => {
        this.task = updatedTask;
      },
      error: (error) => {
        console.error('Error blocking task', error);
      }
    });
  }

  unblockTask(): void {
    if (!this.task) return;

    this.taskService.unblockTask(this.task.id).subscribe({
      next: (updatedTask) => {
        this.task = updatedTask;
      },
      error: (error) => {
        console.error('Error unblocking task', error);
      }
    });
  }

  getStatusClass(status: TaskStatus): string {
    switch (status) {
      case TaskStatus.TODO:
        return 'status-todo';
      case TaskStatus.IN_PROGRESS:
        return 'status-in-progress';
      case TaskStatus.REVIEW:
        return 'status-review';
      case TaskStatus.DONE:
        return 'status-done';
      case TaskStatus.BLOCKED:
        return 'status-blocked';
      default:
        return '';
    }
  }
}
