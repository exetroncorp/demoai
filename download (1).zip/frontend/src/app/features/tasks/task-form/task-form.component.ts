import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskService } from '../../../core/services/task.service';
import { ProjectService } from '../../../core/services/project.service';
import { DeveloperService } from '../../../core/services/developer.service';
import { TaskRequest, TaskStatus } from '../../../core/models/task.model';
import { ProjectResponse } from '../../../core/models/project.model';
import { DeveloperResponse } from '../../../core/models/developer.model';

@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="task-form-container">
      <h1>{{ isEditMode ? 'Edit Task' : 'Create New Task' }}</h1>
      
      <form [formGroup]="taskForm" (ngSubmit)="onSubmit()">
        <div class="form-group">
          <label for="title">Task Title</label>
          <input 
            type="text" 
            id="title" 
            formControlName="title" 
            placeholder="Enter task title"
          >
          <div *ngIf="taskForm.get('title')?.invalid && taskForm.get('title')?.touched" class="error-message">
            <span *ngIf="taskForm.get('title')?.errors?.['required']">Task title is required</span>
            <span *ngIf="taskForm.get('title')?.errors?.['minlength']">Task title must be at least 2 characters</span>
            <span *ngIf="taskForm.get('title')?.errors?.['maxlength']">Task title must be less than 100 characters</span>
          </div>
        </div>
        
        <div class="form-group">
          <label for="description">Description</label>
          <textarea 
            id="description" 
            formControlName="description" 
            placeholder="Enter task description"
            rows="4"
          ></textarea>
          <div *ngIf="taskForm.get('description')?.invalid && taskForm.get('description')?.touched" class="error-message">
            <span *ngIf="taskForm.get('description')?.errors?.['required']">Description is required</span>
            <span *ngIf="taskForm.get('description')?.errors?.['maxlength']">Description must be less than 500 characters</span>
          </div>
        </div>
        
        <div class="form-row">
          <div class="form-group">
            <label for="status">Status</label>
            <select id="status" formControlName="status">
              <option *ngFor="let status of statusOptions" [value]="status">{{ status }}</option>
            </select>
          </div>
          
          <div class="form-group">
            <label for="priority">Priority (1-5)</label>
            <input 
              type="number" 
              id="priority" 
              formControlName="priority" 
              min="1" 
              max="5"
            >
            <div *ngIf="taskForm.get('priority')?.invalid && taskForm.get('priority')?.touched" class="error-message">
              <span *ngIf="taskForm.get('priority')?.errors?.['min'] || taskForm.get('priority')?.errors?.['max']">Priority must be between 1 and 5</span>
            </div>
          </div>
        </div>
        
        <div class="form-group">
          <label for="dueDate">Due Date</label>
          <input 
            type="date" 
            id="dueDate" 
            formControlName="dueDate"
          >
        </div>
        
        <div class="form-group">
          <label for="projectId">Project</label>
          <select id="projectId" formControlName="projectId">
            <option [value]="null">-- Select Project --</option>
            <option *ngFor="let project of projects" [value]="project.id">{{ project.name }}</option>
          </select>
        </div>
        
        <div class="form-group">
          <label for="assigneeId">Assignee</label>
          <select id="assigneeId" formControlName="assigneeId">
            <option [value]="null">-- Unassigned --</option>
            <option *ngFor="let developer of developers" [value]="developer.id">{{ developer.name }}</option>
          </select>
        </div>
        
        <div class="form-actions">
          <button type="button" class="cancel-button" (click)="onCancel()">Cancel</button>
          <button type="submit" class="submit-button" [disabled]="taskForm.invalid || loading">
            {{ isEditMode ? 'Update' : 'Create' }}
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .task-form-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }
    
    h1 {
      margin-bottom: 2rem;
      color: var(--text-primary);
    }
    
    form {
      background-color: var(--surface);
      border-radius: var(--radius);
      padding: 2rem;
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
    }
    
    .form-group {
      margin-bottom: 1.5rem;
    }
    
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.5rem;
    }
    
    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: var(--text-primary);
    }
    
    input, select, textarea {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      font-size: 1rem;
      background-color: var(--surface);
      color: var(--text-primary);
      transition: var(--transition);
    }
    
    input:focus, select:focus, textarea:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.1);
    }
    
    .error-message {
      color: var(--danger);
      font-size: 0.85rem;
      margin-top: 0.5rem;
    }
    
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2rem;
    }
    
    .cancel-button, .submit-button {
      padding: 0.75rem 1.5rem;
      border-radius: var(--radius);
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }
    
    .cancel-button {
      background-color: var(--light);
      color: var(--text-primary);
      border: 1px solid var(--border);
    }
    
    .cancel-button:hover {
      background-color: var(--gray-light);
    }
    
    .submit-button {
      background-color: var(--primary);
      color: white;
      border: none;
    }
    
    .submit-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
    }
    
    .submit-button:disabled {
      opacity: 0.7;
      cursor: not-allowed;
      transform: none;
      box-shadow: none;
    }
    
    @media (max-width: 768px) {
      .form-row {
        grid-template-columns: 1fr;
        gap: 0;
      }
    }
  `]
})
export class TaskFormComponent implements OnInit {
  taskForm: FormGroup;
  isEditMode = false;
  taskId?: number;
  loading = false;
  projects: ProjectResponse[] = [];
  developers: DeveloperResponse[] = [];
  statusOptions = Object.values(TaskStatus);

  constructor(
    private fb: FormBuilder,
    private taskService: TaskService,
    private projectService: ProjectService,
    private developerService: DeveloperService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.taskForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      description: ['', [Validators.required, Validators.maxLength(500)]],
      status: [TaskStatus.TODO, [Validators.required]],
      priority: [3, [Validators.min(1), Validators.max(5)]],
      dueDate: [''],
      projectId: [null],
      assigneeId: [null]
    });
  }

  ngOnInit(): void {
    this.loadProjects();
    this.loadDevelopers();
    
    // Check if we're in edit mode
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id && id !== 'new') {
        this.isEditMode = true;
        this.taskId = +id;
        this.loadTask(this.taskId);
      } else {
        // Check if projectId is provided as a query parameter
        this.route.queryParamMap.subscribe(queryParams => {
          const projectId = queryParams.get('projectId');
          if (projectId) {
            this.taskForm.patchValue({ projectId: +projectId });
          }
        });
      }
    });
  }

  loadTask(id: number): void {
    this.loading = true;
    this.taskService.getTaskById(id).subscribe({
      next: (task) => {
        this.taskForm.patchValue({
          title: task.title,
          description: task.description,
          status: task.status,
          priority: task.priority,
          dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : '',
          projectId: task.project?.id,
          assigneeId: task.assignee?.id
        });
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading task', error);
        this.loading = false;
        this.router.navigate(['/tasks']);
      }
    });
  }

  loadProjects(): void {
    this.projectService.getAllProjects().subscribe({
      next: (projects) => {
        this.projects = projects;
      },
      error: (error) => {
        console.error('Error loading projects', error);
      }
    });
  }

  loadDevelopers(): void {
    this.developerService.getAllDevelopers().subscribe({
      next: (developers) => {
        this.developers = developers;
      },
      error: (error) => {
        console.error('Error loading developers', error);
      }
    });
  }

  onSubmit(): void {
    if (this.taskForm.invalid) {
      return;
    }

    const taskRequest: TaskRequest = {
      title: this.taskForm.value.title,
      description: this.taskForm.value.description,
      status: this.taskForm.value.status,
      priority: this.taskForm.value.priority,
      dueDate: this.taskForm.value.dueDate,
      projectId: this.taskForm.value.projectId,
      assigneeId: this.taskForm.value.assigneeId
    };

    this.loading = true;

    if (this.isEditMode && this.taskId) {
      this.taskService.updateTask(this.taskId, taskRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/tasks']);
        },
        error: (error) => {
          console.error('Error updating task', error);
          this.loading = false;
        }
      });
    } else {
      this.taskService.createTask(taskRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/tasks']);
        },
        error: (error) => {
          console.error('Error creating task', error);
          this.loading = false;
        }
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/tasks']);
  }
}
