import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TeamService } from '../../../core/services/team.service';
import { TeamRequest } from '../../../core/models/team.model';

@Component({
  selector: 'app-team-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="team-form-container">
      <h1>{{ isEditMode ? 'Edit Team' : 'Create Team' }}</h1>
      
      <form [formGroup]="teamForm" (ngSubmit)="onSubmit()">
        <div class="form-group">
          <label for="name">Team Name</label>
          <input 
            type="text" 
            id="name" 
            formControlName="name" 
            placeholder="Enter team name"
          >
          <div *ngIf="teamForm.get('name')?.invalid && teamForm.get('name')?.touched" class="error-message">
            <span *ngIf="teamForm.get('name')?.errors?.['required']">Team name is required</span>
            <span *ngIf="teamForm.get('name')?.errors?.['minlength']">Team name must be at least 2 characters</span>
            <span *ngIf="teamForm.get('name')?.errors?.['maxlength']">Team name must be less than 50 characters</span>
          </div>
        </div>
        
        <div class="form-group">
          <label for="department">Department</label>
          <input 
            type="text" 
            id="department" 
            formControlName="department" 
            placeholder="Enter department name"
          >
          <div *ngIf="teamForm.get('department')?.invalid && teamForm.get('department')?.touched" class="error-message">
            <span *ngIf="teamForm.get('department')?.errors?.['maxlength']">Department must be less than 100 characters</span>
          </div>
        </div>
        
        <div class="form-actions">
          <button type="button" class="cancel-button" (click)="onCancel()">Cancel</button>
          <button type="submit" class="submit-button" [disabled]="teamForm.invalid || loading">
            {{ isEditMode ? 'Update' : 'Create' }}
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .team-form-container {
      max-width: 600px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }
    
    h1 {
      margin-bottom: 2rem;
      color: #333;
    }
    
    form {
      background-color: white;
      border-radius: 8px;
      padding: 2rem;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .form-group {
      margin-bottom: 1.5rem;
    }
    
    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: #333;
    }
    
    input {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
    }
    
    input:focus {
      outline: none;
      border-color: #3f51b5;
    }
    
    .error-message {
      color: #d32f2f;
      font-size: 0.9rem;
      margin-top: 0.5rem;
    }
    
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2rem;
    }
    
    button {
      padding: 0.75rem 1.5rem;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    
    .cancel-button {
      background-color: #f5f5f5;
      color: #333;
      border: 1px solid #ddd;
    }
    
    .cancel-button:hover {
      background-color: #e0e0e0;
    }
    
    .submit-button {
      background-color: #3f51b5;
      color: white;
      border: none;
    }
    
    .submit-button:hover {
      background-color: #303f9f;
    }
    
    .submit-button:disabled {
      background-color: #c5cae9;
      cursor: not-allowed;
    }
  `]
})
export class TeamFormComponent implements OnInit {
  teamForm: FormGroup;
  isEditMode = false;
  teamId?: number;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private teamService: TeamService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.teamForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      department: ['', [Validators.maxLength(100)]]
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id && id !== 'new') {
        this.isEditMode = true;
        this.teamId = +id;
        this.loadTeam(this.teamId);
      }
    });
  }

  loadTeam(id: number): void {
    this.loading = true;
    this.teamService.getTeamById(id).subscribe({
      next: (team) => {
        this.teamForm.patchValue({
          name: team.name,
          department: team.department
        });
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading team', error);
        this.loading = false;
        this.router.navigate(['/teams']);
      }
    });
  }

  onSubmit(): void {
    if (this.teamForm.invalid) {
      return;
    }

    const teamRequest: TeamRequest = {
      name: this.teamForm.value.name,
      department: this.teamForm.value.department
    };

    this.loading = true;

    if (this.isEditMode && this.teamId) {
      this.teamService.updateTeam(this.teamId, teamRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/teams']);
        },
        error: (error) => {
          console.error('Error updating team', error);
          this.loading = false;
        }
      });
    } else {
      this.teamService.createTeam(teamRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/teams']);
        },
        error: (error) => {
          console.error('Error creating team', error);
          this.loading = false;
        }
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/teams']);
  }
}
