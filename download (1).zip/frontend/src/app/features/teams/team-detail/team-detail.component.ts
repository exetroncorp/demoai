import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { TeamService } from '../../../core/services/team.service';
import { DeveloperService } from '../../../core/services/developer.service';
import { ProjectService } from '../../../core/services/project.service';
import { TeamResponse } from '../../../core/models/team.model';
import { DeveloperResponse } from '../../../core/models/developer.model';
import { ProjectResponse, ProjectStatus } from '../../../core/models/project.model';
import { AssignDeveloperComponent } from '../assign-developer/assign-developer.component';
import { AssignProjectComponent } from '../assign-project/assign-project.component';
import { TeamPdfComponent } from '../team-pdf/team-pdf.component';

@Component({
  selector: 'app-team-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, AssignDeveloperComponent, AssignProjectComponent, TeamPdfComponent],
  template: `
    <div class="team-detail-container" *ngIf="team">
      <div class="header">
        <h1>{{ team.name }}</h1>
        <div class="actions">
          <a [routerLink]="['/teams', team.id, 'edit']" class="edit-button">Edit Team</a>
          <button class="delete-button" (click)="deleteTeam()">Delete Team</button>
        </div>
      </div>

      <div class="team-info">
        <app-team-pdf #pdfComponent></app-team-pdf>
        <div class="info-card">
          <h2>Team Information</h2>
          <div class="info-row">
            <span class="label">Department:</span>
            <span class="value">{{ team.department || 'Not specified' }}</span>
          </div>
          <div class="info-row">
            <span class="label">Developers:</span>
            <span class="value">{{ team.developers?.length || 0 }}</span>
          </div>
          <div class="info-row">
            <span class="label">Projects:</span>
            <span class="value">{{ team.projects?.length || 0 }}</span>
          </div>
        </div>
      </div>

      <div class="developers-section">
        <div class="section-header">
          <h2>Team Members</h2>
          <button class="add-button" (click)="showAssignDeveloperModal()">
            <span class="button-icon">+</span> Add Developer
          </button>
        </div>

        <div class="developers-list">
          <div *ngIf="!team.developers || team.developers.length === 0" class="empty-state">
            <div class="empty-icon">👤</div>
            <h3>No developers in this team yet</h3>
            <p>Add developers to this team to start collaborating</p>
            <button class="btn-primary" (click)="showAssignDeveloperModal()">
              <span class="button-icon">+</span> Add Developer
            </button>
          </div>

          <div *ngIf="team.developers && team.developers.length > 0" class="team-members">
            <div class="member-cards">
              <div *ngFor="let developer of team.developers" class="member-card">
                <div class="member-avatar">{{ developer.name.charAt(0) }}</div>
                <div class="member-info">
                  <h3>{{ developer.name }}</h3>
                  <p class="member-role">{{ developer.role }}</p>
                  <p class="member-skill" *ngIf="hasSkillLevel(developer)">{{ getSkillLevel(developer) }}</p>
                </div>
                <div class="member-actions">
                  <a [routerLink]="['/developers', developer.id]" class="action-link">View Profile</a>
                  <button class="remove-button" (click)="removeDeveloper(developer.id)">
                    <span class="button-icon">✕</span> Remove
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="projects-section">
        <div class="section-header">
          <h2>Projects</h2>
          <button class="add-button" (click)="showAssignProjectModal()">
            <span class="button-icon">+</span> Add Project
          </button>
        </div>

        <div class="projects-list">
          <div *ngIf="!team.projects || team.projects.length === 0" class="empty-state">
            <div class="empty-icon">📋</div>
            <h3>No projects in this team yet</h3>
            <p>Add projects to this team to start tracking work</p>
            <button class="btn-primary" (click)="showAssignProjectModal()">
              <span class="button-icon">+</span> Add Project
            </button>
          </div>

          <div *ngIf="team.projects && team.projects.length > 0" class="project-cards">
            <div *ngFor="let project of team.projects" class="project-card">
              <div class="project-header">
                <h3>{{ project.name }}</h3>
                <span class="status-badge" [ngClass]="getStatusClass(project.status)">{{ project.status }}</span>
              </div>
              <div class="project-actions">
                <a [routerLink]="['/projects', project.id]" class="view-button">View Project</a>
                <button class="remove-button" (click)="removeProject(project.id)">
                  <span class="button-icon">✕</span> Remove
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Assign Developer Component -->
      <app-assign-developer
        [teamId]="team.id"
        [isVisible]="isAssignDeveloperModalVisible"
        (close)="hideAssignDeveloperModal()"
        (developerAssigned)="onDeveloperAssigned()"
      ></app-assign-developer>

      <!-- Assign Project Component -->
      <app-assign-project
        [teamId]="team.id"
        [isVisible]="isAssignProjectModalVisible"
        (close)="hideAssignProjectModal()"
        (projectAssigned)="onProjectAssigned()"
      ></app-assign-project>
    </div>
  `,
  styles: [`
    .team-detail-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
      animation: fadeIn 0.5s ease-in-out;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    h1 {
      margin: 0;
      color: var(--primary-dark);
      font-size: 2.5rem;
      font-weight: 700;
    }

    .actions {
      display: flex;
      gap: 1rem;
    }

    .edit-button {
      display: inline-flex;
      align-items: center;
      background-color: var(--primary);
      color: white;
      padding: 0.75rem 1.25rem;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
      box-shadow: var(--shadow);
    }

    .edit-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
      text-decoration: none;
    }

    .delete-button {
      display: inline-flex;
      align-items: center;
      background-color: var(--danger);
      color: white;
      padding: 0.75rem 1.25rem;
      border-radius: var(--radius);
      border: none;
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
      box-shadow: var(--shadow);
    }

    .delete-button:hover {
      background-color: #d32f2f;
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .team-info {
      margin-bottom: 2rem;
    }

    .info-card {
      background-color: white;
      border-radius: var(--radius);
      padding: 2rem;
      box-shadow: var(--shadow);
      transition: var(--transition);
    }

    .info-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
    }

    .info-card h2 {
      margin-top: 0;
      color: var(--primary-dark);
      margin-bottom: 1.5rem;
      font-size: 1.75rem;
      position: relative;
      padding-bottom: 0.75rem;
    }

    .info-card h2::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 50px;
      height: 3px;
      background-color: var(--primary);
      border-radius: 3px;
    }

    .info-row {
      display: flex;
      margin-bottom: 1rem;
      padding: 0.75rem 0;
      border-bottom: 1px solid #f0f0f0;
    }

    .info-row:last-child {
      border-bottom: none;
      margin-bottom: 0;
    }

    .label {
      font-weight: 600;
      width: 150px;
      color: var(--dark);
    }

    .value {
      color: var(--gray);
      font-weight: 500;
    }

    .developers-section {
      background-color: white;
      border-radius: var(--radius);
      padding: 2rem;
      box-shadow: var(--shadow);
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
      position: relative;
      padding-bottom: 0.75rem;
      border-bottom: 1px solid #f0f0f0;
    }

    .section-header h2 {
      margin: 0;
      color: var(--primary-dark);
      font-size: 1.75rem;
    }

    .button-icon {
      margin-right: 0.5rem;
      font-weight: bold;
    }

    .add-button {
      display: inline-flex;
      align-items: center;
      background-color: var(--success);
      color: white;
      padding: 0.75rem 1.25rem;
      border-radius: var(--radius);
      border: none;
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
      box-shadow: var(--shadow);
    }

    .add-button:hover {
      background-color: #00a844;
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .empty-state {
      padding: 3rem 2rem;
      text-align: center;
      color: var(--gray);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }

    .empty-icon {
      font-size: 4rem;
      color: var(--gray-light);
      margin-bottom: 1rem;
    }

    .empty-state h3 {
      color: var(--dark);
      margin: 0;
    }

    .empty-state p {
      color: var(--gray);
      margin-bottom: 1.5rem;
      max-width: 400px;
    }

    .team-members {
      padding: 1rem 0;
    }

    .member-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .member-card {
      border: 1px solid #f0f0f0;
      border-radius: var(--radius);
      padding: 1.5rem;
      display: flex;
      flex-direction: column;
      transition: var(--transition);
      position: relative;
      overflow: hidden;
    }

    .member-card:hover {
      border-color: var(--primary-light);
      transform: translateY(-5px);
      box-shadow: var(--shadow);
    }

    .member-avatar {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background-color: var(--primary);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      font-weight: bold;
      margin-bottom: 1rem;
    }

    /* Projects section */
    .projects-section {
      margin-top: 3rem;
    }

    .project-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1.5rem;
      margin-top: 1.5rem;
    }

    .project-card {
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.5rem;
      background-color: var(--surface);
      transition: var(--transition);
    }

    .project-card:hover {
      border-color: var(--primary-light);
      transform: translateY(-5px);
      box-shadow: var(--shadow);
    }

    .project-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }

    .project-header h3 {
      margin: 0;
      color: var(--text-primary);
    }

    .status-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 1rem;
      font-size: 0.85rem;
      font-weight: 500;
    }

    .status-planned {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .status-in-progress {
      background-color: #fff8e1;
      color: #ff8f00;
    }

    .status-completed {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .status-on-hold {
      background-color: #fce4ec;
      color: #d81b60;
    }

    .status-cancelled {
      background-color: #f5f5f5;
      color: #757575;
    }

    .project-actions {
      display: flex;
      justify-content: space-between;
      margin-top: 1rem;
    }

    .member-info {
      flex: 1;
    }

    .member-info h3 {
      margin: 0 0 0.5rem 0;
      color: var(--dark);
      font-size: 1.25rem;
    }

    .member-role {
      color: var(--primary);
      font-weight: 500;
      margin: 0 0 0.25rem 0;
    }

    .member-skill {
      color: var(--gray);
      font-size: 0.9rem;
      margin: 0 0 1rem 0;
    }

    .member-actions {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      margin-top: auto;
      padding-top: 1rem;
      border-top: 1px solid #f0f0f0;
    }

    .action-link {
      color: var(--primary);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .action-link:hover {
      color: var(--primary-dark);
      text-decoration: underline;
    }

    .remove-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background-color: #ffebee;
      color: var(--danger);
      padding: 0.5rem 0.75rem;
      border-radius: var(--radius);
      border: none;
      cursor: pointer;
      font-size: 0.9rem;
      font-weight: 500;
      transition: var(--transition);
    }

    .remove-button:hover {
      background-color: var(--danger);
      color: white;
    }

    @media (max-width: 768px) {
      .header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .actions {
        width: 100%;
      }

      .edit-button, .delete-button {
        flex: 1;
        justify-content: center;
      }

      .member-cards {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class TeamDetailComponent implements OnInit, AfterViewInit {
  @ViewChild('pdfComponent') pdfComponent?: TeamPdfComponent;
  team?: TeamResponse;
  availableDevelopers: DeveloperResponse[] = [];
  isAssignDeveloperModalVisible = false;
  isAssignProjectModalVisible = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private teamService: TeamService,
    private developerService: DeveloperService,
    private projectService: ProjectService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.loadTeam(+id);
      }
    });
  }

  ngAfterViewInit(): void {
    if (this.team && this.pdfComponent) {
      this.pdfComponent.setTeamId(this.team.id);
    }
  }

  loadTeam(id: number): void {
    this.teamService.getTeamById(id).subscribe({
      next: (team) => {
        this.team = team;
        if (this.pdfComponent) {
          this.pdfComponent.setTeamId(team.id);
        }
      },
      error: (error) => {
        console.error('Error loading team', error);
        this.router.navigate(['/teams']);
      }
    });
  }

  showAssignDeveloperModal(): void {
    this.isAssignDeveloperModalVisible = true;
  }

  hideAssignDeveloperModal(): void {
    this.isAssignDeveloperModalVisible = false;
  }

  showAssignProjectModal(): void {
    this.isAssignProjectModalVisible = true;
  }

  hideAssignProjectModal(): void {
    this.isAssignProjectModalVisible = false;
  }

  onDeveloperAssigned(): void {
    if (this.team) {
      this.loadTeam(this.team.id);
    }
  }

  removeDeveloper(developerId: number): void {
    if (!this.team) return;

    if (confirm('Are you sure you want to remove this developer from the team?')) {
      this.teamService.removeDeveloperFromTeam(this.team.id, developerId).subscribe({
        next: () => {
          this.loadTeam(this.team!.id);
        },
        error: (error) => {
          console.error('Error removing developer from team', error);
        }
      });
    }
  }

  deleteTeam(): void {
    if (!this.team) return;

    if (confirm('Are you sure you want to delete this team? This action cannot be undone.')) {
      this.teamService.deleteTeam(this.team.id).subscribe({
        next: () => {
          this.router.navigate(['/teams']);
        },
        error: (error) => {
          console.error('Error deleting team', error);
        }
      });
    }
  }

  hasSkillLevel(developer: any): boolean {
    return developer && 'skillLevel' in developer && developer.skillLevel;
  }

  getSkillLevel(developer: any): string {
    return developer && 'skillLevel' in developer ? developer.skillLevel : '';
  }

  onProjectAssigned(): void {
    if (this.team) {
      this.loadTeam(this.team.id);
    }
  }

  removeProject(projectId: number): void {
    if (!this.team) return;

    if (confirm('Are you sure you want to remove this project from the team?')) {
      this.projectService.removeProjectFromTeam(projectId).subscribe({
        next: () => {
          this.loadTeam(this.team!.id);
        },
        error: (error) => {
          console.error('Error removing project from team', error);
        }
      });
    }
  }

  getStatusClass(status: string): string {
    switch (status) {
      case ProjectStatus.PLANNED:
        return 'status-planned';
      case ProjectStatus.IN_PROGRESS:
        return 'status-in-progress';
      case ProjectStatus.COMPLETED:
        return 'status-completed';
      case ProjectStatus.ON_HOLD:
        return 'status-on-hold';
      case ProjectStatus.CANCELLED:
        return 'status-cancelled';
      default:
        return '';
    }
  }
}
