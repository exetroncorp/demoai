import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { DeveloperResponse } from '../../../core/models/developer.model';
import { TeamResponse } from '../../../core/models/team.model';
import { DeveloperService } from '../../../core/services/developer.service';
import { TeamService } from '../../../core/services/team.service';

@Component({
  selector: 'app-assign-developer',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="assign-developer-modal" *ngIf="isVisible">
      <div class="modal-backdrop" (click)="onClose()"></div>
      <div class="modal-content animate-fade-in">
        <div class="modal-header">
          <h2>Assign Developer to Team</h2>
          <button type="button" class="close-button" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <div *ngIf="loading" class="loading-spinner">
            <div class="spinner"></div>
            <p>Loading developers...</p>
          </div>

          <div *ngIf="!loading && availableDevelopers.length === 0" class="empty-state">
            <p>No available developers to assign.</p>
            <a [routerLink]="['/developers/new']" class="btn-primary">Add New Developer</a>
          </div>

          <div *ngIf="!loading && availableDevelopers.length > 0" class="developer-list">
            <div class="search-box">
              <input
                type="text"
                [(ngModel)]="searchTerm"
                placeholder="Search developers..."
                class="search-input"
              >
            </div>

            <div class="developers-grid">
              <div
                *ngFor="let developer of filteredDevelopers"
                class="developer-card"
                [class.selected]="selectedDeveloperId === developer.id"
                (click)="selectDeveloper(developer.id)"
              >
                <div class="developer-avatar">{{ developer.name.charAt(0) }}</div>
                <div class="developer-info">
                  <h3>{{ developer.name }}</h3>
                  <p class="developer-role">{{ developer.role }}</p>
                  <p class="developer-skill">{{ developer.skillLevel }}</p>
                </div>
                <div class="selection-indicator"></div>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-outline" (click)="onClose()">Cancel</button>
          <button
            type="button"
            class="btn-primary"
            [disabled]="!selectedDeveloperId || assigning"
            (click)="assignDeveloper()"
          >
            <span *ngIf="!assigning">Assign Developer</span>
            <span *ngIf="assigning">Assigning...</span>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .assign-developer-modal {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-backdrop {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      backdrop-filter: blur(3px);
    }

    .modal-content {
      position: relative;
      width: 90%;
      max-width: 700px;
      max-height: 90vh;
      background-color: white;
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #f0f0f0;
    }

    .modal-header h2 {
      margin: 0;
      color: var(--primary-dark);
    }

    .close-button {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: var(--gray);
      cursor: pointer;
      padding: 0;
      transition: var(--transition);
    }

    .close-button:hover {
      color: var(--dark);
      transform: none;
      box-shadow: none;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      max-height: calc(90vh - 130px);
    }

    .modal-footer {
      padding: 1rem 1.5rem;
      border-top: 1px solid #f0f0f0;
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
    }

    .loading-spinner {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .spinner {
      width: 40px;
      height: 40px;
      border: 3px solid rgba(98, 0, 234, 0.1);
      border-radius: 50%;
      border-top-color: var(--primary);
      animation: spin 1s ease-in-out infinite;
      margin-bottom: 1rem;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .empty-state {
      text-align: center;
      padding: 2rem;
      color: var(--gray);
    }

    .empty-state p {
      margin-bottom: 1rem;
    }

    .search-box {
      margin-bottom: 1.5rem;
    }

    .search-input {
      width: 100%;
      padding: 0.75rem 1rem;
      border: 1px solid var(--gray-light);
      border-radius: var(--radius);
      font-size: 1rem;
      transition: var(--transition);
    }

    .search-input:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(98, 0, 234, 0.1);
    }

    .developers-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 1rem;
    }

    .developer-card {
      border: 1px solid var(--gray-light);
      border-radius: var(--radius);
      padding: 1.5rem;
      cursor: pointer;
      transition: var(--transition);
      position: relative;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .developer-card:hover {
      border-color: var(--primary-light);
      transform: translateY(-3px);
      box-shadow: var(--shadow);
    }

    .developer-card.selected {
      border-color: var(--primary);
      background-color: rgba(98, 0, 234, 0.05);
    }

    .developer-card.selected .selection-indicator {
      position: absolute;
      top: 0;
      right: 0;
      width: 0;
      height: 0;
      border-style: solid;
      border-width: 0 30px 30px 0;
      border-color: transparent var(--primary) transparent transparent;
    }

    .developer-avatar {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background-color: var(--primary);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      font-weight: bold;
      margin-bottom: 1rem;
    }

    .developer-info {
      flex: 1;
    }

    .developer-info h3 {
      margin: 0 0 0.5rem 0;
      font-size: 1.1rem;
      color: var(--dark);
    }

    .developer-role {
      color: var(--primary);
      font-weight: 500;
      margin: 0 0 0.25rem 0;
    }

    .developer-skill {
      color: var(--gray);
      font-size: 0.9rem;
      margin: 0;
    }

    .btn-outline {
      background-color: transparent;
      border: 2px solid var(--primary);
      color: var(--primary);
    }

    .btn-outline:hover {
      background-color: var(--primary);
      color: white;
    }

    .btn-primary {
      background-color: var(--primary);
      color: white;
    }

    .btn-primary:hover {
      background-color: var(--primary-dark);
    }

    .btn-primary:disabled {
      background-color: var(--gray-light);
      cursor: not-allowed;
      transform: none;
      box-shadow: none;
    }

    @media (max-width: 768px) {
      .developers-grid {
        grid-template-columns: 1fr;
      }

      .developer-card {
        flex-direction: row;
        text-align: left;
        align-items: flex-start;
      }

      .developer-avatar {
        margin-right: 1rem;
        margin-bottom: 0;
      }
    }
  `]
})
export class AssignDeveloperComponent implements OnInit {
  @Input() teamId!: number;
  @Input() isVisible = false;
  @Output() close = new EventEmitter<void>();
  @Output() developerAssigned = new EventEmitter<void>();

  availableDevelopers: DeveloperResponse[] = [];
  selectedDeveloperId: number | null = null;
  searchTerm = '';
  loading = false;
  assigning = false;

  constructor(
    private developerService: DeveloperService,
    private teamService: TeamService
  ) {}

  ngOnInit(): void {
    if (this.isVisible) {
      this.loadAvailableDevelopers();
    }
  }

  ngOnChanges(): void {
    if (this.isVisible) {
      this.loadAvailableDevelopers();
    } else {
      this.resetForm();
    }
  }

  loadAvailableDevelopers(): void {
    this.loading = true;
    this.developerService.getAllDevelopers().subscribe({
      next: (developers) => {
        // Filter out developers already in the team
        this.availableDevelopers = developers.filter(dev => !dev.team || dev.team.id !== this.teamId);
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading developers', error);
        this.loading = false;
      }
    });
  }

  get filteredDevelopers(): DeveloperResponse[] {
    if (!this.searchTerm.trim()) {
      return this.availableDevelopers;
    }

    const term = this.searchTerm.toLowerCase().trim();
    return this.availableDevelopers.filter(dev =>
      dev.name.toLowerCase().includes(term) ||
      dev.role.toLowerCase().includes(term) ||
      (dev.skillLevel && dev.skillLevel.toLowerCase().includes(term))
    );
  }

  selectDeveloper(id: number): void {
    this.selectedDeveloperId = id;
  }

  assignDeveloper(): void {
    if (!this.selectedDeveloperId) return;

    this.assigning = true;
    this.teamService.assignDeveloperToTeam(this.teamId, this.selectedDeveloperId).subscribe({
      next: () => {
        this.assigning = false;
        this.developerAssigned.emit();
        this.onClose();
      },
      error: (error) => {
        console.error('Error assigning developer to team', error);
        this.assigning = false;
      }
    });
  }

  resetForm(): void {
    this.selectedDeveloperId = null;
    this.searchTerm = '';
  }

  onClose(): void {
    this.close.emit();
  }
}
