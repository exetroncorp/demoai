import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TeamService } from '../../../core/services/team.service';
import { TeamResponse } from '../../../core/models/team.model';
import { TeamPdfComponent } from '../team-pdf/team-pdf.component';

@Component({
  selector: 'app-team-list',
  standalone: true,
  imports: [CommonModule, RouterLink, TeamPdfComponent],
  template: `
    <div class="team-list-container">
      <div class="header">
        <h1>Teams</h1>
        <a routerLink="/teams/new" class="add-button">Add Team</a>
      </div>

      <app-team-pdf></app-team-pdf>

      <div class="team-list">
        <div *ngIf="loading" class="loading">Loading teams...</div>

        <div *ngIf="!loading && teams.length === 0" class="empty-state">
          <p>No teams found. Create your first team!</p>
          <a routerLink="/teams/new" class="add-button">Add Team</a>
        </div>

        <table *ngIf="!loading && teams.length > 0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Department</th>
              <th>Developers</th>
              <th>Projects</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let team of teams">
              <td>{{ team.name }}</td>
              <td>{{ team.department }}</td>
              <td>{{ team.developers?.length || 0 }}</td>
              <td>{{ team.projects?.length || 0 }}</td>
              <td class="actions">
                <a [routerLink]="['/teams', team.id]" class="view-button">View</a>
                <a [routerLink]="['/teams', team.id, 'edit']" class="edit-button">Edit</a>
                <button class="delete-button" (click)="deleteTeam(team.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .team-list-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    h1 {
      margin: 0;
      color: #333;
    }

    .add-button {
      display: inline-block;
      background-color: #3f51b5;
      color: white;
      padding: 0.5rem 1rem;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
      transition: background-color 0.3s;
    }

    .add-button:hover {
      background-color: #303f9f;
    }

    .team-list {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 1rem;
      text-align: left;
      border-bottom: 1px solid #eee;
    }

    th {
      background-color: #f5f5f5;
      font-weight: 500;
      color: #333;
    }

    .actions {
      display: flex;
      gap: 0.5rem;
    }

    .view-button, .edit-button {
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      text-decoration: none;
      font-size: 0.9rem;
    }

    .view-button {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .edit-button {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .delete-button {
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      background-color: #ffebee;
      color: #d32f2f;
      border: none;
      cursor: pointer;
      font-size: 0.9rem;
    }

    .loading, .empty-state {
      padding: 2rem;
      text-align: center;
      color: #666;
    }

    .empty-state p {
      margin-bottom: 1rem;
    }
  `]
})
export class TeamListComponent implements OnInit {
  teams: TeamResponse[] = [];
  loading = true;

  constructor(private teamService: TeamService) {}

  ngOnInit(): void {
    this.loadTeams();
  }

  loadTeams(): void {
    this.loading = true;
    this.teamService.getAllTeams().subscribe({
      next: (teams) => {
        this.teams = teams;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading teams', error);
        this.loading = false;
      }
    });
  }

  deleteTeam(id: number): void {
    if (confirm('Are you sure you want to delete this team?')) {
      this.teamService.deleteTeam(id).subscribe({
        next: () => {
          this.teams = this.teams.filter(team => team.id !== id);
        },
        error: (error) => {
          console.error('Error deleting team', error);
        }
      });
    }
  }
}
