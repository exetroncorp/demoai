import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProjectService } from '../../../core/services/project.service';
import { ProjectResponse } from '../../../core/models/project.model';

@Component({
  selector: 'app-assign-project',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="assign-project-modal" [class.visible]="isVisible">
      <div class="modal-backdrop" (click)="onClose()"></div>
      <div class="modal-content">
        <div class="modal-header">
          <h2>Assign Project to Team</h2>
          <button class="close-button" (click)="onClose()">✕</button>
        </div>
        
        <div class="modal-body">
          <div *ngIf="loading" class="loading">Loading projects...</div>
          
          <div *ngIf="!loading && availableProjects.length === 0" class="empty-state">
            <p>No available projects found.</p>
            <a routerLink="/projects/new" class="create-button">Create New Project</a>
          </div>
          
          <div *ngIf="!loading && availableProjects.length > 0" class="project-list">
            <div class="search-box">
              <input
                type="text"
                [(ngModel)]="searchTerm"
                placeholder="Search projects..."
                class="search-input"
              >
            </div>

            <div class="projects-grid">
              <div
                *ngFor="let project of filteredProjects"
                class="project-card"
                [class.selected]="selectedProjectId === project.id"
                (click)="selectProject(project.id)"
              >
                <div class="project-info">
                  <h3>{{ project.name }}</h3>
                  <p class="project-status">{{ project.status }}</p>
                  <p class="project-description">{{ project.description | slice:0:100 }}{{ project.description.length > 100 ? '...' : '' }}</p>
                </div>
                <div class="selection-indicator"></div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="modal-footer">
          <button class="cancel-button" (click)="onClose()">Cancel</button>
          <button 
            class="assign-button" 
            [disabled]="!selectedProjectId" 
            (click)="assignProject()"
          >
            Assign Project
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .assign-project-modal {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.3s ease, visibility 0.3s ease;
    }
    
    .assign-project-modal.visible {
      opacity: 1;
      visibility: visible;
    }
    
    .modal-backdrop {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }
    
    .modal-content {
      position: relative;
      width: 90%;
      max-width: 800px;
      max-height: 90vh;
      background-color: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      display: flex;
      flex-direction: column;
      transform: translateY(20px);
      transition: transform 0.3s ease;
      border: 1px solid var(--border);
    }
    
    .assign-project-modal.visible .modal-content {
      transform: translateY(0);
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid var(--border);
    }
    
    .modal-header h2 {
      margin: 0;
      color: var(--text-primary);
    }
    
    .close-button {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: var(--text-secondary);
      padding: 0.25rem;
      line-height: 1;
    }
    
    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }
    
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      padding: 1.5rem;
      border-top: 1px solid var(--border);
    }
    
    .loading {
      text-align: center;
      padding: 2rem;
      color: var(--text-secondary);
    }
    
    .empty-state {
      text-align: center;
      padding: 2rem;
    }
    
    .create-button {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      text-decoration: none;
      margin-top: 1rem;
    }
    
    .search-box {
      margin-bottom: 1.5rem;
    }
    
    .search-input {
      width: 100%;
      padding: 0.75rem 1rem;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      font-size: 1rem;
    }
    
    .projects-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1rem;
      max-height: 400px;
      overflow-y: auto;
    }
    
    .project-card {
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.25rem;
      cursor: pointer;
      position: relative;
      transition: var(--transition);
      background-color: var(--surface);
    }
    
    .project-card:hover {
      border-color: var(--primary-light);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
    }
    
    .project-card.selected {
      border-color: var(--primary);
      background-color: rgba(98, 0, 234, 0.05);
    }
    
    .project-card.selected::after {
      content: '✓';
      position: absolute;
      top: 1rem;
      right: 1rem;
      color: var(--primary);
      font-weight: bold;
    }
    
    .project-info h3 {
      margin-top: 0;
      margin-bottom: 0.5rem;
      color: var(--text-primary);
    }
    
    .project-status {
      display: inline-block;
      padding: 0.25rem 0.5rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      background-color: rgba(98, 0, 234, 0.1);
      color: var(--primary);
      margin-bottom: 0.75rem;
    }
    
    .project-description {
      color: var(--text-secondary);
      font-size: 0.9rem;
      margin: 0;
    }
    
    .cancel-button {
      padding: 0.75rem 1.5rem;
      background-color: transparent;
      color: var(--text-primary);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      cursor: pointer;
    }
    
    .assign-button {
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border: none;
      border-radius: var(--radius);
      cursor: pointer;
    }
    
    .assign-button:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }
  `]
})
export class AssignProjectComponent implements OnInit, OnChanges {
  @Input() teamId!: number;
  @Input() isVisible = false;
  @Output() close = new EventEmitter<void>();
  @Output() projectAssigned = new EventEmitter<void>();

  availableProjects: ProjectResponse[] = [];
  filteredProjects: ProjectResponse[] = [];
  selectedProjectId?: number;
  searchTerm = '';
  loading = false;

  constructor(private projectService: ProjectService) {}

  ngOnInit(): void {
    if (this.isVisible) {
      this.loadAvailableProjects();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['isVisible'] && changes['isVisible'].currentValue === true) {
      this.loadAvailableProjects();
    }
  }

  loadAvailableProjects(): void {
    this.loading = true;
    this.projectService.getAllProjects().subscribe({
      next: (projects) => {
        // Filter out projects already assigned to a team
        this.availableProjects = projects.filter(project => !project.team || project.team.id !== this.teamId);
        this.applyFilter();
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading projects', error);
        this.loading = false;
      }
    });
  }

  applyFilter(): void {
    if (!this.searchTerm.trim()) {
      this.filteredProjects = this.availableProjects;
      return;
    }

    const term = this.searchTerm.toLowerCase().trim();
    this.filteredProjects = this.availableProjects.filter(project =>
      project.name.toLowerCase().includes(term) ||
      project.description.toLowerCase().includes(term) ||
      project.status.toLowerCase().includes(term)
    );
  }

  selectProject(id: number): void {
    this.selectedProjectId = id;
  }

  assignProject(): void {
    if (!this.selectedProjectId) return;

    this.projectService.assignProjectToTeam(this.selectedProjectId, this.teamId).subscribe({
      next: () => {
        this.projectAssigned.emit();
        this.onClose();
      },
      error: (error) => {
        console.error('Error assigning project to team', error);
      }
    });
  }

  onClose(): void {
    this.selectedProjectId = undefined;
    this.searchTerm = '';
    this.close.emit();
  }
}
