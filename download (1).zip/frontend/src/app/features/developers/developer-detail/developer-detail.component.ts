import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { DeveloperService } from '../../../core/services/developer.service';
import { TeamService } from '../../../core/services/team.service';
import { DeveloperResponse } from '../../../core/models/developer.model';
import { TeamResponse } from '../../../core/models/team.model';
import { DeveloperPdfComponent } from '../developer-pdf/developer-pdf.component';

@Component({
  selector: 'app-developer-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, DeveloperPdfComponent],
  template: `
    <div class="developer-detail-container" *ngIf="developer">
      <div class="profile-header">
        <div class="profile-avatar" *ngIf="!developer.pictureUrl">{{ developer.name.charAt(0) }}</div>
        <div class="profile-avatar profile-avatar-img" *ngIf="developer.pictureUrl">
          <img [src]="developer.pictureUrl" [alt]="developer.name">
        </div>
        <div class="profile-info">
          <h1>{{ developer.name }}</h1>
          <div class="profile-meta">
            <span class="profile-role">{{ developer.role }}</span>
            <span class="profile-divider">•</span>
            <span class="profile-skill">{{ developer.skillLevel || 'Skill level not specified' }}</span>
          </div>
        </div>
        <div class="profile-actions">
          <a [routerLink]="['/developers', developer.id, 'edit']" class="edit-button">
            <span class="button-icon">✏️</span> Edit
          </a>
          <button class="delete-button" (click)="deleteDeveloper()">
            <span class="button-icon">🗑️</span> Delete
          </button>
        </div>
      </div>

      <div class="content-grid">
        <div class="main-content">
          <app-developer-pdf #pdfComponent></app-developer-pdf>
          <div class="info-card">
            <h2>Developer Information</h2>
            <div class="info-row">
              <span class="label">Full Name:</span>
              <span class="value">{{ developer.name }}</span>
            </div>
            <div class="info-row">
              <span class="label">Role:</span>
              <span class="value">{{ developer.role }}</span>
            </div>
            <div class="info-row">
              <span class="label">Email:</span>
              <span class="value email-value">
                <a href="mailto:{{ developer.email }}">{{ developer.email }}</a>
              </span>
            </div>
            <div class="info-row">
              <span class="label">Skill Level:</span>
              <span class="value">
                <span class="skill-badge">{{ developer.skillLevel || 'Not specified' }}</span>
              </span>
            </div>
            <div class="info-row">
              <span class="label">Team:</span>
              <span class="value" *ngIf="developer.team">
                <a [routerLink]="['/teams', developer.team.id]" class="team-link">{{ developer.team.name }}</a>
              </span>
              <span class="value not-assigned" *ngIf="!developer.team">Not assigned to a team</span>
            </div>
          </div>
        </div>

        <div class="side-content">
          <div class="team-section" *ngIf="!developer.team">
            <div class="section-header">
              <h2>Assign to Team</h2>
            </div>

            <div class="team-list">
              <div *ngIf="loading" class="loading-spinner">
                <div class="spinner"></div>
                <p>Loading teams...</p>
              </div>

              <div *ngIf="!loading && teams.length === 0" class="empty-state">
                <div class="empty-icon">🏢</div>
                <h3>No teams available</h3>
                <p>Create a team first to assign this developer</p>
                <a routerLink="/teams/new" class="btn-primary">Create Team</a>
              </div>

              <div *ngIf="!loading && teams.length > 0" class="team-cards">
                <div *ngFor="let team of teams" class="team-card">
                  <div class="team-card-header">
                    <h3>{{ team.name }}</h3>
                    <span class="team-department">{{ team.department || 'No department' }}</span>
                  </div>
                  <div class="team-card-body">
                    <div class="team-stat">
                      <span class="team-stat-value">{{ team.developers?.length || 0 }}</span>
                      <span class="team-stat-label">developers</span>
                    </div>
                  </div>
                  <div class="team-card-footer">
                    <button class="assign-button" (click)="assignToTeam(team.id)">
                      <span class="button-icon">➕</span> Assign to Team
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="team-section current-team-section" *ngIf="developer.team">
            <div class="section-header">
              <h2>Current Team</h2>
            </div>

            <div class="current-team">
              <div class="current-team-card">
                <div class="team-card-header">
                  <h3>{{ developer.team.name }}</h3>
                  <a [routerLink]="['/teams', developer.team.id]" class="view-team-link">View Team</a>
                </div>
                <div class="team-card-footer">
                  <button class="remove-button" (click)="removeFromTeam()">
                    <span class="button-icon">✕</span> Remove from Team
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .developer-detail-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
      animation: fadeIn 0.5s ease-in-out;
    }

    /* Profile Header */
    .profile-header {
      display: flex;
      align-items: center;
      margin-bottom: 2rem;
      padding: 2rem;
      background-color: white;
      border-radius: var(--radius);
      box-shadow: var(--shadow);
    }

    .profile-avatar {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      background-color: var(--primary);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 3rem;
      font-weight: bold;
      margin-right: 2rem;
      flex-shrink: 0;
      overflow: hidden;
    }

    .profile-avatar-img {
      background-color: transparent;
    }

    .profile-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .profile-info {
      flex: 1;
    }

    .profile-info h1 {
      margin: 0 0 0.5rem 0;
      color: var(--dark);
      font-size: 2.5rem;
      font-weight: 700;
    }

    .profile-meta {
      display: flex;
      align-items: center;
      color: var(--gray);
      font-size: 1.1rem;
    }

    .profile-role {
      color: var(--primary);
      font-weight: 600;
    }

    .profile-divider {
      margin: 0 0.75rem;
      color: var(--gray-light);
    }

    .profile-skill {
      font-weight: 500;
    }

    .profile-actions {
      display: flex;
      gap: 1rem;
    }

    .button-icon {
      margin-right: 0.5rem;
    }

    .edit-button {
      display: inline-flex;
      align-items: center;
      background-color: var(--primary);
      color: white;
      padding: 0.75rem 1.25rem;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
      box-shadow: var(--shadow);
    }

    .edit-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
      text-decoration: none;
    }

    .delete-button {
      display: inline-flex;
      align-items: center;
      background-color: var(--danger);
      color: white;
      padding: 0.75rem 1.25rem;
      border-radius: var(--radius);
      border: none;
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
      box-shadow: var(--shadow);
    }

    .delete-button:hover {
      background-color: #d32f2f;
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    /* Content Grid */
    .content-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 2rem;
    }

    /* Main Content */
    .info-card {
      background-color: white;
      border-radius: var(--radius);
      padding: 2rem;
      box-shadow: var(--shadow);
      transition: var(--transition);
    }

    .info-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
    }

    .info-card h2 {
      margin-top: 0;
      color: var(--primary-dark);
      margin-bottom: 1.5rem;
      font-size: 1.75rem;
      position: relative;
      padding-bottom: 0.75rem;
    }

    .info-card h2::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 50px;
      height: 3px;
      background-color: var(--primary);
      border-radius: 3px;
    }

    .info-row {
      display: flex;
      margin-bottom: 1rem;
      padding: 0.75rem 0;
      border-bottom: 1px solid #f0f0f0;
    }

    .info-row:last-child {
      border-bottom: none;
      margin-bottom: 0;
    }

    .label {
      font-weight: 600;
      width: 150px;
      color: var(--dark);
    }

    .value {
      color: var(--gray);
      font-weight: 500;
      flex: 1;
    }

    .email-value a {
      color: var(--primary);
      text-decoration: none;
      transition: var(--transition);
    }

    .email-value a:hover {
      color: var(--primary-dark);
      text-decoration: underline;
    }

    .skill-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      background-color: rgba(98, 0, 234, 0.1);
      color: var(--primary);
      border-radius: 20px;
      font-weight: 500;
    }

    .team-link {
      color: var(--primary);
      text-decoration: none;
      font-weight: 600;
      transition: var(--transition);
    }

    .team-link:hover {
      color: var(--primary-dark);
      text-decoration: underline;
    }

    .not-assigned {
      color: var(--gray-light);
      font-style: italic;
    }

    /* Side Content */
    .team-section {
      background-color: white;
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
      margin-bottom: 2rem;
    }

    .section-header {
      margin-bottom: 1.5rem;
      position: relative;
      padding-bottom: 0.75rem;
      border-bottom: 1px solid #f0f0f0;
    }

    .section-header h2 {
      margin: 0;
      color: var(--primary-dark);
      font-size: 1.5rem;
    }

    .loading-spinner {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .spinner {
      width: 40px;
      height: 40px;
      border: 3px solid rgba(98, 0, 234, 0.1);
      border-radius: 50%;
      border-top-color: var(--primary);
      animation: spin 1s ease-in-out infinite;
      margin-bottom: 1rem;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .empty-state {
      padding: 2rem;
      text-align: center;
      color: var(--gray);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }

    .empty-icon {
      font-size: 3rem;
      color: var(--gray-light);
      margin-bottom: 0.5rem;
    }

    .empty-state h3 {
      color: var(--dark);
      margin: 0;
    }

    .empty-state p {
      color: var(--gray);
      margin-bottom: 1rem;
    }

    .btn-primary {
      display: inline-block;
      background-color: var(--primary);
      color: white;
      padding: 0.75rem 1.25rem;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .btn-primary:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
      text-decoration: none;
    }

    .team-cards {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .team-card {
      border: 1px solid #f0f0f0;
      border-radius: var(--radius);
      overflow: hidden;
      transition: var(--transition);
    }

    .team-card:hover {
      border-color: var(--primary-light);
      transform: translateY(-3px);
      box-shadow: var(--shadow);
    }

    .team-card-header {
      padding: 1rem;
      border-bottom: 1px solid #f0f0f0;
    }

    .team-card-header h3 {
      margin: 0 0 0.25rem 0;
      color: var(--dark);
      font-size: 1.2rem;
    }

    .team-department {
      color: var(--gray);
      font-size: 0.9rem;
    }

    .team-card-body {
      padding: 1rem;
      background-color: #f9f9f9;
    }

    .team-stat {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .team-stat-value {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--primary);
    }

    .team-stat-label {
      color: var(--gray);
      font-size: 0.9rem;
    }

    .team-card-footer {
      padding: 1rem;
    }

    .assign-button {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      padding: 0.75rem;
      background-color: var(--success);
      color: white;
      border-radius: var(--radius);
      border: none;
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }

    .assign-button:hover {
      background-color: #00a844;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .current-team-section {
      background-color: #f0f7ff;
      border: 1px solid #d0e1fd;
    }

    .current-team-card {
      border: none;
      background-color: white;
      border-radius: var(--radius);
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    .view-team-link {
      display: inline-block;
      margin-top: 0.5rem;
      color: var(--primary);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .view-team-link:hover {
      color: var(--primary-dark);
      text-decoration: underline;
    }

    .remove-button {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      padding: 0.75rem;
      background-color: #ffebee;
      color: var(--danger);
      border-radius: var(--radius);
      border: none;
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }

    .remove-button:hover {
      background-color: var(--danger);
      color: white;
    }

    /* Responsive */
    @media (max-width: 992px) {
      .content-grid {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 768px) {
      .profile-header {
        flex-direction: column;
        text-align: center;
      }

      .profile-avatar {
        margin-right: 0;
        margin-bottom: 1rem;
      }

      .profile-actions {
        margin-top: 1.5rem;
        width: 100%;
        justify-content: center;
      }

      .label {
        width: 120px;
      }
    }
  `]
})
export class DeveloperDetailComponent implements OnInit {
  developer?: DeveloperResponse;
  teams: TeamResponse[] = [];
  loading = false;

  @ViewChild('pdfComponent') pdfComponent?: DeveloperPdfComponent;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private developerService: DeveloperService,
    private teamService: TeamService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.loadDeveloper(+id);
        this.loadTeams();
      }
    });
  }

  loadDeveloper(id: number): void {
    this.developerService.getDeveloperById(id).subscribe({
      next: (developer) => {
        this.developer = developer;
        if (this.pdfComponent && developer.team) {
          this.pdfComponent.setTeamId(developer.team.id);
        }
      },
      error: (error) => {
        console.error('Error loading developer', error);
        this.router.navigate(['/developers']);
      }
    });
  }

  loadTeams(): void {
    this.loading = true;
    this.teamService.getAllTeams().subscribe({
      next: (teams) => {
        this.teams = teams;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading teams', error);
        this.loading = false;
      }
    });
  }

  assignToTeam(teamId: number): void {
    if (!this.developer) return;

    this.teamService.assignDeveloperToTeam(teamId, this.developer.id).subscribe({
      next: () => {
        this.loadDeveloper(this.developer!.id);
      },
      error: (error) => {
        console.error('Error assigning developer to team', error);
      }
    });
  }

  removeFromTeam(): void {
    if (!this.developer || !this.developer.team) return;

    if (confirm('Are you sure you want to remove this developer from the team?')) {
      this.teamService.removeDeveloperFromTeam(this.developer.team.id, this.developer.id).subscribe({
        next: () => {
          this.loadDeveloper(this.developer!.id);
        },
        error: (error) => {
          console.error('Error removing developer from team', error);
        }
      });
    }
  }

  deleteDeveloper(): void {
    if (!this.developer) return;

    if (confirm('Are you sure you want to delete this developer? This action cannot be undone.')) {
      this.developerService.deleteDeveloper(this.developer.id).subscribe({
        next: () => {
          this.router.navigate(['/developers']);
        },
        error: (error) => {
          console.error('Error deleting developer', error);
        }
      });
    }
  }
}
