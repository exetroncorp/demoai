import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DeveloperService } from '../../../core/services/developer.service';
import { DeveloperResponse } from '../../../core/models/developer.model';
import { DeveloperPdfComponent } from '../developer-pdf/developer-pdf.component';

@Component({
  selector: 'app-developer-list',
  standalone: true,
  imports: [CommonModule, RouterLink, DeveloperPdfComponent],
  template: `
    <div class="developer-list-container">
      <div class="header">
        <h1>Developers</h1>
        <a routerLink="/developers/new" class="add-button">Add Developer</a>
      </div>

      <app-developer-pdf></app-developer-pdf>

      <div class="developer-list">
        <div *ngIf="loading" class="loading">Loading developers...</div>

        <div *ngIf="!loading && developers.length === 0" class="empty-state">
          <p>No developers found. Create your first developer!</p>
          <a routerLink="/developers/new" class="add-button">Add Developer</a>
        </div>

        <table *ngIf="!loading && developers.length > 0">
          <thead>
            <tr>
              <th>Photo</th>
              <th>Name</th>
              <th>Role</th>
              <th>Email</th>
              <th>Skill Level</th>
              <th>Team</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let developer of developers">
              <td class="photo-cell">
                <div class="developer-photo">
                  <img *ngIf="developer.pictureUrl" [src]="developer.pictureUrl" [alt]="developer.name">
                  <div *ngIf="!developer.pictureUrl" class="no-photo">{{ developer.name.charAt(0) }}</div>
                </div>
              </td>
              <td>{{ developer.name }}</td>
              <td>{{ developer.role }}</td>
              <td>{{ developer.email }}</td>
              <td>{{ developer.skillLevel }}</td>
              <td>{{ developer.team ? developer.team.name : 'Not Assigned' }}</td>
              <td class="actions">
                <a [routerLink]="['/developers', developer.id]" class="view-button">View</a>
                <a [routerLink]="['/developers', developer.id, 'edit']" class="edit-button">Edit</a>
                <button class="delete-button" (click)="deleteDeveloper(developer.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .developer-list-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    h1 {
      margin: 0;
      color: #333;
    }

    .add-button {
      display: inline-block;
      background-color: #3f51b5;
      color: white;
      padding: 0.5rem 1rem;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
      transition: background-color 0.3s;
    }

    .add-button:hover {
      background-color: #303f9f;
    }

    .developer-list {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 1rem;
      text-align: left;
      border-bottom: 1px solid #eee;
    }

    th {
      background-color: #f5f5f5;
      font-weight: 500;
      color: #333;
    }

    .actions {
      display: flex;
      gap: 0.5rem;
    }

    .photo-cell {
      width: 60px;
    }

    .developer-photo {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #e0e0e0;
    }

    .developer-photo img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .no-photo {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #3f51b5;
      color: white;
      font-weight: bold;
      font-size: 1.2rem;
    }

    .view-button, .edit-button {
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      text-decoration: none;
      font-size: 0.9rem;
    }

    .view-button {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .edit-button {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .delete-button {
      padding: 0.25rem 0.5rem;
      border-radius: 4px;
      background-color: #ffebee;
      color: #d32f2f;
      border: none;
      cursor: pointer;
      font-size: 0.9rem;
    }

    .loading, .empty-state {
      padding: 2rem;
      text-align: center;
      color: #666;
    }

    .empty-state p {
      margin-bottom: 1rem;
    }
  `]
})
export class DeveloperListComponent implements OnInit {
  developers: DeveloperResponse[] = [];
  loading = true;

  constructor(private developerService: DeveloperService) {}

  ngOnInit(): void {
    this.loadDevelopers();
  }

  loadDevelopers(): void {
    this.loading = true;
    this.developerService.getAllDevelopers().subscribe({
      next: (developers) => {
        this.developers = developers;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading developers', error);
        this.loading = false;
      }
    });
  }

  deleteDeveloper(id: number): void {
    if (confirm('Are you sure you want to delete this developer?')) {
      this.developerService.deleteDeveloper(id).subscribe({
        next: () => {
          this.developers = this.developers.filter(developer => developer.id !== id);
        },
        error: (error) => {
          console.error('Error deleting developer', error);
        }
      });
    }
  }
}
