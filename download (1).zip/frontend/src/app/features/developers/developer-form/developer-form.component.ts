import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DeveloperService } from '../../../core/services/developer.service';
import { DeveloperRequest } from '../../../core/models/developer.model';

@Component({
  selector: 'app-developer-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="developer-form-container">
      <h1>{{ isEditMode ? 'Edit Developer' : 'Create Developer' }}</h1>

      <form [formGroup]="developerForm" (ngSubmit)="onSubmit()">
        <div class="form-group">
          <label for="name">Name</label>
          <input
            type="text"
            id="name"
            formControlName="name"
            placeholder="Enter developer name"
          >
          <div *ngIf="developerForm.get('name')?.invalid && developerForm.get('name')?.touched" class="error-message">
            <span *ngIf="developerForm.get('name')?.errors?.['required']">Name is required</span>
            <span *ngIf="developerForm.get('name')?.errors?.['minlength']">Name must be at least 2 characters</span>
            <span *ngIf="developerForm.get('name')?.errors?.['maxlength']">Name must be less than 100 characters</span>
          </div>
        </div>

        <div class="form-group">
          <label for="role">Role</label>
          <input
            type="text"
            id="role"
            formControlName="role"
            placeholder="Enter developer role"
          >
          <div *ngIf="developerForm.get('role')?.invalid && developerForm.get('role')?.touched" class="error-message">
            <span *ngIf="developerForm.get('role')?.errors?.['required']">Role is required</span>
            <span *ngIf="developerForm.get('role')?.errors?.['maxlength']">Role must be less than 100 characters</span>
          </div>
        </div>

        <div class="form-group">
          <label for="email">Email</label>
          <input
            type="email"
            id="email"
            formControlName="email"
            placeholder="Enter developer email"
          >
          <div *ngIf="developerForm.get('email')?.invalid && developerForm.get('email')?.touched" class="error-message">
            <span *ngIf="developerForm.get('email')?.errors?.['required']">Email is required</span>
            <span *ngIf="developerForm.get('email')?.errors?.['email']">Please enter a valid email</span>
          </div>
        </div>

        <div class="form-group">
          <label for="skillLevel">Skill Level</label>
          <select id="skillLevel" formControlName="skillLevel">
            <option value="">Select skill level</option>
            <option value="Junior">Junior</option>
            <option value="Mid-level">Mid-level</option>
            <option value="Senior">Senior</option>
            <option value="Lead">Lead</option>
          </select>
          <div *ngIf="developerForm.get('skillLevel')?.invalid && developerForm.get('skillLevel')?.touched" class="error-message">
            <span *ngIf="developerForm.get('skillLevel')?.errors?.['maxlength']">Skill level must be less than 50 characters</span>
          </div>
        </div>

        <div class="form-group">
          <label for="pictureUrl">Profile Picture URL</label>
          <input
            type="text"
            id="pictureUrl"
            formControlName="pictureUrl"
            placeholder="Enter profile picture URL"
          >
          <div *ngIf="developerForm.get('pictureUrl')?.invalid && developerForm.get('pictureUrl')?.touched" class="error-message">
            <span *ngIf="developerForm.get('pictureUrl')?.errors?.['maxlength']">URL must be less than 255 characters</span>
          </div>
          <div class="picture-preview" *ngIf="developerForm.get('pictureUrl')?.value">
            <img [src]="developerForm.get('pictureUrl')?.value" alt="Profile preview">
          </div>
        </div>

        <div class="form-actions">
          <button type="button" class="cancel-button" (click)="onCancel()">Cancel</button>
          <button type="submit" class="submit-button" [disabled]="developerForm.invalid || loading">
            {{ isEditMode ? 'Update' : 'Create' }}
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .developer-form-container {
      max-width: 600px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }

    h1 {
      margin-bottom: 2rem;
      color: #333;
    }

    form {
      background-color: white;
      border-radius: 8px;
      padding: 2rem;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: #333;
    }

    input, select {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
    }

    input:focus, select:focus {
      outline: none;
      border-color: #3f51b5;
    }

    .error-message {
      color: #d32f2f;
      font-size: 0.9rem;
      margin-top: 0.5rem;
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2rem;
    }

    button {
      padding: 0.75rem 1.5rem;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .cancel-button {
      background-color: #f5f5f5;
      color: #333;
      border: 1px solid #ddd;
    }

    .cancel-button:hover {
      background-color: #e0e0e0;
    }

    .submit-button {
      background-color: #3f51b5;
      color: white;
      border: none;
    }

    .submit-button:hover {
      background-color: #303f9f;
    }

    .submit-button:disabled {
      background-color: #c5cae9;
      cursor: not-allowed;
    }

    .picture-preview {
      margin-top: 1rem;
      border: 1px solid #ddd;
      border-radius: 4px;
      padding: 0.5rem;
      max-width: 200px;
    }

    .picture-preview img {
      width: 100%;
      height: auto;
      border-radius: 4px;
    }
  `]
})
export class DeveloperFormComponent implements OnInit {
  developerForm: FormGroup;
  isEditMode = false;
  developerId?: number;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private developerService: DeveloperService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.developerForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      role: ['', [Validators.required, Validators.maxLength(100)]],
      email: ['', [Validators.required, Validators.email]],
      skillLevel: ['', [Validators.maxLength(50)]],
      pictureUrl: ['', [Validators.maxLength(255)]]
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id && id !== 'new') {
        this.isEditMode = true;
        this.developerId = +id;
        this.loadDeveloper(this.developerId);
      }
    });
  }

  loadDeveloper(id: number): void {
    this.loading = true;
    this.developerService.getDeveloperById(id).subscribe({
      next: (developer) => {
        this.developerForm.patchValue({
          name: developer.name,
          role: developer.role,
          email: developer.email,
          skillLevel: developer.skillLevel,
          pictureUrl: developer.pictureUrl
        });
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading developer', error);
        this.loading = false;
        this.router.navigate(['/developers']);
      }
    });
  }

  onSubmit(): void {
    if (this.developerForm.invalid) {
      return;
    }

    const developerRequest: DeveloperRequest = {
      name: this.developerForm.value.name,
      role: this.developerForm.value.role,
      email: this.developerForm.value.email,
      skillLevel: this.developerForm.value.skillLevel,
      pictureUrl: this.developerForm.value.pictureUrl
    };

    this.loading = true;

    if (this.isEditMode && this.developerId) {
      this.developerService.updateDeveloper(this.developerId, developerRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/developers']);
        },
        error: (error) => {
          console.error('Error updating developer', error);
          this.loading = false;
        }
      });
    } else {
      this.developerService.createDeveloper(developerRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/developers']);
        },
        error: (error) => {
          console.error('Error creating developer', error);
          this.loading = false;
        }
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/developers']);
  }
}
