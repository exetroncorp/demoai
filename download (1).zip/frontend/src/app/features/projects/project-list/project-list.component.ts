import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProjectService } from '../../../core/services/project.service';
import { ProjectResponse, ProjectStatus } from '../../../core/models/project.model';
import { ProjectPdfComponent } from '../project-pdf/project-pdf.component';

@Component({
  selector: 'app-project-list',
  standalone: true,
  imports: [CommonModule, RouterLink, ProjectPdfComponent],
  template: `
    <div class="project-list-container">
      <div class="header">
        <h1>Projects</h1>
        <a routerLink="/projects/new" class="add-button">Add Project</a>
      </div>

      <app-project-pdf></app-project-pdf>

      <div class="project-list">
        <div *ngIf="loading" class="loading">Loading projects...</div>

        <div *ngIf="!loading && projects.length === 0" class="empty-state">
          <p>No projects found. Create your first project!</p>
          <a routerLink="/projects/new" class="add-button">Add Project</a>
        </div>

        <table *ngIf="!loading && projects.length > 0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Status</th>
              <th>Team</th>
              <th>Tasks</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let project of projects">
              <td>{{ project.name }}</td>
              <td>
                <span class="status-badge" [ngClass]="getStatusClass(project.status)">
                  {{ project.status }}
                </span>
              </td>
              <td>{{ project.team ? project.team.name : 'Not Assigned' }}</td>
              <td>{{ project.tasks?.length || 0 }}</td>
              <td class="actions">
                <a [routerLink]="['/projects', project.id]" class="view-button">View</a>
                <a [routerLink]="['/projects', project.id, 'edit']" class="edit-button">Edit</a>
                <button class="delete-button" (click)="deleteProject(project.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .project-list-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    .add-button {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .add-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
      text-decoration: none;
    }

    .loading {
      text-align: center;
      padding: 2rem;
      font-size: 1.2rem;
      color: var(--gray);
    }

    .empty-state {
      text-align: center;
      padding: 3rem;
      background-color: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
    }

    .empty-state p {
      margin-bottom: 1.5rem;
      font-size: 1.2rem;
      color: var(--gray);
    }

    table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      border-radius: var(--radius);
      overflow: hidden;
      box-shadow: var(--shadow);
    }

    th, td {
      padding: 1rem;
      text-align: left;
    }

    th {
      background-color: rgba(98, 0, 234, 0.05);
      font-weight: 500;
      color: var(--primary-dark);
      border-bottom: 2px solid var(--primary-light);
    }

    tr:nth-child(even) {
      background-color: rgba(0, 0, 0, 0.02);
    }

    tr:hover {
      background-color: rgba(98, 0, 234, 0.05);
    }

    .actions {
      display: flex;
      gap: 0.5rem;
    }

    .view-button, .edit-button {
      padding: 0.5rem 1rem;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      font-size: 0.9rem;
      transition: var(--transition);
    }

    .view-button {
      background-color: var(--light);
      color: var(--primary);
    }

    .view-button:hover {
      background-color: var(--primary-light);
      color: white;
      text-decoration: none;
    }

    .edit-button {
      background-color: var(--secondary-light);
      color: var(--dark);
    }

    .edit-button:hover {
      background-color: var(--secondary);
      text-decoration: none;
    }

    .delete-button {
      padding: 0.5rem 1rem;
      border-radius: var(--radius);
      background-color: transparent;
      color: var(--danger);
      border: 1px solid var(--danger);
      font-weight: 500;
      font-size: 0.9rem;
    }

    .delete-button:hover {
      background-color: var(--danger);
      color: white;
    }

    .status-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 1rem;
      font-size: 0.85rem;
      font-weight: 500;
    }

    .status-planned {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .status-in-progress {
      background-color: #fff8e1;
      color: #ff8f00;
    }

    .status-completed {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .status-on-hold {
      background-color: #fce4ec;
      color: #d81b60;
    }

    .status-cancelled {
      background-color: #f5f5f5;
      color: #757575;
    }
  `]
})
export class ProjectListComponent implements OnInit {
  projects: ProjectResponse[] = [];
  loading = true;

  constructor(private projectService: ProjectService) {}

  ngOnInit(): void {
    this.loadProjects();
  }

  loadProjects(): void {
    this.loading = true;
    this.projectService.getAllProjects().subscribe({
      next: (projects) => {
        this.projects = projects;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading projects', error);
        this.loading = false;
      }
    });
  }

  deleteProject(id: number): void {
    if (confirm('Are you sure you want to delete this project?')) {
      this.projectService.deleteProject(id).subscribe({
        next: () => {
          this.projects = this.projects.filter(project => project.id !== id);
        },
        error: (error) => {
          console.error('Error deleting project', error);
        }
      });
    }
  }

  getStatusClass(status: string): string {
    switch (status) {
      case ProjectStatus.PLANNED:
        return 'status-planned';
      case ProjectStatus.IN_PROGRESS:
        return 'status-in-progress';
      case ProjectStatus.COMPLETED:
        return 'status-completed';
      case ProjectStatus.ON_HOLD:
        return 'status-on-hold';
      case ProjectStatus.CANCELLED:
        return 'status-cancelled';
      default:
        return '';
    }
  }
}
