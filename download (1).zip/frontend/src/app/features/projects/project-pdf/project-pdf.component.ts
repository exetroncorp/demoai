import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-project-pdf',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="pdf-actions">
      <h2>PDF Reports</h2>
      <div class="pdf-buttons">
        <button class="pdf-button" (click)="downloadAllProjectsPdf()">
          <span class="pdf-icon">📄</span>
          Download All Projects PDF
        </button>
        <button *ngIf="projectId" class="pdf-button" (click)="downloadProjectTasksPdf()">
          <span class="pdf-icon">📄</span>
          Download Project Tasks PDF
        </button>
      </div>
    </div>
  `,
  styles: [`
    .pdf-actions {
      background-color: var(--surface);
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
      margin-bottom: 2rem;
    }

    h2 {
      margin-top: 0;
      margin-bottom: 1.5rem;
      color: var(--text-primary);
      font-size: 1.5rem;
    }

    .pdf-buttons {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .pdf-button {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1rem;
      background-color: var(--primary);
      color: white;
      border: none;
      border-radius: var(--radius);
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }

    .pdf-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
    }

    .pdf-icon {
      font-size: 1.2rem;
    }

    @media (min-width: 768px) {
      .pdf-buttons {
        flex-direction: row;
      }
    }
  `]
})
export class ProjectPdfComponent {
  @Input() projectId?: number;

  constructor() {}

  setProjectId(projectId: number) {
    this.projectId = projectId;
  }

  downloadAllProjectsPdf() {
    const pdfUrl = `${environment.pdfServiceUrl}/api/pdf/projects`;
    this.openPdfInNewTab(pdfUrl);
  }

  downloadProjectTasksPdf() {
    if (!this.projectId) return;

    const pdfUrl = `${environment.pdfServiceUrl}/api/pdf/projects/${this.projectId}/tasks`;
    this.openPdfInNewTab(pdfUrl);
  }

  private openPdfInNewTab(url: string) {
    window.open(url, '_blank');
  }
}
