import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from '../../../core/services/project.service';
import { TeamService } from '../../../core/services/team.service';
import { ProjectRequest, ProjectStatus } from '../../../core/models/project.model';
import { TeamResponse } from '../../../core/models/team.model';

@Component({
  selector: 'app-project-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="project-form-container">
      <h1>{{ isEditMode ? 'Edit Project' : 'Create Project' }}</h1>
      
      <form [formGroup]="projectForm" (ngSubmit)="onSubmit()">
        <div class="form-group">
          <label for="name">Project Name</label>
          <input 
            type="text" 
            id="name" 
            formControlName="name" 
            placeholder="Enter project name"
          >
          <div *ngIf="projectForm.get('name')?.invalid && projectForm.get('name')?.touched" class="error-message">
            <span *ngIf="projectForm.get('name')?.errors?.['required']">Project name is required</span>
            <span *ngIf="projectForm.get('name')?.errors?.['minlength']">Project name must be at least 2 characters</span>
            <span *ngIf="projectForm.get('name')?.errors?.['maxlength']">Project name must be less than 100 characters</span>
          </div>
        </div>
        
        <div class="form-group">
          <label for="description">Description</label>
          <textarea 
            id="description" 
            formControlName="description" 
            rows="4" 
            placeholder="Enter project description"
          ></textarea>
          <div *ngIf="projectForm.get('description')?.invalid && projectForm.get('description')?.touched" class="error-message">
            <span *ngIf="projectForm.get('description')?.errors?.['required']">Description is required</span>
            <span *ngIf="projectForm.get('description')?.errors?.['maxlength']">Description must be less than 500 characters</span>
          </div>
        </div>
        
        <div class="form-row">
          <div class="form-group half-width">
            <label for="startDate">Start Date</label>
            <input 
              type="date" 
              id="startDate" 
              formControlName="startDate"
            >
          </div>
          
          <div class="form-group half-width">
            <label for="endDate">End Date</label>
            <input 
              type="date" 
              id="endDate" 
              formControlName="endDate"
            >
            <div *ngIf="projectForm.get('endDate')?.invalid && projectForm.get('endDate')?.touched" class="error-message">
              <span *ngIf="projectForm.get('endDate')?.errors?.['endDateAfterStart']">End date must be after start date</span>
            </div>
          </div>
        </div>
        
        <div class="form-group">
          <label for="status">Status</label>
          <select id="status" formControlName="status">
            <option [value]="ProjectStatus.PLANNED">Planned</option>
            <option [value]="ProjectStatus.IN_PROGRESS">In Progress</option>
            <option [value]="ProjectStatus.COMPLETED">Completed</option>
            <option [value]="ProjectStatus.ON_HOLD">On Hold</option>
            <option [value]="ProjectStatus.CANCELLED">Cancelled</option>
          </select>
          <div *ngIf="projectForm.get('status')?.invalid && projectForm.get('status')?.touched" class="error-message">
            <span *ngIf="projectForm.get('status')?.errors?.['required']">Status is required</span>
          </div>
        </div>
        
        <div class="form-group">
          <label for="teamId">Assign to Team</label>
          <select id="teamId" formControlName="teamId">
            <option [value]="null">-- Select Team --</option>
            <option *ngFor="let team of teams" [value]="team.id">{{ team.name }}</option>
          </select>
        </div>
        
        <div class="form-actions">
          <button type="button" class="cancel-button" (click)="onCancel()">Cancel</button>
          <button type="submit" class="submit-button" [disabled]="projectForm.invalid || loading">
            {{ isEditMode ? 'Update' : 'Create' }}
          </button>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .project-form-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }
    
    h1 {
      margin-bottom: 2rem;
      color: var(--text-primary);
    }
    
    form {
      background-color: var(--surface);
      border-radius: var(--radius);
      padding: 2rem;
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
    }
    
    .form-group {
      margin-bottom: 1.5rem;
    }
    
    .form-row {
      display: flex;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }
    
    .half-width {
      flex: 1;
      margin-bottom: 0;
    }
    
    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
    }
    
    input, select, textarea {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      font-size: 1rem;
      background-color: var(--surface);
      color: var(--text-primary);
    }
    
    .error-message {
      color: var(--danger);
      font-size: 0.85rem;
      margin-top: 0.5rem;
    }
    
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      margin-top: 2rem;
    }
    
    .cancel-button {
      padding: 0.75rem 1.5rem;
      background-color: transparent;
      color: var(--text-primary);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }
    
    .cancel-button:hover {
      background-color: var(--border);
    }
    
    .submit-button {
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }
    
    .submit-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
    }
    
    .submit-button:disabled {
      opacity: 0.7;
      cursor: not-allowed;
      transform: none;
    }
  `]
})
export class ProjectFormComponent implements OnInit {
  projectForm: FormGroup;
  isEditMode = false;
  projectId?: number;
  loading = false;
  teams: TeamResponse[] = [];
  ProjectStatus = ProjectStatus;

  constructor(
    private fb: FormBuilder,
    private projectService: ProjectService,
    private teamService: TeamService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.projectForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(100)]],
      description: ['', [Validators.required, Validators.maxLength(500)]],
      startDate: [''],
      endDate: [''],
      status: [ProjectStatus.PLANNED, [Validators.required]],
      teamId: [null]
    }, { validators: this.dateValidator });
  }

  ngOnInit(): void {
    this.loadTeams();
    
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id && id !== 'new') {
        this.isEditMode = true;
        this.projectId = +id;
        this.loadProject(this.projectId);
      }
    });
  }

  loadTeams(): void {
    this.teamService.getAllTeams().subscribe({
      next: (teams) => {
        this.teams = teams;
      },
      error: (error) => {
        console.error('Error loading teams', error);
      }
    });
  }

  loadProject(id: number): void {
    this.loading = true;
    this.projectService.getProjectById(id).subscribe({
      next: (project) => {
        this.projectForm.patchValue({
          name: project.name,
          description: project.description,
          startDate: project.startDate,
          endDate: project.endDate,
          status: project.status,
          teamId: project.team?.id || null
        });
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading project', error);
        this.loading = false;
        this.router.navigate(['/projects']);
      }
    });
  }

  dateValidator(group: FormGroup): { [key: string]: any } | null {
    const startDate = group.get('startDate')?.value;
    const endDate = group.get('endDate')?.value;
    
    if (startDate && endDate && new Date(endDate) < new Date(startDate)) {
      group.get('endDate')?.setErrors({ endDateAfterStart: true });
      return { endDateAfterStart: true };
    }
    
    return null;
  }

  onSubmit(): void {
    if (this.projectForm.invalid) {
      return;
    }

    const projectRequest: ProjectRequest = {
      name: this.projectForm.value.name,
      description: this.projectForm.value.description,
      startDate: this.projectForm.value.startDate,
      endDate: this.projectForm.value.endDate,
      status: this.projectForm.value.status,
      teamId: this.projectForm.value.teamId
    };

    this.loading = true;

    if (this.isEditMode && this.projectId) {
      this.projectService.updateProject(this.projectId, projectRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/projects']);
        },
        error: (error) => {
          console.error('Error updating project', error);
          this.loading = false;
        }
      });
    } else {
      this.projectService.createProject(projectRequest).subscribe({
        next: () => {
          this.loading = false;
          this.router.navigate(['/projects']);
        },
        error: (error) => {
          console.error('Error creating project', error);
          this.loading = false;
        }
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/projects']);
  }
}
