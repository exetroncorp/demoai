import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from '../../../core/services/project.service';
import { TaskService } from '../../../core/services/task.service';
import { ProjectResponse, ProjectStatus } from '../../../core/models/project.model';
import { TaskResponse, TaskStatus } from '../../../core/models/task.model';
import { ProjectPdfComponent } from '../project-pdf/project-pdf.component';

@Component({
  selector: 'app-project-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, ProjectPdfComponent],
  template: `
    <div class="project-detail-container" *ngIf="project">
      <div class="header">
        <div class="title-section">
          <h1>{{ project.name }}</h1>
          <span class="status-badge" [ngClass]="getStatusClass(project.status)">
            {{ project.status }}
          </span>
        </div>
        <div class="actions">
          <a [routerLink]="['/projects', project.id, 'edit']" class="edit-button">Edit Project</a>
          <button class="delete-button" (click)="deleteProject()">Delete Project</button>
        </div>
      </div>

      <div class="project-info">
        <app-project-pdf #pdfComponent></app-project-pdf>
        <div class="info-card">
          <h2>Project Details</h2>
          <div class="info-content">
            <div class="info-row">
              <span class="label">Description:</span>
              <span class="value">{{ project.description }}</span>
            </div>
            <div class="info-row">
              <span class="label">Team:</span>
              <span class="value">
                <a *ngIf="project.team" [routerLink]="['/teams', project.team.id]">{{ project.team.name }}</a>
                <span *ngIf="!project.team">Not assigned to a team</span>
              </span>
            </div>
            <div class="info-row">
              <span class="label">Start Date:</span>
              <span class="value">{{ project.startDate ? (project.startDate | date:'mediumDate') : 'Not specified' }}</span>
            </div>
            <div class="info-row">
              <span class="label">End Date:</span>
              <span class="value">{{ project.endDate ? (project.endDate | date:'mediumDate') : 'Not specified' }}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="tasks-section">
        <div class="section-header">
          <h2>Tasks</h2>
          <a [routerLink]="['/tasks/new']" [queryParams]="{projectId: project.id}" class="add-button">Add Task</a>
        </div>

        <div *ngIf="loading" class="loading">Loading tasks...</div>

        <div *ngIf="!loading && tasks.length === 0" class="empty-state">
          <p>No tasks found for this project.</p>
          <a [routerLink]="['/tasks/new']" [queryParams]="{projectId: project.id}" class="add-button">Add Task</a>
        </div>

        <div *ngIf="!loading && tasks.length > 0" class="task-list">
          <div class="task-card" *ngFor="let task of tasks">
            <div class="task-header">
              <h3 class="task-title">{{ task.title }}</h3>
              <span class="task-status" [ngClass]="getTaskStatusClass(task.status)">{{ task.status }}</span>
            </div>
            <p class="task-description">{{ task.description }}</p>
            <div class="task-meta">
              <div class="task-assignee" *ngIf="task.assignee">
                <span class="meta-label">Assignee:</span>
                <a [routerLink]="['/developers', task.assignee.id]">{{ task.assignee.name }}</a>
              </div>
              <div class="task-due-date" *ngIf="task.dueDate">
                <span class="meta-label">Due:</span>
                <span>{{ task.dueDate | date:'mediumDate' }}</span>
              </div>
            </div>
            <div class="task-actions">
              <a [routerLink]="['/tasks', task.id]" class="view-button">View</a>
              <a [routerLink]="['/tasks', task.id, 'edit']" class="edit-button">Edit</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .project-detail-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem 1rem;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    .title-section {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    h1 {
      margin: 0;
      color: var(--text-primary);
    }

    .status-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 1rem;
      font-size: 0.85rem;
      font-weight: 500;
    }

    .status-planned {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .status-in-progress {
      background-color: #fff8e1;
      color: #ff8f00;
    }

    .status-completed {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .status-on-hold {
      background-color: #fce4ec;
      color: #d81b60;
    }

    .status-cancelled {
      background-color: #f5f5f5;
      color: #757575;
    }

    .actions {
      display: flex;
      gap: 1rem;
    }

    .edit-button, .add-button {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .edit-button:hover, .add-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
      text-decoration: none;
    }

    .delete-button {
      padding: 0.75rem 1.5rem;
      background-color: transparent;
      color: var(--danger);
      border: 1px solid var(--danger);
      border-radius: var(--radius);
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }

    .delete-button:hover {
      background-color: var(--danger);
      color: white;
    }

    .project-info {
      margin-bottom: 2rem;
    }

    .info-card {
      background-color: var(--surface);
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
    }

    .info-card h2 {
      margin-top: 0;
      margin-bottom: 1.5rem;
      color: var(--text-primary);
      font-size: 1.5rem;
    }

    .info-content {
      display: grid;
      gap: 1rem;
    }

    .info-row {
      display: grid;
      grid-template-columns: 150px 1fr;
      gap: 1rem;
    }

    .label {
      font-weight: 500;
      color: var(--text-secondary);
    }

    .value {
      color: var(--text-primary);
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }

    .section-header h2 {
      margin: 0;
      color: var(--text-primary);
    }

    .loading {
      text-align: center;
      padding: 2rem;
      font-size: 1.2rem;
      color: var(--gray);
    }

    .empty-state {
      text-align: center;
      padding: 3rem;
      background-color: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
    }

    .empty-state p {
      margin-bottom: 1.5rem;
      font-size: 1.2rem;
      color: var(--text-secondary);
    }

    .task-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 1.5rem;
    }

    .task-card {
      background-color: var(--surface);
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
      border: 1px solid var(--border);
      transition: var(--transition);
    }

    .task-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
    }

    .task-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }

    .task-title {
      margin: 0;
      font-size: 1.2rem;
      color: var(--text-primary);
    }

    .task-status {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .task-status-todo {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .task-status-in-progress {
      background-color: #fff8e1;
      color: #ff8f00;
    }

    .task-status-review {
      background-color: #f3e5f5;
      color: #8e24aa;
    }

    .task-status-done {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .task-status-blocked {
      background-color: #ffebee;
      color: #d32f2f;
    }

    .task-description {
      margin-bottom: 1.5rem;
      color: var(--text-primary);
      font-size: 0.95rem;
      line-height: 1.5;
    }

    .task-meta {
      display: flex;
      justify-content: space-between;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }

    .meta-label {
      color: var(--text-secondary);
      margin-right: 0.5rem;
    }

    .task-actions {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
    }

    .view-button, .edit-button {
      padding: 0.5rem 1rem;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      font-size: 0.9rem;
      transition: var(--transition);
    }

    .view-button {
      background-color: var(--light);
      color: var(--primary);
    }

    .view-button:hover {
      background-color: var(--primary-light);
      color: white;
      text-decoration: none;
    }

    .edit-button {
      background-color: var(--secondary-light);
      color: var(--dark);
    }

    .edit-button:hover {
      background-color: var(--secondary);
      text-decoration: none;
    }

    @media (max-width: 768px) {
      .header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .actions {
        width: 100%;
      }

      .edit-button, .delete-button {
        flex: 1;
        text-align: center;
      }

      .info-row {
        grid-template-columns: 1fr;
      }

      .task-list {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class ProjectDetailComponent implements OnInit, AfterViewInit {
  @ViewChild('pdfComponent') pdfComponent?: ProjectPdfComponent;
  project?: ProjectResponse;
  tasks: TaskResponse[] = [];
  loading = true;

  constructor(
    private projectService: ProjectService,
    private taskService: TaskService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.loadProject(+id);
      }
    });
  }

  ngAfterViewInit(): void {
    if (this.project && this.pdfComponent) {
      this.pdfComponent.setProjectId(this.project.id);
    }
  }

  loadProject(id: number): void {
    this.loading = true;
    this.projectService.getProjectById(id).subscribe({
      next: (project) => {
        this.project = project;
        if (this.pdfComponent) {
          this.pdfComponent.setProjectId(project.id);
        }
        this.loadTasks(id);
      },
      error: (error) => {
        console.error('Error loading project', error);
        this.loading = false;
        this.router.navigate(['/projects']);
      }
    });
  }

  loadTasks(projectId: number): void {
    this.taskService.getTasksByProject(projectId).subscribe({
      next: (tasks) => {
        this.tasks = tasks;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading tasks', error);
        this.loading = false;
      }
    });
  }

  deleteProject(): void {
    if (!this.project) return;

    if (confirm(`Are you sure you want to delete the project "${this.project.name}"?`)) {
      this.projectService.deleteProject(this.project.id).subscribe({
        next: () => {
          this.router.navigate(['/projects']);
        },
        error: (error) => {
          console.error('Error deleting project', error);
        }
      });
    }
  }

  getStatusClass(status: string): string {
    switch (status) {
      case ProjectStatus.PLANNED:
        return 'status-planned';
      case ProjectStatus.IN_PROGRESS:
        return 'status-in-progress';
      case ProjectStatus.COMPLETED:
        return 'status-completed';
      case ProjectStatus.ON_HOLD:
        return 'status-on-hold';
      case ProjectStatus.CANCELLED:
        return 'status-cancelled';
      default:
        return '';
    }
  }

  getTaskStatusClass(status: string): string {
    switch (status) {
      case TaskStatus.TODO:
        return 'task-status-todo';
      case TaskStatus.IN_PROGRESS:
        return 'task-status-in-progress';
      case TaskStatus.REVIEW:
        return 'task-status-review';
      case TaskStatus.DONE:
        return 'task-status-done';
      case TaskStatus.BLOCKED:
        return 'task-status-blocked';
      default:
        return '';
    }
  }
}
