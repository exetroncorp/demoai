import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TeamService } from '../../core/services/team.service';
import { DeveloperService } from '../../core/services/developer.service';
import { ProjectService } from '../../core/services/project.service';
import { TeamResponse } from '../../core/models/team.model';
import { DeveloperResponse } from '../../core/models/developer.model';
import { ProjectResponse, ProjectStatus } from '../../core/models/project.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="dashboard">
      <div class="hero-section">
        <div class="hero-content">
          <h1>Welcome to Dev Team Manager</h1>
          <p class="hero-subtitle">Manage your development teams and resources efficiently</p>
          <div class="hero-actions">
            <a routerLink="/teams/new" class="btn-primary">Create Team</a>
            <a routerLink="/developers/new" class="btn-secondary">Add Developer</a>
            <a routerLink="/projects/new" class="btn-tertiary">New Project</a>
          </div>
        </div>
      </div>

      <div class="stats-container">
        <div class="stat-card">
          <div class="stat-icon">👥</div>
          <div class="stat-content">
            <h2>Teams</h2>
            <p class="stat-number">{{ teams.length }}</p>
            <p class="stat-description">Active development teams</p>
          </div>
          <a routerLink="/teams" class="view-all">View All Teams</a>
        </div>

        <div class="stat-card">
          <div class="stat-icon">👨‍💻</div>
          <div class="stat-content">
            <h2>Developers</h2>
            <p class="stat-number">{{ developers.length }}</p>
            <p class="stat-description">Skilled professionals</p>
          </div>
          <a routerLink="/developers" class="view-all">View All Developers</a>
        </div>

        <div class="stat-card">
          <div class="stat-icon">📋</div>
          <div class="stat-content">
            <h2>Projects</h2>
            <p class="stat-number">{{ projects.length }}</p>
            <p class="stat-description">Active projects</p>
          </div>
          <a routerLink="/projects" class="view-all">View All Projects</a>
        </div>
      </div>

      <div class="recent-container">
        <div class="recent-section">
          <div class="section-header">
            <h2>Recent Teams</h2>
            <a routerLink="/teams" class="view-all-small">View All</a>
          </div>
          <div class="list-container">
            <div *ngIf="teams.length === 0" class="empty-state">
              <p>No teams available</p>
              <a routerLink="/teams/new" class="btn-primary">Create Your First Team</a>
            </div>
            <ul *ngIf="teams.length > 0" class="entity-list">
              <li *ngFor="let team of teams.slice(0, 5)" class="entity-item">
                <div class="entity-info">
                  <a [routerLink]="['/teams', team.id]" class="entity-name">{{ team.name }}</a>
                  <span class="entity-meta">{{ team.department || 'No department' }}</span>
                </div>
                <div class="entity-actions">
                  <a [routerLink]="['/teams', team.id]" class="action-btn">View</a>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div class="recent-section">
          <div class="section-header">
            <h2>Recent Developers</h2>
            <a routerLink="/developers" class="view-all-small">View All</a>
          </div>
          <div class="list-container">
            <div *ngIf="developers.length === 0" class="empty-state">
              <p>No developers available</p>
              <a routerLink="/developers/new" class="btn-primary">Add Your First Developer</a>
            </div>
            <ul *ngIf="developers.length > 0" class="entity-list">
              <li *ngFor="let developer of developers.slice(0, 5)" class="entity-item">
                <div class="entity-info">
                  <a [routerLink]="['/developers', developer.id]" class="entity-name">{{ developer.name }}</a>
                  <span class="entity-meta">{{ developer.role }}</span>
                </div>
                <div class="entity-actions">
                  <a [routerLink]="['/developers', developer.id]" class="action-btn">View</a>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div class="recent-section">
          <div class="section-header">
            <h2>Recent Projects</h2>
            <a routerLink="/projects" class="view-all-small">View All</a>
          </div>
          <div class="list-container">
            <div *ngIf="projects.length === 0" class="empty-state">
              <p>No projects available</p>
              <a routerLink="/projects/new" class="btn-primary">Create Your First Project</a>
            </div>
            <ul *ngIf="projects.length > 0" class="entity-list">
              <li *ngFor="let project of projects.slice(0, 5)" class="entity-item">
                <div class="entity-info">
                  <a [routerLink]="['/projects', project.id]" class="entity-name">{{ project.name }}</a>
                  <span class="entity-meta">
                    <span class="status-badge-small" [ngClass]="getStatusClass(project.status)">{{ project.status }}</span>
                  </span>
                </div>
                <div class="entity-actions">
                  <a [routerLink]="['/projects', project.id]" class="action-btn">View</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard {
      max-width: 1200px;
      margin: 0 auto;
    }

    /* Hero Section */
    .hero-section {
      background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
      color: white;
      border-radius: var(--radius);
      padding: 3rem 2rem;
      margin-bottom: 2rem;
      text-align: center;
      box-shadow: var(--shadow);
      animation: fadeIn 0.5s ease-in-out;
    }

    .hero-content {
      max-width: 800px;
      margin: 0 auto;
    }

    .hero-section h1 {
      font-size: 2.5rem;
      margin-bottom: 1rem;
      color: white;
      font-weight: 700;
    }

    .hero-subtitle {
      font-size: 1.2rem;
      margin-bottom: 2rem;
      opacity: 0.9;
    }

    .hero-actions {
      display: flex;
      justify-content: center;
      gap: 1rem;
    }

    .btn-primary, .btn-secondary, .btn-tertiary {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      border-radius: var(--radius);
      font-weight: 500;
      text-decoration: none;
      transition: var(--transition);
    }

    .btn-primary {
      background-color: var(--secondary);
      color: var(--dark);
    }

    .btn-primary:hover {
      background-color: var(--secondary-dark);
      transform: translateY(-3px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      text-decoration: none;
    }

    .btn-secondary {
      background-color: rgba(255, 255, 255, 0.2);
      color: white;
      backdrop-filter: blur(5px);
    }

    .btn-secondary:hover {
      background-color: rgba(255, 255, 255, 0.3);
      transform: translateY(-3px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      text-decoration: none;
    }

    .btn-tertiary {
      background-color: rgba(255, 255, 255, 0.1);
      color: white;
      backdrop-filter: blur(5px);
    }

    .btn-tertiary:hover {
      background-color: rgba(255, 255, 255, 0.2);
      transform: translateY(-3px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      text-decoration: none;
    }

    /* Stats Section */
    .stats-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .stat-card {
      background-color: white;
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
      display: flex;
      flex-direction: column;
      transition: var(--transition);
      position: relative;
      overflow: hidden;
    }

    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
    }

    .stat-icon {
      font-size: 2.5rem;
      margin-bottom: 1rem;
      color: var(--primary);
    }

    .stat-content {
      flex: 1;
    }

    .stat-card h2 {
      margin-top: 0;
      color: var(--primary-dark);
      font-size: 1.5rem;
      margin-bottom: 0.5rem;
    }

    .stat-number {
      font-size: 2.5rem;
      font-weight: bold;
      margin: 0.5rem 0;
      color: var(--dark);
    }

    .stat-description {
      color: var(--gray);
      margin-bottom: 1rem;
    }

    .view-all {
      display: inline-block;
      color: var(--primary);
      text-decoration: none;
      font-weight: 500;
      margin-top: auto;
      padding-top: 1rem;
      border-top: 1px solid #f0f0f0;
      transition: var(--transition);
    }

    .view-all:hover {
      color: var(--primary-dark);
      text-decoration: none;
    }

    .quick-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      margin-top: 1rem;
    }

    .quick-action-btn {
      flex: 1;
      min-width: 120px;
      padding: 0.75rem 1rem;
      background-color: var(--light);
      color: var(--primary);
      border-radius: var(--radius);
      text-align: center;
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .quick-action-btn:hover {
      background-color: var(--primary);
      color: white;
      transform: translateY(-2px);
      text-decoration: none;
    }

    /* Recent Sections */
    .recent-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .recent-section {
      background-color: white;
      border-radius: var(--radius);
      padding: 1.5rem;
      box-shadow: var(--shadow);
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }

    .section-header h2 {
      margin: 0;
      color: var(--primary-dark);
      font-size: 1.5rem;
    }

    .view-all-small {
      color: var(--primary);
      text-decoration: none;
      font-size: 0.9rem;
      font-weight: 500;
    }

    .list-container {
      min-height: 300px;
    }

    .entity-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .entity-item {
      padding: 1rem;
      border-bottom: 1px solid #f0f0f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: var(--transition);
    }

    .entity-item:hover {
      background-color: rgba(98, 0, 234, 0.03);
    }

    .entity-item:last-child {
      border-bottom: none;
    }

    .entity-info {
      display: flex;
      flex-direction: column;
    }

    .entity-name {
      color: var(--dark);
      text-decoration: none;
      font-weight: 500;
      margin-bottom: 0.25rem;
    }

    .entity-name:hover {
      color: var(--primary);
    }

    .entity-meta {
      color: var(--gray);
      font-size: 0.9rem;
    }

    .status-badge-small {
      display: inline-block;
      padding: 0.15rem 0.5rem;
      border-radius: 1rem;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .status-planned {
      background-color: #e3f2fd;
      color: #1976d2;
    }

    .status-in-progress {
      background-color: #fff8e1;
      color: #ff8f00;
    }

    .status-completed {
      background-color: #e8f5e9;
      color: #388e3c;
    }

    .status-on-hold {
      background-color: #fce4ec;
      color: #d81b60;
    }

    .status-cancelled {
      background-color: #f5f5f5;
      color: #757575;
    }

    .entity-actions {
      display: flex;
      gap: 0.5rem;
    }

    .action-btn {
      padding: 0.4rem 0.75rem;
      background-color: var(--light);
      color: var(--primary);
      border-radius: var(--radius);
      text-decoration: none;
      font-size: 0.9rem;
      font-weight: 500;
      transition: var(--transition);
    }

    .action-btn:hover {
      background-color: var(--primary);
      color: white;
      text-decoration: none;
    }

    .empty-state {
      color: var(--gray);
      text-align: center;
      padding: 3rem 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .hero-section {
        padding: 2rem 1rem;
      }

      .hero-section h1 {
        font-size: 2rem;
      }

      .hero-subtitle {
        font-size: 1rem;
      }

      .hero-actions {
        flex-direction: column;
        gap: 0.75rem;
      }

      .stats-container,
      .recent-container {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class DashboardComponent implements OnInit {
  teams: TeamResponse[] = [];
  developers: DeveloperResponse[] = [];
  projects: ProjectResponse[] = [];

  constructor(
    private teamService: TeamService,
    private developerService: DeveloperService,
    private projectService: ProjectService
  ) {}

  ngOnInit(): void {
    this.loadTeams();
    this.loadDevelopers();
    this.loadProjects();
  }

  loadTeams(): void {
    this.teamService.getAllTeams().subscribe({
      next: (teams) => {
        this.teams = teams;
      },
      error: (error) => {
        console.error('Error loading teams', error);
      }
    });
  }

  loadDevelopers(): void {
    this.developerService.getAllDevelopers().subscribe({
      next: (developers) => {
        this.developers = developers;
      },
      error: (error) => {
        console.error('Error loading developers', error);
      }
    });
  }

  loadProjects(): void {
    this.projectService.getAllProjects().subscribe({
      next: (projects) => {
        this.projects = projects;
      },
      error: (error) => {
        console.error('Error loading projects', error);
      }
    });
  }

  getStatusClass(status: string): string {
    switch (status) {
      case ProjectStatus.PLANNED:
        return 'status-planned';
      case ProjectStatus.IN_PROGRESS:
        return 'status-in-progress';
      case ProjectStatus.COMPLETED:
        return 'status-completed';
      case ProjectStatus.ON_HOLD:
        return 'status-on-hold';
      case ProjectStatus.CANCELLED:
        return 'status-cancelled';
      default:
        return '';
    }
  }
}
