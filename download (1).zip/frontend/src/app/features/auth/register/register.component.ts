import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="register-container">
      <div class="register-card">
        <h2>Sign Up</h2>
        
        <form *ngIf="!isSuccessful" name="form" (ngSubmit)="f.form.valid && onSubmit()" #f="ngForm" novalidate>
          <div class="form-group">
            <label for="username">Username</label>
            <input
              type="text"
              class="form-control"
              name="username"
              [(ngModel)]="form.username"
              required
              minlength="3"
              maxlength="20"
              #username="ngModel"
              [ngClass]="{ 'is-invalid': f.submitted && username.errors }"
            />
            <div *ngIf="username.errors && f.submitted" class="error-message">
              <div *ngIf="username.errors['required']">Username is required</div>
              <div *ngIf="username.errors['minlength']">
                Username must be at least 3 characters
              </div>
              <div *ngIf="username.errors['maxlength']">
                Username must be at most 20 characters
              </div>
            </div>
          </div>
          
          <div class="form-group">
            <label for="email">Email</label>
            <input
              type="email"
              class="form-control"
              name="email"
              [(ngModel)]="form.email"
              required
              email
              #email="ngModel"
              [ngClass]="{ 'is-invalid': f.submitted && email.errors }"
            />
            <div *ngIf="email.errors && f.submitted" class="error-message">
              <div *ngIf="email.errors['required']">Email is required</div>
              <div *ngIf="email.errors['email']">
                Email must be a valid email address
              </div>
            </div>
          </div>
          
          <div class="form-group">
            <label for="password">Password</label>
            <input
              type="password"
              class="form-control"
              name="password"
              [(ngModel)]="form.password"
              required
              minlength="6"
              #password="ngModel"
              [ngClass]="{ 'is-invalid': f.submitted && password.errors }"
            />
            <div *ngIf="password.errors && f.submitted" class="error-message">
              <div *ngIf="password.errors['required']">Password is required</div>
              <div *ngIf="password.errors['minlength']">
                Password must be at least 6 characters
              </div>
            </div>
          </div>
          
          <div class="form-actions">
            <button class="submit-button">Sign Up</button>
          </div>
          
          <div class="form-footer">
            <p>Already have an account? <a routerLink="/login">Sign in</a></p>
          </div>
        </form>

        <div *ngIf="isSuccessful" class="success-message">
          <p>Your registration is successful!</p>
          <a routerLink="/login" class="login-link">Proceed to Login</a>
        </div>

        <div *ngIf="isSignUpFailed" class="error-message">
          Registration failed: {{ errorMessage }}
        </div>
      </div>
    </div>
  `,
  styles: [`
    .register-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: calc(100vh - 200px);
      padding: 2rem 1rem;
    }

    .register-card {
      background-color: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      padding: 2rem;
      width: 100%;
      max-width: 450px;
      border: 1px solid var(--border);
    }

    .dark-theme .register-card {
      background-color: var(--card-bg);
    }

    h2 {
      text-align: center;
      margin-bottom: 2rem;
      color: var(--primary);
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
    }

    input {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      font-size: 1rem;
      background-color: var(--surface);
      color: var(--text-primary);
    }

    .dark-theme input {
      background-color: var(--input-bg);
    }

    input:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.1);
    }

    .is-invalid {
      border-color: var(--danger) !important;
    }

    .error-message {
      color: var(--danger);
      font-size: 0.85rem;
      margin-top: 0.5rem;
    }

    .success-message {
      text-align: center;
      color: var(--success);
      margin-top: 1rem;
    }

    .form-actions {
      margin-top: 2rem;
    }

    .submit-button {
      width: 100%;
      padding: 0.75rem;
      background-color: var(--primary);
      color: white;
      border: none;
      border-radius: var(--radius);
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }

    .submit-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
    }

    .form-footer {
      margin-top: 1.5rem;
      text-align: center;
      color: var(--text-secondary);
    }

    .form-footer a, .login-link {
      color: var(--primary);
      text-decoration: none;
      font-weight: 500;
    }

    .form-footer a:hover, .login-link:hover {
      text-decoration: underline;
    }

    .login-link {
      display: inline-block;
      margin-top: 1rem;
      padding: 0.5rem 1rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      transition: var(--transition);
    }

    .login-link:hover {
      background-color: var(--primary-dark);
      text-decoration: none;
      transform: translateY(-2px);
      box-shadow: var(--shadow);
    }
  `]
})
export class RegisterComponent implements OnInit {
  form: any = {
    username: null,
    email: null,
    password: null
  };
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
  }

  onSubmit(): void {
    const { username, email, password } = this.form;

    this.authService.register(username, email, password).subscribe({
      next: data => {
        this.isSuccessful = true;
        this.isSignUpFailed = false;
      },
      error: err => {
        this.errorMessage = err.error.message || 'Registration failed. Please try again.';
        this.isSignUpFailed = true;
      }
    });
  }
}
