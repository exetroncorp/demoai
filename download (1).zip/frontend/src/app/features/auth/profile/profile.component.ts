import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TokenStorageService } from '../../../core/services/token-storage.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="profile-container">
      <div class="profile-card">
        <h2>User Profile</h2>
        
        <div *ngIf="currentUser; else loggedOut">
          <div class="profile-info">
            <div class="info-item">
              <span class="label">Username:</span>
              <span class="value">{{ currentUser.username }}</span>
            </div>
            
            <div class="info-item">
              <span class="label">Email:</span>
              <span class="value">{{ currentUser.email }}</span>
            </div>
            
            <div class="info-item">
              <span class="label">Roles:</span>
              <ul class="roles-list">
                <li *ngFor="let role of currentUser.roles">{{ role }}</li>
              </ul>
            </div>
          </div>
          
          <div class="profile-actions">
            <a routerLink="/" class="back-button">Back to Dashboard</a>
          </div>
        </div>
        
        <ng-template #loggedOut>
          <div class="not-logged-in">
            <p>Please login to view your profile.</p>
            <a routerLink="/login" class="login-button">Login</a>
          </div>
        </ng-template>
      </div>
    </div>
  `,
  styles: [`
    .profile-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: calc(100vh - 200px);
      padding: 2rem 1rem;
    }

    .profile-card {
      background-color: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      padding: 2rem;
      width: 100%;
      max-width: 600px;
      border: 1px solid var(--border);
    }

    .dark-theme .profile-card {
      background-color: var(--card-bg);
    }

    h2 {
      text-align: center;
      margin-bottom: 2rem;
      color: var(--primary);
    }

    .profile-info {
      margin-bottom: 2rem;
    }

    .info-item {
      margin-bottom: 1rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid var(--border);
    }

    .info-item:last-child {
      border-bottom: none;
    }

    .label {
      display: block;
      font-weight: 500;
      color: var(--text-secondary);
      margin-bottom: 0.5rem;
    }

    .value {
      font-size: 1.1rem;
      color: var(--text-primary);
    }

    .roles-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .roles-list li {
      display: inline-block;
      background-color: var(--primary-light);
      color: white;
      padding: 0.25rem 0.75rem;
      border-radius: 1rem;
      margin-right: 0.5rem;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
    }

    .profile-actions {
      text-align: center;
      margin-top: 2rem;
    }

    .back-button {
      display: inline-block;
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .back-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
      text-decoration: none;
    }

    .not-logged-in {
      text-align: center;
      color: var(--text-secondary);
    }

    .login-button {
      display: inline-block;
      margin-top: 1rem;
      padding: 0.75rem 1.5rem;
      background-color: var(--primary);
      color: white;
      border-radius: var(--radius);
      text-decoration: none;
      font-weight: 500;
      transition: var(--transition);
    }

    .login-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
      text-decoration: none;
    }
  `]
})
export class ProfileComponent implements OnInit {
  currentUser: any;

  constructor(private token: TokenStorageService) { }

  ngOnInit(): void {
    this.currentUser = this.token.getUser();
  }
}
