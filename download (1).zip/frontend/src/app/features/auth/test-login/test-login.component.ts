import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-test-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container">
      <h2>Test Login</h2>
      
      <div class="form-group">
        <label for="username">Username</label>
        <input type="text" id="username" [(ngModel)]="username" class="form-control">
      </div>
      
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" [(ngModel)]="password" class="form-control">
      </div>
      
      <button (click)="login()" class="btn btn-primary">Login</button>
      <button (click)="checkUser()" class="btn btn-secondary">Check User</button>
      
      <div *ngIf="result" class="result">
        <h3>Result:</h3>
        <pre>{{ result | json }}</pre>
      </div>
    </div>
  `,
  styles: [`
    .container {
      max-width: 600px;
      margin: 2rem auto;
      padding: 2rem;
      border: 1px solid #ddd;
      border-radius: 8px;
      background-color: var(--surface);
    }
    
    .form-group {
      margin-bottom: 1rem;
    }
    
    label {
      display: block;
      margin-bottom: 0.5rem;
    }
    
    .form-control {
      width: 100%;
      padding: 0.5rem;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    
    .btn {
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-right: 0.5rem;
    }
    
    .btn-primary {
      background-color: var(--primary);
      color: white;
    }
    
    .btn-secondary {
      background-color: #6c757d;
      color: white;
    }
    
    .result {
      margin-top: 2rem;
      padding: 1rem;
      background-color: #f8f9fa;
      border-radius: 4px;
    }
    
    pre {
      white-space: pre-wrap;
      word-wrap: break-word;
    }
  `]
})
export class TestLoginComponent {
  username = 'zoubida';
  password = 'zoubida21';
  result: any = null;
  
  constructor(private http: HttpClient) {}
  
  login() {
    this.http.post(`${environment.apiUrl}/simple-auth/login`, {
      username: this.username,
      password: this.password
    }).subscribe({
      next: (response) => {
        this.result = response;
        console.log('Login successful', response);
      },
      error: (error) => {
        this.result = error;
        console.error('Login failed', error);
      }
    });
  }
  
  checkUser() {
    this.http.get(`${environment.apiUrl}/simple-auth/check-user/${this.username}`).subscribe({
      next: (response) => {
        this.result = response;
        console.log('User check', response);
      },
      error: (error) => {
        this.result = error;
        console.error('User check failed', error);
      }
    });
  }
}
