import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { TokenStorageService } from '../../../core/services/token-storage.service';
import { AuthEventService } from '../../../core/services/auth-event.service';

@Component({
  selector: 'app-simple-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="login-container">
      <div class="login-card">
        <h2>Login</h2>

        <form *ngIf="!isLoggedIn" name="form" (ngSubmit)="onSubmit()" #f="ngForm" novalidate>
          <div class="form-group">
            <label for="username">Username</label>
            <input
              type="text"
              class="form-control"
              name="username"
              [(ngModel)]="form.username"
              required
              #username="ngModel"
            />
            <div *ngIf="username.errors && f.submitted" class="error-message">
              Username is required!
            </div>
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input
              type="password"
              class="form-control"
              name="password"
              [(ngModel)]="form.password"
              required
              #password="ngModel"
            />
            <div *ngIf="password.errors && f.submitted" class="error-message">
              Password is required
            </div>
          </div>

          <div class="form-actions">
            <button class="submit-button">Login</button>
          </div>

          <div class="form-footer">
            <p>Default credentials: zoubida / zoubida21</p>
          </div>
        </form>

        <div *ngIf="isLoggedIn" class="logged-in-message">
          <p>You are logged in as {{ username }}.</p>
          <button class="submit-button" (click)="navigateToDashboard()">Go to Dashboard</button>
        </div>

        <div *ngIf="isLoginFailed" class="error-message">
          Login failed: {{ errorMessage }}
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: calc(100vh - 200px);
      padding: 2rem 1rem;
    }

    .login-card {
      background-color: var(--surface);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      padding: 2rem;
      width: 100%;
      max-width: 450px;
      border: 1px solid var(--border);
    }

    .dark-theme .login-card {
      background-color: var(--card-bg);
    }

    h2 {
      text-align: center;
      margin-bottom: 2rem;
      color: var(--primary);
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
    }

    input {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      font-size: 1rem;
      background-color: var(--surface);
      color: var(--text-primary);
    }

    .dark-theme input {
      background-color: var(--input-bg);
    }

    input:focus {
      outline: none;
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.1);
    }

    .error-message {
      color: var(--danger);
      font-size: 0.85rem;
      margin-top: 0.5rem;
    }

    .form-actions {
      margin-top: 2rem;
    }

    .submit-button {
      width: 100%;
      padding: 0.75rem;
      background-color: var(--primary);
      color: white;
      border: none;
      border-radius: var(--radius);
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      transition: var(--transition);
    }

    .submit-button:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: var(--shadow);
    }

    .form-footer {
      margin-top: 1.5rem;
      text-align: center;
      color: var(--text-secondary);
    }

    .logged-in-message {
      text-align: center;
      margin-top: 1rem;
    }
  `]
})
export class SimpleLoginComponent implements OnInit {
  form: any = {
    username: 'zoubida',
    password: 'zoubida21'
  };
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  username = '';
  returnUrl = '/';

  constructor(
    private http: HttpClient,
    private tokenStorage: TokenStorageService,
    private authEventService: AuthEventService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    // Get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

    if (this.tokenStorage.getToken()) {
      this.isLoggedIn = true;
      this.username = this.tokenStorage.getUser().username;

      // If already logged in, redirect to return URL
      setTimeout(() => {
        this.router.navigate([this.returnUrl]);
      }, 1000);
    }
  }

  onSubmit(): void {
    const { username, password } = this.form;

    console.log('Attempting login with:', { username, password: '******' });

    // Bypass the login process completely
    const mockUser = {
      id: 1,
      username: 'zoubida',
      email: 'zoubida@example.com',
      roles: ['ADMIN'],
      accessToken: 'dummy-token-' + Date.now(),
      tokenType: 'Bearer'
    };

    this.tokenStorage.saveToken(mockUser.accessToken);
    this.tokenStorage.saveUser(mockUser);

    this.isLoginFailed = false;
    this.isLoggedIn = true;
    this.username = this.tokenStorage.getUser().username;

    setTimeout(() => {
      this.router.navigate([this.returnUrl]);
    }, 1500);

    /* Uncomment this when the backend is working
    this.http.get(`${environment.apiUrl}/bypass/login`).subscribe({
      next: (data: any) => {
        console.log('Login successful:', data);
        this.tokenStorage.saveToken(data.accessToken);
        this.tokenStorage.saveUser(data);

        this.isLoginFailed = false;
        this.isLoggedIn = true;
        this.username = this.tokenStorage.getUser().username;

        setTimeout(() => {
          this.router.navigate(['/']);
        }, 1500);
      },
      error: (err) => {
        console.error('Login error:', err);
        this.errorMessage = err.error?.message || 'Invalid username or password';
        this.isLoginFailed = true;
      }
    });
    */
  }

  navigateToDashboard(): void {
    this.router.navigate([this.returnUrl]);
  }
}
