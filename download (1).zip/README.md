# Dev Team Manager

A Spring Boot application for managing development teams, developers, projects, and tasks, following Domain-Driven Design (DDD) principles and Hexagonal Architecture.

## Features

- Team management
- Developer management
- Project management
- Task management
- RESTful API
- H2 in-memory database
- OpenAPI documentation

## Architecture

This application follows the principles of Domain-Driven Design (DDD) and Hexagonal Architecture (Ports and Adapters):

- **Domain Layer**: Contains the core business logic, domain models, and repository interfaces (ports)
- **Application Layer**: Contains the application services that implement use cases
- **Infrastructure Layer**: Contains the adapters for external systems (persistence, web, etc.)

## Technologies

- Java 17
- Spring Boot 3.2.1
- Spring Data JPA
- H2 Database
- Cucumber for BDD
- JUnit 5 for unit testing
- SpringDoc OpenAPI for API documentation

## Getting Started

### Prerequisites

- Java 17 or higher
- Maven 3.6 or higher

### Running the Application

```bash
mvn spring-boot:run
```

The application will start on port 8080 by default.

### Accessing the H2 Console

The H2 console is available at: http://localhost:8080/h2-console

- JDBC URL: `jdbc:h2:mem:devteamdb`
- Username: `sa`
- Password: `password`

### Accessing the API Documentation

The OpenAPI documentation is available at: http://localhost:8080/swagger-ui.html

## Testing

### Running Unit Tests

```bash
mvn test
```

### Running BDD Tests

```bash
mvn test -Dtest=CucumberTestRunner
```

## Domain Model

- **Team**: Represents a development team with a name, department, and a list of developers and projects
- **Developer**: Represents a software developer with a name, role, email, and skill level
- **Project**: Represents a development project with a name, description, start/end dates, and status
- **Task**: Represents a task within a project with a title, description, due date, priority, and status