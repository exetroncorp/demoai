package com.devteam.devteammanager.application.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/api/bypass")
public class BypassAuthController {

    @GetMapping("/login")
    public Map<String, Object> login() {
        Map<String, Object> response = new HashMap<>();
        response.put("id", 1);
        response.put("username", "zoubida");
        response.put("email", "zoubida@example.com");
        response.put("roles", java.util.Arrays.asList("ADMIN"));
        response.put("accessToken", "dummy-token-" + System.currentTimeMillis());
        response.put("tokenType", "Bearer");
        
        return response;
    }
}
