package com.devteam.devteammanager.application.dto;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.model.TaskStatus;

import java.time.LocalDate;

/**
 * DTO for task responses.
 */
public class TaskResponse {

    private Long id;
    private String title;
    private String description;
    private TaskStatus status;
    private LocalDate dueDate;
    private Integer priority;
    private ProjectSummaryResponse project;
    private DeveloperSummaryResponse assignee;

    // Default constructor for JSON serialization
    public TaskResponse() {
    }

    public TaskResponse(Task task) {
        this.id = task.getId();
        this.title = task.getTitle();
        this.description = task.getDescription();
        this.status = task.getStatus();
        this.dueDate = task.getDueDate();
        this.priority = task.getPriority();
        
        if (task.getProject() != null) {
            this.project = new ProjectSummaryResponse(task.getProject());
        }
        
        if (task.getAssignee() != null) {
            this.assignee = new DeveloperSummaryResponse(task.getAssignee());
        }
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public Integer getPriority() {
        return priority;
    }

    public ProjectSummaryResponse getProject() {
        return project;
    }

    public DeveloperSummaryResponse getAssignee() {
        return assignee;
    }

    /**
     * Nested class for summarized project information in task responses.
     */
    public static class ProjectSummaryResponse {
        private Long id;
        private String name;

        public ProjectSummaryResponse(Project project) {
            this.id = project.getId();
            this.name = project.getName();
        }

        public Long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }

    /**
     * Nested class for summarized developer information in task responses.
     */
    public static class DeveloperSummaryResponse {
        private Long id;
        private String name;
        private String role;

        public DeveloperSummaryResponse(Developer developer) {
            this.id = developer.getId();
            this.name = developer.getName();
            this.role = developer.getRole();
        }

        public Long getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getRole() {
            return role;
        }
    }
}
