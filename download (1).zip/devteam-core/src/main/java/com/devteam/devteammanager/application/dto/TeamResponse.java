package com.devteam.devteammanager.application.dto;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.Team;

import java.util.List;
import java.util.stream.Collectors;

/**
 * DTO for team responses.
 */
public class TeamResponse {

    private Long id;
    private String name;
    private String department;
    private List<DeveloperSummaryResponse> developers;
    private List<ProjectSummaryResponse> projects;

    // Default constructor for JSON serialization
    public TeamResponse() {
    }

    public TeamResponse(Team team) {
        this.id = team.getId();
        this.name = team.getName();
        this.department = team.getDepartment();

        if (team.getDevelopers() != null) {
            this.developers = team.getDevelopers().stream()
                    .map(DeveloperSummaryResponse::new)
                    .collect(Collectors.toList());
        }

        if (team.getProjects() != null) {
            this.projects = team.getProjects().stream()
                    .map(ProjectSummaryResponse::new)
                    .collect(Collectors.toList());
        }
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public List<DeveloperSummaryResponse> getDevelopers() {
        return developers;
    }

    public List<ProjectSummaryResponse> getProjects() {
        return projects;
    }

    /**
     * Nested class for summarized developer information in team responses.
     */
    public static class DeveloperSummaryResponse {
        private Long id;
        private String name;
        private String role;

        public DeveloperSummaryResponse(Developer developer) {
            this.id = developer.getId();
            this.name = developer.getName();
            this.role = developer.getRole();
        }

        public Long getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getRole() {
            return role;
        }
    }

    /**
     * Nested class for summarized project information in team responses.
     */
    public static class ProjectSummaryResponse {
        private Long id;
        private String name;
        private String status;

        public ProjectSummaryResponse(Project project) {
            this.id = project.getId();
            this.name = project.getName();
            this.status = project.getStatus().toString();
        }

        public Long getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getStatus() {
            return status;
        }
    }
}
