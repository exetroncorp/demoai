package com.devteam.devteammanager.domain.repository;

import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.ProjectStatus;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Project entity.
 * This is a port in the hexagonal architecture.
 */
public interface ProjectRepository {
    
    /**
     * Saves a project
     *
     * @param project the project to save
     * @return the saved project
     */
    Project save(Project project);
    
    /**
     * Finds a project by ID
     *
     * @param id the project ID
     * @return an Optional containing the project if found, or empty if not found
     */
    Optional<Project> findById(Long id);
    
    /**
     * Finds all projects
     *
     * @return a list of all projects
     */
    List<Project> findAll();
    
    /**
     * Finds projects by team ID
     *
     * @param teamId the team ID
     * @return a list of projects for the specified team
     */
    List<Project> findByTeamId(Long teamId);
    
    /**
     * Finds projects by status
     *
     * @param status the project status
     * @return a list of projects with the specified status
     */
    List<Project> findByStatus(ProjectStatus status);
    
    /**
     * Deletes a project
     *
     * @param project the project to delete
     */
    void delete(Project project);
    
    /**
     * Deletes a project by ID
     *
     * @param id the ID of the project to delete
     */
    void deleteById(Long id);
    
    /**
     * Checks if a project exists by ID
     *
     * @param id the project ID
     * @return true if the project exists, false otherwise
     */
    boolean existsById(Long id);
}
