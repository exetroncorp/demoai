package com.devteam.devteammanager.application.service;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.Team;
import com.devteam.devteammanager.domain.repository.DeveloperRepository;
import com.devteam.devteammanager.domain.repository.ProjectRepository;
import com.devteam.devteammanager.domain.repository.TeamRepository;
import com.devteam.devteammanager.domain.service.TeamService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of the TeamService interface.
 */
@Service
public class TeamServiceImpl implements TeamService {

    private final TeamRepository teamRepository;
    private final DeveloperRepository developerRepository;
    private final ProjectRepository projectRepository;

    public TeamServiceImpl(TeamRepository teamRepository, DeveloperRepository developerRepository, ProjectRepository projectRepository) {
        this.teamRepository = teamRepository;
        this.developerRepository = developerRepository;
        this.projectRepository = projectRepository;
    }

    @Override
    @Transactional
    public Team createTeam(String name, String department) {
        if (teamRepository.existsByName(name)) {
            throw new IllegalArgumentException("Team with name " + name + " already exists");
        }

        Team team = new Team(name, department);
        return teamRepository.save(team);
    }

    @Override
    @Transactional
    public Team updateTeam(Long id, String name, String department) {
        Team team = teamRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Team not found with id: " + id));

        // Check if the new name is already taken by another team
        if (!team.getName().equals(name) && teamRepository.existsByName(name)) {
            throw new IllegalArgumentException("Team with name " + name + " already exists");
        }

        team.setName(name);
        team.setDepartment(department);
        return teamRepository.save(team);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Team> findTeamById(Long id) {
        return teamRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Team> findAllTeams() {
        return teamRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Team> findTeamsByDepartment(String department) {
        return teamRepository.findByDepartment(department);
    }

    @Override
    @Transactional
    public void deleteTeam(Long id) {
        if (!teamRepository.existsById(id)) {
            throw new IllegalArgumentException("Team not found with id: " + id);
        }
        teamRepository.deleteById(id);
    }

    @Override
    @Transactional
    public void assignDeveloperToTeam(Long developerId, Long teamId) {
        Developer developer = developerRepository.findById(developerId)
                .orElseThrow(() -> new IllegalArgumentException("Developer not found with id: " + developerId));

        Team team = teamRepository.findById(teamId)
                .orElseThrow(() -> new IllegalArgumentException("Team not found with id: " + teamId));

        team.addDeveloper(developer);
        teamRepository.save(team);
    }

    @Override
    @Transactional
    public void removeDeveloperFromTeam(Long developerId, Long teamId) {
        Developer developer = developerRepository.findById(developerId)
                .orElseThrow(() -> new IllegalArgumentException("Developer not found with id: " + developerId));

        Team team = teamRepository.findById(teamId)
                .orElseThrow(() -> new IllegalArgumentException("Team not found with id: " + teamId));

        if (developer.getTeam() == null || !developer.getTeam().getId().equals(teamId)) {
            throw new IllegalArgumentException("Developer is not assigned to this team");
        }

        team.removeDeveloper(developer);
        teamRepository.save(team);
    }

    @Override
    @Transactional
    public void assignProjectToTeam(Long projectId, Long teamId) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + projectId));

        Team team = teamRepository.findById(teamId)
                .orElseThrow(() -> new IllegalArgumentException("Team not found with id: " + teamId));

        team.addProject(project);
        teamRepository.save(team);
        projectRepository.save(project);
    }

    @Override
    @Transactional
    public void removeProjectFromTeam(Long projectId) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + projectId));

        if (project.getTeam() == null) {
            throw new IllegalArgumentException("Project is not assigned to any team");
        }

        Team team = project.getTeam();
        team.removeProject(project);
        teamRepository.save(team);
        projectRepository.save(project);
    }
}
