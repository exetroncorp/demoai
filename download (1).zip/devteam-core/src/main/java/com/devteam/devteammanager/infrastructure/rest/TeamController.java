package com.devteam.devteammanager.infrastructure.rest;

import com.devteam.devteammanager.application.dto.TeamRequest;
import com.devteam.devteammanager.application.dto.TeamResponse;
import com.devteam.devteammanager.domain.model.Team;
import com.devteam.devteammanager.domain.service.TeamService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * REST controller for Team-related operations.
 */
@RestController
@RequestMapping("/api/teams")
public class TeamController {

    private final TeamService teamService;

    public TeamController(TeamService teamService) {
        this.teamService = teamService;
    }

    /**
     * Creates a new team
     *
     * @param request the team creation request
     * @return the created team
     */
    @PostMapping
    public ResponseEntity<TeamResponse> createTeam(@Valid @RequestBody TeamRequest request) {
        Team team = teamService.createTeam(request.getName(), request.getDepartment());
        return new ResponseEntity<>(new TeamResponse(team), HttpStatus.CREATED);
    }

    /**
     * Updates an existing team
     *
     * @param id      the team ID
     * @param request the team update request
     * @return the updated team
     */
    @PutMapping("/{id}")
    public ResponseEntity<TeamResponse> updateTeam(@PathVariable Long id, @Valid @RequestBody TeamRequest request) {
        try {
            Team team = teamService.updateTeam(id, request.getName(), request.getDepartment());
            return ResponseEntity.ok(new TeamResponse(team));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Gets a team by ID
     *
     * @param id the team ID
     * @return the team if found, or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<TeamResponse> getTeam(@PathVariable Long id) {
        return teamService.findTeamById(id)
                .map(team -> ResponseEntity.ok(new TeamResponse(team)))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Gets all teams
     *
     * @return a list of all teams
     */
    @GetMapping
    public ResponseEntity<List<TeamResponse>> getAllTeams() {
        List<TeamResponse> teams = teamService.findAllTeams().stream()
                .map(TeamResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(teams);
    }

    /**
     * Gets teams by department
     *
     * @param department the department name
     * @return a list of teams in the specified department
     */
    @GetMapping("/department/{department}")
    public ResponseEntity<List<TeamResponse>> getTeamsByDepartment(@PathVariable String department) {
        List<TeamResponse> teams = teamService.findTeamsByDepartment(department).stream()
                .map(TeamResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(teams);
    }

    /**
     * Deletes a team
     *
     * @param id the team ID
     * @return 204 if deleted, 404 if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTeam(@PathVariable Long id) {
        try {
            teamService.deleteTeam(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Assigns a developer to a team
     *
     * @param teamId      the team ID
     * @param developerId the developer ID
     * @return 204 if assigned, 404 if team or developer not found
     */
    @PostMapping("/{teamId}/developers/{developerId}")
    public ResponseEntity<Void> assignDeveloperToTeam(@PathVariable Long teamId, @PathVariable Long developerId) {
        try {
            teamService.assignDeveloperToTeam(developerId, teamId);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Removes a developer from a team
     *
     * @param teamId      the team ID
     * @param developerId the developer ID
     * @return 204 if removed, 404 if team or developer not found
     */
    @DeleteMapping("/{teamId}/developers/{developerId}")
    public ResponseEntity<Void> removeDeveloperFromTeam(@PathVariable Long teamId, @PathVariable Long developerId) {
        try {
            teamService.removeDeveloperFromTeam(developerId, teamId);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
