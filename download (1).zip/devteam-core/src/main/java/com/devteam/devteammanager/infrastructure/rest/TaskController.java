package com.devteam.devteammanager.infrastructure.rest;

import com.devteam.devteammanager.application.dto.TaskRequest;
import com.devteam.devteammanager.application.dto.TaskResponse;
import com.devteam.devteammanager.application.dto.TaskStatusRequest;
import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * REST controller for Task-related operations.
 */
@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    /**
     * Creates a new task
     *
     * @param request the task creation request
     * @return the created task
     */
    @PostMapping
    public ResponseEntity<TaskResponse> createTask(@Valid @RequestBody TaskRequest request) {
        try {
            Task task = taskService.createTask(
                    request.getTitle(),
                    request.getDescription(),
                    request.getDueDate(),
                    request.getPriority(),
                    request.getProjectId()
            );

            // If an assignee ID is provided, assign the task to the developer
            if (request.getAssigneeId() != null) {
                try {
                    taskService.assignTaskToDeveloper(task.getId(), request.getAssigneeId());
                    // Refresh the task to get the updated assignee
                    task = taskService.findTaskById(task.getId()).orElseThrow();
                } catch (IllegalArgumentException e) {
                    // If the developer doesn't exist, we still create the task but don't assign it
                }
            }

            return new ResponseEntity<>(new TaskResponse(task), HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Updates an existing task
     *
     * @param id      the task ID
     * @param request the task update request
     * @return the updated task
     */
    @PutMapping("/{id}")
    public ResponseEntity<TaskResponse> updateTask(
            @PathVariable Long id,
            @Valid @RequestBody TaskRequest request
    ) {
        try {
            Task task = taskService.updateTask(
                    id,
                    request.getTitle(),
                    request.getDescription(),
                    request.getDueDate(),
                    request.getPriority()
            );

            // If a status is provided and different from the current status, update the task status
            if (request.getStatus() != null && request.getStatus() != task.getStatus()) {
                switch (request.getStatus()) {
                    case IN_PROGRESS:
                        task = taskService.startTask(id);
                        break;
                    case DONE:
                        task = taskService.completeTask(id);
                        break;
                    case TODO:
                        task = taskService.reopenTask(id);
                        break;
                    case BLOCKED:
                        task = taskService.blockTask(id);
                        break;
                    default:
                        // Other statuses are not directly supported through the service
                        break;
                }
            }

            // If an assignee ID is provided, assign the task to the developer
            if (request.getAssigneeId() != null) {
                taskService.assignTaskToDeveloper(id, request.getAssigneeId());
                // Refresh the task to get the updated assignee
                task = taskService.findTaskById(id).orElseThrow();
            }

            return ResponseEntity.ok(new TaskResponse(task));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Gets a task by ID
     *
     * @param id the task ID
     * @return the task if found, or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<TaskResponse> getTask(@PathVariable Long id) {
        return taskService.findTaskById(id)
                .map(task -> ResponseEntity.ok(new TaskResponse(task)))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Gets all tasks
     *
     * @return a list of all tasks
     */
    @GetMapping
    public ResponseEntity<List<TaskResponse>> getAllTasks() {
        List<TaskResponse> tasks = taskService.findAllTasks().stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(tasks);
    }

    /**
     * Gets tasks by project ID
     *
     * @param projectId the project ID
     * @return a list of tasks for the specified project
     */
    @GetMapping("/project/{projectId}")
    public ResponseEntity<List<TaskResponse>> getTasksByProject(@PathVariable Long projectId) {
        List<TaskResponse> tasks = taskService.findTasksByProjectId(projectId).stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(tasks);
    }

    /**
     * Gets tasks by developer ID
     *
     * @param developerId the developer ID
     * @return a list of tasks assigned to the specified developer
     */
    @GetMapping("/developer/{developerId}")
    public ResponseEntity<List<TaskResponse>> getTasksByDeveloper(@PathVariable Long developerId) {
        List<TaskResponse> tasks = taskService.findTasksByAssigneeId(developerId).stream()
                .map(TaskResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(tasks);
    }

    /**
     * Deletes a task
     *
     * @param id the task ID
     * @return 204 if deleted, 404 if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable Long id) {
        try {
            taskService.deleteTask(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Assigns a task to a developer
     *
     * @param taskId      the task ID
     * @param developerId the developer ID
     * @return the updated task
     */
    @PutMapping("/{taskId}/developer/{developerId}")
    public ResponseEntity<TaskResponse> assignTaskToDeveloper(
            @PathVariable Long taskId,
            @PathVariable Long developerId
    ) {
        try {
            taskService.assignTaskToDeveloper(taskId, developerId);
            return taskService.findTaskById(taskId)
                    .map(task -> ResponseEntity.ok(new TaskResponse(task)))
                    .orElse(ResponseEntity.notFound().build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Unassigns a task from its current developer
     *
     * @param taskId the task ID
     * @return the updated task
     */
    @DeleteMapping("/{taskId}/developer")
    public ResponseEntity<TaskResponse> unassignTask(@PathVariable Long taskId) {
        try {
            taskService.unassignTask(taskId);
            return taskService.findTaskById(taskId)
                    .map(task -> ResponseEntity.ok(new TaskResponse(task)))
                    .orElse(ResponseEntity.notFound().build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Starts a task
     *
     * @param id the task ID
     * @return the updated task
     */
    @PutMapping("/{id}/start")
    public ResponseEntity<TaskResponse> startTask(@PathVariable Long id) {
        try {
            Task task = taskService.startTask(id);
            return ResponseEntity.ok(new TaskResponse(task));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Completes a task
     *
     * @param id the task ID
     * @return the updated task
     */
    @PutMapping("/{id}/complete")
    public ResponseEntity<TaskResponse> completeTask(@PathVariable Long id) {
        try {
            Task task = taskService.completeTask(id);
            return ResponseEntity.ok(new TaskResponse(task));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Reopens a task
     *
     * @param id the task ID
     * @return the updated task
     */
    @PutMapping("/{id}/reopen")
    public ResponseEntity<TaskResponse> reopenTask(@PathVariable Long id) {
        try {
            Task task = taskService.reopenTask(id);
            return ResponseEntity.ok(new TaskResponse(task));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Blocks a task
     *
     * @param id the task ID
     * @return the updated task
     */
    @PutMapping("/{id}/block")
    public ResponseEntity<TaskResponse> blockTask(@PathVariable Long id) {
        try {
            Task task = taskService.blockTask(id);
            return ResponseEntity.ok(new TaskResponse(task));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Unblocks a task
     *
     * @param id the task ID
     * @return the updated task
     */
    @PutMapping("/{id}/unblock")
    public ResponseEntity<TaskResponse> unblockTask(@PathVariable Long id) {
        try {
            Task task = taskService.unblockTask(id);
            return ResponseEntity.ok(new TaskResponse(task));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Updates a task's status
     *
     * @param id the task ID
     * @param request the status update request
     * @return the updated task
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<TaskResponse> updateTaskStatus(
            @PathVariable Long id,
            @RequestBody TaskStatusRequest request
    ) {
        try {
            Task task;
            switch (request.getStatus()) {
                case IN_PROGRESS:
                    task = taskService.startTask(id);
                    break;
                case DONE:
                    task = taskService.completeTask(id);
                    break;
                case TODO:
                    task = taskService.reopenTask(id);
                    break;
                case BLOCKED:
                    task = taskService.blockTask(id);
                    break;
                default:
                    return ResponseEntity.badRequest().build();
            }
            return ResponseEntity.ok(new TaskResponse(task));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
