package com.devteam.devteammanager.application.dto;

import com.devteam.devteammanager.domain.model.TaskStatus;

/**
 * DTO for task status update requests.
 */
public class TaskStatusRequest {
    private TaskStatus status;

    public TaskStatusRequest() {
    }

    public TaskStatusRequest(TaskStatus status) {
        this.status = status;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }
}
