package com.devteam.devteammanager.domain.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.Objects;

/**
 * Task entity representing a task within a project.
 * This is a domain model following DDD principles.
 */
@Entity
@Table(name = "tasks")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TaskStatus status;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name = "priority")
    private Integer priority;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "project_id")
    private Project project;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id")
    private Developer assignee;

    /**
     * Default constructor required by JPA
     */
    protected Task() {
    }

    /**
     * Constructor for creating a new Task
     *
     * @param title       the task title
     * @param description the task description
     * @param dueDate     the task due date
     * @param priority    the task priority (1-5, with 5 being highest)
     */
    public Task(String title, String description, LocalDate dueDate, Integer priority) {
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
        this.status = TaskStatus.TODO;
    }

    /**
     * Assigns the task to a project
     *
     * @param project the project to assign the task to
     */
    public void assignToProject(Project project) {
        this.project = project;
    }

    /**
     * Removes the task from its current project
     */
    public void removeFromProject() {
        this.project = null;
    }

    /**
     * Assigns the task to a developer
     *
     * @param developer the developer to assign the task to
     */
    public void assignToDeveloper(Developer developer) {
        this.assignee = developer;
    }

    /**
     * Unassigns the task from its current developer
     */
    public void unassignFromDeveloper() {
        this.assignee = null;
    }

    /**
     * Starts the task
     */
    public void start() {
        if (status == TaskStatus.TODO) {
            status = TaskStatus.IN_PROGRESS;
        } else {
            throw new IllegalStateException("Task can only be started from TODO state");
        }
    }

    /**
     * Completes the task
     */
    public void complete() {
        if (status != TaskStatus.DONE) {
            status = TaskStatus.DONE;
        } else {
            throw new IllegalStateException("Task is already completed");
        }
    }

    /**
     * Reopens a completed task
     */
    public void reopen() {
        if (status == TaskStatus.DONE) {
            status = TaskStatus.TODO;
        } else {
            throw new IllegalStateException("Only completed tasks can be reopened");
        }
    }

    /**
     * Blocks a task
     */
    public void block() {
        if (status == TaskStatus.TODO || status == TaskStatus.IN_PROGRESS) {
            status = TaskStatus.BLOCKED;
        } else {
            throw new IllegalStateException("Only TODO or IN_PROGRESS tasks can be blocked");
        }
    }

    /**
     * Unblocks a task
     */
    public void unblock() {
        if (status == TaskStatus.BLOCKED) {
            status = TaskStatus.TODO;
        } else {
            throw new IllegalStateException("Only blocked tasks can be unblocked");
        }
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Project getProject() {
        return project;
    }

    public Developer getAssignee() {
        return assignee;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return Objects.equals(id, task.id) &&
                Objects.equals(title, task.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title);
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", status=" + status +
                ", dueDate=" + dueDate +
                ", priority=" + priority +
                ", project=" + (project != null ? project.getName() : "none") +
                ", assignee=" + (assignee != null ? assignee.getName() : "unassigned") +
                '}';
    }
}
