package com.devteam.devteammanager.infrastructure.rest;

import com.devteam.devteammanager.application.dto.ProjectRequest;
import com.devteam.devteammanager.application.dto.ProjectResponse;
import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.service.ProjectService;
import com.devteam.devteammanager.domain.service.TeamService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * REST controller for Project-related operations.
 */
@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private final ProjectService projectService;
    private final TeamService teamService;

    public ProjectController(ProjectService projectService, TeamService teamService) {
        this.projectService = projectService;
        this.teamService = teamService;
    }

    /**
     * Creates a new project
     *
     * @param request the project creation request
     * @return the created project
     */
    @PostMapping
    public ResponseEntity<ProjectResponse> createProject(@Valid @RequestBody ProjectRequest request) {
        Project project = projectService.createProject(
                request.getName(),
                request.getDescription(),
                request.getStartDate(),
                request.getEndDate()
        );
        
        // If a team ID is provided, assign the project to the team
        if (request.getTeamId() != null) {
            try {
                teamService.assignProjectToTeam(project.getId(), request.getTeamId());
            } catch (IllegalArgumentException e) {
                // If the team doesn't exist, we still create the project but don't assign it
            }
        }
        
        // If a status is provided, update the project status
        if (request.getStatus() != null && request.getStatus() != project.getStatus()) {
            project = projectService.updateProjectStatus(project.getId(), request.getStatus());
        }
        
        return new ResponseEntity<>(new ProjectResponse(project), HttpStatus.CREATED);
    }

    /**
     * Updates an existing project
     *
     * @param id      the project ID
     * @param request the project update request
     * @return the updated project
     */
    @PutMapping("/{id}")
    public ResponseEntity<ProjectResponse> updateProject(
            @PathVariable Long id,
            @Valid @RequestBody ProjectRequest request
    ) {
        try {
            Project project = projectService.updateProject(
                    id,
                    request.getName(),
                    request.getDescription(),
                    request.getStartDate(),
                    request.getEndDate()
            );
            
            // If a status is provided, update the project status
            if (request.getStatus() != null && request.getStatus() != project.getStatus()) {
                project = projectService.updateProjectStatus(id, request.getStatus());
            }
            
            // If a team ID is provided, assign the project to the team
            if (request.getTeamId() != null) {
                try {
                    teamService.assignProjectToTeam(id, request.getTeamId());
                    // Refresh the project to get the updated team
                    project = projectService.findProjectById(id).orElseThrow();
                } catch (IllegalArgumentException e) {
                    // If the team doesn't exist, we still update the project but don't assign it
                }
            }
            
            return ResponseEntity.ok(new ProjectResponse(project));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Gets a project by ID
     *
     * @param id the project ID
     * @return the project if found, or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<ProjectResponse> getProject(@PathVariable Long id) {
        return projectService.findProjectById(id)
                .map(project -> ResponseEntity.ok(new ProjectResponse(project)))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Gets all projects
     *
     * @return a list of all projects
     */
    @GetMapping
    public ResponseEntity<List<ProjectResponse>> getAllProjects() {
        List<ProjectResponse> projects = projectService.findAllProjects().stream()
                .map(ProjectResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(projects);
    }

    /**
     * Gets projects by team ID
     *
     * @param teamId the team ID
     * @return a list of projects for the specified team
     */
    @GetMapping("/team/{teamId}")
    public ResponseEntity<List<ProjectResponse>> getProjectsByTeam(@PathVariable Long teamId) {
        List<ProjectResponse> projects = projectService.findProjectsByTeamId(teamId).stream()
                .map(ProjectResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(projects);
    }

    /**
     * Deletes a project
     *
     * @param id the project ID
     * @return 204 if deleted, 404 if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProject(@PathVariable Long id) {
        try {
            projectService.deleteProject(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Assigns a project to a team
     *
     * @param projectId the project ID
     * @param teamId    the team ID
     * @return the updated project
     */
    @PutMapping("/{projectId}/team/{teamId}")
    public ResponseEntity<ProjectResponse> assignProjectToTeam(
            @PathVariable Long projectId,
            @PathVariable Long teamId
    ) {
        try {
            teamService.assignProjectToTeam(projectId, teamId);
            return projectService.findProjectById(projectId)
                    .map(project -> ResponseEntity.ok(new ProjectResponse(project)))
                    .orElse(ResponseEntity.notFound().build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Removes a project from its team
     *
     * @param projectId the project ID
     * @return the updated project
     */
    @DeleteMapping("/{projectId}/team")
    public ResponseEntity<ProjectResponse> removeProjectFromTeam(@PathVariable Long projectId) {
        try {
            teamService.removeProjectFromTeam(projectId);
            return projectService.findProjectById(projectId)
                    .map(project -> ResponseEntity.ok(new ProjectResponse(project)))
                    .orElse(ResponseEntity.notFound().build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Starts a project
     *
     * @param id the project ID
     * @return the updated project
     */
    @PutMapping("/{id}/start")
    public ResponseEntity<ProjectResponse> startProject(@PathVariable Long id) {
        try {
            Project project = projectService.startProject(id);
            return ResponseEntity.ok(new ProjectResponse(project));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Completes a project
     *
     * @param id the project ID
     * @return the updated project
     */
    @PutMapping("/{id}/complete")
    public ResponseEntity<ProjectResponse> completeProject(@PathVariable Long id) {
        try {
            Project project = projectService.completeProject(id);
            return ResponseEntity.ok(new ProjectResponse(project));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Cancels a project
     *
     * @param id the project ID
     * @return the updated project
     */
    @PutMapping("/{id}/cancel")
    public ResponseEntity<ProjectResponse> cancelProject(@PathVariable Long id) {
        try {
            Project project = projectService.cancelProject(id);
            return ResponseEntity.ok(new ProjectResponse(project));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
