package com.devteam.devteammanager.domain.model;

/**
 * Enum representing the possible states of a project.
 */
public enum ProjectStatus {
    PLANNED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
