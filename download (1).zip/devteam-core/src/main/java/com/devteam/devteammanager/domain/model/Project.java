package com.devteam.devteammanager.domain.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Project entity representing a development project.
 * This is a domain model following DDD principles.
 */
@Entity
@Table(name = "projects")
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String description;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProjectStatus status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id")
    private Team team;

    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Task> tasks = new ArrayList<>();

    /**
     * Default constructor required by JPA
     */
    protected Project() {
    }

    /**
     * Constructor for creating a new Project
     *
     * @param name        the project name
     * @param description the project description
     * @param startDate   the project start date
     * @param endDate     the project end date
     */
    public Project(String name, String description, LocalDate startDate, LocalDate endDate) {
        this.name = name;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = ProjectStatus.PLANNED;
    }

    /**
     * Assigns the project to a team
     *
     * @param team the team to assign the project to
     */
    public void assignToTeam(Team team) {
        this.team = team;
    }

    /**
     * Removes the project from its current team
     */
    public void removeFromTeam() {
        this.team = null;
    }

    /**
     * Adds a task to the project
     *
     * @param task the task to add
     */
    public void addTask(Task task) {
        tasks.add(task);
        task.assignToProject(this);
    }

    /**
     * Removes a task from the project
     *
     * @param task the task to remove
     */
    public void removeTask(Task task) {
        tasks.remove(task);
        task.removeFromProject();
    }

    /**
     * Gets an unmodifiable view of the tasks in this project
     *
     * @return unmodifiable list of tasks
     */
    public List<Task> getTasks() {
        return Collections.unmodifiableList(tasks);
    }

    /**
     * Starts the project
     */
    public void start() {
        if (status == ProjectStatus.PLANNED) {
            status = ProjectStatus.IN_PROGRESS;
            startDate = LocalDate.now();
        } else {
            throw new IllegalStateException("Project can only be started from PLANNED state");
        }
    }

    /**
     * Completes the project
     */
    public void complete() {
        if (status == ProjectStatus.IN_PROGRESS) {
            status = ProjectStatus.COMPLETED;
            endDate = LocalDate.now();
        } else {
            throw new IllegalStateException("Project can only be completed from IN_PROGRESS state");
        }
    }

    /**
     * Cancels the project
     */
    public void cancel() {
        if (status != ProjectStatus.COMPLETED) {
            status = ProjectStatus.CANCELLED;
            endDate = LocalDate.now();
        } else {
            throw new IllegalStateException("Completed projects cannot be cancelled");
        }
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    /**
     * Sets the project ID (used for JPA and testing)
     *
     * @param id the project ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public ProjectStatus getStatus() {
        return status;
    }

    public Team getTeam() {
        return team;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Project project = (Project) o;
        return Objects.equals(id, project.id) &&
                Objects.equals(name, project.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }

    @Override
    public String toString() {
        return "Project{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", status=" + status +
                ", team=" + (team != null ? team.getName() : "none") +
                ", tasks=" + tasks.size() +
                '}';
    }
}
