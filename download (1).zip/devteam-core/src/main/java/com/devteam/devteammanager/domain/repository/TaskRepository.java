package com.devteam.devteammanager.domain.repository;

import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.model.TaskStatus;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Task entity.
 * This is a port in the hexagonal architecture.
 */
public interface TaskRepository {
    
    /**
     * Saves a task
     *
     * @param task the task to save
     * @return the saved task
     */
    Task save(Task task);
    
    /**
     * Finds a task by ID
     *
     * @param id the task ID
     * @return an Optional containing the task if found, or empty if not found
     */
    Optional<Task> findById(Long id);
    
    /**
     * Finds all tasks
     *
     * @return a list of all tasks
     */
    List<Task> findAll();
    
    /**
     * Finds tasks by project ID
     *
     * @param projectId the project ID
     * @return a list of tasks for the specified project
     */
    List<Task> findByProjectId(Long projectId);
    
    /**
     * Finds tasks by assignee ID
     *
     * @param developerId the developer ID
     * @return a list of tasks assigned to the specified developer
     */
    List<Task> findByAssigneeId(Long developerId);
    
    /**
     * Finds tasks by status
     *
     * @param status the task status
     * @return a list of tasks with the specified status
     */
    List<Task> findByStatus(TaskStatus status);
    
    /**
     * Deletes a task
     *
     * @param task the task to delete
     */
    void delete(Task task);
    
    /**
     * Deletes a task by ID
     *
     * @param id the ID of the task to delete
     */
    void deleteById(Long id);
    
    /**
     * Checks if a task exists by ID
     *
     * @param id the task ID
     * @return true if the task exists, false otherwise
     */
    boolean existsById(Long id);
}
