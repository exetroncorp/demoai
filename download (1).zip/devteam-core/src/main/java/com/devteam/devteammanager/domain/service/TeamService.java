package com.devteam.devteammanager.domain.service;

import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.Team;
import java.util.List;
import java.util.Optional;

/**
 * Service interface for Team-related operations.
 * This is a port in the hexagonal architecture.
 */
public interface TeamService {

    /**
     * Creates a new team
     *
     * @param name       the team name
     * @param department the department the team belongs to
     * @return the created team
     */
    Team createTeam(String name, String department);

    /**
     * Updates an existing team
     *
     * @param id         the team ID
     * @param name       the new team name
     * @param department the new department
     * @return the updated team
     * @throws IllegalArgumentException if the team does not exist
     */
    Team updateTeam(Long id, String name, String department);

    /**
     * Finds a team by ID
     *
     * @param id the team ID
     * @return an Optional containing the team if found, or empty if not found
     */
    Optional<Team> findTeamById(Long id);

    /**
     * Finds all teams
     *
     * @return a list of all teams
     */
    List<Team> findAllTeams();

    /**
     * Finds teams by department
     *
     * @param department the department name
     * @return a list of teams in the specified department
     */
    List<Team> findTeamsByDepartment(String department);

    /**
     * Deletes a team
     *
     * @param id the ID of the team to delete
     * @throws IllegalArgumentException if the team does not exist
     */
    void deleteTeam(Long id);

    /**
     * Assigns a developer to a team
     *
     * @param developerId the developer ID
     * @param teamId      the team ID
     * @throws IllegalArgumentException if the developer or team does not exist
     */
    void assignDeveloperToTeam(Long developerId, Long teamId);

    /**
     * Removes a developer from a team
     *
     * @param developerId the developer ID
     * @param teamId      the team ID
     * @throws IllegalArgumentException if the developer or team does not exist
     */
    void removeDeveloperFromTeam(Long developerId, Long teamId);

    /**
     * Assigns a project to a team
     *
     * @param projectId the project ID
     * @param teamId    the team ID
     * @throws IllegalArgumentException if the project or team does not exist
     */
    void assignProjectToTeam(Long projectId, Long teamId);

    /**
     * Removes a project from a team
     *
     * @param projectId the project ID
     * @throws IllegalArgumentException if the project does not exist
     */
    void removeProjectFromTeam(Long projectId);
}
