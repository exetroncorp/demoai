package com.devteam.devteammanager.domain.service;

import com.devteam.devteammanager.domain.model.Developer;
import java.util.List;
import java.util.Optional;

/**
 * Service interface for Developer-related operations.
 * This is a port in the hexagonal architecture.
 */
public interface DeveloperService {

    /**
     * Creates a new developer
     *
     * @param name       the developer's name
     * @param role       the developer's role
     * @param email      the developer's email
     * @param skillLevel the developer's skill level
     * @param pictureUrl the developer's profile picture URL
     * @return the created developer
     */
    Developer createDeveloper(String name, String role, String email, String skillLevel, String pictureUrl);

    /**
     * Creates a new developer without a picture
     *
     * @param name       the developer's name
     * @param role       the developer's role
     * @param email      the developer's email
     * @param skillLevel the developer's skill level
     * @return the created developer
     */
    Developer createDeveloper(String name, String role, String email, String skillLevel);

    /**
     * Updates an existing developer
     *
     * @param id         the developer ID
     * @param name       the new name
     * @param role       the new role
     * @param email      the new email
     * @param skillLevel the new skill level
     * @param pictureUrl the new profile picture URL
     * @return the updated developer
     * @throws IllegalArgumentException if the developer does not exist
     */
    Developer updateDeveloper(Long id, String name, String role, String email, String skillLevel, String pictureUrl);

    /**
     * Updates an existing developer without changing the picture
     *
     * @param id         the developer ID
     * @param name       the new name
     * @param role       the new role
     * @param email      the new email
     * @param skillLevel the new skill level
     * @return the updated developer
     * @throws IllegalArgumentException if the developer does not exist
     */
    Developer updateDeveloper(Long id, String name, String role, String email, String skillLevel);

    /**
     * Finds a developer by ID
     *
     * @param id the developer ID
     * @return an Optional containing the developer if found, or empty if not found
     */
    Optional<Developer> findDeveloperById(Long id);

    /**
     * Finds all developers
     *
     * @return a list of all developers
     */
    List<Developer> findAllDevelopers();

    /**
     * Finds developers by team ID
     *
     * @param teamId the team ID
     * @return a list of developers in the specified team
     */
    List<Developer> findDevelopersByTeamId(Long teamId);

    /**
     * Deletes a developer
     *
     * @param id the ID of the developer to delete
     * @throws IllegalArgumentException if the developer does not exist
     */
    void deleteDeveloper(Long id);
}
