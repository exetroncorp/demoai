package com.devteam.devteammanager.domain.service;

import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.ProjectStatus;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Service interface for Project-related operations.
 * This is a port in the hexagonal architecture.
 */
public interface ProjectService {

    /**
     * Creates a new project
     *
     * @param name        the project name
     * @param description the project description
     * @param startDate   the project start date
     * @param endDate     the project end date
     * @return the created project
     */
    Project createProject(String name, String description, LocalDate startDate, LocalDate endDate);

    /**
     * Updates an existing project
     *
     * @param id          the project ID
     * @param name        the new name
     * @param description the new description
     * @param startDate   the new start date
     * @param endDate     the new end date
     * @return the updated project
     * @throws IllegalArgumentException if the project does not exist
     */
    Project updateProject(Long id, String name, String description, LocalDate startDate, LocalDate endDate);

    /**
     * Finds a project by ID
     *
     * @param id the project ID
     * @return an Optional containing the project if found, or empty if not found
     */
    Optional<Project> findProjectById(Long id);

    /**
     * Finds all projects
     *
     * @return a list of all projects
     */
    List<Project> findAllProjects();

    /**
     * Finds projects by team ID
     *
     * @param teamId the team ID
     * @return a list of projects for the specified team
     */
    List<Project> findProjectsByTeamId(Long teamId);

    /**
     * Finds projects by status
     *
     * @param status the project status
     * @return a list of projects with the specified status
     */
    List<Project> findProjectsByStatus(ProjectStatus status);

    /**
     * Deletes a project
     *
     * @param id the ID of the project to delete
     * @throws IllegalArgumentException if the project does not exist
     */
    void deleteProject(Long id);

    /**
     * Assigns a project to a team
     *
     * @param projectId the project ID
     * @param teamId    the team ID
     * @throws IllegalArgumentException if the project or team does not exist
     */
    void assignProjectToTeam(Long projectId, Long teamId);

    /**
     * Starts a project
     *
     * @param id the project ID
     * @return the updated project
     * @throws IllegalArgumentException if the project does not exist
     * @throws IllegalStateException    if the project cannot be started
     */
    Project startProject(Long id);

    /**
     * Completes a project
     *
     * @param id the project ID
     * @return the updated project
     * @throws IllegalArgumentException if the project does not exist
     * @throws IllegalStateException    if the project cannot be completed
     */
    Project completeProject(Long id);

    /**
     * Cancels a project
     *
     * @param id the project ID
     * @return the updated project
     * @throws IllegalArgumentException if the project does not exist
     * @throws IllegalStateException    if the project cannot be cancelled
     */
    Project cancelProject(Long id);

    /**
     * Updates the status of a project directly
     *
     * @param id     the project ID
     * @param status the new status
     * @return the updated project
     * @throws IllegalArgumentException if the project does not exist
     */
    Project updateProjectStatus(Long id, ProjectStatus status);
}
