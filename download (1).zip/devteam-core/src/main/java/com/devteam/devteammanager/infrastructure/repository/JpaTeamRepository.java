package com.devteam.devteammanager.infrastructure.repository;

import com.devteam.devteammanager.domain.model.Team;
import com.devteam.devteammanager.domain.repository.TeamRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * JPA implementation of the TeamRepository interface.
 * This is an adapter in the hexagonal architecture.
 */
@Repository
public interface JpaTeamRepository extends JpaRepository<Team, Long>, TeamRepository {
    
    /**
     * Finds a team by name
     *
     * @param name the team name
     * @return an Optional containing the team if found, or empty if not found
     */
    Optional<Team> findByName(String name);
    
    /**
     * Finds teams by department
     *
     * @param department the department name
     * @return a list of teams in the specified department
     */
    List<Team> findByDepartment(String department);
    
    /**
     * Checks if a team exists by name
     *
     * @param name the team name
     * @return true if the team exists, false otherwise
     */
    boolean existsByName(String name);
}
