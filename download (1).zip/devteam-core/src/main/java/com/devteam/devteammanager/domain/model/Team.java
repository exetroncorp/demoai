package com.devteam.devteammanager.domain.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Team entity representing a development team.
 * This is a domain model following DDD principles.
 */
@Entity
@Table(name = "teams")
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name;

    @Column(name = "department")
    private String department;

    @OneToMany(mappedBy = "team", cascade = CascadeType.ALL, orphanRemoval = false)
    private List<Developer> developers = new ArrayList<>();

    @OneToMany(mappedBy = "team", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Project> projects = new ArrayList<>();

    /**
     * Default constructor required by JPA
     */
    protected Team() {
    }

    /**
     * Constructor for creating a new Team
     *
     * @param name       the team name
     * @param department the department the team belongs to
     */
    public Team(String name, String department) {
        this.name = name;
        this.department = department;
    }

    /**
     * Adds a developer to the team
     *
     * @param developer the developer to add
     */
    public void addDeveloper(Developer developer) {
        developers.add(developer);
        developer.assignToTeam(this);
    }

    /**
     * Removes a developer from the team
     *
     * @param developer the developer to remove
     */
    public void removeDeveloper(Developer developer) {
        developers.remove(developer);
        developer.removeFromTeam();
    }

    /**
     * Adds a project to the team
     *
     * @param project the project to add
     */
    public void addProject(Project project) {
        projects.add(project);
        project.assignToTeam(this);
    }

    /**
     * Removes a project from the team
     *
     * @param project the project to remove
     */
    public void removeProject(Project project) {
        projects.remove(project);
        project.removeFromTeam();
    }

    /**
     * Gets an unmodifiable view of the developers in this team
     *
     * @return unmodifiable list of developers
     */
    public List<Developer> getDevelopers() {
        return Collections.unmodifiableList(developers);
    }

    /**
     * Gets an unmodifiable view of the projects in this team
     *
     * @return unmodifiable list of projects
     */
    public List<Project> getProjects() {
        return Collections.unmodifiableList(projects);
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Team team = (Team) o;
        return Objects.equals(id, team.id) &&
                Objects.equals(name, team.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }

    @Override
    public String toString() {
        return "Team{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", department='" + department + '\'' +
                ", developers=" + developers.size() +
                ", projects=" + projects.size() +
                '}';
    }
}
