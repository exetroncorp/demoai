package com.example.demo.application;

import com.example.demo.domain.Developer;
import com.example.demo.domain.DeveloperRepository;
import com.example.demo.domain.Team;
import com.example.demo.domain.TeamRepository;
import com.example.demo.domain.port.api.AssignDeveloperToTeamUseCase;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeamService implements AssignDeveloperToTeamUseCase {

    private final TeamRepository teamRepository;
    private final DeveloperRepository developerRepository;

    public TeamService(TeamRepository teamRepository, DeveloperRepository developerRepository) {
        this.teamRepository = teamRepository;
        this.developerRepository = developerRepository;
    }

    public Team createTeam(String name) {
        Team team = new Team();
        team.setName(name);
        return teamRepository.save(team);
    }

    @Override
    public void assignDeveloperToTeam(Long developerId, Long teamId) {
        Optional<Developer> developerOptional = developerRepository.findById(developerId);
        Optional<Team> teamOptional = teamRepository.findById(teamId);

        if (developerOptional.isPresent() && teamOptional.isPresent()) {
            Developer developer = developerOptional.get();
            Team team = teamOptional.get();

            developer.setTeamId(teamId);
            developerRepository.save(developer);

            List<Long> developerIds = team.getDeveloperIds();
            if (developerIds == null) {
                developerIds = new java.util.ArrayList<>();
            }
            if(!developerIds.contains(developerId)) {
                developerIds.add(developerId);
            }

            team.setDeveloperIds(developerIds);
            teamRepository.save(team);
        } else {
            throw new IllegalArgumentException("Developer or Team not found");
        }
    }
}
