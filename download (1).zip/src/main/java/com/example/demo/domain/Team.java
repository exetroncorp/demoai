package com.example.demo.domain;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @ElementCollection
    private List<Long> developerIds; // Added developerIds field

    public Team() {
    }

    public Team(String name, List<Long> developerIds) {
        this.name = name;
        this.developerIds = developerIds;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

     public List<Long> getDeveloperIds() { // Added getter for developerIds
        return developerIds;
    }

    public void setDeveloperIds(List<Long> developerIds) { // Added setter for developerIds
        this.developerIds = developerIds;
    }


}
