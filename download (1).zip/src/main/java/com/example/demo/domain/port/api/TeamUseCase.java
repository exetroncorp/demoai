package com.example.demo.domain.port.api;

import com.example.demo.domain.Team;

public interface TeamUseCase {
    Team createTeam(String name);
}
