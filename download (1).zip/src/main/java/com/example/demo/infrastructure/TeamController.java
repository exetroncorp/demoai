package com.example.demo.infrastructure;

import com.example.demo.application.TeamService;
import com.example.demo.domain.Team;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/teams")
public class TeamController {

    private final TeamService teamService;

    public TeamController(TeamService teamService) {
        this.teamService = teamService;
    }

    @PostMapping
    public ResponseEntity<Team> createTeam(@RequestBody String name) {
        Team createdTeam = teamService.createTeam(name);
        return new ResponseEntity<>(createdTeam, HttpStatus.CREATED);
    }

    @PostMapping("/{teamId}/developers/{developerId}")
    public ResponseEntity<Void> assignDeveloperToTeam(
            @PathVariable Long teamId,
            @PathVariable Long developerId) {
        try {
            teamService.assignDeveloperToTeam(developerId, teamId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }
}
