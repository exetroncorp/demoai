package com.devteam.devteammanager.infrastructure.config;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.ProjectStatus;
import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.model.TaskStatus;
import com.devteam.devteammanager.domain.model.Team;
import com.devteam.devteammanager.domain.repository.DeveloperRepository;
import com.devteam.devteammanager.domain.repository.ProjectRepository;
import com.devteam.devteammanager.domain.repository.TaskRepository;
import com.devteam.devteammanager.domain.repository.TeamRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Configuration for initializing sample data.
 */
@Configuration
public class DataInitializer {

    /**
     * Initializes sample data for development environment.
     *
     * @param teamRepository      the team repository
     * @param developerRepository the developer repository
     * @return a CommandLineRunner that initializes the data
     */
    @Bean
    @Profile("!test")
    public CommandLineRunner initData(
            TeamRepository teamRepository,
            DeveloperRepository developerRepository,
            ProjectRepository projectRepository,
            TaskRepository taskRepository
    ) {
        return args -> {
            // Create teams
            Team backendTeam = new Team("Backend Team", "Engineering");
            Team frontendTeam = new Team("Frontend Team", "Engineering");
            Team qaTeam = new Team("QA Team", "Quality Assurance");

            teamRepository.save(backendTeam);
            teamRepository.save(frontendTeam);
            teamRepository.save(qaTeam);

            // Create developers
            Developer johnDoe = new Developer("John Doe", "Software Engineer", "john.doe@example.com", "Senior");
            Developer janeDoe = new Developer("Jane Doe", "Software Engineer", "jane.doe@example.com", "Mid-level");
            Developer bobSmith = new Developer("Bob Smith", "Frontend Developer", "bob.smith@example.com", "Senior");
            Developer aliceJones = new Developer("Alice Jones", "QA Engineer", "alice.jones@example.com", "Senior");
            Developer charlieBrown = new Developer("Charlie Brown", "Backend Developer", "charlie.brown@example.com", "Junior");

            // Assign developers to teams
            backendTeam.addDeveloper(johnDoe);
            backendTeam.addDeveloper(charlieBrown);
            frontendTeam.addDeveloper(janeDoe);
            frontendTeam.addDeveloper(bobSmith);
            qaTeam.addDeveloper(aliceJones);

            // Save developers
            developerRepository.save(johnDoe);
            developerRepository.save(janeDoe);
            developerRepository.save(bobSmith);
            developerRepository.save(aliceJones);
            developerRepository.save(charlieBrown);

            // Save teams again to ensure relationships are saved
            teamRepository.save(backendTeam);
            teamRepository.save(frontendTeam);
            teamRepository.save(qaTeam);

            // Create projects
            Project apiProject = new Project("API Development", "Develop RESTful API for the application",
                    java.time.LocalDate.now(), java.time.LocalDate.now().plusMonths(3));
            // Start the project to set status to IN_PROGRESS
            try {
                apiProject.start();
            } catch (IllegalStateException e) {
                // Ignore if already started
            }

            Project uiProject = new Project("UI Development", "Develop user interface for the application",
                    java.time.LocalDate.now(), java.time.LocalDate.now().plusMonths(2));
            // Start the project to set status to IN_PROGRESS
            try {
                uiProject.start();
            } catch (IllegalStateException e) {
                // Ignore if already started
            }

            Project testingProject = new Project("Application Testing", "Test the application for bugs and issues",
                    java.time.LocalDate.now().plusMonths(2), java.time.LocalDate.now().plusMonths(4));

            // Assign projects to teams
            backendTeam.addProject(apiProject);
            frontendTeam.addProject(uiProject);
            qaTeam.addProject(testingProject);

            // Save projects
            projectRepository.save(apiProject);
            projectRepository.save(uiProject);
            projectRepository.save(testingProject);

            // Create tasks
            Task apiDesignTask = new Task("API Design", "Design the API endpoints and data models",
                    java.time.LocalDate.now().plusWeeks(1), 5);
            // Start the task to set status to IN_PROGRESS
            try {
                apiDesignTask.start();
            } catch (IllegalStateException e) {
                // Ignore if already started
            }

            Task apiImplementationTask = new Task("API Implementation", "Implement the API endpoints",
                    java.time.LocalDate.now().plusWeeks(4), 4);
            // Status is already TODO by default

            Task uiDesignTask = new Task("UI Design", "Design the user interface",
                    java.time.LocalDate.now().plusWeeks(1), 5);
            // Start the task to set status to IN_PROGRESS
            try {
                uiDesignTask.start();
            } catch (IllegalStateException e) {
                // Ignore if already started
            }

            Task uiImplementationTask = new Task("UI Implementation", "Implement the user interface",
                    java.time.LocalDate.now().plusWeeks(3), 4);
            // Status is already TODO by default

            Task testPlanTask = new Task("Test Plan Creation", "Create test plan for the application",
                    java.time.LocalDate.now().plusWeeks(8), 3);
            // Status is already TODO by default

            // Assign tasks to projects
            apiProject.addTask(apiDesignTask);
            apiProject.addTask(apiImplementationTask);
            uiProject.addTask(uiDesignTask);
            uiProject.addTask(uiImplementationTask);
            testingProject.addTask(testPlanTask);

            // Assign tasks to developers
            apiDesignTask.assignToDeveloper(johnDoe);
            uiDesignTask.assignToDeveloper(bobSmith);
            testPlanTask.assignToDeveloper(aliceJones);

            // Save tasks
            taskRepository.save(apiDesignTask);
            taskRepository.save(apiImplementationTask);
            taskRepository.save(uiDesignTask);
            taskRepository.save(uiImplementationTask);
            taskRepository.save(testPlanTask);

            // Save projects again to ensure relationships are saved
            projectRepository.save(apiProject);
            projectRepository.save(uiProject);
            projectRepository.save(testingProject);

            // Save teams again to ensure relationships are saved
            teamRepository.save(backendTeam);
            teamRepository.save(frontendTeam);
            teamRepository.save(qaTeam);
        };
    }
}
