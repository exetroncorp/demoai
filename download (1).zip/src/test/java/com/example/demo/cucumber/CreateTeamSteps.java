package com.example.demo.cucumber;

import com.example.demo.domain.Developer;
import com.example.demo.domain.DeveloperRepository;
import com.example.demo.domain.Team;
import com.example.demo.domain.TeamRepository;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CreateTeamSteps {

    @LocalServerPort
    private int port;

    private String teamName;
    private ResponseEntity<Team> response;

    @Autowired
    private TeamRepository teamRepository;
    @Autowired
    private DeveloperRepository developerRepository;

    private Long developerId;
    private Long teamId;

    @Given("I have a team name")
    public void i_have_a_team_name() {
        teamName = "Test Team";
    }

    @When("I create a team with the name")
    public void i_create_a_team_with_the_name() {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:" + port + "/teams";
        response = restTemplate.postForEntity(url, teamName, Team.class);
    }

    @Then("the team should be created")
    public void the_team_should_be_created() {
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(Objects.requireNonNull(response.getBody()).getId());
        assertEquals(teamName, response.getBody().getName());
    }

    @Given("a developer exists")
    public void a_developer_exists() {
        Developer developer = new Developer("Test Developer", "Software Engineer", null);
        developer = developerRepository.save(developer);
        developerId = developer.getId();
    }

    @Given("a team exists")
    public void a_team_exists() {
        Team team = new Team("Test Team", null);
        team = teamRepository.save(team);
        teamId = team.getId();
    }

    @When("I assign the developer to the team")
    public void i_assign_the_developer_to_the_team() {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:" + port + "/teams/" + teamId + "/developers/" + developerId;
        restTemplate.postForEntity(url, null, Void.class);
    }

    @Then("the developer should be assigned to the team")
    public void the_developer_should_be_assigned_to_the_team() {
        Team team = teamRepository.findById(teamId).orElse(null);
        Developer developer = developerRepository.findById(developerId).orElse(null);
        assertNotNull(team);
        assertNotNull(developer);
        assertEquals(teamId, developer.getTeamId());
    }
}
