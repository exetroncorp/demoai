mvn spring-boot:run
cd frontend
npm run dev