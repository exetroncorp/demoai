# Cloud IDE - Development Guide

This guide provides instructions on how to launch the Cloud IDE application in development mode.

## Prerequisites

- Java 17 or higher
- Node.js and npm (for frontend development)
- Git

## Project Structure

The project consists of two main parts:
- Backend: Spring Boot application
- Frontend: React application built with Vite

## Running the Backend

1. Clone the repository:
   ```
   git clone <repository-url>
   cd cloud-ide
   ```

2. Build and run the Spring Boot application:
   ```
   mvn spring-boot:run
   ```

3. The backend will start on `http://localhost:8080`

4. You can access the H2 database console at `http://localhost:8080/h2-console` with the following credentials:
   - JDBC URL: `jdbc:h2:mem:cloudidedb`
   - Username: `sa`
   - Password: `password`

## Running the Frontend

1. Navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. The frontend will be available at `http://localhost:5173`

## Development Notes

- The application uses an H2 in-memory database, which means data will be reset when the application restarts.
- The backend creates a `./tmp` directory for temporary files.
- CORS is configured to allow requests from the frontend running on `http://localhost:5173`.
- The application uses Spring Boot DevTools, which enables automatic restart when code changes are detected.

## Building for Production

1. Build the backend:
   ```
   mvn clean package
   ```

2. Build the frontend:
   ```
   cd frontend
   npm run build
   ```

## Troubleshooting

- If you encounter port conflicts, you can change the backend port in `src/main/resources/application.properties`.
- For frontend issues, check the Vite documentation at https://vitejs.dev/guide/.
