package com.example.cloudide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.io.File;

@SpringBootApplication
public class CloudIdeApplication {

    public static void main(String[] args) {
        // Create and set custom temp directory
        File tempDir = new File("./tmp");
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }
        System.setProperty("java.io.tmpdir", tempDir.getAbsolutePath());

        SpringApplication.run(CloudIdeApplication.class, args);
    }

}
