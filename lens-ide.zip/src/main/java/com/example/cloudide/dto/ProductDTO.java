package com.example.cloudide.dto;

import com.example.cloudide.model.Product;
import com.example.cloudide.model.ResourceUsage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDTO {
    private String id;
    private LocalDateTime date;
    private String name;
    private String clusterId;
    private String url;
    private KubernetesConfigDTO kubernetes;
    private List<UserDTO> users;
    private UserDTO admin;
    private ResourceUsage resourceUsage;
    
    public static ProductDTO fromEntity(Product product) {
        ProductDTO dto = new ProductDTO();
        dto.setId(product.getId());
        dto.setDate(product.getDate());
        dto.setName(product.getName());
        dto.setClusterId(product.getClusterId());
        dto.setUrl(product.getUrl());
        
        if (product.getKubernetes() != null) {
            KubernetesConfigDTO kubernetesDTO = new KubernetesConfigDTO();
            kubernetesDTO.setNamespace(product.getKubernetes().getNamespace());
            kubernetesDTO.setApiKey(product.getKubernetes().getApiKey());
            dto.setKubernetes(kubernetesDTO);
        }
        
        if (product.getUsers() != null) {
            dto.setUsers(product.getUsers().stream()
                    .map(UserDTO::fromEntity)
                    .collect(Collectors.toList()));
        }
        
        if (product.getAdmin() != null) {
            dto.setAdmin(UserDTO.fromEntity(product.getAdmin()));
        }
        
        dto.setResourceUsage(product.getResourceUsage());
        
        return dto;
    }
    
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class KubernetesConfigDTO {
        private String namespace;
        private String apiKey;
    }
}