package com.example.cloudide.dto;

import com.example.cloudide.model.PodConfig;
import com.example.cloudide.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {
    private String id;
    private String name;
    private String email;
    private String role;
    private String avatar;
    private LocalDateTime lastActivity;
    private PodConfig podConfig;
    
    public static UserDTO fromEntity(User user) {
        if (user == null) {
            return null;
        }
        
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setRole(user.getRole());
        dto.setAvatar(user.getAvatar());
        dto.setLastActivity(user.getLastActivity());
        dto.setPodConfig(user.getPodConfig());
        
        return dto;
    }
}