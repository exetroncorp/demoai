package com.example.cloudide.config;

import com.example.cloudide.model.*;
import com.example.cloudide.repository.KubernetesPodRepository;
import com.example.cloudide.repository.ProductRepository;
import com.example.cloudide.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final KubernetesPodRepository podRepository;

    @Autowired
    public DataInitializer(
            UserRepository userRepository,
            ProductRepository productRepository,
            KubernetesPodRepository podRepository) {
        this.userRepository = userRepository;
        this.productRepository = productRepository;
        this.podRepository = podRepository;
    }

    @Override
    @Transactional
    public void run(String... args) {
        // Create users
        User user1 = new User(
                "u1",
                "John Doe",
                "john@example.com",
                "admin",
                "https://i.pravatar.cc/150?u=u1",
                LocalDateTime.now(),
                new PodConfig(null, "2", "4Gi", "20Gi", "running", LocalDateTime.now())
        );

        User user2 = new User(
                "u2",
                "Jane Smith",
                "jane@example.com",
                "developer",
                "https://i.pravatar.cc/150?u=u2",
                LocalDateTime.now().minusDays(1),
                new PodConfig(null, "1", "2Gi", "10Gi", "stopped", LocalDateTime.now().minusDays(1))
        );

        User user3 = new User(
                "u3",
                "Bob Johnson",
                "bob@example.com",
                "viewer",
                "https://i.pravatar.cc/150?u=u3",
                LocalDateTime.now().minusDays(6),
                null
        );

        User user4 = new User(
                "u4",
                "Alice Williams",
                "alice@example.com",
                "developer",
                "https://i.pravatar.cc/150?u=u4",
                LocalDateTime.now().minusDays(2),
                new PodConfig(null, "0.5", "1Gi", "5Gi", "pending", LocalDateTime.now())
        );

        List<User> users = Arrays.asList(user1, user2, user3, user4);
        userRepository.saveAll(users);

        // Create resource usages
        ResourceUsage resourceUsage1 = new ResourceUsage(
                null,
                "0/8 cores",
                "0/16Gi",
                "0/100Gi",
                new ResourceUsage.DefaultLimits("2 cores", "4Gi", "20Gi")
        );

        ResourceUsage resourceUsage2 = new ResourceUsage(
                null,
                "0/4 cores",
                "0/8Gi",
                "0/50Gi",
                new ResourceUsage.DefaultLimits("1 core", "2Gi", "10Gi")
        );

        // Create products
        Product product1 = new Product(
                "1",
                LocalDateTime.now(),
                "Product A",
                "cluster-001",
                "https://api.example.com/product-a",
                new Product.KubernetesConfig("prod", ""),
                Arrays.asList(user1, user2, user3),
                user1,
                resourceUsage1
        );

        Product product2 = new Product(
                "2",
                LocalDateTime.now(),
                "Product B",
                "cluster-002",
                "https://api.example.com/product-b",
                new Product.KubernetesConfig("staging", ""),
                Arrays.asList(user1, user4),
                user1,
                resourceUsage2
        );

        List<Product> products = Arrays.asList(product1, product2);
        productRepository.saveAll(products);

        // Create Kubernetes pods
        KubernetesPod pod1 = new KubernetesPod(
                null,
                "jupyterhub-0",
                "Running",
                "prod",
                null,
                "jupyterhub",
                null
        );

        KubernetesPod pod2 = new KubernetesPod(
                null,
                "k8s-proxy-0",
                "Running",
                "prod",
                null,
                "proxy",
                null
        );

        KubernetesPod pod3 = new KubernetesPod(
                null,
                "code-server-u1",
                "Running",
                "prod",
                "u1",
                "code-server",
                new KubernetesPod.PodResources("2", "4Gi", "20Gi")
        );

        KubernetesPod pod4 = new KubernetesPod(
                null,
                "code-server-u2",
                "Terminated",
                "prod",
                "u2",
                "code-server",
                new KubernetesPod.PodResources("1", "2Gi", "10Gi")
        );

        KubernetesPod pod5 = new KubernetesPod(
                null,
                "jupyterhub-0",
                "Running",
                "staging",
                null,
                "jupyterhub",
                null
        );

        KubernetesPod pod6 = new KubernetesPod(
                null,
                "k8s-proxy-0",
                "Running",
                "staging",
                null,
                "proxy",
                null
        );

        KubernetesPod pod7 = new KubernetesPod(
                null,
                "code-server-u4",
                "Pending",
                "staging",
                "u4",
                "code-server",
                new KubernetesPod.PodResources("0.5", "1Gi", "5Gi")
        );

        List<KubernetesPod> pods = Arrays.asList(pod1, pod2, pod3, pod4, pod5, pod6, pod7);
        podRepository.saveAll(pods);
    }
}
