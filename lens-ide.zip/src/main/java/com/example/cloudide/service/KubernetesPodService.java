package com.example.cloudide.service;

import com.example.cloudide.model.KubernetesPod;
import com.example.cloudide.repository.KubernetesPodRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class KubernetesPodService {

    private final KubernetesPodRepository podRepository;

    @Autowired
    public KubernetesPodService(KubernetesPodRepository podRepository) {
        this.podRepository = podRepository;
    }

    public List<KubernetesPod> getAllPods() {
        return podRepository.findAll();
    }

    public Optional<KubernetesPod> getPodById(Long id) {
        return podRepository.findById(id);
    }

    public List<KubernetesPod> getPodsByNamespace(String namespace) {
        return podRepository.findByNamespace(namespace);
    }

    public List<KubernetesPod> getPodsByUser(String userId) {
        return podRepository.findByUser(userId);
    }

    public List<KubernetesPod> getPodsByNamespaceAndUser(String namespace, String userId) {
        return podRepository.findByNamespaceAndUser(namespace, userId);
    }

    @Transactional
    public KubernetesPod createPod(KubernetesPod pod) {
        return podRepository.save(pod);
    }

    @Transactional
    public Optional<KubernetesPod> updatePod(Long id, KubernetesPod podDetails) {
        return podRepository.findById(id)
                .map(existingPod -> {
                    existingPod.setName(podDetails.getName());
                    existingPod.setStatus(podDetails.getStatus());
                    existingPod.setNamespace(podDetails.getNamespace());
                    existingPod.setUser(podDetails.getUser());
                    existingPod.setType(podDetails.getType());

                    if (podDetails.getResources() != null) {
                        existingPod.setResources(podDetails.getResources());
                    }

                    return podRepository.save(existingPod);
                });
    }

    @Transactional
    public Optional<KubernetesPod> updatePodStatus(Long id, String status) {
        return podRepository.findById(id)
                .map(pod -> {
                    pod.setStatus(status);
                    return podRepository.save(pod);
                });
    }

    @Transactional
    public void deletePod(Long id) {
        podRepository.deleteById(id);
    }

    public String getPodLogs(String podName) {
        try {
            // Connect to Kubernetes API and get real logs
            Process process = Runtime.getRuntime().exec("kubectl logs " + podName);
            process.waitFor();

            // Read the output
            java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(process.getInputStream()));

            StringBuilder logs = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                logs.append(line).append("\n");
            }

            // If no logs were retrieved, provide a fallback message
            if (logs.length() == 0) {
                logs.append("[").append(java.time.LocalDateTime.now()).append("] ");
                logs.append("No logs available for pod ").append(podName).append("\n");
                logs.append("[INFO] Pod may still be initializing or has no output");
            }

            return logs.toString();
        } catch (Exception e) {
            // Log the error and return a message
            e.printStackTrace();
            return "Error retrieving logs: " + e.getMessage();
        }
    }
}
