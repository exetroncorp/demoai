package com.example.cloudide.service;

import com.example.cloudide.model.PodConfig;
import com.example.cloudide.model.User;
import com.example.cloudide.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(String id) {
        return userRepository.findById(id);
    }

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Transactional
    public User createUser(User user) {
        if (user.getId() == null || user.getId().isEmpty()) {
            user.setId("u" + UUID.randomUUID().toString().substring(0, 8));
        }
        
        if (user.getLastActivity() == null) {
            user.setLastActivity(LocalDateTime.now());
        }
        
        return userRepository.save(user);
    }

    @Transactional
    public Optional<User> updateUser(String id, User userDetails) {
        return userRepository.findById(id)
                .map(existingUser -> {
                    existingUser.setName(userDetails.getName());
                    existingUser.setEmail(userDetails.getEmail());
                    existingUser.setRole(userDetails.getRole());
                    existingUser.setAvatar(userDetails.getAvatar());
                    existingUser.setLastActivity(LocalDateTime.now());
                    
                    return userRepository.save(existingUser);
                });
    }

    @Transactional
    public Optional<User> updateUserPodConfig(String userId, PodConfig podConfig) {
        return userRepository.findById(userId)
                .map(user -> {
                    podConfig.setLastActivity(LocalDateTime.now());
                    user.setPodConfig(podConfig);
                    user.setLastActivity(LocalDateTime.now());
                    return userRepository.save(user);
                });
    }

    @Transactional
    public Optional<User> startUserPod(String userId) {
        return userRepository.findById(userId)
                .map(user -> {
                    if (user.getPodConfig() == null) {
                        throw new IllegalStateException("Pod not configured for user: " + userId);
                    }
                    
                    user.getPodConfig().setStatus("running");
                    user.getPodConfig().setLastActivity(LocalDateTime.now());
                    user.setLastActivity(LocalDateTime.now());
                    
                    return userRepository.save(user);
                });
    }

    @Transactional
    public Optional<User> stopUserPod(String userId) {
        return userRepository.findById(userId)
                .map(user -> {
                    if (user.getPodConfig() == null) {
                        throw new IllegalStateException("Pod not configured for user: " + userId);
                    }
                    
                    user.getPodConfig().setStatus("stopped");
                    user.getPodConfig().setLastActivity(LocalDateTime.now());
                    user.setLastActivity(LocalDateTime.now());
                    
                    return userRepository.save(user);
                });
    }

    @Transactional
    public Optional<User> deleteUserPod(String userId) {
        return userRepository.findById(userId)
                .map(user -> {
                    user.setPodConfig(null);
                    user.setLastActivity(LocalDateTime.now());
                    return userRepository.save(user);
                });
    }

    @Transactional
    public void deleteUser(String id) {
        userRepository.deleteById(id);
    }
}