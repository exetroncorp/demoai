package com.example.cloudide.service;

import com.example.cloudide.model.Product;
import com.example.cloudide.model.User;
import com.example.cloudide.repository.ProductRepository;
import com.example.cloudide.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @Autowired
    public ProductService(ProductRepository productRepository, UserRepository userRepository) {
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Optional<Product> getProductById(String id) {
        return productRepository.findById(id);
    }

    public List<Product> getProductsByUser(User user) {
        return productRepository.findByUsersContaining(user);
    }

    public List<Product> getProductsByAdmin(User admin) {
        return productRepository.findByAdmin(admin);
    }

    @Transactional
    public Product createProduct(Product product) {
        if (product.getId() == null || product.getId().isEmpty()) {
            product.setId(UUID.randomUUID().toString().substring(0, 8));
        }
        
        if (product.getDate() == null) {
            product.setDate(LocalDateTime.now());
        }
        
        return productRepository.save(product);
    }

    @Transactional
    public Optional<Product> updateProduct(String id, Product productDetails) {
        return productRepository.findById(id)
                .map(existingProduct -> {
                    existingProduct.setName(productDetails.getName());
                    existingProduct.setClusterId(productDetails.getClusterId());
                    existingProduct.setUrl(productDetails.getUrl());
                    
                    if (productDetails.getKubernetes() != null) {
                        existingProduct.setKubernetes(productDetails.getKubernetes());
                    }
                    
                    if (productDetails.getResourceUsage() != null) {
                        existingProduct.setResourceUsage(productDetails.getResourceUsage());
                    }
                    
                    return productRepository.save(existingProduct);
                });
    }

    @Transactional
    public Optional<Product> updateProductUsers(String productId, List<User> users) {
        return productRepository.findById(productId)
                .map(product -> {
                    product.setUsers(users);
                    return productRepository.save(product);
                });
    }

    @Transactional
    public Optional<Product> updateProductAdmin(String productId, String adminId) {
        return productRepository.findById(productId)
                .flatMap(product -> 
                    userRepository.findById(adminId)
                        .map(admin -> {
                            product.setAdmin(admin);
                            return productRepository.save(product);
                        })
                );
    }

    @Transactional
    public Optional<Product> retrieveApiKey(String productId, String url) {
        return productRepository.findById(productId)
                .map(product -> {
                    // In a real application, this would make an API call to retrieve the key
                    // For now, we'll generate a mock key
                    String apiKey = "k8s-key-" + UUID.randomUUID().toString().substring(0, 8);
                    
                    Product.KubernetesConfig kubernetes = product.getKubernetes();
                    kubernetes.setApiKey(apiKey);
                    product.setKubernetes(kubernetes);
                    
                    return productRepository.save(product);
                });
    }

    @Transactional
    public void deleteProduct(String id) {
        productRepository.deleteById(id);
    }
}