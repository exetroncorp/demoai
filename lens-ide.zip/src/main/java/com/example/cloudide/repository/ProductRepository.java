package com.example.cloudide.repository;

import com.example.cloudide.model.Product;
import com.example.cloudide.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, String> {
    List<Product> findByUsersContaining(User user);
    List<Product> findByAdmin(User admin);
}