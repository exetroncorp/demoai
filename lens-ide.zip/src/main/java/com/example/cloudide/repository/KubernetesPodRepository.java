package com.example.cloudide.repository;

import com.example.cloudide.model.KubernetesPod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KubernetesPodRepository extends JpaRepository<KubernetesPod, Long> {
    List<KubernetesPod> findByNamespace(String namespace);
    List<KubernetesPod> findByUser(String userId);
    List<KubernetesPod> findByNamespaceAndUser(String namespace, String userId);
}