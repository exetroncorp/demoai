package com.example.cloudide.controller;

import com.example.cloudide.model.KubernetesPod;
import com.example.cloudide.service.KubernetesPodService;
import com.example.cloudide.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pods")
public class KubernetesPodController {

    private final KubernetesPodService podService;
    private final ProductService productService;

    @Autowired
    public KubernetesPodController(KubernetesPodService podService, ProductService productService) {
        this.podService = podService;
        this.productService = productService;
    }

    @GetMapping
    public ResponseEntity<List<KubernetesPod>> getAllPods() {
        return ResponseEntity.ok(podService.getAllPods());
    }

    @GetMapping("/{id}")
    public ResponseEntity<KubernetesPod> getPodById(@PathVariable Long id) {
        return podService.getPodById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/namespace/{namespace}")
    public ResponseEntity<List<KubernetesPod>> getPodsByNamespace(@PathVariable String namespace) {
        return ResponseEntity.ok(podService.getPodsByNamespace(namespace));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<KubernetesPod>> getPodsByUser(@PathVariable String userId) {
        return ResponseEntity.ok(podService.getPodsByUser(userId));
    }

    @GetMapping("/product/{productId}")
    public ResponseEntity<List<KubernetesPod>> getPodsByProduct(@PathVariable String productId) {
        return productService.getProductById(productId)
                .map(product -> ResponseEntity.ok(podService.getPodsByNamespace(product.getKubernetes().getNamespace())))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<KubernetesPod> createPod(@RequestBody KubernetesPod pod) {
        return ResponseEntity.status(HttpStatus.CREATED).body(podService.createPod(pod));
    }

    @PutMapping("/{id}")
    public ResponseEntity<KubernetesPod> updatePod(@PathVariable Long id, @RequestBody KubernetesPod pod) {
        return podService.updatePod(id, pod)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<KubernetesPod> updatePodStatus(@PathVariable Long id, @RequestBody Map<String, String> request) {
        String status = request.get("status");
        if (status == null) {
            return ResponseEntity.badRequest().build();
        }

        return podService.updatePodStatus(id, status)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePod(@PathVariable Long id) {
        return podService.getPodById(id)
                .map(pod -> {
                    podService.deletePod(id);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{podName}/logs")
    public ResponseEntity<String> getPodLogs(@PathVariable String podName) {
        return ResponseEntity.ok(podService.getPodLogs(podName));
    }

    @GetMapping("/product/{productId}/system-architecture")
    public ResponseEntity<Map<String, Object>> getSystemArchitecture(@PathVariable String productId) {
        if (!productService.getProductById(productId).isPresent()) {
            return ResponseEntity.notFound().build();
        }

        try {
            // Get real system architecture data from Kubernetes API
            Process process = Runtime.getRuntime().exec("kubectl get pods -o json");
            process.waitFor();

            // Read the output
            java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(process.getInputStream()));

            StringBuilder jsonStr = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonStr.append(line);
            }

            // Parse JSON and convert to system architecture format
            // This is a simplified example - in a real application, you would parse the JSON properly
            List<Map<String, Object>> nodes = new java.util.ArrayList<>();
            List<Map<String, Object>> links = new java.util.ArrayList<>();

            // Add a proxy node
            nodes.add(Map.of("id", "proxy", "label", "K8s Proxy", "type", "proxy"));

            // Add pod nodes and links from the real data
            // In a real application, you would parse the JSON and extract the actual pod information
            List<KubernetesPod> pods = podService.getPodsByNamespace("default");
            for (KubernetesPod pod : pods) {
                nodes.add(Map.of(
                    "id", pod.getName(), 
                    "label", "Pod: " + pod.getName(), 
                    "type", "pod"
                ));
                links.add(Map.of("source", "proxy", "target", pod.getName()));
            }

            Map<String, Object> architecture = Map.of(
                "nodes", nodes,
                "links", links
            );

            return ResponseEntity.ok(architecture);
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback to a basic structure if there's an error
            Map<String, Object> fallbackArchitecture = Map.of(
                "nodes", List.of(Map.of("id", "proxy", "label", "K8s Proxy", "type", "proxy")),
                "links", List.of()
            );
            return ResponseEntity.ok(fallbackArchitecture);
        }
    }
}
