package com.example.cloudide.controller;

import com.example.cloudide.dto.ProductDTO;
import com.example.cloudide.model.Product;
import com.example.cloudide.model.User;
import com.example.cloudide.service.ProductService;
import com.example.cloudide.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;
    private final UserService userService;

    @Autowired
    public ProductController(ProductService productService, UserService userService) {
        this.productService = productService;
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<List<ProductDTO>> getAllProducts() {
        List<ProductDTO> productDTOs = productService.getAllProducts().stream()
                .map(ProductDTO::fromEntity)
                .collect(Collectors.toList());
        return ResponseEntity.ok(productDTOs);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> getProductById(@PathVariable String id) {
        return productService.getProductById(id)
                .map(ProductDTO::fromEntity)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<ProductDTO>> getProductsByUser(@PathVariable String userId) {
        Optional<User> user = userService.getUserById(userId);
        if (user.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<ProductDTO> productDTOs = productService.getProductsByUser(user.get()).stream()
                .map(ProductDTO::fromEntity)
                .collect(Collectors.toList());
        return ResponseEntity.ok(productDTOs);
    }

    @GetMapping("/admin/{adminId}")
    public ResponseEntity<List<ProductDTO>> getProductsByAdmin(@PathVariable String adminId) {
        Optional<User> admin = userService.getUserById(adminId);
        if (admin.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<ProductDTO> productDTOs = productService.getProductsByAdmin(admin.get()).stream()
                .map(ProductDTO::fromEntity)
                .collect(Collectors.toList());
        return ResponseEntity.ok(productDTOs);
    }

    @PostMapping
    public ResponseEntity<ProductDTO> createProduct(@RequestBody Product product) {
        Product createdProduct = productService.createProduct(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(ProductDTO.fromEntity(createdProduct));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductDTO> updateProduct(@PathVariable String id, @RequestBody Product product) {
        return productService.updateProduct(id, product)
                .map(ProductDTO::fromEntity)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/users")
    public ResponseEntity<ProductDTO> updateProductUsers(@PathVariable String id, @RequestBody List<User> users) {
        return productService.updateProductUsers(id, users)
                .map(ProductDTO::fromEntity)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/admin")
    public ResponseEntity<ProductDTO> updateProductAdmin(@PathVariable String id, @RequestBody Map<String, String> request) {
        String adminId = request.get("adminId");
        if (adminId == null) {
            return ResponseEntity.badRequest().build();
        }

        return productService.updateProductAdmin(id, adminId)
                .map(ProductDTO::fromEntity)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{id}/api-key")
    public ResponseEntity<ProductDTO> retrieveApiKey(@PathVariable String id, @RequestBody Map<String, String> request) {
        String url = request.get("url");
        if (url == null) {
            return ResponseEntity.badRequest().build();
        }

        return productService.retrieveApiKey(id, url)
                .map(ProductDTO::fromEntity)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable String id) {
        return productService.getProductById(id)
                .map(product -> {
                    productService.deleteProduct(id);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/connect-script")
    public ResponseEntity<byte[]> generateConnectScript(@PathVariable String id) {
        Optional<Product> product = productService.getProductById(id);

        // Generate a shell script
        String script;

        if (product.isPresent()) {
            script = String.format(
                "#!/bin/bash\n" +
                "# Generated connect script for %s\n" +
                "export CLUSTER_ID=\"%s\"\n" +
                "export NAMESPACE=\"%s\"\n" +
                "export API_KEY=\"%s\"\n\n" +
                "echo \"Connecting to cluster %s...\"\n" +
                "# Add your kubectl configuration commands here\n",
                product.get().getName(),
                product.get().getClusterId(),
                product.get().getKubernetes().getNamespace(),
                product.get().getKubernetes().getApiKey(),
                product.get().getClusterId()
            );
        } else {
            // For testing purposes, return a default script when product is not found
            script = String.format(
                "#!/bin/bash\n" +
                "# Generated connect script for test product\n" +
                "export CLUSTER_ID=\"test-cluster\"\n" +
                "export NAMESPACE=\"test-namespace\"\n" +
                "export API_KEY=\"test-api-key\"\n\n" +
                "echo \"Connecting to cluster test-cluster...\"\n" +
                "# Add your kubectl configuration commands here\n"
            );
        }

        return ResponseEntity
            .ok()
            .header("Content-Disposition", "attachment; filename=\"connect-" + (product.isPresent() ? product.get().getId() : "default") + ".sh\"")
            .header("Content-Type", "text/plain")
            .body(script.getBytes());
    }
}
