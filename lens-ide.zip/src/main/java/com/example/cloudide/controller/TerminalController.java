package com.example.cloudide.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api/terminal")
public class TerminalController {

    @PostMapping("/execute")
    public ResponseEntity<Map<String, Object>> executeCommand(@RequestBody Map<String, String> request) {
        String command = request.get("command");
        String namespace = request.get("namespace");

        Map<String, Object> response = new HashMap<>();

        if (command == null || command.trim().isEmpty()) {
            response.put("success", false);
            response.put("error", "Command cannot be empty");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            // Execute the command on the host server
            ProcessBuilder processBuilder = new ProcessBuilder();

            // Set up the command based on the namespace if provided
            if (namespace != null && !namespace.trim().isEmpty()) {
                processBuilder.command("powershell.exe", "-Command", "kubectl config use-context " + namespace + "; " + command);
            } else {
                processBuilder.command("powershell.exe", "-Command", command);
            }

            Process process = processBuilder.start();

            // Read the standard output
            BufferedReader stdOutReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder stdOut = new StringBuilder();
            String line;
            while ((line = stdOutReader.readLine()) != null) {
                stdOut.append(line).append("\n");
            }

            // Read the standard error
            BufferedReader stdErrReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            StringBuilder stdErr = new StringBuilder();
            while ((line = stdErrReader.readLine()) != null) {
                stdErr.append(line).append("\n");
            }

            // Wait for the process to complete with a timeout
            boolean completed = process.waitFor(10, TimeUnit.SECONDS);

            if (!completed) {
                process.destroyForcibly();
                response.put("success", false);
                response.put("error", "Command execution timed out");
                return ResponseEntity.ok(response);
            }

            int exitCode = process.exitValue();

            response.put("success", exitCode == 0);
            response.put("output", stdOut.toString());

            if (exitCode != 0) {
                response.put("error", stdErr.toString());
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Error executing command: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }

    @PostMapping("/interrupt")
    public ResponseEntity<Map<String, Object>> interruptCommand(@RequestBody Map<String, String> request) {
        String processId = request.get("processId");

        Map<String, Object> response = new HashMap<>();

        if (processId == null || processId.trim().isEmpty()) {
            response.put("success", false);
            response.put("error", "Process ID cannot be empty");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            // Stop the process using PowerShell
            Process process = Runtime.getRuntime().exec("powershell.exe -Command Stop-Process -Id " + processId + " -Force");
            int exitCode = process.waitFor();

            response.put("success", exitCode == 0);

            if (exitCode != 0) {
                BufferedReader stdErrReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                StringBuilder stdErr = new StringBuilder();
                String line;
                while ((line = stdErrReader.readLine()) != null) {
                    stdErr.append(line).append("\n");
                }
                response.put("error", stdErr.toString());
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "Error interrupting command: " + e.getMessage());
            return ResponseEntity.ok(response);
        }
    }
}
