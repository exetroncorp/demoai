package com.example.cloudide.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "resource_usages")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResourceUsage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String cpu;

    @Column(nullable = false)
    private String memory;

    @Column(nullable = false)
    private String storage;

    @Embedded
    private DefaultLimits defaultLimits;

    @Embeddable
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DefaultLimits {
        @Column(name = "default_cpu", nullable = false)
        private String cpu;

        @Column(name = "default_memory", nullable = false)
        private String memory;

        @Column(name = "default_storage", nullable = false)
        private String storage;
    }
}
