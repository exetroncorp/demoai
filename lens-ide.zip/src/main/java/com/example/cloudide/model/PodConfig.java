package com.example.cloudide.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "pod_configs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PodConfig {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String cpu;
    
    @Column(nullable = false)
    private String memory;
    
    @Column(nullable = false)
    private String storage;
    
    @Column(nullable = false)
    private String status;
    
    private LocalDateTime lastActivity;
}