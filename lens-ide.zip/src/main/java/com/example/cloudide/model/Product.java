package com.example.cloudide.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "products")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    @Id
    private String id;

    @Column(nullable = false)
    private LocalDateTime date;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String clusterId;

    @Column(nullable = false)
    private String url;

    @Embedded
    private KubernetesConfig kubernetes;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "product_users",
        joinColumns = @JoinColumn(name = "product_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private List<User> users;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "admin_id", nullable = false)
    private User admin;

    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    private ResourceUsage resourceUsage;

    @Embeddable
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class KubernetesConfig {
        @Column(name = "namespace", nullable = false)
        private String namespace;

        @Column(name = "api_key")
        private String apiKey;
    }
}
