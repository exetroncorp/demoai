package com.example.cloudide.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "kubernetes_pods")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class KubernetesPod {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String status;

    @Column(nullable = false)
    private String namespace;

    @Column(name = "user_id")
    private String user;

    private String type;

    @Column(name = "cpu")
    private String cpu;

    @Column(name = "memory")
    private String memory;

    @Column(name = "storage")
    private String storage;

    public KubernetesPod(Long id, String name, String status, String namespace, String user, String type, PodResources resources) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.namespace = namespace;
        this.user = user;
        this.type = type;
        if (resources != null) {
            this.cpu = resources.getCpu();
            this.memory = resources.getMemory();
            this.storage = resources.getStorage();
        }
    }

    public PodResources getResources() {
        if (cpu == null && memory == null && storage == null) {
            return null;
        }
        return new PodResources(cpu, memory, storage);
    }

    public void setResources(PodResources resources) {
        if (resources != null) {
            this.cpu = resources.getCpu();
            this.memory = resources.getMemory();
            this.storage = resources.getStorage();
        } else {
            this.cpu = null;
            this.memory = null;
            this.storage = null;
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PodResources {
        private String cpu;
        private String memory;
        private String storage;
    }
}
