package com.example.cloudide;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SimpleTest {

    @Test
    void simpleTest() {
        // This is a simple test that doesn't load the application context
        assertTrue(true, "This test should always pass");
    }
}