package com.example.cloudide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.MOCK,
    classes = com.example.cloudide.CloudIdeApplication.class
)
@TestPropertySource(properties = {
    "spring.jpa.hibernate.ddl-auto=create-drop",
    "spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE",
    "spring.datasource.driverClassName=org.h2.Driver",
    "spring.datasource.username=sa",
    "spring.datasource.password=password",
    "spring.jpa.database-platform=org.hibernate.dialect.H2Dialect",
    "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
    "spring.sql.init.mode=always",
    "spring.jpa.defer-datasource-initialization=true",
    "spring.main.allow-bean-definition-overriding=true"
})
@org.springframework.boot.test.mock.mockito.MockBean(com.example.cloudide.config.DataInitializer.class)
class CloudIdeApplicationTests {

    @Test
    void contextLoads() {
        // This test simply checks if the application context loads successfully
    }

}
