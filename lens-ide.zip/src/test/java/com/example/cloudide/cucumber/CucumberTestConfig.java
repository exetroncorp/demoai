package com.example.cloudide.cucumber;

import com.example.cloudide.config.DataInitializer;
import com.example.cloudide.model.Product;
import com.example.cloudide.model.User;
import com.example.cloudide.repository.ProductRepository;
import com.example.cloudide.repository.KubernetesPodRepository;
import com.example.cloudide.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.boot.CommandLineRunner;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@TestConfiguration
public class CucumberTestConfig {

    @Bean
    @Primary
    public DataInitializer dataInitializer(UserRepository userRepository, ProductRepository productRepository, KubernetesPodRepository podRepository) {
        // Return a mock DataInitializer that does nothing
        return new DataInitializer(userRepository, productRepository, podRepository) {
            @Override
            public void run(String... args) {
                // Do nothing - this prevents the original DataInitializer from running
            }
        };
    }

    @Bean
    public CommandLineRunner testDataInitializer(UserRepository userRepository, ProductRepository productRepository, KubernetesPodRepository podRepository) {
        return args -> {
            // Create test users
            // Create pod config for test-admin
            com.example.cloudide.model.PodConfig podConfig = new com.example.cloudide.model.PodConfig();
            podConfig.setCpu("2");
            podConfig.setMemory("4Gi");
            podConfig.setStorage("10Gi");
            podConfig.setStatus("STOPPED");
            podConfig.setLastActivity(LocalDateTime.now());

            User testAdmin = new User(
                    "test-admin",
                    "Test Admin",
                    "admin@test.com",
                    "admin",
                    null,
                    LocalDateTime.now(),
                    podConfig
            );

            // Create user with invalid config
            User invalidConfigUser = new User(
                    "invalid-config-user",
                    "Invalid Config User",
                    "invalid@test.com",
                    "user",
                    null,
                    LocalDateTime.now(),
                    null
            );

            userRepository.save(testAdmin);
            userRepository.save(invalidConfigUser);

            // Create test products
            Product product1 = new Product(
                    "test-1",
                    LocalDateTime.now(),
                    "Test Product 1",
                    "test-cluster",
                    "https://api.example.com/test-1",
                    new Product.KubernetesConfig("test", "test-api-key"),
                    null,
                    testAdmin,
                    null
            );

            Product product2 = new Product(
                    "test-2",
                    LocalDateTime.now(),
                    "Test Product 2",
                    "test-cluster",
                    "https://api.example.com/test-2",
                    new Product.KubernetesConfig("test", "test-api-key"),
                    null,
                    testAdmin,
                    null
            );

            List<Product> products = Arrays.asList(product1, product2);
            productRepository.saveAll(products);

            // Create test pod
            com.example.cloudide.model.KubernetesPod pod = new com.example.cloudide.model.KubernetesPod();
            pod.setId(1L);
            pod.setName("test-pod");
            pod.setNamespace("test");
            pod.setStatus("RUNNING");
            pod.setUser("test-admin");
            pod.setType("jupyter");
            pod.setCpu("2");
            pod.setMemory("4Gi");
            pod.setStorage("10Gi");
            podRepository.save(pod);
        };
    }
}
