package com.example.cloudide.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import io.restassured.http.ContentType;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
public class KubernetesPodApiStepDefinitions {

    private Map<String, Object> podPayload;
    private Map<String, Object> podStatusPayload;

    @When("I send a POST request to {string} with the pod payload")
    public void iSendAPOSTRequestToWithThePodPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending POST request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(podPayload)
                .when()
                .post(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @When("I send a PUT request to {string} with the pod payload")
    public void iSendAPUTRequestToWithThePodPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending PUT request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(podPayload)
                .when()
                .put(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @When("I send a PUT request to {string} with the pod status payload")
    public void iSendAPUTRequestToWithThePodStatusPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending PUT request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(podStatusPayload)
                .when()
                .put(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @Given("I have a valid pod payload")
    public void iHaveAValidPodPayload() {
        podPayload = new HashMap<>();
        podPayload.put("name", "test-pod");
        podPayload.put("namespace", "test-namespace");
        podPayload.put("status", "PENDING");
        podPayload.put("userId", "test-admin");
        podPayload.put("productId", "test-1");

        System.out.println("[DEBUG_LOG] Created pod payload: " + podPayload);
    }

    @Given("I have a valid pod status payload")
    public void iHaveAValidPodStatusPayload() {
        podStatusPayload = new HashMap<>();
        podStatusPayload.put("status", "RUNNING");

        System.out.println("[DEBUG_LOG] Created pod status payload: " + podStatusPayload);
    }


    @And("the response should contain a list of pods")
    public void theResponseShouldContainAListOfPods() {
        ApiStepDefinitions.response.then().body("", is(instanceOf(java.util.List.class)));
    }

    @Then("if the response is {int}, it should contain a list of pods")
    public void ifTheResponseIsItShouldContainAListOfPods(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("", is(instanceOf(java.util.List.class)));
        }
    }

    @And("if the response is {int}, it should contain a pod with id {string}")
    public void ifTheResponseIsItShouldContainAPodWithId(int statusCode, String id) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("id", equalTo(Long.parseLong(id)));
        }
    }

    @And("the response should contain the created pod")
    public void theResponseShouldContainTheCreatedPod() {
        ApiStepDefinitions.response.then()
                .body("name", equalTo(podPayload.get("name")))
                .body("namespace", equalTo(podPayload.get("namespace")))
                .body("status", equalTo(podPayload.get("status")));
    }

    @And("if the response is {int}, it should contain the updated pod")
    public void ifTheResponseIsItShouldContainTheUpdatedPod(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then()
                    .body("name", equalTo(podPayload.get("name")))
                    .body("namespace", equalTo(podPayload.get("namespace")))
                    .body("status", equalTo(podPayload.get("status")));
        }
    }

    @Then("the response should contain the updated pod")
    public void theResponseShouldContainTheUpdatedPod() {
        ApiStepDefinitions.response.then()
                .body("name", equalTo(podPayload.get("name")))
                .body("namespace", equalTo(podPayload.get("namespace")))
                .body("status", equalTo(podPayload.get("status")));
    }

    @And("if the response is {int}, it should contain a pod with status {string}")
    public void ifTheResponseIsItShouldContainAPodWithStatus(int statusCode, String status) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("status", equalTo(status));
        }
    }

    @Then("the response should contain a pod with status {string}")
    public void theResponseShouldContainAPodWithStatus(String status) {
        ApiStepDefinitions.response.then().body("status", equalTo(status));
    }

    @And("the response should contain pod logs")
    public void theResponseShouldContainPodLogs() {
        String responseBody = ApiStepDefinitions.response.getBody().asString();
        assertTrue(responseBody.length() > 0, "Expected pod logs to be non-empty");
    }

    @And("if the response is {int}, it should contain a system architecture diagram")
    public void ifTheResponseIsItShouldContainASystemArchitectureDiagram(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then()
                    .body("nodes", is(instanceOf(java.util.List.class)))
                    .body("links", is(instanceOf(java.util.List.class)));
        }
    }

    @Then("the response should contain a system architecture diagram")
    public void theResponseShouldContainASystemArchitectureDiagram() {
        ApiStepDefinitions.response.then()
                .body("nodes", is(instanceOf(java.util.List.class)))
                .body("links", is(instanceOf(java.util.List.class)));
    }

    @Then("the response should contain a pod with id {string}")
    public void theResponseShouldContainAPodWithId(String id) {
        ApiStepDefinitions.response.then().body("id", equalTo(Integer.parseInt(id)));
    }
}
