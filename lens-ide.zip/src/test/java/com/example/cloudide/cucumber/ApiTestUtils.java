package com.example.cloudide.cucumber;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Utility class for API testing with common methods used by step definitions.
 */
public class ApiTestUtils {

    /**
     * Sets up the RestAssured base URI and port.
     * 
     * @param port The port to use for RestAssured
     * @return A RequestSpecification for making requests
     */
    public static RequestSpecification setupRestAssured(int port) {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = port;
        return given();
    }

    /**
     * Sends a GET request to the specified endpoint.
     * 
     * @param request The RequestSpecification to use
     * @param endpoint The endpoint to send the request to
     * @return The Response from the request
     */
    public static Response sendGetRequest(RequestSpecification request, String endpoint) {
        System.out.println("[DEBUG_LOG] Sending GET request to: " + endpoint);
        Response response = request.when().get(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + response.getBody().asString());
        return response;
    }

    /**
     * Sends a DELETE request to the specified endpoint.
     * 
     * @param request The RequestSpecification to use
     * @param endpoint The endpoint to send the request to
     * @return The Response from the request
     */
    public static Response sendDeleteRequest(RequestSpecification request, String endpoint) {
        System.out.println("[DEBUG_LOG] Sending DELETE request to: " + endpoint);
        Response response = request.when().delete(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + response.getStatusCode());
        return response;
    }

    /**
     * Sends a POST request to the specified endpoint.
     * 
     * @param request The RequestSpecification to use
     * @param endpoint The endpoint to send the request to
     * @return The Response from the request
     */
    public static Response sendPostRequest(RequestSpecification request, String endpoint) {
        System.out.println("[DEBUG_LOG] Sending POST request to: " + endpoint);
        Response response = request.when().post(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + response.getBody().asString());
        return response;
    }

    /**
     * Asserts that the response status code is the expected value.
     * 
     * @param response The Response to check
     * @param expectedStatusCode The expected status code
     */
    public static void assertStatusCode(Response response, int expectedStatusCode) {
        assertEquals(expectedStatusCode, response.getStatusCode());
    }

    /**
     * Asserts that the response status code is one of the expected values.
     * 
     * @param response The Response to check
     * @param statusCode1 The first expected status code
     * @param statusCode2 The second expected status code
     */
    public static void assertStatusCodeOneOf(Response response, int statusCode1, int statusCode2) {
        int actualStatusCode = response.getStatusCode();
        assertTrue(
            actualStatusCode == statusCode1 || actualStatusCode == statusCode2,
            "Expected status code to be either " + statusCode1 + " or " + statusCode2 + ", but was " + actualStatusCode
        );
    }

    /**
     * Asserts that the response status code is one of the expected values.
     * 
     * @param response The Response to check
     * @param statusCode1 The first expected status code
     * @param statusCode2 The second expected status code
     * @param statusCode3 The third expected status code
     */
    public static void assertStatusCodeOneOfThree(Response response, int statusCode1, int statusCode2, int statusCode3) {
        int actualStatusCode = response.getStatusCode();
        assertTrue(
            actualStatusCode == statusCode1 || actualStatusCode == statusCode2 || actualStatusCode == statusCode3,
            "Expected status code to be either " + statusCode1 + ", " + statusCode2 + ", or " + statusCode3 + ", but was " + actualStatusCode
        );
    }
}