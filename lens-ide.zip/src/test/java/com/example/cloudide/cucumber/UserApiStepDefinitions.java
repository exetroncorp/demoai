package com.example.cloudide.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.http.ContentType;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
public class UserApiStepDefinitions {

    private Map<String, Object> userPayload;
    private Map<String, Object> podConfigPayload;

    @When("I send a POST request to {string} with the user payload")
    public void iSendAPOSTRequestToWithTheUserPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending POST request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(userPayload)
                .when()
                .post(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @When("I send a PUT request to {string} with the user payload")
    public void iSendAPUTRequestToWithTheUserPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending PUT request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(userPayload)
                .when()
                .put(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @When("I send a PUT request to {string} with the pod config payload")
    public void iSendAPUTRequestToWithThePodConfigPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending PUT request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(podConfigPayload)
                .when()
                .put(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @Given("I have a valid user payload")
    public void iHaveAValidUserPayload() {
        userPayload = new HashMap<>();
        userPayload.put("id", "test-user");
        userPayload.put("name", "Test User");
        userPayload.put("email", "user" + System.currentTimeMillis() + "@test.com");
        userPayload.put("role", "USER");

        System.out.println("[DEBUG_LOG] Created user payload: " + userPayload);
    }

    @Given("I have a valid pod config payload")
    public void iHaveAValidPodConfigPayload() {
        podConfigPayload = new HashMap<>();
        podConfigPayload.put("cpu", "2");
        podConfigPayload.put("memory", "4Gi");
        podConfigPayload.put("storage", "10Gi");
        podConfigPayload.put("status", "STOPPED");

        System.out.println("[DEBUG_LOG] Created pod config payload: " + podConfigPayload);
    }


    @And("the response should contain a list of users")
    public void theResponseShouldContainAListOfUsers() {
        ApiStepDefinitions.response.then().body("", is(instanceOf(java.util.List.class)));
    }

    @And("if the response is {int}, it should contain a user with id {string}")
    public void ifTheResponseIsItShouldContainAUserWithId(int statusCode, String id) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("id", equalTo(id));
        }
    }

    @And("if the response is {int}, it should contain a user with email {string}")
    public void ifTheResponseIsItShouldContainAUserWithEmail(int statusCode, String email) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("email", equalTo(email));
        }
    }

    @And("the response should contain the created user")
    public void theResponseShouldContainTheCreatedUser() {
        ApiStepDefinitions.response.then()
                .body("id", equalTo(userPayload.get("id")))
                .body("name", equalTo(userPayload.get("name")))
                .body("email", equalTo(userPayload.get("email")))
                .body("role", equalTo(userPayload.get("role")));
    }

    @And("if the response is {int}, it should contain the updated user")
    public void ifTheResponseIsItShouldContainTheUpdatedUser(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then()
                    .body("name", equalTo(userPayload.get("name")))
                    .body("email", equalTo(userPayload.get("email")))
                    .body("role", equalTo(userPayload.get("role")));
        }
    }

    @Then("the response should contain the updated user")
    public void theResponseShouldContainTheUpdatedUser() {
        ApiStepDefinitions.response.then()
                .body("name", equalTo(userPayload.get("name")))
                .body("email", equalTo(userPayload.get("email")))
                .body("role", equalTo(userPayload.get("role")));
    }

    @And("if the response is {int}, it should contain a user with updated pod config")
    public void ifTheResponseIsItShouldContainAUserWithUpdatedPodConfig(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then()
                    .body("podConfig.cpu", equalTo(podConfigPayload.get("cpu")))
                    .body("podConfig.memory", equalTo(podConfigPayload.get("memory")))
                    .body("podConfig.storage", equalTo(podConfigPayload.get("storage")))
                    .body("podConfig.status", equalTo(podConfigPayload.get("status")));
        }
    }

    @And("the response should contain a user with updated pod config")
    public void theResponseShouldContainAUserWithUpdatedPodConfig() {
        ApiStepDefinitions.response.then()
                .body("podConfig.cpu", equalTo(podConfigPayload.get("cpu")))
                .body("podConfig.memory", equalTo(podConfigPayload.get("memory")))
                .body("podConfig.storage", equalTo(podConfigPayload.get("storage")))
                .body("podConfig.status", equalTo(podConfigPayload.get("status")));
    }

    @And("if the response is {int}, it should contain a user with pod status {string}")
    public void ifTheResponseIsItShouldContainAUserWithPodStatus(int statusCode, String status) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("podConfig.status", equalTo(status));
        }
    }

    @And("the response should contain a user with pod status {string}")
    public void theResponseShouldContainAUserWithPodStatus(String status) {
        ApiStepDefinitions.response.then().body("podConfig.status", equalTo(status));
    }

    @And("if the response is {int}, it should contain a user with no pod config")
    public void ifTheResponseIsItShouldContainAUserWithNoPodConfig(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("podConfig", is(nullValue()));
        }
    }

    @And("the response should contain a user with no pod config")
    public void theResponseShouldContainAUserWithNoPodConfig() {
        ApiStepDefinitions.response.then().body("podConfig", is(nullValue()));
    }

    @Then("the response should contain a user with id {string}")
    public void theResponseShouldContainAUserWithId(String id) {
        ApiStepDefinitions.response.then().body("id", equalTo(id));
    }

    @Then("the response should contain a user with email {string}")
    public void theResponseShouldContainAUserWithEmail(String email) {
        ApiStepDefinitions.response.then().body("email", equalTo(email));
    }
}
