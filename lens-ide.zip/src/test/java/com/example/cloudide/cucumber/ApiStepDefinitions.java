package com.example.cloudide.cucumber;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.springframework.boot.test.web.server.LocalServerPort;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Common step definitions for API testing.
 */
public class ApiStepDefinitions {

    @LocalServerPort
    private int port;

    // These variables are static so they can be shared across step definition classes
    protected static Response response;
    protected static RequestSpecification request;

    @Given("the application is running")
    public void theApplicationIsRunning() {
        request = ApiTestUtils.setupRestAssured(port);
    }

    @When("I send a GET request to {string}")
    public void iSendAGETRequestTo(String endpoint) {
        response = ApiTestUtils.sendGetRequest(request, endpoint);
    }

    @When("I send a DELETE request to {string}")
    public void iSendADELETERequestTo(String endpoint) {
        response = ApiTestUtils.sendDeleteRequest(request, endpoint);
    }

    @When("I send a POST request to {string}")
    public void iSendAPOSTRequestTo(String endpoint) {
        response = ApiTestUtils.sendPostRequest(request, endpoint);
    }

    @Then("the response status code should be {int}")
    public void theResponseStatusCodeShouldBe(int statusCode) {
        ApiTestUtils.assertStatusCode(response, statusCode);
    }

    @Then("the response status code should be {int} or {int}")
    public void theResponseStatusCodeShouldBeOneOf(int statusCode1, int statusCode2) {
        ApiTestUtils.assertStatusCodeOneOf(response, statusCode1, statusCode2);
    }

    @Then("the response status code should be {int} or {int} or {int}")
    public void theResponseStatusCodeShouldBeOneOfThree(int statusCode1, int statusCode2, int statusCode3) {
        ApiTestUtils.assertStatusCodeOneOfThree(response, statusCode1, statusCode2, statusCode3);
    }
}
