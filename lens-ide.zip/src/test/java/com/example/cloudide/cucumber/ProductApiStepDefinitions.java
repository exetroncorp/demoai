package com.example.cloudide.cucumber;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.restassured.http.ContentType;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
public class ProductApiStepDefinitions {

    private Map<String, Object> productPayload;

    @When("I send a POST request to {string} with the product payload")
    public void iSendAPOSTRequestToWithTheProductPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending POST request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(productPayload)
                .when()
                .post(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @When("I send a PUT request to {string} with the product payload")
    public void iSendAPUTRequestToWithTheProductPayload(String endpoint) {
        System.out.println("[DEBUG_LOG] Sending PUT request to: " + endpoint);
        ApiStepDefinitions.response = ApiStepDefinitions.request
                .contentType(ContentType.JSON)
                .body(productPayload)
                .when()
                .put(endpoint);
        System.out.println("[DEBUG_LOG] Response status code: " + ApiStepDefinitions.response.getStatusCode());
        System.out.println("[DEBUG_LOG] Response body: " + ApiStepDefinitions.response.getBody().asString());
    }

    @Given("I have a valid product payload")
    public void iHaveAValidProductPayload() {
        productPayload = new HashMap<>();
        productPayload.put("name", "Test Product");
        productPayload.put("clusterId", "test-cluster");
        productPayload.put("url", "https://test-product.example.com");

        Map<String, String> kubernetes = new HashMap<>();
        kubernetes.put("namespace", "test-namespace");
        kubernetes.put("apiKey", "test-api-key");
        productPayload.put("kubernetes", kubernetes);

        System.out.println("[DEBUG_LOG] Created product payload: " + productPayload);
    }

    @Given("I have a valid product payload with admin")
    public void iHaveAValidProductPayloadWithAdmin() {
        // First create a basic product payload
        iHaveAValidProductPayload();

        // Add admin information
        Map<String, Object> admin = new HashMap<>();
        admin.put("id", "test-admin");
        admin.put("name", "Test Admin");
        admin.put("email", "admin@test.com");
        admin.put("role", "ADMIN");

        productPayload.put("admin", admin);

        System.out.println("[DEBUG_LOG] Created product payload with admin: " + productPayload);
    }


    @And("the response should contain a list of products")
    public void theResponseShouldContainAListOfProducts() {
        ApiStepDefinitions.response.then().body("", is(instanceOf(java.util.List.class)));
    }

    @And("if the response is {int}, it should contain a list of products")
    public void ifTheResponseIsItShouldContainAListOfProducts(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("", is(instanceOf(java.util.List.class)));
        }
    }

    @And("the response should contain a product with id {string}")
    public void theResponseShouldContainAProductWithId(String id) {
        ApiStepDefinitions.response.then().body("id", equalTo(id));
    }

    @And("if the response is {int}, it should contain a product with id {string}")
    public void ifTheResponseIsItShouldContainAProductWithId(int statusCode, String id) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then().body("id", equalTo(id));
        }
    }

    @And("the response should contain the created product")
    public void theResponseShouldContainTheCreatedProduct() {
        ApiStepDefinitions.response.then()
                .body("name", equalTo(productPayload.get("name")))
                .body("clusterId", equalTo(productPayload.get("clusterId")))
                .body("url", equalTo(productPayload.get("url")));
    }

    @And("if the response is {int}, it should contain the created product")
    public void ifTheResponseIsItShouldContainTheCreatedProduct(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then()
                    .body("name", equalTo(productPayload.get("name")))
                    .body("clusterId", equalTo(productPayload.get("clusterId")))
                    .body("url", equalTo(productPayload.get("url")));
        }
    }

    @And("the response should contain the updated product")
    public void theResponseShouldContainTheUpdatedProduct() {
        ApiStepDefinitions.response.then()
                .body("name", equalTo(productPayload.get("name")))
                .body("clusterId", equalTo(productPayload.get("clusterId")))
                .body("url", equalTo(productPayload.get("url")));
    }

    @And("if the response is {int}, it should contain the updated product")
    public void ifTheResponseIsItShouldContainTheUpdatedProduct(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            ApiStepDefinitions.response.then()
                    .body("name", equalTo(productPayload.get("name")))
                    .body("clusterId", equalTo(productPayload.get("clusterId")))
                    .body("url", equalTo(productPayload.get("url")));
        }
    }

    @And("the response should contain a shell script")
    public void theResponseShouldContainAShellScript() {
        String responseBody = ApiStepDefinitions.response.getBody().asString();
        assertTrue(responseBody.contains("#!/bin/bash"));
        assertTrue(responseBody.contains("CLUSTER_ID"));
        assertTrue(responseBody.contains("NAMESPACE"));
        assertTrue(responseBody.contains("API_KEY"));
    }

    @And("if the response is {int}, it should contain a shell script")
    public void ifTheResponseIsItShouldContainAShellScript(int statusCode) {
        if (ApiStepDefinitions.response.getStatusCode() == statusCode) {
            String responseBody = ApiStepDefinitions.response.getBody().asString();
            assertTrue(responseBody.contains("#!/bin/bash"));
            assertTrue(responseBody.contains("CLUSTER_ID"));
            assertTrue(responseBody.contains("NAMESPACE"));
            assertTrue(responseBody.contains("API_KEY"));
        }
    }
}
