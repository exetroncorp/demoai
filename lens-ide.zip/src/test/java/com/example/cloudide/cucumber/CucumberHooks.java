package com.example.cloudide.cucumber;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Hooks for Cucumber tests.
 * This class is responsible for setting up the test environment before tests run
 * and cleaning up after tests complete.
 */
@CucumberContextConfiguration
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {com.example.cloudide.CloudIdeApplication.class, CucumberTestConfig.class}
)
@ActiveProfiles("test")
public class CucumberHooks {

    private static boolean applicationStarted = false;

    /**
     * This hook runs before each scenario.
     * It ensures the application is started only once for all scenarios.
     */
    @Before
    public void beforeScenario() {
        if (!applicationStarted) {
            System.out.println("[DEBUG_LOG] Starting application for all scenarios");
            applicationStarted = true;
        }
    }

    /**
     * This hook runs after all scenarios have completed.
     * It can be used for cleanup operations.
     */
    @After
    public void afterScenario() {
        // No cleanup needed as Spring Boot will handle shutdown
    }
}