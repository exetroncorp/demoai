// API URLs
export const API_BASE_URL = 'http://localhost:8080/api';
export const WS_BASE_URL = 'ws://localhost:8080/api';

// Terminal paths
export const TERMINAL_PATH = '/terminal';