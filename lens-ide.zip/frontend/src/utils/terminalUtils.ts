
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import { WebLinksAddon } from 'xterm-addon-web-links';
import { SearchAddon } from 'xterm-addon-search';

// Define the terminal options with correct types
export const getDefaultTerminalOptions = () => ({
  cursorBlink: true,
  fontSize: 14,
  fontFamily: 'JetBrains Mono, Consolas, monospace',
  theme: {
    background: '#1a1b1e',
    foreground: '#ffffff',
    cursor: '#ffffff',
    black: '#000000',
    brightBlack: '#808080',
    red: '#ff0000',
    brightRed: '#ff8080',
    green: '#00ff00',
    brightGreen: '#80ff80',
    yellow: '#ffff00',
    brightYellow: '#ffff80',
    blue: '#0000ff',
    brightBlue: '#8080ff',
    magenta: '#ff00ff',
    brightMagenta: '#ff80ff',
    cyan: '#00ffff',
    brightCyan: '#80ffff',
    white: '#ffffff',
    brightWhite: '#ffffff'
  },
  allowTransparency: true,
  scrollback: 10000,
  convertEol: true,
  cursorStyle: 'block' as const, // Type-cast to literal type
  wordSeparator: ' ()[]{}\'"',
});

export const setupTerminalAddons = (term: Terminal) => {
  const fitAddon = new FitAddon();
  const webLinksAddon = new WebLinksAddon();
  const searchAddon = new SearchAddon();

  term.loadAddon(fitAddon);
  term.loadAddon(webLinksAddon);
  term.loadAddon(searchAddon);

  return { fitAddon, webLinksAddon, searchAddon };
};

export const displayWelcomeMessage = (term: Terminal, namespace: string) => {
  term.writeln('\x1b[1;32m╔══════════════════════════════════════╗');
  term.writeln('║ Connected to Kubernetes Terminal      ║');
  term.writeln('╚══════════════════════════════════════╝\x1b[0m');
  term.writeln(`\x1b[34mNamespace:\x1b[0m ${namespace}`);
  term.writeln('\x1b[90mType commands and press Enter to execute.\x1b[0m');
  term.writeln('\x1b[90mPress Ctrl+C to interrupt a command.\x1b[0m');
  term.writeln('\x1b[90mType \x1b[1;33mhelp\x1b[0;90m to see available commands.\x1b[0m');
  term.writeln('');
  term.write('\x1b[32m$\x1b[0m ');
};

export const displayErrorMessage = (term: Terminal) => {
  term.writeln('\x1b[1;31m╔══════════════════════════════════════╗');
  term.writeln('║ Failed to connect to terminal server   ║');
  term.writeln('╚══════════════════════════════════════╝\x1b[0m');
  term.writeln('\x1b[33mRunning in mock mode\x1b[0m');
  term.writeln('\x1b[90mType \x1b[1;33mhelp\x1b[0;90m to see available commands.\x1b[0m');
  term.write('\x1b[32m$\x1b[0m ');
};
