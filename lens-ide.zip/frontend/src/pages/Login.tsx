
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { LogIn, Key } from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";

const Login = () => {
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Add a small delay to simulate API call
    setTimeout(() => {
      const success = login(password);
      
      if (success) {
        toast({
          title: "Login successful",
          description: "Welcome to Kubernetes Product Nexus",
        });
        navigate("/");
      } else {
        toast({
          title: "Login failed",
          description: "Invalid master key",
          variant: "destructive",
        });
      }
      
      setIsLoading(false);
    }, 500);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background to-background/80 p-4 relative font-jetbrains">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      <div className="w-full max-w-md space-y-8 rounded-lg bg-card p-8 shadow-xl border border-border">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-foreground tracking-tight">Kubernetes Product Nexus</h1>
          <p className="mt-2 text-muted-foreground">Enter master key to continue</p>
        </div>
        
        <form onSubmit={handleSubmit} className="mt-8 space-y-6">
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-foreground">
              Master Key
            </label>
            <div className="mt-1 relative">
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter master key"
                className="pl-10 bg-background/50 font-mono"
                required
              />
              <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            </div>
          </div>
          
          <Button 
            type="submit" 
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground flex items-center justify-center gap-2"
            disabled={isLoading}
          >
            {isLoading ? "Authenticating..." : "Login"}
            {!isLoading && <LogIn className="w-4 h-4" />}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default Login;
