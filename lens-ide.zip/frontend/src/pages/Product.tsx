
import { ProductDetail } from "@/components/ProductDetail";

const Product = () => {
  return <ProductDetail />;
};

export default Product;
