
import { ProductList } from "@/components/ProductList";
import { Dashboard } from "@/components/Dashboard";

const Index = () => {
  return (
    <div className="container mx-auto p-6 space-y-8">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      <Dashboard />
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Products</h2>
        <ProductList />
      </div>
    </div>
  );
};

export default Index;
