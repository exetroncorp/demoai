
import { useRef, useCallback } from 'react';
import { Terminal } from 'xterm';
import { useToast } from "@/hooks/use-toast";

type MessageHandler = (data: unknown) => void;

interface UseTerminalWebSocketOptions {
  url: string;
  namespace: string;
  term: Terminal | null;
  cols: number;
  rows: number;
}

export const useTerminalWebSocket = ({
  url,
  namespace,
  term,
  cols,
  rows
}: UseTerminalWebSocketOptions) => {
  const wsRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();
  const mockStreamingRef = useRef<NodeJS.Timeout | null>(null);

  const initializeWebSocket = useCallback(() => {
    if (!term) return null;

    try {
      // Real implementation using WebSocket connection
      console.log("Initializing WebSocket connection (real mode)");

      const ws = new WebSocket(`${url}/${namespace}`);
      wsRef.current = ws;

      ws.onopen = () => {
        // Send initial connection message
        ws.send(JSON.stringify({
          type: 'init',
          namespace: namespace,
          cols: cols,
          rows: rows
        }));

        term.writeln('\x1b[1;32mConnected to Cloud IDE terminal server\x1b[0m');
        term.writeln('This terminal is connected to your code-server pod running on Kubernetes');
        term.writeln('Type `help` for available commands.');
        term.write('$ ');
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          switch (data.type) {
            case 'output':
              term.writeln(data.content);
              if (!data.streaming) {
                term.write('$ ');
              }
              break;
            case 'error':
              term.writeln(`\x1b[1;31mError: ${data.content}\x1b[0m`);
              term.write('$ ');
              break;
            case 'streamEnd':
              term.write('$ ');
              break;
          }
        } catch (e) {
          console.error('Failed to parse WebSocket message:', e);
          term.writeln('\x1b[1;31mError: Invalid server response\x1b[0m');
          term.write('$ ');
        }
      };

      ws.onclose = () => {
        term.writeln('\x1b[1;31m=== Connection closed ===\x1b[0m');
        toast({
          variant: "destructive",
          title: "Connection lost",
          description: "Terminal connection was closed. Try refreshing the page.",
        });
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        toast({
          variant: "destructive",
          title: "Connection error",
          description: "Failed to connect to terminal server.",
        });
      };

      return ws;
    } catch (error) {
      console.error('Failed to initialize WebSocket:', error);
      toast({
        variant: "destructive",
        title: "Connection error",
        description: "Failed to initialize terminal connection.",
      });

      return null;
    }
  }, [term, url, namespace, cols, rows, toast]);

  const sendCommand = useCallback((command: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'command',
        content: command.trim()
      }));
    } else if (term) {
      // Use real command execution via REST API
      console.log("Sending command via REST API:", command);

      // Show command is being processed
      term.writeln(`Executing: ${command}`);

      // Execute the command on the server
      fetch('/api/terminal/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          command: command.trim(),
          namespace: namespace
        }),
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Display the command output
          if (data.output) {
            term.writeln(data.output);
          } else {
            term.writeln('Command executed successfully (no output)');
          }
        } else {
          // Display error message
          term.writeln('\x1b[1;31mError: ' + (data.error || 'Unknown error occurred') + '\x1b[0m');
        }

        // Show prompt after command completes
        term.write('\x1b[32m$\x1b[0m ');
      })
      .catch(error => {
        console.error('Error executing command:', error);
        term.writeln('\x1b[1;31mError: Failed to execute command. Server may be unavailable.\x1b[0m');
        term.write('\x1b[32m$\x1b[0m ');
      });

      // Don't show prompt immediately, wait for the response
      return;
    }
  }, [term, namespace]);

  const sendInterrupt = useCallback(() => {
    if (mockStreamingRef.current) {
      clearInterval(mockStreamingRef.current);
      mockStreamingRef.current = null;
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'interrupt' }));
    } else if (term) {
      // Use real interrupt via REST API
      console.log("Sending interrupt via REST API");
      term.writeln('^C');

      // In a real implementation, we would track the process ID of the running command
      // For now, we'll use a dummy process ID
      const dummyProcessId = "0"; // This won't actually interrupt anything

      fetch('/api/terminal/interrupt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          processId: dummyProcessId
        }),
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          term.writeln('Command interrupted');
        } else {
          term.writeln('\x1b[1;31mError: ' + (data.error || 'Failed to interrupt command') + '\x1b[0m');
        }
        term.write('\x1b[32m$\x1b[0m ');
      })
      .catch(error => {
        console.error('Error interrupting command:', error);
        term.writeln('\x1b[1;31mError: Failed to interrupt command. Server may be unavailable.\x1b[0m');
        term.write('\x1b[32m$\x1b[0m ');
      });
    }
  }, [term]);

  const sendResize = useCallback((cols: number, rows: number) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'resize',
        cols: cols,
        rows: rows
      }));
    }
    console.log(`Terminal resized to ${cols}x${rows}`);
  }, []);

  const closeConnection = useCallback(() => {
    if (mockStreamingRef.current) {
      clearInterval(mockStreamingRef.current);
      mockStreamingRef.current = null;
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.close();
    }
    wsRef.current = null;
  }, []);

  return {
    webSocket: wsRef.current,
    initializeWebSocket,
    sendCommand,
    sendInterrupt,
    sendResize,
    closeConnection
  };
};
