
import { useCallback, useRef } from 'react';
import { Terminal } from 'xterm';

interface UseTerminalInputOptions {
  term: Terminal | null;
  onCommand: (command: string) => void;
  onInterrupt: () => void;
}

export const useTerminalInput = ({
  term,
  onCommand,
  onInterrupt
}: UseTerminalInputOptions) => {
  const commandHistoryRef = useRef<string[]>([]);
  const historyIndexRef = useRef<number>(-1);
  const currentLineRef = useRef<string>('');
  const cursorPositionRef = useRef<number>(0);

  const setupInputHandlers = useCallback(() => {
    if (!term) return;

    console.log("Setting up terminal input handlers");

    const keyHandler = ({ key, domEvent }: { key: string, domEvent: KeyboardEvent }) => {
      const printable = !domEvent.altKey && !domEvent.ctrlKey && !domEvent.metaKey;

      switch (domEvent.keyCode) {
        case 13: // Enter
          term.writeln('');
          if (currentLineRef.current.trim()) {
            commandHistoryRef.current.push(currentLineRef.current.trim());
            historyIndexRef.current = commandHistoryRef.current.length;
            onCommand(currentLineRef.current.trim());
          } else {
            term.write('\x1b[32m$\x1b[0m ');
          }
          currentLineRef.current = '';
          cursorPositionRef.current = 0;
          break;

        case 38: // Up arrow
          if (historyIndexRef.current > 0) {
            historyIndexRef.current--;
            term.write('\x1b[2K\r\x1b[32m$\x1b[0m ');
            currentLineRef.current = commandHistoryRef.current[historyIndexRef.current];
            term.write(currentLineRef.current);
            cursorPositionRef.current = currentLineRef.current.length;
          }
          break;

        case 40: // Down arrow
          if (historyIndexRef.current < commandHistoryRef.current.length - 1) {
            historyIndexRef.current++;
            term.write('\x1b[2K\r\x1b[32m$\x1b[0m ');
            currentLineRef.current = commandHistoryRef.current[historyIndexRef.current];
            term.write(currentLineRef.current);
            cursorPositionRef.current = currentLineRef.current.length;
          } else if (historyIndexRef.current === commandHistoryRef.current.length - 1) {
            historyIndexRef.current = commandHistoryRef.current.length;
            term.write('\x1b[2K\r\x1b[32m$\x1b[0m ');
            currentLineRef.current = '';
            cursorPositionRef.current = 0;
          }
          break;

        case 37: // Left arrow
          if (cursorPositionRef.current > 0) {
            cursorPositionRef.current--;
            term.write(key);
          }
          break;

        case 39: // Right arrow
          if (cursorPositionRef.current < currentLineRef.current.length) {
            cursorPositionRef.current++;
            term.write(key);
          }
          break;

        case 8: // Backspace
          if (cursorPositionRef.current > 0) {
            currentLineRef.current = 
              currentLineRef.current.slice(0, cursorPositionRef.current - 1) + 
              currentLineRef.current.slice(cursorPositionRef.current);
            cursorPositionRef.current--;
            term.write('\b \b');
          }
          break;

        case 3: // Ctrl+C
          onInterrupt();
          term.writeln('^C');
          term.write('\x1b[32m$\x1b[0m ');
          currentLineRef.current = '';
          cursorPositionRef.current = 0;
          break;

        default:
          if (printable) {
            currentLineRef.current = 
              currentLineRef.current.slice(0, cursorPositionRef.current) + 
              key + 
              currentLineRef.current.slice(cursorPositionRef.current);
            cursorPositionRef.current++;
            term.write(key);
          }
      }
    };

    term.onKey(keyHandler);
  }, [term, onCommand, onInterrupt]);

  return { setupInputHandlers };
};
