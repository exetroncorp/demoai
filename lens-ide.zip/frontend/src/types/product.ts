export interface Product {
  id: string;
  date: string;
  name: string;
  clusterId: string;
  url: string;
  kubernetes: {
    namespace: string;
    apiKey: string;
  };
  users: User[];
  admin: User;
  getApiKey: (url: string) => Promise<string>;
  resourceUsage: ResourceUsage;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: "admin" | "developer" | "viewer";
  avatar?: string;
  podConfig?: PodConfig;
  lastActivity?: string;
}

export interface PodConfig {
  cpu: string;
  memory: string;
  storage: string;
  status: "running" | "stopped" | "pending" | "error";
  lastActivity?: string;
}

export interface KubernetesPod {
  name: string;
  status: string;
  namespace: string;
  user?: string;
  type?: "code-server" | "jupyterhub" | "proxy";
  resources?: {
    cpu: string;
    memory: string;
    storage: string;
  };
}

export interface ResourceUsage {
  cpu: string;
  memory: string;
  storage: string;
  defaultLimits: {
    cpu: string;
    memory: string;
    storage: string;
  };
}
