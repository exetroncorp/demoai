
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { PodsList } from "./PodsList";
import { PodLogsViewer } from "./PodLogsViewer";
import { SystemArchitecture } from "./SystemArchitecture";
import { KubernetesTerminal } from "./KubernetesTerminal";
import { Terminal } from "lucide-react";
import { KubernetesPod, Product } from "@/types/product";
import { useState } from "react";

interface KubernetesResourcesTabsProps {
  product: Product;
  pods: KubernetesPod[] | undefined;
  namespace: string;
}

export const KubernetesResourcesTabs = ({ 
  product, 
  pods,
  namespace
}: KubernetesResourcesTabsProps) => {
  const [activeTab, setActiveTab] = useState<string>("pods");
  const [selectedPod, setSelectedPod] = useState<string | null>(null);

  const handleViewLogs = (podName: string) => {
    setSelectedPod(podName);
    setActiveTab("logs");
  };

  return (
    <Card className="glass-card">
      <div className="p-6">
        <h2 className="text-xl font-semibold mb-4">Kubernetes Resources</h2>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="pods">Pods</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
            <TabsTrigger value="terminal">Terminal</TabsTrigger>
            <TabsTrigger value="architecture">Architecture</TabsTrigger>
          </TabsList>
          
          <TabsContent value="pods" className="mt-4">
            <PodsList 
              pods={pods} 
              onViewLogs={handleViewLogs}
              users={product.users}
            />
          </TabsContent>

          <TabsContent value="logs" className="mt-4">
            <PodLogsViewer selectedPod={selectedPod} />
          </TabsContent>

          <TabsContent value="terminal" className="mt-4">
            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center gap-2 mb-4">
                <Terminal className="h-4 w-4" />
                <span className="text-sm">Kubectl Terminal</span>
              </div>
              <KubernetesTerminal namespace={namespace} />
            </div>
          </TabsContent>
          
          <TabsContent value="architecture" className="mt-4">
            <SystemArchitecture productId={product.id} product={product} />
          </TabsContent>
        </Tabs>
      </div>
    </Card>
  );
};
