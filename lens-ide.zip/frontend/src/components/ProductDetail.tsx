
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { getProduct, getPodsByProduct } from "@/services/productService";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { UserPodManagement } from "./UserPodManagement";
import { ProductInfo } from "./ProductInfo";
import { TeamManagement } from "./TeamManagement";
import { KubernetesResourcesTabs } from "./KubernetesResourcesTabs";
import { startUserPod, stopUserPod, deleteUserPod, updateUserPodConfig } from "@/services/productService";
import { PodConfig } from "@/types/product";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: () => getProduct(id!),
  });

  const { data: pods } = useQuery({
    queryKey: ["pods", id],
    queryFn: () => getPodsByProduct(id!),
    enabled: !!id,
  });

  // Pod management mutations
  const updatePodConfigMutation = useMutation({
    mutationFn: ({ userId, podConfig }: { userId: string; podConfig: PodConfig }) =>
      updateUserPodConfig(id!, userId, podConfig),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["product", id] });
      queryClient.invalidateQueries({ queryKey: ["pods", id] });
    }
  });

  const startPodMutation = useMutation({
    mutationFn: (userId: string) => startUserPod(id!, userId),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["product", id] });
      queryClient.invalidateQueries({ queryKey: ["pods", id] });
      toast({
        title: "Pod started",
        description: `Started pod for ${data.name}`,
      });
    }
  });

  const stopPodMutation = useMutation({
    mutationFn: (userId: string) => stopUserPod(id!, userId),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["product", id] });
      queryClient.invalidateQueries({ queryKey: ["pods", id] });
      toast({
        title: "Pod stopped",
        description: `Stopped pod for ${data.name}`,
      });
    }
  });

  const deletePodMutation = useMutation({
    mutationFn: (userId: string) => deleteUserPod(id!, userId),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["product", id] });
      queryClient.invalidateQueries({ queryKey: ["pods", id] });
      toast({
        title: "Pod deleted",
        description: `Deleted pod for ${data.name}`,
      });
    }
  });

  const handleUpdateUserPod = async (userId: string, podConfig: PodConfig) => {
    await updatePodConfigMutation.mutateAsync({ userId, podConfig });
  };

  const handleStartPod = async (userId: string) => {
    await startPodMutation.mutateAsync(userId);
  };

  const handleStopPod = async (userId: string) => {
    await stopPodMutation.mutateAsync(userId);
  };

  const handleDeletePod = async (userId: string) => {
    await deletePodMutation.mutateAsync(userId);
  };

  if (isLoading) {
    return <div className="container mx-auto p-6">Loading...</div>;
  }

  if (!product) {
    return <div className="container mx-auto p-6">Product not found</div>;
  }

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <Button
        variant="ghost"
        className="mb-6"
        onClick={() => navigate("/")}
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Products
      </Button>

      <div className="grid gap-6">
        <ProductInfo product={product} />
        
        <UserPodManagement 
          users={product.users}
          onUpdateUserPod={handleUpdateUserPod}
          onStartPod={handleStartPod}
          onStopPod={handleStopPod}
          onDeletePod={handleDeletePod}
        />

        <TeamManagement product={product} />

        <KubernetesResourcesTabs 
          product={product} 
          pods={pods}
          namespace={product.kubernetes.namespace}
        />
      </div>
    </div>
  );
};
