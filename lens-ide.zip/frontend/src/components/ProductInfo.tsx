import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Product } from "@/types/product";
import { Copy, Download, Eye, EyeOff, ExternalLink, Key, MemoryStick, HardDrive, Cpu, Edit } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { retrieveApiKey, generateConnectScript, updateDefaultResourceLimits } from "@/services/productService";
import { Input } from "./ui/input";

interface ProductInfoProps {
  product: Product;
}

export const ProductInfo = ({ product }: ProductInfoProps) => {
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [editingLimits, setEditingLimits] = useState<boolean>(false);
  const [defaultLimits, setDefaultLimits] = useState({
    cpu: product.resourceUsage.defaultLimits.cpu,
    memory: product.resourceUsage.defaultLimits.memory,
    storage: product.resourceUsage.defaultLimits.storage,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const retrieveApiKeyMutation = useMutation({
    mutationFn: ({ productId, url }: { productId: string; url: string }) => 
      retrieveApiKey(productId, url),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["product", product.id] });
      toast({
        title: "API Key Retrieved",
        description: "The Kubernetes API key has been retrieved successfully",
      });
      setShowApiKey(true);
    },
  });

  const handleDownloadScript = async () => {
    if (!product.id) return;
    const blob = await generateConnectScript(product.id);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `connect-${product.clusterId}.sh`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = (text: string, itemName: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied!",
        description: `${itemName} copied to clipboard`,
      });
    });
  };

  const handleRetrieveApiKey = () => {
    retrieveApiKeyMutation.mutate({ productId: product.id, url: product.url });
  };

  const toggleApiKeyVisibility = () => {
    setShowApiKey(prev => !prev);
  };

  const updateLimitsMutation = useMutation({
    mutationFn: (limits: { cpu: string, memory: string, storage: string }) => 
      updateDefaultResourceLimits(product.id, limits),
    onSuccess: (updatedProduct) => {
      queryClient.invalidateQueries({ queryKey: ["product", product.id] });
      setEditingLimits(false);
      toast({
        title: "Limits Updated",
        description: "Default resource limits have been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update default resource limits",
        variant: "destructive",
      });
    }
  });

  const handleLimitsSubmit = () => {
    updateLimitsMutation.mutate(defaultLimits);
  };

  return (
    <Card className="glass-card">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">{product.name}</h1>
          <Button onClick={handleDownloadScript}>
            <Download className="mr-2 h-4 w-4" />
            Connect Script
          </Button>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="text-sm text-muted-foreground mb-1">Date</h3>
            <p>{new Date(product.date).toLocaleDateString()}</p>
          </div>

          <div>
            <h3 className="text-sm text-muted-foreground mb-1">Cluster ID</h3>
            <div className="flex items-center">
              <code className="terminal-text">{product.clusterId}</code>
              <Button 
                variant="ghost" 
                size="sm" 
                className="ml-2 h-6 w-6 p-0" 
                onClick={() => copyToClipboard(product.clusterId, "Cluster ID")}
              >
                <Copy className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>

          <div>
            <h3 className="text-sm text-muted-foreground mb-1">URL</h3>
            <div className="flex items-center">
              <a 
                href={product.url} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-500 hover:text-blue-600 break-all flex items-center"
              >
                {product.url}
                <ExternalLink className="h-3.5 w-3.5 ml-1 inline" />
              </a>
              <Button 
                variant="ghost" 
                size="sm" 
                className="ml-2 h-6 w-6 p-0" 
                onClick={() => copyToClipboard(product.url, "URL")}
              >
                <Copy className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm text-muted-foreground">Default Resource Limits</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setEditingLimits(!editingLimits)}
              >
                <Edit className="h-4 w-4" />
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
              <div className="flex items-center space-x-2 p-3 bg-secondary/50 rounded-lg">
                <Cpu className="h-4 w-4 text-muted-foreground" />
                <div className="w-full">
                  <p className="text-sm font-medium">CPU</p>
                  {editingLimits ? (
                    <Input
                      value={defaultLimits.cpu}
                      onChange={(e) => setDefaultLimits({ ...defaultLimits, cpu: e.target.value })}
                      className="h-6 text-xs"
                    />
                  ) : (
                    <p className="text-xs text-muted-foreground">{defaultLimits.cpu}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-2 p-3 bg-secondary/50 rounded-lg">
                <MemoryStick className="h-4 w-4 text-muted-foreground" />
                <div className="w-full">
                  <p className="text-sm font-medium">Memory</p>
                  {editingLimits ? (
                    <Input
                      value={defaultLimits.memory}
                      onChange={(e) => setDefaultLimits({ ...defaultLimits, memory: e.target.value })}
                      className="h-6 text-xs"
                    />
                  ) : (
                    <p className="text-xs text-muted-foreground">{defaultLimits.memory}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-2 p-3 bg-secondary/50 rounded-lg">
                <HardDrive className="h-4 w-4 text-muted-foreground" />
                <div className="w-full">
                  <p className="text-sm font-medium">Storage</p>
                  {editingLimits ? (
                    <Input
                      value={defaultLimits.storage}
                      onChange={(e) => setDefaultLimits({ ...defaultLimits, storage: e.target.value })}
                      className="h-6 text-xs"
                    />
                  ) : (
                    <p className="text-xs text-muted-foreground">{defaultLimits.storage}</p>
                  )}
                </div>
              </div>
            </div>
            {editingLimits && (
              <div className="mt-4 flex justify-end gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setDefaultLimits({
                      cpu: product.resourceUsage.defaultLimits.cpu,
                      memory: product.resourceUsage.defaultLimits.memory,
                      storage: product.resourceUsage.defaultLimits.storage,
                    });
                    setEditingLimits(false);
                  }}
                >
                  Cancel
                </Button>
                <Button
                  size="sm"
                  onClick={handleLimitsSubmit}
                >
                  Save Changes
                </Button>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-sm text-muted-foreground mb-1">Kubernetes</h3>
            <div className="space-y-2">
              <p>
                <span className="text-muted-foreground">Namespace: </span>
                <code className="terminal-text">{product.kubernetes.namespace}</code>
              </p>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">API Key: </span>
                {product.kubernetes.apiKey ? (
                  <>
                    <code className="terminal-text">
                      {showApiKey ? product.kubernetes.apiKey : "••••••••••••••••"}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={toggleApiKeyVisibility}
                    >
                      {showApiKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                    </Button>
                  </>
                ) : (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleRetrieveApiKey}
                    disabled={retrieveApiKeyMutation.isPending}
                  >
                    <Key className="mr-2 h-3.5 w-3.5" />
                    {retrieveApiKeyMutation.isPending ? "Retrieving..." : "Retrieve API Key"}
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};
