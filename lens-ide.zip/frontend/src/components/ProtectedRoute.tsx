
import { Navigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ThemeToggle from "./ThemeToggle";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { isAuthenticated, logout } = useAuth();
  const { toast } = useToast();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out",
    });
  };
  
  return (
    <div className="relative min-h-screen font-jetbrains">
      <div className="absolute top-4 right-4 z-50 flex items-center gap-3">
        <ThemeToggle />
        <Button 
          variant="outline" 
          onClick={handleLogout}
          className="bg-background/10 backdrop-blur-sm hover:bg-background/20 border-background/20 text-foreground flex items-center gap-2"
        >
          Logout
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
      {children}
    </div>
  );
};

export default ProtectedRoute;
