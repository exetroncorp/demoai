
import { useQuery } from "@tanstack/react-query";
import { getProducts } from "@/services/productService";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { useNavigate } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Grid, List } from "lucide-react";
import type { Product } from "@/types/product";

export const ProductList = () => {
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"grid" | "table">("grid");
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Product;
    direction: "asc" | "desc";
  }>({ key: "date", direction: "desc" });
  
  const navigate = useNavigate();
  
  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: getProducts
  });

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(search.toLowerCase()) ||
    product.clusterId.toLowerCase().includes(search.toLowerCase()) ||
    product.url.toLowerCase().includes(search.toLowerCase())
  );

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortConfig.key === "date") {
      return sortConfig.direction === "asc" 
        ? new Date(a.date).getTime() - new Date(b.date).getTime()
        : new Date(b.date).getTime() - new Date(a.date).getTime();
    }
    return sortConfig.direction === "asc"
      ? a[sortConfig.key] > b[sortConfig.key] ? 1 : -1
      : b[sortConfig.key] > a[sortConfig.key] ? 1 : -1;
  });

  const handleSort = (key: keyof Product) => {
    setSortConfig(current => ({
      key,
      direction: current.key === key && current.direction === "asc" ? "desc" : "asc"
    }));
  };

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Products</h1>
        <p className="text-muted-foreground">Manage your Kubernetes products</p>
      </div>

      <div className="mb-6 flex items-center gap-4">
        <Input
          placeholder="Search products by name, cluster ID, or URL..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-md glass-card"
        />
        <div className="flex items-center gap-2">
          <Button
            variant={view === "grid" ? "default" : "outline"}
            size="icon"
            onClick={() => setView("grid")}
          >
            <Grid className="h-4 w-4" />
          </Button>
          <Button
            variant={view === "table" ? "default" : "outline"}
            size="icon"
            onClick={() => setView("table")}
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {isLoading ? (
        <p>Loading products...</p>
      ) : view === "grid" ? (
        <ScrollArea className="h-[600px] rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sortedProducts.map((product) => (
              <Card
                key={product.id}
                className="glass-card cursor-pointer transition-all hover:scale-[1.02] hover:shadow-lg"
                onClick={() => navigate(`/product/${product.id}`)}
              >
                <div className="p-6">
                  <p className="text-xs text-muted-foreground mb-2">
                    {new Date(product.date).toLocaleDateString()}
                  </p>
                  <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm text-muted-foreground">Cluster:</span>
                    <code className="terminal-text">{product.clusterId}</code>
                  </div>
                  <p className="text-sm text-muted-foreground truncate">
                    {product.url}
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </ScrollArea>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead 
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => handleSort("date")}
                >
                  Date {sortConfig.key === "date" && (sortConfig.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => handleSort("name")}
                >
                  Name {sortConfig.key === "name" && (sortConfig.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead 
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => handleSort("clusterId")}
                >
                  Cluster ID {sortConfig.key === "clusterId" && (sortConfig.direction === "asc" ? "↑" : "↓")}
                </TableHead>
                <TableHead>URL</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedProducts.map((product) => (
                <TableRow
                  key={product.id}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => navigate(`/product/${product.id}`)}
                >
                  <TableCell>
                    {new Date(product.date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>{product.name}</TableCell>
                  <TableCell>
                    <code className="terminal-text">{product.clusterId}</code>
                  </TableCell>
                  <TableCell className="font-mono text-sm truncate max-w-[200px]">
                    {product.url}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};
