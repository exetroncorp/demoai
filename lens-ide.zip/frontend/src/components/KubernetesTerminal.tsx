
import { useEffect, useRef, useState } from 'react';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import 'xterm/css/xterm.css';
import { 
  getDefaultTerminalOptions, 
  setupTerminalAddons,
  displayWelcomeMessage,
  displayErrorMessage
} from '@/utils/terminalUtils';
import { useTerminalWebSocket } from '@/hooks/useTerminalWebSocket';
import { useTerminalInput } from '@/hooks/useTerminalInput';
import { WS_BASE_URL, TERMINAL_PATH } from '@/utils/constants';

interface KubernetesTerminalProps {
  namespace: string;
}

export const KubernetesTerminal = ({ namespace }: KubernetesTerminalProps) => {
  const terminalRef = useRef<HTMLDivElement>(null);
  const terminalInstance = useRef<Terminal | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize terminal
  useEffect(() => {
    if (!terminalRef.current) return;

    // Create and configure the terminal
    const term = new Terminal(getDefaultTerminalOptions());
    const { fitAddon } = setupTerminalAddons(term);

    try {
      term.open(terminalRef.current);
      fitAddon.fit();
      console.log("Terminal opened successfully");

      terminalInstance.current = term;
      fitAddonRef.current = fitAddon;
      setIsInitialized(true);
    } catch (error) {
      console.error("Failed to initialize terminal:", error);
    }

    return () => {
      console.log("Disposing terminal");
      term.dispose();
    };
  }, []);

  // Set up WebSocket connection
  const { 
    initializeWebSocket,
    sendCommand,
    sendInterrupt,
    sendResize,
    closeConnection
  } = useTerminalWebSocket({
    url: `${WS_BASE_URL}${TERMINAL_PATH}`,
    namespace,
    term: terminalInstance.current,
    cols: terminalInstance.current?.cols || 80,
    rows: terminalInstance.current?.rows || 24
  });

  // Set up input handlers
  const { setupInputHandlers } = useTerminalInput({
    term: terminalInstance.current,
    onCommand: sendCommand,
    onInterrupt: sendInterrupt
  });

  // Connect to server and setup handlers
  useEffect(() => {
    if (!terminalInstance.current || !isInitialized) return;

    console.log("Setting up terminal connections and handlers");

    try {
      // Try to initialize WebSocket
      const ws = initializeWebSocket();

      if (ws) {
        // If connected successfully, show welcome message
        console.log("WebSocket connection successful");
        displayWelcomeMessage(terminalInstance.current, namespace);
      } else {
        // If connection failed, show error message
        console.log("WebSocket connection failed, entering mock mode");
        displayErrorMessage(terminalInstance.current);
      }

      // Set up input handling
      setupInputHandlers();

      // Handle window resize
      const handleResize = () => {
        if (fitAddonRef.current && terminalInstance.current) {
          fitAddonRef.current.fit();
          sendResize(
            terminalInstance.current.cols,
            terminalInstance.current.rows
          );
        }
      };

      window.addEventListener('resize', handleResize);

      // Force a resize after a short delay to ensure proper rendering
      setTimeout(() => {
        handleResize();
      }, 100);

      return () => {
        closeConnection();
        window.removeEventListener('resize', handleResize);
      };
    } catch (error) {
      console.error('Terminal initialization error:', error);
      if (terminalInstance.current) {
        displayErrorMessage(terminalInstance.current);
      }
    }
  }, [namespace, initializeWebSocket, setupInputHandlers, sendResize, closeConnection, isInitialized]);

  return (
    <div 
      ref={terminalRef} 
      className="h-[400px] w-full rounded-lg overflow-hidden border border-white/10 bg-black flex items-center justify-center"
      style={{ position: 'relative' }}
    >
      {!isInitialized && (
        <div className="absolute inset-0 flex items-center justify-center text-gray-400">
          Initializing terminal...
        </div>
      )}
    </div>
  );
};
