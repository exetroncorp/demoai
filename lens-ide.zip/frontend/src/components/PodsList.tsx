
import { KubernetesPod } from "@/types/product";
import { Button } from "@/components/ui/button";
import { User } from "@/types/product";

interface PodsListProps {
  pods: KubernetesPod[] | undefined;
  onViewLogs: (podName: string) => void;
  users: User[];
}

export const PodsList = ({ pods, onViewLogs, users }: PodsListProps) => {
  if (!pods || pods.length === 0) {
    return <p className="text-muted-foreground">No pods found</p>;
  }

  return (
    <div className="space-y-2">
      {pods.map((pod) => (
        <div
          key={pod.name}
          className="flex items-center justify-between p-3 rounded-lg bg-secondary"
        >
          <div>
            <p className="font-mono flex items-center">
              {pod.name}
              {pod.type && (
                <span className={`ml-2 px-2 py-0.5 text-xs rounded-full ${
                  pod.type === 'code-server' ? 'bg-blue-500/20 text-blue-400' : 
                  pod.type === 'jupyterhub' ? 'bg-purple-500/20 text-purple-400' : 'bg-green-500/20 text-green-400'
                }`}>
                  {pod.type}
                </span>
              )}
            </p>
            <p className="text-sm text-muted-foreground">
              {pod.namespace} {pod.user && `• User: ${users.find(u => u.id === pod.user)?.name || pod.user}`}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className={`px-2 py-1 text-xs rounded-full ${
              pod.status === 'Running' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
            }`}>
              {pod.status}
            </span>
            {pod.resources && (
              <span className="text-xs text-muted-foreground mr-2">
                {pod.resources.cpu} CPU • {pod.resources.memory} RAM
              </span>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onViewLogs(pod.name)}
            >
              View Logs
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
};
