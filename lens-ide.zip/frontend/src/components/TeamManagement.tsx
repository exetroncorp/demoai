
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, UserPlus } from "lucide-react";
import { useState } from "react";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Product } from "@/types/product";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getAvailableUsers, updateProductUsers, updateProductAdmin } from "@/services/productService";

interface TeamManagementProps {
  product: Product;
}

export const TeamManagement = ({ product }: TeamManagementProps) => {
  const [userSearchQuery, setUserSearchQuery] = useState<string>("");
  const [isUserDialogOpen, setIsUserDialogOpen] = useState<boolean>(false);
  const [isAdminDialogOpen, setIsAdminDialogOpen] = useState<boolean>(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: availableUsers } = useQuery({
    queryKey: ["availableUsers"],
    queryFn: () => getAvailableUsers(),
    enabled: isUserDialogOpen || isAdminDialogOpen,
  });

  const updateUsersMutation = useMutation({
    mutationFn: ({ productId, users }: { productId: string; users: User[] }) => 
      updateProductUsers(productId, users),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["product", product.id] });
      toast({
        title: "Users updated",
        description: "The product users list has been updated",
      });
      setIsUserDialogOpen(false);
    },
  });

  const updateAdminMutation = useMutation({
    mutationFn: ({ productId, adminId }: { productId: string; adminId: string }) => 
      updateProductAdmin(productId, adminId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["product", product.id] });
      toast({
        title: "Admin updated",
        description: "The product admin has been updated",
      });
      setIsAdminDialogOpen(false);
    },
  });

  const handleAddUser = (userId: string) => {
    if (!product) return;
    
    const userToAdd = availableUsers?.find(u => u.id === userId);
    if (!userToAdd) return;
    
    if (product.users.some(u => u.id === userId)) {
      toast({
        title: "User already added",
        description: "This user is already assigned to this product",
      });
      return;
    }
    
    const updatedUsers = [...product.users, userToAdd];
    updateUsersMutation.mutate({ productId: product.id, users: updatedUsers });
  };

  const handleRemoveUser = (userId: string) => {
    if (!product) return;
    
    if (product.admin.id === userId) {
      toast({
        title: "Cannot remove admin",
        description: "Please assign a new admin before removing this user",
        variant: "destructive"
      });
      return;
    }
    
    const updatedUsers = product.users.filter(u => u.id !== userId);
    updateUsersMutation.mutate({ productId: product.id, users: updatedUsers });
  };

  const handleSetAdmin = (userId: string) => {
    if (!product) return;
    updateAdminMutation.mutate({ productId: product.id, adminId: userId });
  };

  const filteredAvailableUsers = availableUsers?.filter(user => 
    user.name.toLowerCase().includes(userSearchQuery.toLowerCase()) || 
    user.email.toLowerCase().includes(userSearchQuery.toLowerCase())
  );

  return (
    <Card className="glass-card">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Team Management</h2>
          <Dialog open={isUserDialogOpen} onOpenChange={setIsUserDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="mr-2 h-4 w-4" />
                Manage Users
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Manage Product Users</DialogTitle>
                <DialogDescription>
                  Add or remove users for this product.
                </DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <Input 
                  placeholder="Search users by name or email"
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  className="mb-4"
                />
                <div className="space-y-4">
                  <h4 className="text-sm font-medium">Current Users</h4>
                  <div className="space-y-2">
                    {product.users.map(user => (
                      <div key={user.id} className="flex items-center justify-between p-2 rounded bg-secondary">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{user.name}</p>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {user.id === product.admin.id && (
                            <span className="px-2 py-1 text-xs rounded-full bg-blue-500/20 text-blue-400 flex items-center">
                              <Shield className="h-3 w-3 mr-1" />
                              Admin
                            </span>
                          )}
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleRemoveUser(user.id)}
                            disabled={user.id === product.admin.id}
                          >
                            Remove
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <h4 className="text-sm font-medium mt-6">Available Users</h4>
                  <div className="space-y-2">
                    {filteredAvailableUsers?.filter(user => !product.users.some(u => u.id === user.id)).map(user => (
                      <div key={user.id} className="flex items-center justify-between p-2 rounded bg-secondary">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{user.name}</p>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleAddUser(user.id)}
                        >
                          Add User
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm text-muted-foreground">Admin</h3>
            <Dialog open={isAdminDialogOpen} onOpenChange={setIsAdminDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Shield className="mr-2 h-3 w-3" />
                  Change Admin
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Change Product Admin</DialogTitle>
                  <DialogDescription>
                    Select a user to make them the admin of this product.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  <Input 
                    placeholder="Search users by name or email"
                    value={userSearchQuery}
                    onChange={(e) => setUserSearchQuery(e.target.value)}
                    className="mb-4"
                  />
                  <div className="space-y-2">
                    {filteredAvailableUsers?.map(user => (
                      <div key={user.id} className="flex items-center justify-between p-2 rounded bg-secondary">
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{user.name}</p>
                            <p className="text-sm text-muted-foreground">{user.email}</p>
                          </div>
                        </div>
                        <Button 
                          variant={user.id === product.admin.id ? "default" : "outline"} 
                          size="sm"
                          onClick={() => handleSetAdmin(user.id)}
                          disabled={user.id === product.admin.id}
                        >
                          {user.id === product.admin.id ? "Current Admin" : "Set as Admin"}
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30">
            <Avatar>
              <AvatarImage src={product.admin.avatar} />
              <AvatarFallback>{product.admin.name.slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium flex items-center">
                {product.admin.name}
                <Shield className="h-3.5 w-3.5 ml-2 text-blue-500" />
              </p>
              <p className="text-sm text-muted-foreground">{product.admin.email}</p>
            </div>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm text-muted-foreground">Team Members</h3>
            <span className="text-xs text-muted-foreground">{product.users.length} users</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {product.users.filter(user => user.id !== product.admin.id).map(user => (
              <div key={user.id} className="flex items-center space-x-3 p-3 rounded-lg bg-secondary">
                <Avatar>
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{user.name}</p>
                  <div className="flex items-center">
                    <p className="text-sm text-muted-foreground mr-2">{user.email}</p>
                    <span className="px-2 py-0.5 text-xs rounded-full bg-gray-100 dark:bg-gray-800">
                      {user.role}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
};
