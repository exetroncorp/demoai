
import { useQuery } from "@tanstack/react-query";
import { getSystemArchitecture } from "@/services/productService";
import { Network } from "lucide-react";
import { Product } from "@/types/product";
import {
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Line,
} from "recharts";

interface SystemArchitectureProps {
  productId: string;
  product: Product;
}

export const SystemArchitecture = ({ productId, product }: SystemArchitectureProps) => {
  const { data: systemArchitecture } = useQuery({
    queryKey: ["systemArchitecture", productId],
    queryFn: () => getSystemArchitecture(productId),
    enabled: !!productId,
  });

  // Transform nodes data for visualization
  const nodesData = systemArchitecture?.nodes.map((node, index) => ({
    x: node.type === 'hub' ? 400 : node.type === 'proxy' ? 400 : 200 + (index * 200),
    y: node.type === 'hub' ? 100 : node.type === 'proxy' ? 250 : 400,
    z: 100,
    name: node.label,
    type: node.type,
    id: node.id,
  })) || [];

  // Create connection lines data
  const connectionLines = systemArchitecture?.links.map(link => {
    const sourceNode = nodesData.find(node => node.id === link.source);
    const targetNode = nodesData.find(node => node.id === link.target);
    return sourceNode && targetNode ? [sourceNode, targetNode] : [];
  }) || [];

  const getNodeColor = (type: string) => {
    switch (type) {
      case 'hub':
        return '#3b82f6';
      case 'proxy':
        return '#22c55e';
      default:
        return '#8b5cf6';
    }
  };

  return (
    <div className="bg-secondary rounded-lg p-4">
      <div className="flex items-center gap-2 mb-4">
        <Network className="h-4 w-4" />
        <span className="text-sm">System Architecture</span>
      </div>
      <div className="bg-background/50 p-4 rounded-lg border">
        <p className="text-muted-foreground mb-4">Product Architecture Visualization</p>
        <p className="text-xs text-muted-foreground mb-4">
          Cloud IDE with JupyterHub portal, Kubernetes proxy, and dedicated code-server pods for each user
        </p>
        
        <div className="h-[500px]">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
              <XAxis type="number" dataKey="x" domain={[0, 800]} hide />
              <YAxis type="number" dataKey="y" domain={[0, 500]} hide />
              <ZAxis type="number" dataKey="z" range={[100, 100]} />
              
              {connectionLines.map((points, index) => (
                <Line
                  key={index}
                  type="linear"
                  dataKey="y"
                  data={points}
                  stroke="#94a3b8"
                  strokeWidth={1}
                  dot={false}
                />
              ))}

              <Scatter
                data={nodesData}
                shape={(props) => {
                  const { cx, cy, payload } = props;
                  return (
                    <g>
                      <circle
                        cx={cx}
                        cy={cy}
                        r={30}
                        fill={getNodeColor(payload.type)}
                        fillOpacity={0.1}
                        stroke={getNodeColor(payload.type)}
                        strokeOpacity={0.2}
                      />
                      <circle
                        cx={cx}
                        cy={cy}
                        r={20}
                        fill={getNodeColor(payload.type)}
                        fillOpacity={0.2}
                      />
                      <text
                        x={cx}
                        y={cy}
                        dy={-30}
                        fill="currentColor"
                        textAnchor="middle"
                        fontSize={12}
                      >
                        {payload.name}
                      </text>
                    </g>
                  );
                }}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-popover p-2 rounded-lg border shadow-lg">
                        <p className="text-sm font-medium">{payload[0].payload.name}</p>
                        <p className="text-xs text-muted-foreground">
                          Type: {payload[0].payload.type}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
