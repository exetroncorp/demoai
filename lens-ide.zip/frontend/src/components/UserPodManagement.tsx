
import { useState } from 'react';
import { 
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { 
  Cpu, 
  MemoryStick, 
  Database, 
  Play, 
  Pause, 
  Trash2, 
  RefreshCw,
  ArrowUpRight
} from "lucide-react";
import { User, PodConfig } from "@/types/product";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface UserPodManagementProps {
  users: User[];
  onUpdateUserPod: (userId: string, podConfig: PodConfig) => Promise<void>;
  onStartPod: (userId: string) => Promise<void>;
  onStopPod: (userId: string) => Promise<void>;
  onDeletePod: (userId: string) => Promise<void>;
}

export const UserPodManagement = ({
  users,
  onUpdateUserPod,
  onStartPod,
  onStopPod,
  onDeletePod
}: UserPodManagementProps) => {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [newPodConfig, setNewPodConfig] = useState<PodConfig>({
    cpu: "1",
    memory: "2Gi",
    storage: "10Gi",
    status: "stopped"
  });
  const { toast } = useToast();
  
  const handleOpenConfigDialog = (user: User) => {
    setSelectedUser(user);
    if (user.podConfig) {
      setNewPodConfig(user.podConfig);
    } else {
      setNewPodConfig({
        cpu: "1",
        memory: "2Gi",
        storage: "10Gi",
        status: "stopped"
      });
    }
    setIsConfigDialogOpen(true);
  };
  
  const handleSavePodConfig = async () => {
    if (!selectedUser) return;
    
    try {
      await onUpdateUserPod(selectedUser.id, newPodConfig);
      toast({
        title: "Pod configuration updated",
        description: `Updated pod configuration for ${selectedUser.name}`
      });
      setIsConfigDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error updating pod",
        description: "Failed to update pod configuration",
        variant: "destructive"
      });
    }
  };
  
  const handleDeleteConfirm = async () => {
    if (!selectedUser) return;
    
    try {
      await onDeletePod(selectedUser.id);
      toast({
        title: "Pod deleted",
        description: `Deleted pod for ${selectedUser.name}`
      });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error deleting pod",
        description: "Failed to delete user pod",
        variant: "destructive"
      });
    }
  };
  
  const getStatusColor = (status?: string) => {
    switch (status) {
      case "running":
        return "text-green-500";
      case "stopped":
        return "text-gray-500";
      case "pending":
        return "text-amber-500";
      case "error":
        return "text-red-500";
      default:
        return "text-gray-500";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-semibold">User Pod Management</CardTitle>
        <CardDescription>
          Manage dedicated code-server pods for each user
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Resources</TableHead>
              <TableHead>Last Activity</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="px-2 py-1 text-xs rounded-full bg-gray-100 dark:bg-gray-800">
                    {user.role}
                  </span>
                </TableCell>
                <TableCell>
                  {user.podConfig ? (
                    <span className={`font-medium ${getStatusColor(user.podConfig.status)}`}>
                      {user.podConfig.status.charAt(0).toUpperCase() + user.podConfig.status.slice(1)}
                    </span>
                  ) : (
                    <span className="text-gray-500">Not configured</span>
                  )}
                </TableCell>
                <TableCell>
                  {user.podConfig ? (
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1 text-xs">
                        <Cpu className="h-3 w-3" /> {user.podConfig.cpu} CPU
                      </div>
                      <div className="flex items-center gap-1 text-xs">
                        <MemoryStick className="h-3 w-3" /> {user.podConfig.memory} RAM
                      </div>
                      <div className="flex items-center gap-1 text-xs">
                        <Database className="h-3 w-3" /> {user.podConfig.storage} Storage
                      </div>
                    </div>
                  ) : (
                    <span className="text-gray-500">-</span>
                  )}
                </TableCell>
                <TableCell>
                  {user.podConfig?.lastActivity ? (
                    new Date(user.podConfig.lastActivity).toLocaleString()
                  ) : (
                    <span className="text-gray-500">Never</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button 
                      size="icon" 
                      variant="outline"
                      onClick={() => handleOpenConfigDialog(user)}
                      title="Configure pod"
                      className="h-8 w-8"
                    >
                      <Cpu className="h-4 w-4" />
                    </Button>
                    
                    {user.podConfig?.status === "running" ? (
                      <Button 
                        size="icon"
                        variant="outline"
                        onClick={() => onStopPod(user.id)}
                        title="Stop pod"
                        className="h-8 w-8"
                      >
                        <Pause className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button 
                        size="icon"
                        variant="outline"
                        onClick={() => onStartPod(user.id)}
                        title="Start pod"
                        className="h-8 w-8"
                        disabled={!user.podConfig}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                    )}
                    
                    {user.podConfig?.status === "running" && (
                      <Button 
                        size="icon"
                        variant="outline"
                        title="Open code-server"
                        className="h-8 w-8 text-blue-500"
                      >
                        <ArrowUpRight className="h-4 w-4" />
                      </Button>
                    )}
                    
                    <Button 
                      size="icon"
                      variant="destructive"
                      onClick={() => {
                        setSelectedUser(user);
                        setIsDeleteDialogOpen(true);
                      }}
                      title="Delete pod"
                      className="h-8 w-8"
                      disabled={!user.podConfig}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        
        {/* Pod Configuration Dialog */}
        <Dialog open={isConfigDialogOpen} onOpenChange={setIsConfigDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Configure User Pod</DialogTitle>
              <DialogDescription>
                {selectedUser?.name} - {selectedUser?.email}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="cpu">CPU</Label>
                <Select 
                  value={newPodConfig.cpu}
                  onValueChange={(value) => setNewPodConfig({...newPodConfig, cpu: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select CPU" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0.5">0.5 CPU</SelectItem>
                    <SelectItem value="1">1 CPU</SelectItem>
                    <SelectItem value="2">2 CPUs</SelectItem>
                    <SelectItem value="4">4 CPUs</SelectItem>
                    <SelectItem value="8">8 CPUs</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="memory">Memory</Label>
                <Select 
                  value={newPodConfig.memory}
                  onValueChange={(value) => setNewPodConfig({...newPodConfig, memory: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select memory" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1Gi">1Gi</SelectItem>
                    <SelectItem value="2Gi">2Gi</SelectItem>
                    <SelectItem value="4Gi">4Gi</SelectItem>
                    <SelectItem value="8Gi">8Gi</SelectItem>
                    <SelectItem value="16Gi">16Gi</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="storage">Storage</Label>
                <Select 
                  value={newPodConfig.storage}
                  onValueChange={(value) => setNewPodConfig({...newPodConfig, storage: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select storage" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5Gi">5Gi</SelectItem>
                    <SelectItem value="10Gi">10Gi</SelectItem>
                    <SelectItem value="20Gi">20Gi</SelectItem>
                    <SelectItem value="50Gi">50Gi</SelectItem>
                    <SelectItem value="100Gi">100Gi</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsConfigDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSavePodConfig}>Save Configuration</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Pod Deletion</DialogTitle>
              <DialogDescription>
                Are you sure you want to delete the pod for {selectedUser?.name}? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDeleteConfirm}>
                Delete Pod
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};
