
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { getPodLogs } from "@/services/productService";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface PodLogsViewerProps {
  selectedPod: string | null;
}

export const PodLogsViewer = ({ selectedPod }: PodLogsViewerProps) => {
  const [isStreamingLogs, setIsStreamingLogs] = useState(false);
  const [logContent, setLogContent] = useState<string>("");
  const logRef = useRef<HTMLPreElement>(null);
  const intervalRef = useRef<number | null>(null);
  const { toast } = useToast();

  const { data: podLogs } = useQuery({
    queryKey: ["podLogs", selectedPod],
    queryFn: () => getPodLogs(selectedPod!),
    enabled: !!selectedPod && !isStreamingLogs,
  });

  useEffect(() => {
    if (podLogs && !isStreamingLogs) {
      setLogContent(podLogs);
    }
  }, [podLogs, isStreamingLogs]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, []);

  const startLogStreaming = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    setIsStreamingLogs(true);
    toast({
      title: "Log streaming started",
      description: `Streaming logs for pod ${selectedPod}`,
    });

    const getTimestamp = () => {
      const now = new Date();
      return now.toISOString();
    };

    setLogContent(prev => `${prev}\n[${getTimestamp()}] Starting log stream for ${selectedPod}...`);

    const mockLogMessages = [
      "Container runtime started",
      "Initializing application",
      "Loading configuration from env variables",
      "Connected to database",
      "Authenticating with service mesh",
      "Starting HTTP server on port 8080",
      "Health check passed",
      "Processing incoming request",
      "Cache hit ratio: 78.5%",
      "API request completed in 235ms",
      "Memory usage: 256MB",
      "Received webhook notification",
      "Background job scheduled",
      "Processing batch of 100 items",
      "Garbage collection triggered",
      "Warning: high CPU usage detected",
      "Connection pool size adjusted",
      "Circuit breaker reset",
      "Gracefully handling SIGTERM signal",
    ];

    intervalRef.current = window.setInterval(() => {
      const randomLog = mockLogMessages[Math.floor(Math.random() * mockLogMessages.length)];
      const logLevel = Math.random() > 0.8 ? "WARN" : Math.random() > 0.95 ? "ERROR" : "INFO";
      const newLogEntry = `[${getTimestamp()}] [${logLevel}] ${randomLog}`;
      
      setLogContent(prev => `${prev}\n${newLogEntry}`);
      
      if (logRef.current) {
        logRef.current.scrollTop = logRef.current.scrollHeight;
      }
    }, 1500);
  };

  const stopLogStreaming = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsStreamingLogs(false);
    toast({
      title: "Log streaming stopped",
      description: `Stopped streaming logs for pod ${selectedPod}`,
    });
  };

  if (!selectedPod) {
    return <p className="text-muted-foreground">Select a pod to view logs</p>;
  }

  return (
    <div className="bg-secondary rounded-lg p-4">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm font-mono">Logs for {selectedPod}</h3>
        {!isStreamingLogs ? (
          <Button 
            size="sm" 
            onClick={startLogStreaming}
            className="bg-green-600 hover:bg-green-700"
          >
            Stream Logs
          </Button>
        ) : (
          <Button 
            size="sm" 
            onClick={stopLogStreaming}
            variant="destructive"
          >
            Stop Streaming
          </Button>
        )}
      </div>
      <ScrollArea className="h-96 w-full rounded-md border p-4 bg-black">
        <pre ref={logRef} className="font-mono text-sm text-green-400 whitespace-pre-wrap">
          {logContent}
        </pre>
      </ScrollArea>
    </div>
  );
};
