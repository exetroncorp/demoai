import { Product, KubernetesPod } from "@/types/product";

// Re-export user service functions
export { 
  getAvailableUsers, 
  updateUserPodConfig, 
  startUserPod, 
  stopUserPod, 
  deleteUserPod,
  updateProductUsers,
  updateProductAdmin
} from "./userService";

// API base URL
import { API_BASE_URL } from '@/utils/constants';

export const getProducts = async (): Promise<Product[]> => {
  const response = await fetch(`${API_BASE_URL}/products`);
  if (!response.ok) {
    throw new Error('Failed to fetch products');
  }
  return response.json();
};

export const getProduct = async (id: string): Promise<Product | undefined> => {
  const response = await fetch(`${API_BASE_URL}/products/${id}`);
  if (!response.ok) {
    if (response.status === 404) {
      return undefined;
    }
    throw new Error('Failed to fetch product');
  }
  return response.json();
};

export const generateConnectScript = async (productId: string): Promise<Blob> => {
  const response = await fetch(`${API_BASE_URL}/products/${productId}/connect-script`);
  if (!response.ok) {
    throw new Error('Failed to generate connect script');
  }
  return response.blob();
};

export const getPodsByProduct = async (productId: string): Promise<KubernetesPod[]> => {
  const response = await fetch(`${API_BASE_URL}/pods/product/${productId}`);
  if (!response.ok) {
    if (response.status === 404) {
      return [];
    }
    throw new Error('Failed to fetch pods');
  }
  return response.json();
};

export const getPodLogs = async (podName: string): Promise<string> => {
  const response = await fetch(`${API_BASE_URL}/pods/${podName}/logs`);
  if (!response.ok) {
    throw new Error('Failed to fetch pod logs');
  }
  return response.text();
};

export const retrieveApiKey = async (productId: string, url: string): Promise<Product> => {
  const response = await fetch(`${API_BASE_URL}/products/${productId}/api-key`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ url })
  });

  if (!response.ok) {
    throw new Error('Failed to retrieve API key');
  }

  return response.json();
};

export const getSystemArchitecture = async (productId: string): Promise<any> => {
  const response = await fetch(`${API_BASE_URL}/pods/product/${productId}/system-architecture`);

  if (!response.ok) {
    throw new Error('Failed to fetch system architecture');
  }

  return response.json();
};

export const updateDefaultResourceLimits = async (productId: string, defaultLimits: { cpu: string, memory: string, storage: string }): Promise<Product> => {
  // First, get the current product
  const product = await getProduct(productId);

  if (!product) {
    throw new Error('Product not found');
  }

  // Update the default resource limits
  product.resourceUsage.defaultLimits = defaultLimits;

  // Send the updated product to the server
  const response = await fetch(`${API_BASE_URL}/products/${productId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(product)
  });

  if (!response.ok) {
    throw new Error('Failed to update default resource limits');
  }

  return response.json();
};
