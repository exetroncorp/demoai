# **App Name**: Java - BACK TO BASICS

## Core Features:

- Step-by-Step Tutorial: Interactive tutorial steps displayed in a structured format. The application should allow the user to follow each part of the Java Compilation & Execution Workshop linearly, marking progress.
- Interactive Code Blocks: Code blocks with copy-paste functionality. Integrate a code editor component, perhaps with syntax highlighting, for users to experiment with the code examples provided in the workshop.
- AI-Powered Explanations: Generate explanations using a generative AI tool, that can interpret each step's bash commands or java code snippets. Offer an 'Explain' button next to each code block that uses a LLM tool to provide detailed, contextual explanations.
- Knowledge Checks: Quizzes to validate knowledge for each part of the workshop. Implement multiple-choice quizzes at the end of each part of the workshop to test the user's understanding. Display results and provide feedback.
- Spring Boot Examples: Provide pre-configured example Spring Boot projects (accessible through Git). Host the example Spring Boot projects on GitHub or a similar service, and provide links and instructions on how to clone and run them.
- Simulated Compilation: Add console output simulation of java code compilation. For some chosen samples, show compilation transcript within the app UI, rather than requiring local compilation.

## Style Guidelines:

- Primary color: Vivid orange (#FF8C00), evoking energy and Java's brand identity, suggesting active learning.
- Background color: Light beige (#F5F5DC), for a clean and accessible look. 
- Accent color: Deep blue (#1E90FF), providing a contrasting call-to-action color and hinting at the depth of Java knowledge.
- Body text: 'Inter', sans-serif, known for readability in digital environments. 
- Headline: 'Space Grotesk', sans-serif, offers a contemporary and clean aesthetic, ideal for highlighting section titles and interactive elements, while pairing well with Inter.
- Code font: 'Source Code Pro' monospaced font. Specifically, for java samples, system commands and simulation outputs
- Use a clear, modular layout with sections for explanations, code blocks, and interactive elements. Maintain a consistent visual hierarchy.
- Incorporate icons to represent concepts such as compilation, execution, and resources.
- Use subtle animations to provide feedback and indicate progress (e.g., transition effects between steps).