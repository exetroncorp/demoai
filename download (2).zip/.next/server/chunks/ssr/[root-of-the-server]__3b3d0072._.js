module.exports = {

"[project]/src/lib/course-data.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "courseData": (()=>courseData)
});
const courseData = [
    {
        id: "part-1",
        slug: "part-1-the-basics",
        title: "Part 1: The Basics - No Build Tools",
        description: "From source code to running application without build tools.",
        sections: [
            {
                title: "1.1 Simple Java Application",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's start with a basic example. Here's the file structure we'll use:"
                    },
                    {
                        type: "console",
                        title: "Project Structure",
                        output: `workshop/\n├── src/\n│   └── com/\n│       └── example/\n│           ├── Main.java\n│           └── util/\n│               └── Helper.java\n└── lib/\n    └── gson-2.8.9.jar`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "Main.java",
                        code: `package com.example;\nimport com.example.util.Helper;\nimport com.google.gson.Gson;\n\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello from Main!");\n        Helper.greet();\n        \n        Gson gson = new Gson();\n        String json = gson.toJson("Hello JSON");\n        System.out.println("JSON: " + json);\n    }\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "Helper.java",
                        code: `package com.example.util;\n\npublic class Helper {\n    public static void greet() {\n        System.out.println("Hello from Helper!");\n    }\n}`
                    }
                ]
            },
            {
                title: "1.2 Manual Compilation",
                content: [
                    {
                        type: "code",
                        language: "bash",
                        title: "Compilation Command",
                        code: `# Create output directory\nmkdir -p build/classes\n\n# Compile with external library\njavac -d build/classes \\\n      -cp lib/gson-2.8.9.jar \\\n      src/com/example/*.java \\\n      src/com/example/util/*.java`
                    },
                    {
                        type: "paragraph",
                        text: "What happens here:\n- `-d build/classes`: Sets the output directory for compiled `.class` files.\n- `-cp lib/gson-2.8.9.jar`: Specifies the classpath, telling the compiler where to find external dependencies like GSON.\n- `src/com/example/*.java ...`: The source files to compile."
                    }
                ]
            },
            {
                title: "1.3 Manual Execution",
                content: [
                    {
                        type: "code",
                        language: "bash",
                        title: "Execution Command",
                        code: `java -cp build/classes:lib/gson-2.8.9.jar com.example.Main`
                    },
                    {
                        type: "paragraph",
                        text: "What happens here:\n- `-cp build/classes:lib/gson-2.8.9.jar`: Defines the runtime classpath, which includes our compiled classes and the GSON library.\n- `com.example.Main`: The fully qualified name of the class containing the `main` method."
                    },
                    {
                        type: "console",
                        title: "Expected Output",
                        output: `Hello from Main!\nHello from Helper!\nJSON: "Hello JSON"`
                    },
                    {
                        type: "quiz",
                        question: "In the `javac` command, what does the `-d` flag do?",
                        options: [
                            "Specifies a dependency",
                            "Sets the destination directory for .class files",
                            "Disables debugging information",
                            "Defines the main class"
                        ],
                        correctAnswer: "Sets the destination directory for .class files",
                        explanation: "The `-d` flag in `javac` specifies the destination directory where the compiled `.class` files will be placed, preserving the package structure."
                    }
                ]
            }
        ]
    },
    {
        id: "part-2",
        slug: "part-2-understanding-classpath",
        title: "Part 2: Understanding Classpath",
        description: "Learn what the classpath is and how it works.",
        sections: [
            {
                title: "2.1 What is Classpath?",
                content: [
                    {
                        type: "paragraph",
                        text: "The classpath is a crucial parameter for the Java Virtual Machine (JVM) that specifies the locations of user-defined classes and packages. It tells the JVM where to find:\n1. Your compiled classes (.class files)\n2. External libraries (.jar files)\n3. Resources (properties files, images, etc.)"
                    }
                ]
            },
            {
                title: "2.2 Classpath Examples",
                content: [
                    {
                        type: "code",
                        language: "bash",
                        title: "Classpath Examples",
                        code: `# Multiple directories and JARs (Unix/macOS)\njava -cp "build/classes:lib/gson.jar:lib/commons-lang.jar:resources" com.example.Main\n\n# Using wildcards (for all JARs in a directory)\njava -cp "build/classes:lib/*:resources" com.example.Main\n\n# Windows example (note the semicolons)\njava -cp "build\\classes;lib\\*;resources" com.example.Main`
                    }
                ]
            },
            {
                title: "2.3 Classpath Investigation",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's create a utility to inspect the classpath at runtime."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "ClasspathInspector.java",
                        code: `package com.example;\nimport java.net.URL;\nimport java.net.URLClassLoader;\n\npublic class ClasspathInspector {\n    public static void main(String[] args) {\n        System.out.println("=== CLASSPATH INVESTIGATION ===");\n        \n        String classpath = System.getProperty("java.class.path");\n        System.out.println("System Classpath:");\n        for (String path : classpath.split(System.getProperty("path.separator"))) {\n            System.out.println("  " + path);\n        }\n        \n        ClassLoader cl = ClasspathInspector.class.getClassLoader();\n        if (cl instanceof URLClassLoader) {\n            System.out.println("\\nClassLoader URLs:");\n            for (URL url : ((URLClassLoader) cl).getURLs()) {\n                System.out.println("  " + url);\n            }\n        }\n    }\n}`
                    },
                    {
                        type: "quiz",
                        question: "What character is used to separate multiple paths in a Java classpath on Windows?",
                        options: [
                            ": (colon)",
                            ", (comma)",
                            "; (semicolon)",
                            "& (ampersand)"
                        ],
                        correctAnswer: "; (semicolon)",
                        explanation: "Windows uses a semicolon (`;`) to separate entries in the classpath, while Unix-like systems (Linux, macOS) use a colon (`:`)."
                    }
                ]
            }
        ]
    },
    {
        id: "part-3",
        slug: "part-3-resources-and-working-directory",
        title: "Part 3: Resources & Working Directory",
        description: "Learn how to load resources and the importance of the working directory.",
        sections: [
            {
                title: "3.1 Resources Example",
                content: [
                    {
                        type: "paragraph",
                        text: "Resources are non-code files bundled with your application. Here's a typical setup:"
                    },
                    {
                        type: "console",
                        title: "Project Structure",
                        output: `workshop/\n├── src/\n│   └── com/example/ResourceDemo.java\n├── resources/\n│   ├── config.properties\n│   └── data/\n│       └── sample.json\n└── build/\n    └── classes/`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "ResourceDemo.java",
                        code: `package com.example;\nimport java.io.*;\nimport java.util.Properties;\n\npublic class ResourceDemo {\n    public static void main(String[] args) throws Exception {\n        System.out.println("Working Directory: " + System.getProperty("user.dir"));\n        \n        // Method 1: Using ClassLoader (from classpath)\n        try (InputStream stream = ResourceDemo.class.getClassLoader()\n            .getResourceAsStream("config.properties")) {\n            if (stream != null) {\n                Properties props = new Properties();\n                props.load(stream);\n                System.out.println("From classpath: " + props.getProperty("app.name"));\n            } else {\n                 System.out.println("Resource 'config.properties' not found in classpath.");\n            }\n        }\n    }\n}`
                    },
                    {
                        type: "code",
                        language: "properties",
                        title: "config.properties",
                        code: `app.name=My Workshop App\napp.version=1.0`
                    }
                ]
            },
            {
                title: "3.2 Running with Resources",
                content: [
                    {
                        type: "paragraph",
                        text: "To make resources available, they must be on the classpath."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Running with Resources",
                        code: `# Option 1: Copy resources to the classes directory\ncp -r resources/* build/classes/\njava -cp build/classes com.example.ResourceDemo\n\n# Option 2: Add the 'resources' directory to the classpath\njava -cp build/classes:resources com.example.ResourceDemo`
                    },
                    {
                        type: "quiz",
                        question: "What is the recommended way to load a resource file that is bundled inside your JAR?",
                        options: [
                            "new File(\"path/to/resource\")",
                            "ClassLoader.getResourceAsStream(\"resource/name.txt\")",
                            "System.getProperty(\"resource.path\")",
                            "Reading from an absolute file path"
                        ],
                        correctAnswer: "ClassLoader.getResourceAsStream(\"resource/name.txt\")",
                        explanation: "`ClassLoader.getResourceAsStream` is the standard, reliable way to access resources from the classpath, as it works whether the resource is in a folder or packed inside a JAR file."
                    }
                ]
            }
        ]
    },
    {
        id: "part-4",
        slug: "part-4-mavens-role",
        title: "Part 4: Maven's Role",
        description: "Understand how Maven automates compilation and packaging.",
        sections: [
            {
                title: "4.1 What Maven Does",
                content: [
                    {
                        type: "paragraph",
                        text: "Maven is a powerful build automation tool that automates the manual processes we've covered. It handles dependency management, compilation, testing, and packaging based on conventions and a central `pom.xml` file."
                    }
                ]
            },
            {
                title: "4.2 Maven Directory Structure",
                content: [
                    {
                        type: "paragraph",
                        text: "Maven expects a standard project layout, known as 'convention over configuration'."
                    },
                    {
                        type: "console",
                        title: "Standard Maven Layout",
                        output: `my-project/\n├── pom.xml\n├── src/\n│   ├── main/\n│   │   ├── java/          # Source code\n│   │   └── resources/     # Resources (copied to classpath)\n│   └── test/\n│       ├── java/          # Test code\n│       └── resources/     # Test resources\n└── target/                  # Build output\n    ├── classes/           # Compiled main classes + resources\n    └── my-project.jar     # Final JAR`
                    }
                ]
            },
            {
                title: "4.3 Maven Commands Explained",
                content: [
                    {
                        type: "paragraph",
                        text: "Here's what happens behind the scenes for common Maven commands:"
                    },
                    {
                        type: "diagram",
                        diagram: `[pom.xml] ----------> [Maven] ------> Downloads Dependencies (from Maven Central)
                        |
[src/main/java] ----> Compiles Code ----> [target/classes]
                        ^
                        |
[src/main/resources] -> Copies Resources --+
                        |
                        +--> Runs Tests
                        |
                        +--> Packages into JAR -> [target/my-project.jar]`
                    },
                    {
                        type: "console",
                        title: "mvn compile",
                        output: `→ Downloads dependencies\n→ Runs: javac -d target/classes -cp [...] src/main/java/**/*.java\n→ Runs: cp src/main/resources/* target/classes/`
                    },
                    {
                        type: "console",
                        title: "mvn package",
                        output: `→ Runs 'compile' phase first\n→ Runs tests\n→ Runs: jar -cf target/my-project.jar -C target/classes .`
                    },
                    {
                        type: "console",
                        title: "mvn exec:java",
                        output: `→ Runs 'compile' phase first\n→ Runs: java -cp target/classes:[all-runtime-dependencies] com.example.Main`
                    },
                    {
                        type: "quiz",
                        question: "In a standard Maven project, where should you place your main application's resource files?",
                        options: [
                            "src/main/java",
                            "src/resources",
                            "src/main/resources",
                            "resources/"
                        ],
                        correctAnswer: "src/main/resources",
                        explanation: "Maven's convention is to place application resources in `src/main/resources`. These files are then automatically copied to the `target/classes` directory during the build process, making them available on the classpath."
                    }
                ]
            }
        ]
    },
    {
        id: "part-5",
        slug: "part-5-spring-boots-role",
        title: "Part 5: Spring Boot's Role",
        description: "Discover how Spring Boot creates self-contained, executable 'fat JARs'.",
        sections: [
            {
                title: "5.1 What is a JAR and How Does it Become Executable?",
                content: [
                    {
                        type: "paragraph",
                        text: "A JAR (Java ARchive) file is a package file format used to aggregate many Java class files, associated metadata, and resources into one distributable file. It's essentially a ZIP file with a `.jar` extension."
                    },
                    {
                        type: "paragraph",
                        text: "But how does `java -jar myapp.jar` know which class to run? This is a standard Java feature, not something specific to Maven or Spring Boot. It works using a special file inside the JAR called `META-INF/MANIFEST.MF`."
                    },
                    {
                        type: "paragraph",
                        text: "This manifest file can contain a `Main-Class` attribute. When you execute `java -jar myapp.jar`, the JVM looks inside the JAR for this manifest file, reads the value of `Main-Class`, and then executes the `main` method of that specified class."
                    },
                    {
                        type: "console",
                        title: "Example MANIFEST.MF",
                        output: `Manifest-Version: 1.0\nMain-Class: com.example.MyApplication`
                    },
                    {
                        type: "paragraph",
                        text: "So, the ability to run a JAR directly is a core Java feature. The magic of different build tools and frameworks lies in *what* they put into the manifest and how they structure the JAR file around it."
                    }
                ]
            },
            {
                title: "5.2 The Dependency Problem: Why Nested JARs Don't Work",
                content: [
                    {
                        type: "paragraph",
                        text: "You might be thinking, \"Why can't I just put my dependency JARs (like `gson.jar`) inside my main `myapp.jar`?\" This is an excellent question that reveals a core limitation of standard Java."
                    },
                    {
                        type: "paragraph",
                        text: "The reason is that the default Java ClassLoader—the component responsible for finding and loading `.class` files at runtime—can only load code from directories or from the root of JAR files listed directly on the classpath. It **does not know how to look *inside* a JAR file to find *another* nested JAR file** and then load classes from it.\n\nIf you were to place `gson.jar` inside `myapp.jar`, the JVM would simply not be able to find any of the GSON classes when your code runs, resulting in a `NoClassDefFoundError`."
                    },
                    {
                        type: "paragraph",
                        text: "This is the core dependency problem with standard JARs. To run the application, you must place your JAR (`myapp.jar`) and all of its dependency JARs (`gson.jar`, etc.) side-by-side and list them all explicitly on the classpath."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "The Manual Classpath Requirement",
                        code: `# You need to manually provide every single dependency on the classpath!\njava -cp "app.jar:lib/spring-core.jar:lib/spring-web.jar:lib/tomcat.jar:..." com.example.Main`
                    }
                ]
            },
            {
                title: "5.3 The Spring Boot Way: A Smarter Fat JAR",
                content: [
                    {
                        type: "paragraph",
                        text: "So, if `java -jar` is a standard feature and nested JARs don't work by default, what does Spring Boot do that's special? It cleverly uses this standard mechanism. Instead of setting `Main-Class` to *your* application's main class, the `spring-boot-maven-plugin` sets it to a special launcher class provided by Spring Boot itself, like `org.springframework.boot.loader.launch.JarLauncher`."
                    },
                    {
                        type: "paragraph",
                        text: "When you run `java -jar my-app.jar`, you are actually running the `JarLauncher`. This launcher then does two crucial things:\n1. It creates a special ClassLoader that **knows how to find and load classes from the nested dependency JARs** located in the `BOOT-INF/lib/` directory inside the main JAR.\n2. Once the ClassLoader is ready, the launcher finds your *actual* main class (the one annotated with `@SpringBootApplication`, which it discovers from another manifest entry) and invokes its `main` method."
                    },
                    {
                        type: "diagram",
                        diagram: `my-app.jar
├── BOOT-INF/
│   ├── classes/           # Your compiled code (com/example/Main.class)
│   └── lib/               # All dependencies NESTED as is (spring-core.jar, etc.)
├── META-INF/
│   └── MANIFEST.MF        # Main-Class points to Spring Boot's launcher
└── org/
    └── springframework/
        └── boot/
            └── loader/    # Spring Boot's custom ClassLoader code`
                    }
                ]
            },
            {
                title: "5.4 A Spring Boot Example",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's see what this looks like in practice. Here is a very simple `pom.xml` for a Spring Boot web application. It has one core dependency: `spring-boot-starter-web`."
                    },
                    {
                        type: "code",
                        language: "xml",
                        title: "pom.xml (partial)",
                        code: `<dependencies>\n    <dependency>\n        <groupId>org.springframework.boot</groupId>\n        <artifactId>spring-boot-starter-web</artifactId>\n    </dependency>\n</dependencies>\n\n<build>\n    <plugins>\n        <plugin>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-maven-plugin</artifactId>\n            <executions>\n                <execution>\n                    <goals>\n                        <goal>repackage</goal>\n                    </goals>\n                </execution>\n            </executions>\n        </plugin>\n    </plugins>\n</build>`
                    },
                    {
                        type: "paragraph",
                        text: "The `<dependency>` pulls in Spring's web framework, which in turn pulls in other dependencies like Tomcat. The crucial part is the `<plugin>`. The `spring-boot-maven-plugin`'s `repackage` goal is what takes the standard JAR that Maven creates and re-packages it into the special fat JAR structure we've been discussing."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "DemoApplication.java",
                        code: `package com.example.demo;\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\nimport org.springframework.web.bind.annotation.GetMapping;\nimport org.springframework.web.bind.annotation.RestController;\n\n@SpringBootApplication\n@RestController\npublic class DemoApplication {\n\n    public static void main(String[] args) {\n        SpringApplication.run(DemoApplication.class, args);\n    }\n\n    @GetMapping("/")\n    public String hello() {\n        return "Hello from Spring Boot!";\n    }\n}`
                    },
                    {
                        type: "paragraph",
                        text: "When you run `mvn package`, this code gets compiled, and the plugin creates an executable JAR. The `MANIFEST.MF` inside will point to Spring's launcher, *not* `com.example.demo.DemoApplication`."
                    }
                ]
            },
            {
                title: "5.5 Deconstructing the Spring Boot Application",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's break down the key parts of our `DemoApplication.java` to understand what's happening."
                    },
                    {
                        type: "table",
                        headers: [
                            "Annotation / Method",
                            "What It Does"
                        ],
                        rows: [
                            [
                                {
                                    text: "@SpringBootApplication",
                                    highlight: true
                                },
                                "A master annotation that combines three key annotations: `@Configuration`, `@EnableAutoConfiguration`, and `@ComponentScan`. It's the primary entry point for Spring Boot features."
                            ],
                            [
                                {
                                    text: "    @EnableAutoConfiguration",
                                    highlight: false
                                },
                                "Tells Spring Boot to intelligently configure your application based on the JAR dependencies you have on the classpath. For example, because `spring-boot-starter-web` is present, it automatically sets up an embedded Tomcat server and configures Spring MVC."
                            ],
                            [
                                {
                                    text: "    @ComponentScan",
                                    highlight: false
                                },
                                "Tells Spring to scan the current package (`com.example.demo`) and its sub-packages for other components, configurations, and services to register as beans in the application context."
                            ],
                            [
                                {
                                    text: "@RestController",
                                    highlight: true
                                },
                                "A convenience annotation that combines `@Controller` and `@ResponseBody`. It marks the class as a web controller, and tells Spring that the return value of methods within this class should be written directly to the HTTP response body (e.g., as JSON) instead of being resolved to a view template."
                            ],
                            [
                                {
                                    text: "SpringApplication.run(...)",
                                    highlight: true
                                },
                                "This static method bootstraps the entire application. It creates the Spring Application Context, runs the auto-configuration process, and starts the embedded web server, making the application ready to handle requests."
                            ],
                            [
                                {
                                    text: "    DemoApplication.class",
                                    highlight: false
                                },
                                "This is a Java **class literal**. In Java, every class has a special static variable named `class` that provides a `Class` object representing the class at runtime. It's a way to refer to the class itself as an object.\n\n**Purpose:** Passing `DemoApplication.class` tells Spring Boot \"start everything from here.\" It serves two main purposes for Spring:\n1.  **Primary Configuration Source:** Spring examines this class for annotations, most importantly `@SpringBootApplication`, which kicks off all of Spring Boot's magic.\n2.  **Component Scan Anchor:** Spring uses the package of this class (in this case, `com.example.demo`) as the starting point to scan for other components, services, and configurations (`@Component`, `@RestController`, etc.) you've defined in your project."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "5.6 Spring Boot Execution",
                content: [
                    {
                        type: "paragraph",
                        text: "This clever packaging simplifies execution dramatically."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Running a Spring Boot Application",
                        code: `# No more complex classpath needed!\njava -jar my-spring-boot-app.jar`
                    },
                    {
                        type: "paragraph",
                        text: "This single command works because the JVM runs Spring Boot's `JarLauncher` (specified in the manifest), which then correctly sets up its custom classpath from the nested JARs and runs your application."
                    },
                    {
                        type: "quiz",
                        question: "Why can't a standard `java -jar` command run an application with its dependencies nested as JARs inside the main JAR?",
                        options: [
                            "It's a security restriction",
                            "The default Java ClassLoader cannot read from nested JARs",
                            "The MANIFEST.MF file does not support it",
                            "It requires a special license from Oracle"
                        ],
                        correctAnswer: "The default Java ClassLoader cannot read from nested JARs",
                        explanation: "The core Java ClassLoader is designed to load from directories and JARs on the classpath, but not from JARs contained within other JARs. Spring Boot solves this by providing its own launcher and custom ClassLoader."
                    }
                ]
            }
        ]
    },
    {
        id: "part-6",
        slug: "part-6-spring-boot-magic",
        title: "Part 6: Spring Boot Magic - Under the Hood",
        description: "A deeper look at auto-configuration and component scanning.",
        sections: [
            {
                title: "6.1 The Power of DemoApplication.class",
                content: [
                    {
                        type: "paragraph",
                        text: "As we saw, passing `DemoApplication.class` to `SpringApplication.run()` is the key that starts the engine. Let's explore the two main jobs it performs for Spring Boot:\n\n1.  **Primary Configuration Source:** It acts as the main configuration file for the entire application.\n2.  **Component Scan Anchor:** It defines the starting point for finding all your other application components."
                    },
                    {
                        type: "paragraph",
                        text: "First, a quick refresher on the syntax. `DemoApplication.class` is a **Java class literal**. In Java, every class has a special static variable named `class` that provides a `java.lang.Class` object. This object represents the class itself at runtime and contains all its metadata, like its name, its methods, and, most importantly for Spring, its annotations. It's how you can pass a class around like any other object."
                    }
                ]
            },
            {
                title: "6.2 Purpose 1: Primary Configuration Source",
                content: [
                    {
                        type: "paragraph",
                        text: "When Spring receives the `DemoApplication.class` object, the first thing it does is inspect it for annotations. The `@SpringBootApplication` annotation is the most important one. It's a master switch that enables Spring Boot's **auto-configuration** feature."
                    },
                    {
                        type: "paragraph",
                        text: "Auto-configuration is Spring's way of being helpful. It looks at the dependencies (the JARs) you've included in your `pom.xml` and makes intelligent guesses about how you want to configure your application.\n\n- **If it sees `spring-boot-starter-web`:** It assumes you want to build a web application. It will then automatically start and configure an embedded Tomcat web server and set up the necessary components to handle HTTP requests (like Spring MVC's `DispatcherServlet`).\n- **If it sees `spring-boot-starter-data-jpa` and a database driver like `h2`:** It assumes you want to connect to a database. It will then automatically configure a data source, an entity manager, and other necessary beans for database interaction.\n\nThis all happens without you writing a single line of XML or Java configuration for these components. It's convention over configuration, driven by the dependencies you've chosen."
                    }
                ]
            },
            {
                title: "6.3 Purpose 2: Component Scan Anchor",
                content: [
                    {
                        type: "paragraph",
                        text: "The second job is to act as a starting point for **component scanning**. The `@SpringBootApplication` annotation also includes `@ComponentScan`. This tells Spring: \"Look in the package of this class, and all of its sub-packages, for any other classes marked with annotations like `@Component`, `@Service`, `@Repository`, or `@RestController`.\"\n\nLet's see an example. Imagine this project structure:"
                    },
                    {
                        type: "console",
                        title: "Example Project Structure",
                        output: `src/main/java/\n└── com/\n    └── example/\n        └── myapp/\n            ├── Application.java          // Our main class with @SpringBootApplication\n            ├── controller/\n            │   └── UserController.java   // A @RestController\n            └── service/\n                └── UserService.java      // A @Service`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "Application.java",
                        code: `package com.example.myapp;\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\n\n@SpringBootApplication\npublic class Application {\n    public static void main(String[] args) {\n        SpringApplication.run(Application.class, args);\n    }\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "UserController.java",
                        code: `package com.example.myapp.controller;\n\nimport com.example.myapp.service.UserService;\nimport org.springframework.web.bind.annotation.RestController;\nimport org.springframework.beans.factory.annotation.Autowired;\n\n@RestController\npublic class UserController {\n    @Autowired\n    private UserService userService; // Spring will inject this!\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "UserService.java",
                        code: `package com.example.myapp.service;\n\nimport org.springframework.stereotype.Service;\n\n@Service\npublic class UserService {\n    public String getUser() {\n        return "John Doe";\n    }\n}`
                    },
                    {
                        type: "paragraph",
                        text: "Because `Application.java` is in the `com.example.myapp` package, the component scan automatically finds `UserController` (in `com.example.myapp.controller`) and `UserService` (in `com.example.myapp.service`). Spring then creates instances of these classes (called 'beans') and manages their lifecycle. It's even smart enough to handle the `@Autowired` annotation in `UserController` and inject the `UserService` bean into it.\n\nIf you were to place `UserService` in a different package, like `com.another.package`, Spring would *not* find it by default."
                    },
                    {
                        type: "quiz",
                        question: "If you place a `@Service` annotated class in a package *outside* the package tree of your main `@SpringBootApplication` class, what happens by default?",
                        options: [
                            "Spring Boot automatically finds and registers it.",
                            "It will not be found or registered as a Spring bean.",
                            "The application will fail to compile.",
                            "You will get a warning at runtime."
                        ],
                        correctAnswer: "It will not be found or registered as a Spring bean.",
                        explanation: "By default, `@ComponentScan` (part of `@SpringBootApplication`) only scans the package of the main class and its sub-packages. To include other packages, you must explicitly configure them using the `@ComponentScan` annotation with package names."
                    }
                ]
            },
            {
                title: "6.4 The Magic of @Autowired: Dependency Injection",
                content: [
                    {
                        type: "paragraph",
                        text: "In our `UserController` example, we saw the `@Autowired` annotation. This is where Spring's most powerful feature comes into play: **Dependency Injection (DI)**."
                    },
                    {
                        type: "paragraph",
                        text: "Without Spring, if `UserController` needed a `UserService`, you would have to create it yourself, like this: `private UserService userService = new UserService();`. This creates a tight coupling between the two classes. `UserController` is permanently tied to that specific implementation of `UserService`."
                    },
                    {
                        type: "paragraph",
                        text: "Dependency Injection inverts this. It's a form of a broader principle called **Inversion of Control (IoC)**. Instead of your object controlling the creation of its dependencies, control is inverted: the Spring Framework *controls* the creation of objects (called 'beans') and 'injects' them where they are needed. `UserController` no longer creates `UserService`; it simply declares that it needs one, and Spring provides it."
                    },
                    {
                        type: "diagram",
                        diagram: `   [Spring IoC Container]
(manages all beans it knows about)
  /------------------\\
  | @Service         |
  |  UserService bean|
  \\------------------/
       |
       |  @Autowired
       +-------------> [UserController]
                       |
                       | private UserService userService;
                       |  (Spring injects the bean here)
                       \\--------------------------------/`
                    },
                    {
                        type: "paragraph",
                        text: "The benefits are immense. Your components are decoupled, making them easier to manage, reuse, and, critically, test. In a unit test for `UserController`, you can easily inject a *mock* version of `UserService` to test the controller in isolation, without needing a real service."
                    },
                    {
                        type: "paragraph",
                        text: "So the flow is:\n1. Spring starts, component-scans, finds `@Service` on `UserService`, and creates a single instance (a bean) of it for the whole application.\n2. Spring then finds `@RestController` on `UserController` and starts creating a bean for it.\n3. It sees the `@Autowired` annotation on the `userService` field.\n4. It looks in its container of beans, finds the `UserService` bean it created in step 1, and assigns (injects) that instance into the `userService` field.\n\nAll of this happens automatically, managed by the Spring IoC container."
                    },
                    {
                        type: "quiz",
                        question: "What is the primary benefit of using Dependency Injection in Spring?",
                        options: [
                            "It makes the application run faster.",
                            "It reduces the final JAR size.",
                            "It decouples components, making them more modular and easier to test.",
                            "It automatically writes database queries for you."
                        ],
                        correctAnswer: "It decouples components, making them more modular and easier to test.",
                        explanation: "DI allows objects to receive their dependencies from an external source rather than creating them. This removes hard-coded connections between components and simplifies unit testing by allowing mock dependencies to be injected."
                    }
                ]
            }
        ]
    },
    {
        id: "part-7",
        slug: "part-7-the-world-of-spring-beans",
        title: "Part 7: The World of Spring Beans",
        description: "Learn about the fundamental building blocks of a Spring application: Beans and the IoC Container.",
        sections: [
            {
                title: "7.1 What is a Spring Bean?",
                content: [
                    {
                        type: "paragraph",
                        text: "In Spring, a **bean** is simply an object that is instantiated, assembled, and otherwise managed by a Spring **Inversion of Control (IoC) container**. They are the fundamental building blocks of any Spring application."
                    },
                    {
                        type: "paragraph",
                        text: "Think of them not as special, magical entities, but as the regular Java objects (POJOs - Plain Old Java Objects) that form the backbone of your application. When we annotated `UserService` with `@Service` or `UserController` with `@RestController`, we were telling Spring: \"Please create an instance of this class for me, and manage it. Make it a bean.\""
                    },
                    {
                        type: "paragraph",
                        text: "The container gets its instructions on what to instantiate, configure, and assemble by reading configuration metadata. In modern Spring Boot, this metadata is primarily the stereotype annotations:"
                    },
                    {
                        type: "table",
                        headers: [
                            "Annotation",
                            "Purpose"
                        ],
                        rows: [
                            [
                                {
                                    text: "@Component",
                                    highlight: true
                                },
                                "The generic stereotype for any Spring-managed component. It's the base annotation."
                            ],
                            [
                                {
                                    text: "@Service",
                                    highlight: false
                                },
                                "A specialization of `@Component` for the service layer. It indicates that the class holds business logic."
                            ],
                            [
                                {
                                    text: "@Repository",
                                    highlight: false
                                },
                                "A specialization for the persistence layer. It's used on classes that access the database, and it enables Spring's exception translation feature."
                            ],
                            [
                                {
                                    text: "@Controller",
                                    highlight: false
                                },
                                "Indicates a class that handles web requests, typically returning a view name."
                            ],
                            [
                                {
                                    text: "@RestController",
                                    highlight: false
                                },
                                "A convenience annotation that combines `@Controller` and `@ResponseBody`, used for creating RESTful web services."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "7.2 The IoC Container and ApplicationContext",
                content: [
                    {
                        type: "paragraph",
                        text: "The **IoC container** is the heart of the Spring Framework. It's the factory that is responsible for creating the beans, wiring them together, configuring them, and managing their complete lifecycle. The `ApplicationContext` is the central interface in Spring for providing configuration information to the application, and it is the most commonly used implementation of the IoC container."
                    },
                    {
                        type: "diagram",
                        diagram: `+--------------------------------------------------------+
|                   ApplicationContext                       |
|                (Spring IoC Container)                      |
|                                                        |
|  +----------------+  @Autowired   +---------------------+  |
|  | UserService    |------------->|  UserController     |  |
|  | (Bean)         |<-------------|  (Bean)             |  |
|  +----------------+  (injects)    +---------------------+  |
|                                                        |
|           [Manages lifecycle: creation, wiring, destruction]           |
+--------------------------------------------------------+`
                    },
                    {
                        type: "paragraph",
                        text: "When we called `SpringApplication.run()`, we were essentially telling Spring Boot to create and initialize an `ApplicationContext`. This context then performs the component scan, finds all the classes marked as beans, instantiates them, and injects their dependencies (like injecting `UserService` into `UserController`)."
                    }
                ]
            },
            {
                title: "7.3 Understanding Bean Scopes",
                content: [
                    {
                        type: "paragraph",
                        text: "Not all beans are created equal. A bean's **scope** controls how many instances of that bean are created and how long they live. Spring defines several scopes, but the most important one by far is `singleton`."
                    },
                    {
                        type: "table",
                        headers: [
                            "Scope",
                            "Description"
                        ],
                        rows: [
                            [
                                {
                                    text: "singleton",
                                    highlight: true
                                },
                                "**(Default)** Only one single instance of the bean is created per Spring IoC container. When your code asks for this bean, the container always returns the exact same instance. This is ideal for stateless services like repositories and controllers."
                            ],
                            [
                                {
                                    text: "prototype",
                                    highlight: false
                                },
                                "A new instance of the bean is created every single time it is requested from the container. Useful for stateful objects where each user needs their own copy."
                            ],
                            [
                                {
                                    text: "request",
                                    highlight: false
                                },
                                "**(Web-aware)** A new instance is created for each individual HTTP request. Only valid in the context of a web-aware Spring ApplicationContext."
                            ],
                            [
                                {
                                    text: "session",
                                    highlight: false
                                },
                                "**(Web-aware)** A new instance is created for each HTTP session. Only valid in the context of a web-aware Spring ApplicationContext."
                            ]
                        ]
                    },
                    {
                        type: "paragraph",
                        text: "For the vast majority of applications, especially for stateless components like services, repositories, and controllers, the default `singleton` scope is exactly what you want and need."
                    }
                ]
            },
            {
                title: "7.4 Bean Lifecycle Callbacks",
                content: [
                    {
                        type: "paragraph",
                        text: "Because the container manages the beans, it knows exactly when they are created, when their dependencies are injected, and when they are about to be destroyed. This allows you to hook into the bean's lifecycle to perform custom initialization or cleanup logic."
                    },
                    {
                        type: "paragraph",
                        text: "The two most common lifecycle annotations are:\n- **`@PostConstruct`**: Marks a method to be executed *after* the bean has been created and all its dependencies have been injected. This is a perfect place to perform any initialization logic that requires those dependencies.\n- **`@PreDestroy`**: Marks a method to be executed just *before* the bean is removed from the container and destroyed. This is the ideal place for cleanup tasks, like closing a database connection or releasing other resources."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "LifecycleExampleService.java",
                        code: `package com.example.myapp.service;\n\nimport javax.annotation.PostConstruct;\nimport javax.annotation.PreDestroy;\nimport org.springframework.stereotype.Service;\n\n@Service\npublic class LifecycleExampleService {\n\n    public LifecycleExampleService() {\n        System.out.println("1. Constructor called.");\n    }\n\n    @PostConstruct\n    public void init() {\n        System.out.println("2. @PostConstruct: Bean is ready, dependencies are injected. Initializing resources...");\n    }\n\n    public void doWork() {\n        System.out.println("3. Doing work...");\n    }\n\n    @PreDestroy\n    public void cleanup() {\n        System.out.println("4. @PreDestroy: Application is shutting down. Cleaning up resources...");\n    }\n}`
                    },
                    {
                        type: "console",
                        title: "Expected Log Output on Application Start/Stop",
                        output: `1. Constructor called.\n2. @PostConstruct: Bean is ready, dependencies are injected. Initializing resources...\n...\n(Application runs, doWork() might be called)\n...\n4. @PreDestroy: Application is shutting down. Cleaning up resources...`
                    },
                    {
                        type: "quiz",
                        question: "What is the default scope of a Spring bean?",
                        options: [
                            "prototype",
                            "request",
                            "session",
                            "singleton"
                        ],
                        correctAnswer: "singleton",
                        explanation: "By default, every bean defined in a Spring container is a singleton, meaning only one instance of that bean will be created and shared throughout the application."
                    }
                ]
            }
        ]
    },
    {
        id: "part-8",
        slug: "part-8-a-glimpse-inside-the-jvm",
        title: "Part 8: A Glimpse Inside the JVM",
        description: "Understand the Java Virtual Machine that runs your code.",
        sections: [
            {
                title: "8.1 What is the JVM?",
                content: [
                    {
                        type: "paragraph",
                        text: "The Java Virtual Machine (JVM) is the engine that drives the Java ecosystem. It's an abstract computing machine that enables a computer to run a Java program. The primary goal of the JVM is to make Java platform-independent."
                    },
                    {
                        type: "paragraph",
                        text: "This leads to the famous slogan: **\"Write Once, Run Anywhere\" (WORA)**. You can compile your Java code on a Windows machine, and the resulting `.class` files can run on any other machine (like macOS or Linux) that has a compliant JVM installed, without any changes. The JVM acts as a translation layer between your compiled Java code (bytecode) and the specific operating system and hardware it's running on."
                    }
                ]
            },
            {
                title: "8.2 The Journey of a .class File",
                content: [
                    {
                        type: "paragraph",
                        text: "When you compile a `.java` file, you get a `.class` file containing platform-neutral bytecode. This bytecode is the set of instructions for the JVM. Here is a high-level overview of what happens when you run `java MyApp`."
                    },
                    {
                        type: "diagram",
                        diagram: `MyApp.java
    |
 (javac)
    |
    v
MyApp.class (Bytecode)
    |
 (java MyApp)
    |
    v
+-----------------------------------------------------------------+
|                         JVM Instance                            |
|                                                                 |
|  [Class Loader Subsystem] ---> [Runtime Data Areas] <--- [Execution Engine] |
|   - Loads .class files       - Heap (Objects live here)  - Interpreter      |
|   - Links & Initializes      - Stack (Method calls)      - JIT Compiler     |
|                              - Method Area (Class data)  - Garbage Collector|
|                                                                 |
+-----------------------------------------------------------------+
    |
    v
[Native Machine Code -> Runs on Host OS/CPU]`
                    },
                    {
                        type: "paragraph",
                        text: "The `.class` file is first loaded into memory by the Class Loader Subsystem. It's verified and prepared, and memory is allocated for it in the Runtime Data Areas. Finally, a component of the JVM called the Execution Engine runs the bytecode, either by interpreting it or by compiling it 'just-in-time' into native machine code for much faster execution."
                    }
                ]
            },
            {
                title: "8.3 Key JVM Components",
                content: [
                    {
                        type: "paragraph",
                        text: "The JVM has several key parts that work together:"
                    },
                    {
                        type: "table",
                        headers: [
                            "Component",
                            "Description"
                        ],
                        rows: [
                            [
                                {
                                    text: "Class Loader",
                                    highlight: true
                                },
                                "Responsible for dynamically loading Java classes into the JVM at runtime. It finds the `.class` files (using the classpath), loads their bytecode, and prepares them for execution."
                            ],
                            [
                                {
                                    text: "Heap",
                                    highlight: false
                                },
                                "The primary memory area where all objects created by your application are stored. This memory is shared among all threads and is managed by the Garbage Collector."
                            ],
                            [
                                {
                                    text: "Stack",
                                    highlight: false
                                },
                                "Each thread in the JVM has its own private stack. It stores frames for each method invocation, containing local variables, parameters, and partial results. When a method is called, a new frame is pushed onto the stack; when it completes, the frame is popped."
                            ],
                            [
                                {
                                    text: "Method Area / Metaspace",
                                    highlight: false
                                },
                                "A shared memory area that stores per-class structures, such as the runtime constant pool, field and method data, and the code for methods."
                            ],
                            [
                                {
                                    text: "Execution Engine",
                                    highlight: true
                                },
                                "This is the core of the JVM. It executes the bytecode from the loaded `.class` files. It contains an **Interpreter** (reads and executes bytecode line by line) and a **Just-In-Time (JIT) Compiler** (compiles frequently used 'hot' bytecode into native machine code for significant performance boosts)."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "8.4 Garbage Collection (GC) 101",
                content: [
                    {
                        type: "paragraph",
                        text: "One of the most important features of the JVM is automatic memory management, also known as Garbage Collection (GC). Instead of you having to manually allocate and deallocate memory, the GC automatically reclaims memory occupied by objects that are no longer in use by the application."
                    },
                    {
                        type: "paragraph",
                        text: "A common GC strategy is called **Mark and Sweep**. It works in two phases:\n1.  **Mark Phase:** The GC starts from a set of 'root' objects (like variables on the stack) and traverses the entire object graph, marking every object it can reach as 'in use'.\n2.  **Sweep Phase:** The GC then scans the entire heap and reclaims the memory used by any object that was not marked. These are the 'garbage' objects."
                    },
                    {
                        type: "diagram",
                        diagram: `        [HEAP]
    (Before GC)
    [ Obj A (root) ] -> [ Obj B ] -> [ Obj C ]

    [ Obj D (lost) ]

    (After GC)
    [ Obj A (root) ] -> [ Obj B ] -> [ Obj C ]

    [ <free memory>  ]

1. Mark: Start from roots (e.g., stack variables), find all reachable objects (A, B, C).
2. Sweep: Go through the heap and remove all unmarked (unreachable) objects (D).`
                    },
                    {
                        type: "quiz",
                        question: "In the JVM, where are objects created by your application primarily stored?",
                        options: [
                            "The Stack",
                            "The Heap",
                            "PC Registers",
                            "The Method Area"
                        ],
                        correctAnswer: "The Heap",
                        explanation: "The Heap is the runtime data area from which memory for all class instances and arrays is allocated. It is the main memory resource managed by the Garbage Collector."
                    }
                ]
            }
        ]
    }
];
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Button": (()=>Button),
    "buttonVariants": (()=>buttonVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, variant, size, asChild = false, ...props }, ref)=>{
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 46,
        columnNumber: 7
    }, this);
});
Button.displayName = "Button";
;
}}),
"[project]/src/components/ui/scroll-area.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ScrollArea": (()=>ScrollArea),
    "ScrollBar": (()=>ScrollBar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-scroll-area/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const ScrollArea = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("relative overflow-hidden", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
                className: "h-full w-full rounded-[inherit]",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/scroll-area.tsx",
                lineNumber: 17,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ScrollBar, {}, void 0, false, {
                fileName: "[project]/src/components/ui/scroll-area.tsx",
                lineNumber: 20,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Corner"], {}, void 0, false, {
                fileName: "[project]/src/components/ui/scroll-area.tsx",
                lineNumber: 21,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/scroll-area.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, this));
ScrollArea.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"].displayName;
const ScrollBar = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, orientation = "vertical", ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollAreaScrollbar"], {
        ref: ref,
        orientation: orientation,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollAreaThumb"], {
            className: "relative flex-1 rounded-full bg-border"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/scroll-area.tsx",
            lineNumber: 43,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/scroll-area.tsx",
        lineNumber: 30,
        columnNumber: 3
    }, this));
ScrollBar.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollAreaScrollbar"].displayName;
;
}}),
"[project]/src/components/CourseNav.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CourseNav": (()=>CourseNav)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$course$2d$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/course-data.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$scroll$2d$area$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/scroll-area.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpen>");
"use client";
;
;
;
;
;
;
;
;
function CourseNav() {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        className: "w-full h-full flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 border-b",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    href: "/",
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                            className: "h-6 w-6 text-primary"
                        }, void 0, false, {
                            fileName: "[project]/src/components/CourseNav.tsx",
                            lineNumber: 18,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-bold font-headline",
                            children: "Java Deep Dive"
                        }, void 0, false, {
                            fileName: "[project]/src/components/CourseNav.tsx",
                            lineNumber: 19,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/CourseNav.tsx",
                    lineNumber: 17,
                    columnNumber: 10
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/CourseNav.tsx",
                lineNumber: 16,
                columnNumber: 8
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$scroll$2d$area$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollArea"], {
                className: "flex-1",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "p-4 space-y-2",
                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$course$2d$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["courseData"].map((part)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                            asChild: true,
                            variant: pathname === `/${part.slug}` ? "default" : "ghost",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("w-full justify-start text-left h-auto py-2", pathname === `/${part.slug}` ? "" : "text-muted-foreground hover:text-foreground"),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: `/${part.slug}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-semibold",
                                            children: part.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/CourseNav.tsx",
                                            lineNumber: 33,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-xs font-normal opacity-80",
                                            children: part.description
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/CourseNav.tsx",
                                            lineNumber: 34,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/CourseNav.tsx",
                                    lineNumber: 32,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/CourseNav.tsx",
                                lineNumber: 31,
                                columnNumber: 15
                            }, this)
                        }, part.id, false, {
                            fileName: "[project]/src/components/CourseNav.tsx",
                            lineNumber: 25,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/CourseNav.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/CourseNav.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/CourseNav.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__3b3d0072._.js.map