"use client";

import { courseData } from "@/lib/course-data";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";
import { ScrollArea } from "./ui/scroll-area";
import { BookOpen } from "lucide-react";

export function CourseNav() {
  const pathname = usePathname();

  return (
    <aside className="w-full h-full flex flex-col">
       <div className="p-4 border-b">
         <Link href="/" className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary" />
            <h2 className="text-xl font-bold font-headline">Java Deep Dive</h2>
        </Link>
      </div>
      <ScrollArea className="flex-1">
        <nav className="p-4 space-y-2">
          {courseData.map((part) => (
            <Button
              key={part.id}
              asChild
              variant={pathname === `/${part.slug}` ? "default" : "ghost"}
              className={cn("w-full justify-start text-left h-auto py-2", pathname === `/${part.slug}` ? "" : "text-muted-foreground hover:text-foreground")}
            >
              <Link href={`/${part.slug}`}>
                <div>
                    <div className="font-semibold">{part.title}</div>
                    <div className="text-xs font-normal opacity-80">{part.description}</div>
                </div>
              </Link>
            </Button>
          ))}
        </nav>
      </ScrollArea>
    </aside>
  );
}
