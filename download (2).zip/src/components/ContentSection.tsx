import type { ContentItem } from "@/lib/course-data";
import { CodeBlock } from "./CodeBlock";
import { ConsoleOutput } from "./ConsoleOutput";
import { Quiz } from "./Quiz";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";

export function ContentSection({ content, slug }: { content: ContentItem[], slug: string }) {
  return (
    <div className="space-y-4">
      {content.map((item, index) => {
        switch (item.type) {
          case "paragraph":
            return <p key={index} className="leading-relaxed" dangerouslySetInnerHTML={{ __html: item.text.replace(/\n/g, '<br />') }} />;
          case "code":
            return <div key={index}>
              {item.title && <h4 className="font-headline text-lg font-semibold mt-6 mb-1">{item.title}</h4>}
              <CodeBlock code={item.code} language={item.language} />
            </div>;
          case "console":
            return <ConsoleOutput key={index} output={item.output} title={item.title} />;
          case "quiz":
            return <Quiz key={index} {...item} slug={slug} />;
          case "diagram":
             return <ConsoleOutput key={index} output={item.diagram} title="Diagram" />;
          case "table":
            return <Card key={index} className="my-6">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {item.headers.map((header, hIndex) => <TableHead key={hIndex} className={hIndex === 0 ? "w-[200px]" : ""}>{header}</TableHead>)}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {item.rows.map((row, rIndex) => (
                      <TableRow key={rIndex}>
                        {row.map((cell, cIndex) => (
                          <TableCell key={cIndex}>
                            {typeof cell === 'string' ? cell : <code className="font-code text-primary bg-primary/10 px-1 py-0.5 rounded">{cell.text}</code>}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          default:
            return null;
        }
      })}
    </div>
  );
}
