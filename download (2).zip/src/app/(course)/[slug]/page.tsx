import { courseData } from "@/lib/course-data";
import { notFound } from "next/navigation";
import { ContentSection } from "@/components/ContentSection";
import { Separator } from "@/components/ui/separator";

export function generateStaticParams() {
    return courseData.map((part) => ({
        slug: part.slug,
    }));
}

export default function CoursePartPage({ params }: { params: { slug: string } }) {
    const part = courseData.find((p) => p.slug === params.slug);

    if (!part) {
        notFound();
    }

    return (
        <article className="max-w-4xl mx-auto p-6 sm:p-8 md:p-12">
            <header className="mb-8">
                <p className="text-primary font-bold font-headline">{part.title.split(":")[0]}</p>
                <h1 className="text-4xl font-bold font-headline tracking-tight mt-1">{part.title.split(":")[1]}</h1>
                <p className="text-lg text-muted-foreground mt-2">{part.description}</p>
            </header>
            
            <div className="space-y-12">
                {part.sections.map((section, index) => (
                    <section key={index}>
                        <h2 className="font-headline text-3xl font-semibold border-b pb-2 mb-6">{section.title}</h2>
                        <ContentSection content={section.content} slug={params.slug} />
                    </section>
                ))}
            </div>
        </article>
    );
}
