import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MoveRight } from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center p-4 bg-grid-zinc-300/[0.2] dark:bg-grid-zinc-700/[0.2]">
      <Card className="max-w-xl w-full shadow-2xl">
        <CardHeader className="text-center">
          <h1 className="font-headline text-4xl font-bold tracking-tight text-primary">Java - BACK TO BASICS</h1>
          <CardDescription className="text-lg pt-2">
            An interactive course on Java compilation, execution, Maven, and Spring Boot.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          <p className="mb-6 text-center text-muted-foreground">
            From source code to a running application, master the fundamentals of the Java ecosystem.
          </p>
          <Button asChild size="lg" className="font-headline">
            <Link href="/part-1-the-basics">
              Start Learning
              <MoveRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </CardContent>
      </Card>
    </main>
  );
}
