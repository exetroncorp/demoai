"use server";

import { explainCodeSnippet } from "@/ai/flows/explain-code-snippet";
import { z } from "zod";

const explainSchema = z.object({
  code: z.string(),
  language: z.string(),
});

export interface ExplainState {
  explanation?: string;
  error?: string;
}

export async function getExplanation(
  prevState: ExplainState,
  formData: FormData
): Promise<ExplainState> {
  try {
    const { code, language } = explainSchema.parse({
      code: formData.get("code"),
      language: formData.get("language"),
    });

    const result = await explainCodeSnippet({ codeSnippet: code, language });

    return { explanation: result.explanation };
  } catch (e) {
    const error = e instanceof Error ? e.message : "An unknown error occurred.";
    return { error };
  }
}
