#!/bin/bash
set -e

mkdir -p /workspace
exec code-server --bind-addr 0.0.0.0:${PORT} --auth none /workspace
