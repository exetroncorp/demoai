#!/usr/bin/env python3
import json, glob, pathlib

blob = glob.glob('/home/prooter/.prooter/oci/*/blobs/sha256/*.json')[0]
c = json.loads(pathlib.Path(blob).read_text())
print('Entrypoint:', c.get('config',{}).get('Entrypoint'))
print('Cmd:', c.get('config',{}).get('Cmd'))