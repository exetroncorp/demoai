"""Layer extraction and management utilities."""

import gzip
import os
import shutil
import tarfile
from pathlib import Path
from typing import List, Optional, Set


def extract_layer(
    layer_path: Path,
    target_dir: Path,
    handle_whiteouts: bool = True,
) -> None:
    """Extract a single layer to a target directory.
    
    Args:
        layer_path: Path to the layer archive (tar.gz)
        target_dir: Directory to extract to
        handle_whiteouts: Whether to process OCI whiteout files
    """
    target_dir.mkdir(parents=True, exist_ok=True)
    
    # Determine if gzipped
    is_gzip = False
    with open(layer_path, "rb") as f:
        magic = f.read(2)
        is_gzip = magic == b"\x1f\x8b"
    
    mode = "r:gz" if is_gzip else "r:"
    
    with tarfile.open(layer_path, mode) as tar:
        # Get all members
        members = tar.getmembers()
        
        # Process whiteouts first if enabled
        whiteouts: Set[str] = set()
        opaque_dirs: Set[str] = set()
        
        if handle_whiteouts:
            for member in members:
                basename = os.path.basename(member.name)
                dirname = os.path.dirname(member.name)
                
                if basename == ".wh..wh..opq":
                    # Opaque whiteout - directory should be emptied
                    opaque_dirs.add(dirname)
                elif basename.startswith(".wh."):
                    # Regular whiteout - file should be deleted
                    original_name = basename[4:]  # Remove .wh. prefix
                    whiteout_path = os.path.join(dirname, original_name)
                    whiteouts.add(whiteout_path)
        
        # Handle opaque directories - remove their contents
        for opaque_dir in opaque_dirs:
            full_path = target_dir / opaque_dir
            if full_path.exists() and full_path.is_dir():
                for item in full_path.iterdir():
                    if item.is_dir():
                        shutil.rmtree(item)
                    else:
                        item.unlink()
        
        # Handle regular whiteouts - remove specific files
        for whiteout in whiteouts:
            full_path = target_dir / whiteout
            if full_path.exists():
                if full_path.is_dir():
                    shutil.rmtree(full_path)
                else:
                    full_path.unlink()
        
        # Extract non-whiteout members
        for member in members:
            basename = os.path.basename(member.name)
            
            # Skip whiteout files themselves
            if basename.startswith(".wh."):
                continue
            
            # Skip if empty name
            if not member.name or member.name == ".":
                continue
            
            try:
                # Security check - prevent path traversal
                # Use normpath instead of resolve to avoid following symlinks to host during check
                rel_path = os.path.normpath(member.name)
                if rel_path.startswith("..") or os.path.isabs(rel_path):
                    # For absolute paths in tar, we make them relative to target_dir
                    if os.path.isabs(rel_path):
                        member.name = rel_path.lstrip(os.sep)
                    else:
                        print(f"  Warning: Skipping suspicious path: {member.name}")
                        continue
                
                target = target_dir / member.name
                
                # Handle different member types
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with tar.extractfile(member) as src:
                        if src:
                            with open(target, "wb") as dst:
                                shutil.copyfileobj(src, dst)
                    # Set permissions
                    try:
                        os.chmod(target, member.mode)
                    except OSError:
                        pass
                elif member.issym():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if target.exists() or target.is_symlink():
                        target.unlink()
                    target.symlink_to(member.linkname)
                elif member.islnk():
                    # Hard link
                    target.parent.mkdir(parents=True, exist_ok=True)
                    link_target = target_dir / member.linkname
                    if target.exists():
                        target.unlink()
                    if link_target.exists():
                        os.link(link_target, target)
                        
            except Exception as e:
                # Log but continue - some files may fail due to permissions
                print(f"  Warning: Failed to extract {member.name}: {e}")


def apply_layers(
    layer_paths: List[Path],
    target_dir: Path,
    progress_callback: Optional[callable] = None,
) -> None:
    """Apply multiple layers in order to create a root filesystem.
    
    Args:
        layer_paths: List of layer archive paths in order (base first)
        target_dir: Directory to create the filesystem in
        progress_callback: Optional callback(layer_index, total) for progress
    """
    target_dir.mkdir(parents=True, exist_ok=True)
    
    for i, layer_path in enumerate(layer_paths):
        if progress_callback:
            progress_callback(i, len(layer_paths))
        
        extract_layer(layer_path, target_dir)
    
    if progress_callback:
        progress_callback(len(layer_paths), len(layer_paths))


def get_layer_path(layers_dir: Path, digest: str) -> Path:
    """Get the filesystem path for a layer by its digest.
    
    Args:
        layers_dir: Base directory for layers
        digest: Layer digest (e.g., 'sha256:...')
        
    Returns:
        Path to the layer archive
    """
    # Replace : with _ for filesystem compatibility
    safe_name = digest.replace(":", "_")
    return layers_dir / safe_name
