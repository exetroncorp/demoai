
import sys
import os
from pathlib import Path

# Add current directory to sys.path to use local prooter code
sys.path.insert(0, os.getcwd())

import logging
logging.basicConfig(level=logging.DEBUG)

print("Running debug_pull.py from", os.getcwd())
print("Prooter location:", sys.modules.get('prooter'))

from prooter.registry import RegistryClient

try:
    client = RegistryClient()
    print("Starting pull...")
    client.pull_image("debian:bookworm-slim")
    print("Pull finished successfully.")
except Exception as e:
    print(f"Pull failed: {e}")
