#!/usr/bin/env python3
import subprocess, json, pathlib

# pull again to ensure oci dir exists
subprocess.run(["/home/prooter/venv/bin/python", "-m", "prooter", "pull", "nanto2vison/biglayer:test"], check=True)

# find the config blob
digest = subprocess.check_output(
    ["/home/prooter/venv/bin/python", "-m", "prooter", "inspect", "nanto2vison/biglayer:test"],
    text=True
)
manifest = json.loads(digest)
config_digest = manifest["config"]["digest"]
blob_path = pathlib.Path(f"/tmp/oci/{config_digest}")

# extract the blob from the oci layout
layout_dir = pathlib.Path("/home/prooter/.prooter/oci/nanto2vison_biglayer:test")
blob = layout_dir / "blobs" / config_digest
config = json.loads(blob.read_text())
print("Entrypoint:", config.get("config", {}).get("Entrypoint"))
print("Cmd:", config.get("config", {}).get("Cmd"))