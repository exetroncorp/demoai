#!/bin/bash
set -e

PASS=0
FAIL=0
TOTAL=13

step() {
    echo ""
    echo "=============================================="
    echo "  STEP $1: $2"
    echo "=============================================="
}

pass() {
    echo "  ✅ PASSED: $1"
    PASS=$((PASS + 1))
}

fail() {
    echo "  ❌ FAILED: $1"
    FAIL=$((FAIL + 1))
}

echo "╔══════════════════════════════════════════════╗"
echo "║       PROOTER END-TO-END TEST SUITE          ║"
echo "╚══════════════════════════════════════════════╝"

# Step 1: Setup and version check
step 1 "Setup & Version Check"
prooter setup && pass "prooter setup" || fail "prooter setup"

# Step 2: Login to Docker Hub
step 2 "Login to Docker Hub"
if [ -n "$DOCKER_USERNAME" ] && [ -n "$DOCKER_PASSWORD" ]; then
    printf "%s" "$DOCKER_PASSWORD" | prooter login -u "$DOCKER_USERNAME" --password-stdin && pass "prooter login" || fail "prooter login"
else
    echo "  Skipping login; DOCKER_USERNAME/DOCKER_PASSWORD not set"
    pass "prooter login (skipped)"
fi

# Step 3: Pull alpine image
step 3 "Pull alpine:latest"
prooter pull alpine:latest && pass "prooter pull alpine:latest" || fail "prooter pull alpine:latest"

# Step 4: List images (verify alpine is there)
step 4 "List Images"
prooter images
if prooter images | grep -q "alpine"; then
    pass "alpine image listed"
else
    fail "alpine image not listed"
fi

# Step 5: Run container with echo
step 5 "Run Container (echo)"
OUTPUT=$(prooter run --rm alpine:latest echo "Hello from Prooter E2E!")
echo "$OUTPUT"
if echo "$OUTPUT" | grep -q "Hello from Prooter"; then
    pass "prooter run echo"
else
    fail "prooter run echo"
fi

# Step 6: Run container with id (verify faked root)
step 6 "Run Container (id - verify root emulation)"
OUTPUT=$(prooter run --rm alpine:latest id)
echo "$OUTPUT"
if echo "$OUTPUT" | grep -q "uid=0"; then
    pass "prooter run id (uid=0)"
else
    fail "prooter run id (uid=0)"
fi

# Step 7: Build a test image
step 7 "Build Test Image"
prooter build -t test-app:latest -f Dockerfile /home/prooter/prooter/test-e2e && pass "prooter build" || fail "prooter build"

# Step 8: Verify built image in images list
step 8 "Verify Built Image"
prooter images
echo "DEBUG OCI DIR:"
ls -R /home/prooter/.prooter/oci || echo "No OCI dir found"
prooter images | grep "test-app"
if [ $? -eq 0 ]; then
    pass "test-app image listed"
else
    fail "test-app image not listed"
fi

# Step 9: Max layer size limit
step 9 "Max Layer Size Limit"
python3 - <<'PY'
import json
from pathlib import Path
config_path = Path.home() / ".prooter" / "config.json"
data = {}
if config_path.exists():
    try:
        data = json.loads(config_path.read_text())
    except Exception:
        data = {}
data["max_layer_size_MB"] = 64
config_path.parent.mkdir(parents=True, exist_ok=True)
config_path.write_text(json.dumps(data, indent=2))
PY
mkdir -p /home/prooter/test-max-layer/files
dd if=/dev/zero of=/home/prooter/test-max-layer/files/blob1.bin bs=1048576 count=30
dd if=/dev/zero of=/home/prooter/test-max-layer/files/blob2.bin bs=1048576 count=30
dd if=/dev/zero of=/home/prooter/test-max-layer/files/blob3.bin bs=1048576 count=30
cat > /home/prooter/test-max-layer/Dockerfile <<'EOF'
FROM alpine:latest
COPY files/ /data/
CMD ["ls", "-la", "/data"]
EOF
prooter build -t max-layer-test:latest -f Dockerfile /home/prooter/test-max-layer || fail "prooter build max-layer-test"
if python3 - <<'PY'
import json
from pathlib import Path
oci_dir = Path.home() / ".prooter" / "oci"
target = None
for p in oci_dir.iterdir():
    meta = p / "prooter_metadata.json"
    if not meta.exists():
        continue
    try:
        data = json.loads(meta.read_text())
    except Exception:
        continue
    repository = data.get("repository", "")
    if repository.endswith("/max-layer-test") or repository == "max-layer-test":
        target = p
        break
if not target:
    raise SystemExit(1)
index = json.loads((target / "index.json").read_text())
manifest_desc = index["manifests"][0]
digest = manifest_desc["digest"].split(":", 1)[1]
manifest = json.loads((target / "blobs" / "sha256" / digest).read_text())
layers = manifest.get("layers", [])
sizes = [layer.get("size", 0) for layer in layers]
if len(layers) < 2:
    raise SystemExit(1)
if max(sizes or [0]) > 64 * 1024 * 1024:
    raise SystemExit(1)
PY
then
    pass "max_layer_size_MB enforced"
else
    fail "max_layer_size_MB enforced"
fi
python3 - <<'PY'
import json
from pathlib import Path
config_path = Path.home() / ".prooter" / "config.json"
if not config_path.exists():
    raise SystemExit(0)
try:
    data = json.loads(config_path.read_text())
except Exception:
    data = {}
data.pop("max_layer_size_MB", None)
config_path.write_text(json.dumps(data, indent=2))
PY

# Step 10: Tag for Docker Hub
step 10 "Tag Image for Push"
if [ -n "$DOCKER_USERNAME" ] && [ -n "$DOCKER_PASSWORD" ]; then
    prooter tag test-app:latest "$DOCKER_USERNAME/prooter-e2e-test:latest" && pass "prooter tag" || fail "prooter tag"
else
    echo "  Skipping tag; DOCKER_USERNAME/DOCKER_PASSWORD not set"
    pass "prooter tag (skipped)"
fi

# Step 11: Push to Docker Hub
step 11 "Push to Docker Hub"
if [ -n "$DOCKER_USERNAME" ] && [ -n "$DOCKER_PASSWORD" ]; then
    prooter push "$DOCKER_USERNAME/prooter-e2e-test:latest" && pass "prooter push" || fail "prooter push"
else
    echo "  Skipping push; DOCKER_USERNAME/DOCKER_PASSWORD not set"
    pass "prooter push (skipped)"
fi

# Step 12: List all containers
step 12 "List All Containers"
prooter ps -a && pass "prooter ps -a" || fail "prooter ps -a"

# Step 13: Cleanup - remove images
step 13 "Cleanup"
prooter rmi alpine:latest && pass "prooter rmi alpine" || fail "prooter rmi alpine"

# Summary
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║              TEST RESULTS                    ║"
echo "╠══════════════════════════════════════════════╣"
echo "  ✅ Passed: $PASS / $TOTAL"
echo "  ❌ Failed: $FAIL / $TOTAL"
echo "╚══════════════════════════════════════════════╝"

if [ $FAIL -gt 0 ]; then
    exit 1
fi

echo ""
echo "🎉 All E2E tests passed!"
exit 0
