#!/usr/bin/env python3
import json, subprocess, pathlib

# locate the config blob for the pulled image
digest = subprocess.check_output(
    ["/home/prooter/venv/bin/python", "-m", "prooter", "inspect", "nanto2vison/biglayer:test"],
    text=True
)
manifest = json.loads(digest)
config_digest = manifest["config"]["digest"]
blob = pathlib.Path(f"/home/prooter/.prooter/oci/nanto2vison_biglayer:test/blobs/{config_digest}")
c = json.loads(blob.read_text())
print("Entrypoint:", c.get("config", {}).get("Entrypoint"))
print("Cmd:", c.get("config", {}).get("Cmd"))