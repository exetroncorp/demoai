#!/bin/bash
set -e

apt-get update
apt-get install -y --no-install-recommends \
  build-essential \
  clang \
  cmake \
  gdb \
  git \
  pkg-config \
  curl \
  ca-certificates
rm -rf /var/lib/apt/lists/*

if ! command -v code-server >/dev/null 2>&1; then
  curl -fsSL https://code-server.dev/install.sh | sh
fi
