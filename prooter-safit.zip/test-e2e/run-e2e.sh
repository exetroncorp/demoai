#!/bin/bash
set -e

PASS=0
FAIL=0
TOTAL=12

step() {
    echo ""
    echo "=============================================="
    echo "  STEP $1: $2"
    echo "=============================================="
}

pass() {
    echo "  ✅ PASSED: $1"
    PASS=$((PASS + 1))
}

fail() {
    echo "  ❌ FAILED: $1"
    FAIL=$((FAIL + 1))
}

echo "╔══════════════════════════════════════════════╗"
echo "║       PROOTER END-TO-END TEST SUITE          ║"
echo "╚══════════════════════════════════════════════╝"

# Step 1: Setup and version check
step 1 "Setup & Version Check"
prooter setup && pass "prooter setup" || fail "prooter setup"

# Step 2: Login to Docker Hub
step 2 "Login to Docker Hub"
prooter login -u nanto2vison -p dckr_pat_YmsSZ4IoMYXMwNQ7_d_iAFud1HY && pass "prooter login" || fail "prooter login"

# Step 3: Pull alpine image
step 3 "Pull alpine:latest"
prooter pull alpine:latest && pass "prooter pull alpine:latest" || fail "prooter pull alpine:latest"

# Step 4: List images (verify alpine is there)
step 4 "List Images"
prooter images
if prooter images | grep -q "alpine"; then
    pass "alpine image listed"
else
    fail "alpine image not listed"
fi

# Step 5: Run container with echo
step 5 "Run Container (echo)"
OUTPUT=$(prooter run --rm alpine:latest echo "Hello from Prooter E2E!")
echo "$OUTPUT"
if echo "$OUTPUT" | grep -q "Hello from Prooter"; then
    pass "prooter run echo"
else
    fail "prooter run echo"
fi

# Step 6: Run container with id (verify faked root)
step 6 "Run Container (id - verify root emulation)"
OUTPUT=$(prooter run --rm alpine:latest id)
echo "$OUTPUT"
if echo "$OUTPUT" | grep -q "uid=0"; then
    pass "prooter run id (uid=0)"
else
    fail "prooter run id (uid=0)"
fi

# Step 7: Build a test image
step 7 "Build Test Image"
prooter build -t test-app:latest -f Dockerfile /home/prooter/prooter/test-e2e && pass "prooter build" || fail "prooter build"

# Step 8: Verify built image in images list
step 8 "Verify Built Image"
prooter images
echo "DEBUG OCI DIR:"
ls -R /home/prooter/.prooter/oci || echo "No OCI dir found"
prooter images | grep "test-app"
if [ $? -eq 0 ]; then
    pass "test-app image listed"
else
    fail "test-app image not listed"
fi

# Step 9: Tag for Docker Hub
step 9 "Tag Image for Push"
prooter tag test-app:latest nanto2vison/prooter-e2e-test:latest && pass "prooter tag" || fail "prooter tag"

# Step 10: Push to Docker Hub
step 10 "Push to Docker Hub"
prooter push nanto2vison/prooter-e2e-test:latest && pass "prooter push" || fail "prooter push"

# Step 11: List all containers
step 11 "List All Containers"
prooter ps -a && pass "prooter ps -a" || fail "prooter ps -a"

# Step 12: Cleanup - remove images
step 12 "Cleanup"
prooter rmi alpine:latest && pass "prooter rmi alpine" || fail "prooter rmi alpine"

# Summary
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║              TEST RESULTS                    ║"
echo "╠══════════════════════════════════════════════╣"
echo "  ✅ Passed: $PASS / $TOTAL"
echo "  ❌ Failed: $FAIL / $TOTAL"
echo "╚══════════════════════════════════════════════╝"

if [ $FAIL -gt 0 ]; then
    exit 1
fi

echo ""
echo "🎉 All E2E tests passed!"
exit 0
