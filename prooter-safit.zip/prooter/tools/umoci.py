"""Umoci CLI wrapper for OCI image manipulation.

Umoci is a tool for manipulating OCI container images.
It can unpack images to runtime bundles and repack them.

For Debian 12: apt-get install umoci
"""

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Any

from prooter.config import get_config


class UmociError(Exception):
    """Exception raised when umoci command fails."""
    
    def __init__(self, message: str, returncode: int = 1, stderr: str = ""):
        super().__init__(message)
        self.returncode = returncode
        self.stderr = stderr


class Umoci:
    """Wrapper for umoci CLI operations.
    
    Provides Python interface for:
    - Unpacking OCI images to runtime bundles
    - Repacking bundles back to OCI images
    - Modifying image configuration
    """
    
    def __init__(self, config=None):
        """Initialize Umoci wrapper.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or get_config()
        self._binary_path: Optional[Path] = None
    
    @property
    def binary(self) -> Path:
        """Get path to umoci binary."""
        if self._binary_path:
            return self._binary_path
        
        # Check configured location
        configured = self.config.bin_dir / "umoci"
        if configured.exists():
            self._binary_path = configured
            return self._binary_path
        
        # Check system PATH
        system_umoci = shutil.which("umoci")
        if system_umoci:
            self._binary_path = Path(system_umoci)
            return self._binary_path
        
        # Default to configured location (may not exist)
        return configured
    
    def is_available(self) -> bool:
        """Check if umoci is available."""
        binary = self.binary
        if not binary.exists():
            return False
        
        try:
            result = subprocess.run(
                [str(binary), "--version"],
                capture_output=True,
                timeout=10,
            )
            return result.returncode == 0
        except (subprocess.SubprocessError, OSError):
            return False
    
    def _run(
        self,
        args: List[str],
        capture_output: bool = True,
        timeout: int = 300,
    ) -> subprocess.CompletedProcess:
        """Run umoci command.
        
        Args:
            args: Command arguments (without 'umoci' prefix)
            capture_output: Whether to capture stdout/stderr
            timeout: Command timeout in seconds
            
        Returns:
            CompletedProcess result
            
        Raises:
            UmociError: If command fails
        """
        if not self.is_available():
            raise UmociError(
                "umoci not found. Install with: apt-get install umoci"
            )
        
        cmd = [str(self.binary)] + args
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=capture_output,
                timeout=timeout,
                text=True,
            )
            
            if result.returncode != 0:
                stderr = result.stderr if capture_output else ""
                raise UmociError(
                    f"umoci command failed: {' '.join(args)}",
                    returncode=result.returncode,
                    stderr=stderr,
                )
            
            return result
            
        except subprocess.TimeoutExpired:
            raise UmociError(f"umoci command timed out after {timeout}s")
    
    def init(self, layout_path: Path) -> None:
        """Initialize a new OCI image layout.
        
        Args:
            layout_path: Path to create layout at
            
        Raises:
            UmociError: If initialization fails
        """
        args = ["init", "--layout", str(layout_path)]
        
        # Ensure parent directory exists, but DO NOT create layout_path itself
        # umoci init requires the path to not exist or be empty (safest to let it create)
        if not layout_path.parent.exists():
            layout_path.parent.mkdir(parents=True)
            
        self._run(args)
        
    def new(self, image_path: Path, tag: str = "latest") -> None:
        """Create a new image in the layout.
        
        Args:
            image_path: Path to OCI image directory
            tag: Tag name to create
            
        Raises:
            UmociError: If creation fails
        """
        image_ref = f"{image_path}:{tag}"
        args = ["new", "--image", image_ref]
        self._run(args)

    def unpack(
        self,
        image_path: Path,
        bundle_path: Path,
        tag: str = "latest",
        rootless: bool = True,
    ) -> Path:
        """Unpack an OCI image to a runtime bundle.
        
        Creates an OCI runtime bundle with:
        - rootfs/ directory containing the filesystem
        - config.json with runtime configuration
        
        Args:
            image_path: Path to OCI image directory
            bundle_path: Path where bundle will be created
            tag: Image tag/reference to unpack
            rootless: Use rootless mode (recommended for prooter)
            
        Returns:
            Path to the bundle directory
            
        Raises:
            UmociError: If unpack fails
        """
        args = ["unpack"]
        
        if rootless:
            args.append("--rootless")
        
        # Image reference in oci:path:tag format
        image_ref = f"{image_path}:{tag}"
        args.append("--image")
        args.append(image_ref)
        
        # Bundle destination
        args.append(str(bundle_path))
        
        # Ensure parent directory exists
        bundle_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Remove existing bundle if present
        if bundle_path.exists():
            shutil.rmtree(bundle_path)
        
        print(f"Unpacking image to bundle: {bundle_path}")
        self._run(args, capture_output=False)
        
        return bundle_path
    
    def repack(
        self,
        bundle_path: Path,
        image_path: Path,
        tag: str = "latest",
    ) -> Path:
        """Repack a runtime bundle back to an OCI image.
        
        Args:
            bundle_path: Path to the bundle directory
            image_path: Path to OCI image directory
            tag: Tag for the new image layer
            
        Returns:
            Path to the OCI image directory
            
        Raises:
            UmociError: If repack fails
        """
        args = ["repack"]
        
        # Image reference
        image_ref = f"{image_path}:{tag}"
        args.append("--image")
        args.append(image_ref)
        
        # Bundle source
        args.append(str(bundle_path))
        
        print(f"Repacking bundle to image: {image_path}")
        self._run(args, capture_output=False)
        
        return image_path
    
    def configure(
        self,
        image_path: Path,
        tag: str = "latest",
        config_options: Optional[Dict[str, Any]] = None,
        author: Optional[str] = None,
        cmd: Optional[List[str]] = None,
        entrypoint: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        workdir: Optional[str] = None,
        user: Optional[str] = None,
        label: Optional[Dict[str, str]] = None,
    ) -> None:
        """Modify image configuration.
        
        Args:
            image_path: Path to OCI image directory
            tag: Image tag to modify
            config_options: Raw config options dict
            author: Image author
            cmd: Default command
            entrypoint: Entrypoint command
            env: Environment variables
            workdir: Working directory
            user: Default user
            label: Image labels
            
        Raises:
            UmociError: If config modification fails
        """
        args = ["config"]
        
        # Image reference
        image_ref = f"{image_path}:{tag}"
        args.append("--image")
        args.append(image_ref)
        
        if author:
            args.extend(["--author", author])
        
        if cmd:
            args.extend(["--config.cmd", json.dumps(cmd)])
        
        if entrypoint:
            args.extend(["--config.entrypoint", json.dumps(entrypoint)])
        
        if env:
            for key, value in env.items():
                args.extend(["--config.env", f"{key}={value}"])
        
        if workdir:
            args.extend(["--config.workingdir", workdir])
        
        if user:
            args.extend(["--config.user", user])
        
        if label:
            for key, value in label.items():
                args.extend(["--config.label", f"{key}={value}"])
        
        self._run(args)
    
    def raw_op(
        self,
        image_path: Path,
        tag: str = "latest",
        new_tag: Optional[str] = None,
    ) -> None:
        """Create a new tag without modifications (raw operation).
        
        Useful for creating a mutable copy of an image tag.
        
        Args:
            image_path: Path to OCI image directory
            tag: Source tag
            new_tag: New tag name (default: same as tag)
            
        Raises:
            UmociError: If operation fails
        """
        args = ["raw", "add-layer"]
        
        image_ref = f"{image_path}:{tag}"
        args.append("--image")
        args.append(image_ref)
        
        self._run(args)
    
    def list_tags(self, image_path: Path) -> List[str]:
        """List tags in an OCI image.
        
        Args:
            image_path: Path to OCI image directory
            
        Returns:
            List of tag names
            
        Raises:
            UmociError: If listing fails
        """
        # Read index.json directly - umoci doesn't have a list command
        index_path = image_path / "index.json"
        
        if not index_path.exists():
            return []
        
        try:
            with open(index_path) as f:
                index = json.load(f)
            
            tags = []
            for manifest in index.get("manifests", []):
                annotations = manifest.get("annotations", {})
                ref_name = annotations.get("org.opencontainers.image.ref.name")
                if ref_name:
                    tags.append(ref_name)
            
            return tags
            
        except (json.JSONDecodeError, KeyError):
            return []
    
    def get_config(self, image_path: Path, tag: str = "latest") -> Dict[str, Any]:
        """Get the runtime config from an OCI image.
        
        Args:
            image_path: Path to OCI image directory
            tag: Image tag
            
        Returns:
            Config dictionary
            
        Raises:
            UmociError: If config cannot be read
        """
        # This requires reading the blob directly from OCI layout
        index_path = image_path / "index.json"
        
        if not index_path.exists():
            raise UmociError(f"Not a valid OCI image: {image_path}")
        
        try:
            with open(index_path) as f:
                index = json.load(f)
            
            # Find manifest for tag
            manifest_digest = None
            for manifest in index.get("manifests", []):
                annotations = manifest.get("annotations", {})
                ref_name = annotations.get("org.opencontainers.image.ref.name")
                if ref_name == tag:
                    manifest_digest = manifest.get("digest")
                    break
            
            if not manifest_digest:
                raise UmociError(f"Tag not found: {tag}")
            
            # Read manifest blob
            algo, digest = manifest_digest.split(":", 1)
            manifest_path = image_path / "blobs" / algo / digest
            
            with open(manifest_path) as f:
                manifest = json.load(f)
            
            # Read config blob
            config_digest = manifest.get("config", {}).get("digest")
            if not config_digest:
                raise UmociError("No config in manifest")
            
            algo, digest = config_digest.split(":", 1)
            config_path = image_path / "blobs" / algo / digest
            
            with open(config_path) as f:
                return json.load(f)
                
        except (json.JSONDecodeError, KeyError, FileNotFoundError) as e:
            raise UmociError(f"Failed to read config: {e}")
