"""Tests for the image module."""

import json
import os
import tempfile
import tarfile
from pathlib import Path

import pytest

from prooter.image.layer import extract_layer, apply_layers


class TestExtractLayer:
    """Tests for layer extraction."""
    
    def test_extract_simple_layer(self, tmp_path):
        """Test extracting a simple tar layer."""
        # Create a test tar file
        tar_path = tmp_path / "layer.tar"
        target_dir = tmp_path / "extracted"
        
        with tarfile.open(tar_path, "w") as tar:
            # Add a file
            data = b"Hello, World!"
            import io
            info = tarfile.TarInfo(name="test.txt")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
            
            # Add a directory
            dir_info = tarfile.TarInfo(name="subdir")
            dir_info.type = tarfile.DIRTYPE
            tar.addfile(dir_info)
            
            # Add a file in the directory
            info2 = tarfile.TarInfo(name="subdir/nested.txt")
            info2.size = len(data)
            tar.addfile(info2, io.BytesIO(data))
        
        # Extract
        extract_layer(tar_path, target_dir)
        
        # Verify
        assert (target_dir / "test.txt").exists()
        assert (target_dir / "test.txt").read_text() == "Hello, World!"
        assert (target_dir / "subdir").is_dir()
        assert (target_dir / "subdir" / "nested.txt").exists()
    
    def test_extract_gzipped_layer(self, tmp_path):
        """Test extracting a gzipped tar layer."""
        tar_path = tmp_path / "layer.tar.gz"
        target_dir = tmp_path / "extracted"
        
        with tarfile.open(tar_path, "w:gz") as tar:
            data = b"Compressed content"
            import io
            info = tarfile.TarInfo(name="compressed.txt")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        
        extract_layer(tar_path, target_dir)
        
        assert (target_dir / "compressed.txt").exists()
        assert (target_dir / "compressed.txt").read_bytes() == b"Compressed content"
    
    def test_whiteout_handling(self, tmp_path):
        """Test OCI whiteout file handling."""
        # Create initial content
        target_dir = tmp_path / "extracted"
        target_dir.mkdir()
        (target_dir / "keep.txt").write_text("keep")
        (target_dir / "delete.txt").write_text("delete")
        
        # Create a layer with whiteout
        tar_path = tmp_path / "layer.tar"
        
        with tarfile.open(tar_path, "w") as tar:
            # Add whiteout for delete.txt
            import io
            info = tarfile.TarInfo(name=".wh.delete.txt")
            info.size = 0
            tar.addfile(info, io.BytesIO(b""))
            
            # Add a new file
            data = b"new content"
            info2 = tarfile.TarInfo(name="new.txt")
            info2.size = len(data)
            tar.addfile(info2, io.BytesIO(data))
        
        extract_layer(tar_path, target_dir)
        
        # Verify whiteout was processed
        assert (target_dir / "keep.txt").exists()
        assert not (target_dir / "delete.txt").exists()
        assert (target_dir / "new.txt").exists()
        # Whiteout file itself should not exist
        assert not (target_dir / ".wh.delete.txt").exists()


class TestApplyLayers:
    """Tests for applying multiple layers."""
    
    def test_apply_multiple_layers(self, tmp_path):
        """Test applying layers in order."""
        target_dir = tmp_path / "rootfs"
        
        # Create layer 1
        layer1_path = tmp_path / "layer1.tar"
        with tarfile.open(layer1_path, "w") as tar:
            import io
            data = b"layer 1 content"
            info = tarfile.TarInfo(name="file1.txt")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        
        # Create layer 2
        layer2_path = tmp_path / "layer2.tar"
        with tarfile.open(layer2_path, "w") as tar:
            import io
            data = b"layer 2 content"
            info = tarfile.TarInfo(name="file2.txt")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        
        # Apply layers
        apply_layers([layer1_path, layer2_path], target_dir)
        
        # Verify both files exist
        assert (target_dir / "file1.txt").exists()
        assert (target_dir / "file2.txt").exists()
        assert (target_dir / "file1.txt").read_bytes() == b"layer 1 content"
        assert (target_dir / "file2.txt").read_bytes() == b"layer 2 content"
    
    def test_layer_overwrite(self, tmp_path):
        """Test that later layers overwrite earlier ones."""
        target_dir = tmp_path / "rootfs"
        
        # Create layer 1
        layer1_path = tmp_path / "layer1.tar"
        with tarfile.open(layer1_path, "w") as tar:
            import io
            data = b"original"
            info = tarfile.TarInfo(name="file.txt")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        
        # Create layer 2 with same file
        layer2_path = tmp_path / "layer2.tar"
        with tarfile.open(layer2_path, "w") as tar:
            import io
            data = b"modified"
            info = tarfile.TarInfo(name="file.txt")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        
        apply_layers([layer1_path, layer2_path], target_dir)
        
        # Verify later layer won
        assert (target_dir / "file.txt").read_bytes() == b"modified"
