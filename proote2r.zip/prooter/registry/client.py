"""Docker Registry API v2 client."""

import hashlib
import json
import os
from pathlib import Path
from typing import Optional, Callable, Dict, Any

import requests

from prooter.config import get_config
from prooter.registry.auth import RegistryAuth
from prooter.registry.manifest import (
    parse_manifest,
    parse_image_reference,
    ImageManifest,
    ManifestList,
)


class RegistryClient:
    """Client for Docker Registry API v2."""
    
    # Accept headers for manifest requests
    MANIFEST_ACCEPT = ",".join([
        "application/vnd.docker.distribution.manifest.v2+json",
        "application/vnd.docker.distribution.manifest.list.v2+json",
        "application/vnd.oci.image.manifest.v1+json",
        "application/vnd.oci.image.index.v1+json",
    ])
    
    def __init__(
        self,
        auth: Optional[RegistryAuth] = None,
        verify_ssl: bool = True,
    ):
        """Initialize registry client.
        
        Args:
            auth: Authentication handler
            verify_ssl: Whether to verify SSL certificates
        """
        self.auth = auth or RegistryAuth(verify_ssl=verify_ssl)
        self.verify_ssl = verify_ssl
        self.config = get_config()
        self._session = requests.Session()
    
    def _get_registry_url(self, registry: str) -> str:
        """Get the base URL for a registry.
        
        Args:
            registry: Registry hostname
            
        Returns:
            Base URL for API requests
        """
        if registry in ("registry-1.docker.io", "docker.io"):
            mirror = self.config.registry_mirror
            if mirror:
                # Remove trailing slash if present
                if mirror.endswith("/"):
                    mirror = mirror[:-1]
                return mirror
            return "https://registry-1.docker.io"
        elif registry.startswith("localhost"):
            return f"http://{registry}"
        else:
            return f"https://{registry}"
    
    def _request(
        self,
        method: str,
        registry: str,
        repository: str,
        path: str,
        headers: Optional[Dict[str, str]] = None,
        stream: bool = False,
        **kwargs,
    ) -> requests.Response:
        """Make an authenticated request to the registry.
        
        Args:
            method: HTTP method
            registry: Registry hostname
            repository: Repository name
            path: API path
            headers: Additional headers
            stream: Whether to stream the response
            **kwargs: Additional request arguments
            
        Returns:
            Response object
            
        Raises:
            requests.HTTPError: If request fails
        """
        base_url = self._get_registry_url(registry)
        url = f"{base_url}/v2/{repository}/{path}"
        
        request_headers = self.auth.get_auth_headers(registry, repository)
        if headers:
            request_headers.update(headers)
        
        response = self._session.request(
            method,
            url,
            headers=request_headers,
            verify=self.verify_ssl,
            stream=stream,
            timeout=30,
            **kwargs,
        )
        
        response.raise_for_status()
        return response
    
    def get_manifest(
        self,
        image: str,
        platform_os: str = "linux",
        platform_arch: str = "amd64",
    ) -> ImageManifest:
        """Get the manifest for an image.
        
        Args:
            image: Image reference (e.g., 'alpine:3.18')
            platform_os: Target OS (for multi-arch images)
            platform_arch: Target architecture (for multi-arch images)
            
        Returns:
            Parsed image manifest
            
        Raises:
            ValueError: If manifest cannot be resolved
        """
        registry, repository, tag = parse_image_reference(image)
        
        response = self._request(
            "GET",
            registry,
            repository,
            f"manifests/{tag}",
            headers={"Accept": self.MANIFEST_ACCEPT},
        )
        
        manifest_data = response.json()
        manifest = parse_manifest(manifest_data)
        
        # If it's a manifest list, get the specific platform manifest
        if isinstance(manifest, ManifestList):
            platform_manifest = manifest.get_manifest_for_platform(
                os=platform_os,
                architecture=platform_arch,
            )
            
            if not platform_manifest:
                raise ValueError(
                    f"No manifest found for platform {platform_os}/{platform_arch}"
                )
            
            # Fetch the actual manifest
            digest = platform_manifest["digest"]
            response = self._request(
                "GET",
                registry,
                repository,
                f"manifests/{digest}",
                headers={"Accept": self.MANIFEST_ACCEPT},
            )
            
            manifest_data = response.json()
            manifest = parse_manifest(manifest_data)
        
        if not isinstance(manifest, ImageManifest):
            raise ValueError("Unexpected manifest type")
        
        return manifest
    
    def get_config_blob(
        self,
        image: str,
        manifest: ImageManifest,
    ) -> Dict[str, Any]:
        """Get and parse the config blob for an image.
        
        Args:
            image: Image reference
            manifest: Image manifest
            
        Returns:
            Parsed config blob data
        """
        registry, repository, _ = parse_image_reference(image)
        digest = manifest.config.digest
        
        response = self._request(
            "GET",
            registry,
            repository,
            f"blobs/{digest}",
        )
        
        return response.json()
    
    def download_layer(
        self,
        image: str,
        digest: str,
        output_path: Path,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> Path:
        """Download a layer blob to a file.
        
        Args:
            image: Image reference
            digest: Layer digest
            output_path: Path to save the layer
            progress_callback: Optional callback(downloaded, total) for progress
            
        Returns:
            Path to the downloaded file
        """
        registry, repository, _ = parse_image_reference(image)
        
        response = self._request(
            "GET",
            registry,
            repository,
            f"blobs/{digest}",
            stream=True,
        )
        
        total_size = int(response.headers.get("content-length", 0))
        downloaded = 0
        
        # Ensure parent directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Use temporary file for atomic write
        tmp_path = output_path.with_suffix(".tmp")
        
        hasher = hashlib.sha256()
        
        try:
            with open(tmp_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        hasher.update(chunk)
                        downloaded += len(chunk)
                        
                        if progress_callback:
                            progress_callback(downloaded, total_size)
                        
                        # Stop if we've downloaded the expected amount
                        # This prevents hanging if the server keeps the connection open
                        if total_size > 0 and downloaded >= total_size:
                            print(f"DEBUG: Download complete. {downloaded}/{total_size}. Breaking.", flush=True)
                            break
            
            # Verify digest
            computed_digest = f"sha256:{hasher.hexdigest()}"
            if computed_digest != digest:
                raise ValueError(
                    f"Digest mismatch: expected {digest}, got {computed_digest}"
                )
            
            # Rename to final path
            tmp_path.rename(output_path)
            return output_path
            
        except Exception:
            # Clean up temporary file on error
            if tmp_path.exists():
                tmp_path.unlink()
            raise
    
    def pull_image(
        self,
        image: str,
        progress_callback: Optional[Callable[[str, int, int], None]] = None,
    ) -> tuple[ImageManifest, Path]:
        """Pull an image and all its layers.
        
        Args:
            image: Image reference
            progress_callback: Optional callback(layer_digest, downloaded, total)
            
        Returns:
            Tuple of (manifest, image_dir)
        """
        print(f"Pulling {image}...")
        
        # Get manifest
        manifest = self.get_manifest(image)
        print(f"  Manifest: {len(manifest.layers)} layers, {manifest.total_size / 1024 / 1024:.1f} MB total")
        
        # Get config blob
        config_data = self.get_config_blob(image, manifest)
        manifest.config.update_from_config_blob(config_data)
        
        # Create image directory
        registry, repository, tag = parse_image_reference(image)
        image_id = manifest.config.digest.replace("sha256:", "")[:12]
        image_dir = self.config.images_dir / image_id
        image_dir.mkdir(parents=True, exist_ok=True)
        
        # Save manifest
        manifest_path = image_dir / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest.raw_data, f, indent=2)
        
        # Save config
        config_path = image_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(config_data, f, indent=2)
        
        # Save image metadata
        metadata = {
            "image": image,
            "registry": registry,
            "repository": repository,
            "tag": tag,
            "image_id": image_id,
            "layers": [layer.digest for layer in manifest.layers],
        }
        metadata_path = image_dir / "metadata.json"
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)
        
        # Download layers
        for i, layer in enumerate(manifest.layers, 1):
            layer_path = self.config.layers_dir / layer.digest.replace(":", "_")
            
            if layer_path.exists():
                print(f"  Layer {i}/{len(manifest.layers)}: {layer.digest[:19]}... (cached)")
                continue
            
            print(f"  Layer {i}/{len(manifest.layers)}: {layer.digest[:19]}...", end="", flush=True)
            
            def layer_progress(downloaded: int, total: int) -> None:
                if total > 0:
                    pct = downloaded * 100 // total
                    print(f"\r  Layer {i}/{len(manifest.layers)}: {layer.digest[:19]}... {pct}%", end="", flush=True)
                if progress_callback:
                    progress_callback(layer.digest, downloaded, total)
            
            self.download_layer(image, layer.digest, layer_path, layer_progress)
            print(f"\r  Layer {i}/{len(manifest.layers)}: {layer.digest[:19]}... done")
        
        print(f"Successfully pulled {image}")
        return manifest, image_dir
