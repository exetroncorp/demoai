#!/bin/bash
set -e
cd /home/prooter/demo

echo "=== verifying nginx ==="
prooter build -f Dockerfile.nginx -t my-nginx .

echo "Starting Nginx..."
# Run in background
prooter run my-nginx &
PID=$!

# Wait for port 12222
echo "Waiting for port 12222..."
timeout 10s bash -c 'until curl -s http://localhost:12222 > /dev/null; do sleep 1; done'

echo "Curling..."
OUTPUT=$(curl -s http://localhost:12222)
echo "Response: $OUTPUT"

if [[ "$OUTPUT" != *"Hello World"* ]]; then
  echo "Verification Failed: Expected 'Hello World', got '$OUTPUT'"
  kill -9 $PID
  exit 1
fi
echo "Verification Successful!"

echo "Killing prooter..."
kill -9 $PID
