---
name: banking-microservice-backend
description: >
  Generates a complete Spring Boot 3.x microservice using Clean Architecture
  (hexagonal), TDD, banking-grade security, and full regulatory compliance.
  Load when scaffolding a new service or adding a feature module.
allowed-tools: Read Edit Command
license: Internal — BNP Paribas Group
---

# Banking Microservice Backend Skill
# Spring Boot 3.x + Java 21 + Clean Architecture + TDD
# Inherits: banking-bob-rules (all 7 rule files)

---

## 1. Project Bootstrap

### Maven archetype for new service
```bash
mvn archetype:generate \
  -DgroupId=com.bank.${context} \
  -DartifactId=${context}-service \
  -DarchetypeGroupId=org.springframework.boot \
  -DarchetypeArtifactId=spring-boot-starter-parent \
  -Djava.version=21

# Then extract banking rules:
mvn initialize  # triggers skillsjars:extract → .bob/rules/
```

### Required pom.xml dependencies (BANKING STANDARD)
```xml
<!-- Core -->
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.3.x</version>
</parent>

<dependencies>
    <!-- Spring Boot -->
    <dependency><groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-security</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-actuator</artifactId></dependency>
    <dependency><groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-cache</artifactId></dependency>

    <!-- Database -->
    <dependency><groupId>org.postgresql</groupId>
        <artifactId>postgresql</artifactId><scope>runtime</scope></dependency>
    <dependency><groupId>org.flywaydb</groupId>
        <artifactId>flyway-core</artifactId></dependency>

    <!-- Mapping -->
    <dependency><groupId>org.mapstruct</groupId>
        <artifactId>mapstruct</artifactId><version>1.5.5.Final</version></dependency>

    <!-- Lombok -->
    <dependency><groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId><optional>true</optional></dependency>

    <!-- Observability -->
    <dependency><groupId>io.micrometer</groupId>
        <artifactId>micrometer-tracing-bridge-otel</artifactId></dependency>
    <dependency><groupId>io.opentelemetry</groupId>
        <artifactId>opentelemetry-exporter-otlp</artifactId></dependency>

    <!-- JWT -->
    <dependency><groupId>org.springframework.security</groupId>
        <artifactId>spring-security-oauth2-resource-server</artifactId></dependency>
    <dependency><groupId>org.springframework.security</groupId>
        <artifactId>spring-security-oauth2-jose</artifactId></dependency>

    <!-- Documentation -->
    <dependency><groupId>org.springdoc</groupId>
        <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
        <version>2.5.0</version></dependency>

    <!-- Test -->
    <dependency><groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId><scope>test</scope></dependency>
    <dependency><groupId>org.springframework.security</groupId>
        <artifactId>spring-security-test</artifactId><scope>test</scope></dependency>
    <dependency><groupId>org.testcontainers</groupId>
        <artifactId>junit-jupiter</artifactId><scope>test</scope></dependency>
    <dependency><groupId>org.testcontainers</groupId>
        <artifactId>postgresql</artifactId><scope>test</scope></dependency>
    <dependency><groupId>org.testcontainers</groupId>
        <artifactId>kafka</artifactId><scope>test</scope></dependency>
</dependencies>
```

---

## 2. Domain Layer (GENERATE FIRST — pure Java, zero Spring)

### Value Object Template
```java
// Always a record with compact constructor validation
// File: domain/model/{ContextName}Id.java
package com.bank.${context}.domain.model;

import java.util.Objects;
import java.util.UUID;

public record ${Context}Id(UUID value) {
    public ${Context}Id {
        Objects.requireNonNull(value, "${Context}Id must not be null");
    }
    public static ${Context}Id generate() {
        return new ${Context}Id(UUID.randomUUID());
    }
    public static ${Context}Id of(String value) {
        return new ${Context}Id(UUID.fromString(value));
    }
    @Override public String toString() { return value.toString(); }
}
```

### Money Value Object (MANDATORY for all financial services)
```java
// File: domain/model/Money.java
package com.bank.${context}.domain.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import java.util.Objects;

public record Money(BigDecimal amount, Currency currency) {

    // BANKING RULE: Always 4 decimal places for storage precision
    public Money {
        Objects.requireNonNull(amount, "amount must not be null");
        Objects.requireNonNull(currency, "currency must not be null");
        // Normalize scale — prevents equals/compareTo inconsistency
        amount = amount.setScale(4, RoundingMode.HALF_UP);
        if (amount.compareTo(BigDecimal.ZERO) < 0)
            throw new IllegalArgumentException("Money amount cannot be negative: " + amount);
    }

    public static Money of(String amount, String currencyCode) {
        return new Money(new BigDecimal(amount), Currency.getInstance(currencyCode));
    }

    public static Money zero(String currencyCode) {
        return new Money(BigDecimal.ZERO, Currency.getInstance(currencyCode));
    }

    public Money add(Money other) {
        requireSameCurrency(other);
        return new Money(this.amount.add(other.amount), this.currency);
    }

    public Money subtract(Money other) {
        requireSameCurrency(other);
        BigDecimal result = this.amount.subtract(other.amount);
        if (result.compareTo(BigDecimal.ZERO) < 0)
            throw new InsufficientFundsException(this, other);
        return new Money(result, this.currency);
    }

    public Money multiply(BigDecimal factor) {
        return new Money(this.amount.multiply(factor).setScale(4, RoundingMode.HALF_UP), this.currency);
    }

    public boolean isGreaterThan(Money other) {
        requireSameCurrency(other);
        return this.amount.compareTo(other.amount) > 0;
    }

    private void requireSameCurrency(Money other) {
        if (!this.currency.equals(other.currency))
            throw new CurrencyMismatchException(this.currency, other.currency);
    }

    // Display with 2 decimal places — 4-decimal precision is for internal use
    public String displayAmount() {
        return amount.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }
}
```

### Domain Entity Template (Rich model — NOT anemic)
```java
// File: domain/model/${Context}.java
package com.bank.${context}.domain.model;

import com.bank.${context}.domain.event.${Context}CreatedEvent;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ${Context} {

    private final ${Context}Id id;
    private ${Context}Status status;
    private final Money amount;
    private final Instant createdAt;
    private final List<DomainEvent> domainEvents = new ArrayList<>();

    // Factory method — business language, not "new"
    public static ${Context} initiate(Money amount, /* other params */) {
        var entity = new ${Context}(${Context}Id.generate(), amount, Instant.now());
        entity.domainEvents.add(new ${Context}CreatedEvent(entity.id, Instant.now()));
        return entity;
    }

    private ${Context}(${Context}Id id, Money amount, Instant createdAt) {
        this.id = id;
        this.amount = amount;
        this.status = ${Context}Status.PENDING;
        this.createdAt = createdAt;
    }

    // Business methods enforce invariants
    public void approve() {
        if (this.status != ${Context}Status.PENDING)
            throw new InvalidStatusTransitionException(this.id, this.status, ${Context}Status.APPROVED);
        this.status = ${Context}Status.APPROVED;
        this.domainEvents.add(new ${Context}ApprovedEvent(this.id, Instant.now()));
    }

    // Getters — no setters (immutable after creation, changed via business methods)
    public ${Context}Id id() { return id; }
    public ${Context}Status status() { return status; }
    public Money amount() { return amount; }

    // Domain events — cleared after publishing
    public List<DomainEvent> drainEvents() {
        var events = List.copyOf(domainEvents);
        domainEvents.clear();
        return events;
    }
}
```

### Output Port (Repository Interface — in domain layer)
```java
// File: domain/port/out/${Context}Repository.java
package com.bank.${context}.domain.port.out;

import com.bank.${context}.domain.model.${Context};
import com.bank.${context}.domain.model.${Context}Id;
import java.util.Optional;
import java.util.List;

public interface ${Context}Repository {
    ${Context} save(${Context} entity);
    Optional<${Context}> findById(${Context}Id id);
    List<${Context}> findByCustomerId(CustomerId customerId, int page, int size);
    boolean existsById(${Context}Id id);
}
```

### Input Port (Use Case Interface — in domain layer)
```java
// File: domain/port/in/Initiate${Context}UseCase.java
package com.bank.${context}.domain.port.in;

public interface Initiate${Context}UseCase {
    ${Context}Result initiate(Initiate${Context}Command command);

    record Initiate${Context}Command(
        CustomerId customerId,
        Money amount,
        String description,
        String idempotencyKey
    ) {}

    record ${Context}Result(
        ${Context}Id id,
        ${Context}Status status,
        Money amount
    ) {}
}
```

---

## 3. TDD — Test BEFORE Implementation

### Test Template (write FIRST — red phase)
```java
// File: src/test/java/.../application/usecase/Initiate${Context}UseCaseTest.java
package com.bank.${context}.application.usecase;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.BDDMockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Initiate${Context}UseCase")
class Initiate${Context}UseCaseTest {

    @Mock private ${Context}Repository repository;
    @Mock private IdempotencyService idempotencyService;
    @Mock private DomainEventPublisher eventPublisher;

    @InjectMocks private Initiate${Context}UseCaseImpl useCase;

    private static final CustomerId CUSTOMER_ID = CustomerId.of("cust-001");
    private static final Money AMOUNT = Money.of("500.00", "EUR");

    @Nested
    @DisplayName("Happy path")
    class HappyPath {

        @Test
        @DisplayName("should create ${context} with PENDING status when all inputs are valid")
        void should_create${Context}WithPendingStatus_when_allInputsAreValid() {
            // ARRANGE
            var command = new Initiate${Context}Command(CUSTOMER_ID, AMOUNT, "Test", "idem-key-001");
            given(idempotencyService.isNew(command.idempotencyKey())).willReturn(true);
            given(repository.save(any())).willAnswer(inv -> inv.getArgument(0));

            // ACT
            var result = useCase.initiate(command);

            // ASSERT
            assertThat(result.status()).isEqualTo(${Context}Status.PENDING);
            assertThat(result.amount()).isEqualByComparingTo(AMOUNT);  // BigDecimal safe comparison
            assertThat(result.id()).isNotNull();

            then(repository).should().save(any(${Context}.class));
            then(eventPublisher).should().publish(any(${Context}CreatedEvent.class));
        }

        @Test
        @DisplayName("should return existing result when idempotency key already used")
        void should_returnExistingResult_when_idempotencyKeyAlreadyUsed() {
            var command = new Initiate${Context}Command(CUSTOMER_ID, AMOUNT, "Test", "idem-key-001");
            var existing = ${Context}Result.of(${Context}Id.generate(), ${Context}Status.PENDING, AMOUNT);
            given(idempotencyService.isNew(command.idempotencyKey())).willReturn(false);
            given(idempotencyService.getResult(command.idempotencyKey())).willReturn(existing);

            var result = useCase.initiate(command);

            assertThat(result).isEqualTo(existing);
            then(repository).shouldHaveNoInteractions();
        }
    }

    @Nested
    @DisplayName("Validation failures")
    class ValidationFailures {

        @Test
        @DisplayName("should throw ValidationException when amount is zero")
        void should_throwValidationException_when_amountIsZero() {
            var command = new Initiate${Context}Command(CUSTOMER_ID, Money.zero("EUR"), "Test", "key");

            assertThatThrownBy(() -> useCase.initiate(command))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("amount");

            then(repository).shouldHaveNoInteractions();
        }

        @ParameterizedTest
        @NullSource
        @DisplayName("should throw ValidationException when customerId is null")
        void should_throwValidationException_when_customerIdIsNull(CustomerId customerId) {
            var command = new Initiate${Context}Command(customerId, AMOUNT, "Test", "key");

            assertThatThrownBy(() -> useCase.initiate(command))
                .isInstanceOf(ValidationException.class);
        }
    }
}
```

### Use Case Implementation (write AFTER test is red)
```java
// File: application/usecase/Initiate${Context}UseCaseImpl.java
@Service
@RequiredArgsConstructor
@Slf4j
public class Initiate${Context}UseCaseImpl implements Initiate${Context}UseCase {

    private final ${Context}Repository repository;
    private final IdempotencyService idempotencyService;
    private final DomainEventPublisher eventPublisher;

    @Override
    @Transactional
    public ${Context}Result initiate(Initiate${Context}Command command) {
        // Input validation
        Objects.requireNonNull(command.customerId(), "customerId must not be null");
        if (command.amount().isZero())
            throw new ValidationException("amount", "Amount must be greater than zero");

        // Idempotency check
        if (!idempotencyService.isNew(command.idempotencyKey())) {
            log.info("Idempotent request detected key={}", command.idempotencyKey());
            return idempotencyService.getResult(command.idempotencyKey());
        }

        // Domain logic
        var entity = ${Context}.initiate(command.customerId(), command.amount(), command.description());
        var saved = repository.save(entity);

        // Publish domain events (after commit via @TransactionalEventListener)
        saved.drainEvents().forEach(eventPublisher::publish);

        log.info("${Context} initiated id={} amount={} currency={}",
            saved.id(), saved.amount().displayAmount(), saved.amount().currency());

        var result = ${Context}Result.of(saved.id(), saved.status(), saved.amount());
        idempotencyService.store(command.idempotencyKey(), result);
        return result;
    }
}
```

---

## 4. Infrastructure Layer

### JPA Entity (SEPARATE from domain entity)
```java
// File: infrastructure/persistence/${Context}JpaEntity.java
@Entity
@Table(name = "${context}s")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class ${Context}JpaEntity {

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    @Column(name = "customer_id", nullable = false)
    private UUID customerId;

    // BANKING RULE: BigDecimal with NUMERIC(19,4)
    @Column(name = "amount", precision = 19, scale = 4, nullable = false)
    private BigDecimal amount;

    @Column(name = "currency", length = 3, nullable = false)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ${Context}StatusJpa status;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "idempotency_key", unique = true, length = 64)
    private String idempotencyKey;

    // Optimistic locking — mandatory for financial entities
    @Version
    private Long version;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Instant createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Instant updatedAt;
}
```

### Spring Data Repository Adapter
```java
// File: infrastructure/persistence/${Context}RepositoryAdapter.java
@Repository
@RequiredArgsConstructor
public class ${Context}RepositoryAdapter implements ${Context}Repository {

    private final ${Context}JpaRepository jpaRepository;
    private final ${Context}PersistenceMapper mapper;

    @Override
    public ${Context} save(${Context} entity) {
        var jpaEntity = mapper.toJpaEntity(entity);
        var saved = jpaRepository.save(jpaEntity);
        return mapper.toDomain(saved);
    }

    @Override
    public Optional<${Context}> findById(${Context}Id id) {
        return jpaRepository.findById(id.value()).map(mapper::toDomain);
    }

    @Override
    public List<${Context}> findByCustomerId(CustomerId customerId, int page, int size) {
        return jpaRepository.findByCustomerId(
            customerId.value(),
            PageRequest.of(page, Math.min(size, 100), Sort.by("createdAt").descending())
        ).stream().map(mapper::toDomain).toList();
    }
}
```

---

## 5. Presentation Layer

### REST Controller (THIN — delegate to use cases)
```java
// File: presentation/rest/${Context}Controller.java
@RestController
@RequestMapping("/api/v1/${contexts}")
@RequiredArgsConstructor
@Tag(name = "${Context}s", description = "${Context} management operations")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class ${Context}Controller {

    private final Initiate${Context}UseCase initiate${Context}UseCase;
    private final Get${Context}UseCase get${Context}UseCase;
    private final List${Context}sUseCase list${Context}sUseCase;
    private final ${Context}ResponseMapper responseMapper;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasRole('${CONTEXT}_INITIATOR')")
    @Operation(summary = "Initiate a new ${context}")
    public ResponseEntity<${Context}Response> initiate(
            @Valid @RequestBody Create${Context}Request request,
            @RequestHeader("Idempotency-Key") String idempotencyKey,
            Authentication auth) {

        var command = new Initiate${Context}Command(
            CustomerId.of(auth.getName()),
            Money.of(request.amount().toString(), request.currency()),
            request.description(),
            idempotencyKey
        );

        var result = initiate${Context}UseCase.initiate(command);

        return ResponseEntity
            .created(URI.create("/api/v1/${contexts}/" + result.id()))
            .body(responseMapper.toResponse(result));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('${CONTEXT}_VIEWER') and @${context}SecurityService.owns(authentication, #id)")
    @Operation(summary = "Get ${context} by ID")
    public ${Context}Response getById(
            @PathVariable @UUID String id) {
        return get${Context}UseCase.getById(${Context}Id.of(id))
            .map(responseMapper::toResponse)
            .orElseThrow(() -> new NotFoundException("${Context} not found: " + id));
    }

    @GetMapping
    @PreAuthorize("hasRole('${CONTEXT}_VIEWER')")
    @Operation(summary = "List ${context}s for current user")
    public PagedResponse<${Context}SummaryResponse> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") @Max(100) int size,
            Authentication auth) {
        return list${Context}sUseCase.listByCustomer(
            CustomerId.of(auth.getName()), page, size
        );
    }
}
```

### Request/Response DTOs (Records)
```java
// File: presentation/dto/Create${Context}Request.java
public record Create${Context}Request(

    @NotNull(message = "amount is required")
    @DecimalMin(value = "0.01", message = "amount must be greater than zero")
    @DecimalMax(value = "999999999.9999", message = "amount exceeds maximum")
    @Digits(integer = 9, fraction = 4)
    BigDecimal amount,

    @NotNull @Size(min = 3, max = 3) @Pattern(regexp = "[A-Z]{3}")
    String currency,

    @Size(max = 500)
    String description

) {}

// File: presentation/dto/${Context}Response.java
public record ${Context}Response(
    String id,
    String status,
    String amount,          // formatted string — never raw BigDecimal in JSON
    String currency,
    String createdAt        // ISO-8601 string — never Date or Timestamp
) {}
```

### Global Exception Handler
```java
// File: presentation/config/GlobalExceptionHandler.java
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ProblemDetail handleNotFound(NotFoundException ex, HttpServletRequest req) {
        var problem = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problem.setType(URI.create("https://errors.bank.internal/not-found"));
        problem.setProperty("traceId", MDC.get("traceId"));
        return problem;  // RFC 7807
    }

    @ExceptionHandler(ValidationException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ProblemDetail handleValidation(ValidationException ex, HttpServletRequest req) {
        var problem = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_ENTITY, ex.getMessage());
        problem.setType(URI.create("https://errors.bank.internal/validation-error"));
        problem.setProperty("field", ex.getField());
        problem.setProperty("traceId", MDC.get("traceId"));
        return problem;
    }

    @ExceptionHandler(InsufficientFundsException.class)
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    public ProblemDetail handleInsufficientFunds(InsufficientFundsException ex) {
        var problem = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_ENTITY,
            "Insufficient funds for this operation");
        problem.setType(URI.create("https://errors.bank.internal/insufficient-funds"));
        // NOTE: Never expose actual balance in error response
        problem.setProperty("traceId", MDC.get("traceId"));
        return problem;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ProblemDetail handleBeanValidation(MethodArgumentNotValidException ex) {
        var errors = ex.getBindingResult().getFieldErrors().stream()
            .map(fe -> Map.of("field", fe.getField(), "message", fe.getDefaultMessage()))
            .toList();
        var problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
        problem.setType(URI.create("https://errors.bank.internal/invalid-request"));
        problem.setProperty("errors", errors);
        problem.setProperty("traceId", MDC.get("traceId"));
        return problem;
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ProblemDetail handleUnexpected(Exception ex, HttpServletRequest req) {
        // Log full detail internally — expose nothing to client
        log.error("Unhandled exception path={} method={}", req.getRequestURI(), req.getMethod(), ex);
        var problem = ProblemDetail.forStatusAndDetail(HttpStatus.INTERNAL_SERVER_ERROR,
            "An unexpected error occurred");
        problem.setType(URI.create("https://errors.bank.internal/internal-error"));
        problem.setProperty("traceId", MDC.get("traceId"));
        return problem;
    }
}
```

---

## 6. Database Migration (Flyway)

### SQL Migration Template
```sql
-- File: resources/db/migration/V1__create_${context}s_table.sql
CREATE TABLE ${context}s (
    id               UUID        NOT NULL DEFAULT gen_random_uuid(),
    customer_id      UUID        NOT NULL,
    amount           NUMERIC(19,4) NOT NULL CHECK (amount >= 0),
    currency         CHAR(3)     NOT NULL,
    status           VARCHAR(20) NOT NULL,
    description      VARCHAR(500),
    idempotency_key  VARCHAR(64) UNIQUE,
    version          BIGINT      NOT NULL DEFAULT 0,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_${context}s PRIMARY KEY (id),
    CONSTRAINT chk_currency CHECK (currency ~ '^[A-Z]{3}$'),
    CONSTRAINT chk_status CHECK (status IN ('PENDING','APPROVED','REJECTED','COMPLETED','CANCELLED'))
);

CREATE INDEX idx_${context}s_customer_id ON ${context}s (customer_id);
CREATE INDEX idx_${context}s_created_at ON ${context}s (created_at DESC);
CREATE INDEX idx_${context}s_status ON ${context}s (status) WHERE status NOT IN ('COMPLETED','CANCELLED');

-- Audit trigger (append-only audit trail)
CREATE TABLE ${context}s_audit (
    audit_id   UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    ${context}_id UUID    NOT NULL,
    operation  CHAR(1)     NOT NULL CHECK (operation IN ('I','U','D')),
    changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    changed_by TEXT        NOT NULL DEFAULT current_user,
    old_data   JSONB,
    new_data   JSONB
);

CREATE OR REPLACE FUNCTION audit_${context}s() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO ${context}s_audit(${context}_id, operation, old_data, new_data)
    VALUES (
        COALESCE(NEW.id, OLD.id),
        LEFT(TG_OP, 1),
        CASE WHEN TG_OP != 'INSERT' THEN row_to_json(OLD)::JSONB END,
        CASE WHEN TG_OP != 'DELETE' THEN row_to_json(NEW)::JSONB END
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_${context}s_audit
AFTER INSERT OR UPDATE OR DELETE ON ${context}s
FOR EACH ROW EXECUTE FUNCTION audit_${context}s();
```

---

## 7. Integration Test Template

```java
// File: src/test/java/.../presentation/rest/${Context}ControllerIT.java
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Testcontainers
@Tag("integration")
@ActiveProfiles("test")
class ${Context}ControllerIT {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16-alpine")
        .withDatabaseName("${context}_test");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", postgres::getJdbcUrl);
        r.add("spring.datasource.username", postgres::getUsername);
        r.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired private TestRestTemplate rest;
    @Autowired private ${Context}JpaRepository repository;

    @BeforeEach void clean() { repository.deleteAll(); }

    @Test
    @DisplayName("POST /api/v1/${contexts} — should return 201 with valid payload")
    void should_return201_when_validPayload() {
        var request = new Create${Context}Request(
            new BigDecimal("100.00"), "EUR", "Test ${context}"
        );

        var response = rest
            .withBasicAuth("test-user", "test-pass")
            .postForEntity("/api/v1/${contexts}", request, ${Context}Response.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getHeaders().getLocation()).isNotNull();
        assertThat(response.getBody().status()).isEqualTo("PENDING");
        assertThat(response.getBody().amount()).isEqualTo("100.00");
    }

    @Test
    @DisplayName("POST /api/v1/${contexts} — should return 422 when amount is zero")
    void should_return422_when_amountIsZero() {
        var request = new Create${Context}Request(BigDecimal.ZERO, "EUR", "Test");

        var response = rest
            .withBasicAuth("test-user", "test-pass")
            .postForEntity("/api/v1/${contexts}", request, ProblemDetail.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY);
    }
}
```
