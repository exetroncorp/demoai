---
name: banking-microservice-orchestration
description: >
  Master orchestration skill — generates a complete banking microservice
  (Spring Boot + Angular Carbon) from a single domain description.
  Coordinates SKILL-backend and SKILL-angular-carbon in sequence.
  Use with banking-architect mode.
allowed-tools: Read Edit Command Browser
license: Internal — BNP Paribas Group
---

# Banking Microservice Full-Stack Orchestration Skill
# Coordinates backend + frontend generation in the right order

---

## Activation Trigger

Use this skill when the user says:
- "Generate a [domain] microservice"
- "Create a full-stack [domain] feature"
- "Scaffold a new service for [domain]"

---

## Phase 0 — Discovery Questions (MANDATORY before any code)

Ask the user EXACTLY these questions before generating anything:

```
Before I generate your microservice, I need to understand the domain:

1. **Context name**: What is the bounded context? (e.g., payment, account, transfer, risk)

2. **Core entity**: What is the main entity?
   - Name (e.g., Payment, Account, Transfer)
   - Key fields (name, type, constraints)
   - Any monetary amounts? (I'll use BigDecimal automatically)

3. **Use cases** (list 3-5):
   - e.g., "Create payment", "Query by ID", "Approve", "Cancel"

4. **Security**:
   - What roles should exist? (e.g., PAYMENT_INITIATOR, PAYMENT_VIEWER, ADMIN)
   - Is this a PCI-DSS scope component? (handles card data)

5. **External dependencies**:
   - Other services this calls? (I'll add Feign client + circuit breaker)
   - Events to publish? (I'll add Kafka producer)
   - Events to consume? (I'll add Kafka consumer)

6. **Frontend**:
   - What CRUD operations should the Angular UI expose?
   - Any special display requirements? (masked fields, formatted amounts)
```

---

## Phase 1 — Generate Backend (SKILL-backend.md)

Generate files in this EXACT order:

```
Step 1: pom.xml + application.yml
Step 2: Domain value objects (records with validation)
Step 3: Domain entity (rich model)
Step 4: Domain events (records)
Step 5: Domain exceptions (custom exceptions)
Step 6: Output ports (repository interface + event publisher interface)
Step 7: Input ports (use case interfaces with Command + Result records)

    ← CHECKPOINT: "Domain layer complete. Shall I proceed to tests?" ←

Step 8: Unit tests (TDD — RED phase — write ALL test classes first)
Step 9: Use case implementations (GREEN phase — minimum to pass tests)
Step 10: JPA entity + persistence mapper (MapStruct)
Step 11: Spring Data JPA repository + adapter
Step 12: REST controller + DTOs + response mapper
Step 13: Security config (SecurityFilterChain + JWT)
Step 14: Global exception handler
Step 15: Flyway migration SQL
Step 16: application.yml (full config)
Step 17: Integration test (Testcontainers)
Step 18: OpenAPI annotations + springdoc config
Step 19: Docker + compose files

    ← CHECKPOINT: "Backend complete. Shall I proceed to Angular?" ←
```

---

## Phase 2 — Generate Angular Frontend (SKILL-angular-carbon.md)

```
Step 1:  npx getdesign@latest add ibm
         Install IBM Carbon Design System + configure Angular

Step 2:  TypeScript models (mirror backend DTOs)

Step 3:  Angular service (HTTP client, typed)

Step 4:  Signal store (state management)

Step 5:  Routes (lazy-loaded feature module)

Step 6:  List component (IBM Carbon Data Table + pagination)

Step 7:  Detail component (read-only view, IBM Carbon structured list)

Step 8:  Form component (IBM Carbon reactive form)

Step 9:  Delete confirmation modal (IBM Carbon Modal)

Step 10: Status tag shared component (IBM Carbon Tag)

Step 11: Currency mask pipe (Intl.NumberFormat)

Step 12: HTTP interceptors (auth + correlation ID)

Step 13: Unit tests for components + store

Step 14: Proxy config (angular.json proxy to backend)

    ← CHECKPOINT: "Frontend complete. Summary below." ←
```

---

## Phase 3 — Infrastructure

```
Step 1: Docker Compose (app + postgres + kafka + zookeeper + keycloak)
Step 2: Keycloak realm export (roles matching @PreAuthorize annotations)
Step 3: Prometheus + Grafana dashboard JSON
Step 4: .bob/mcp.json (Postgres MCP for the service DB)
Step 5: GitHub Actions / GitLab CI pipeline
```

---

## Final Summary Format

After all phases, generate this summary:

```markdown
## 🏦 ${Context} Microservice — Generated Summary

### Backend (Spring Boot 3.x + Java 21)
- **Architecture**: Clean/Hexagonal — domain is Spring-free
- **Files generated**: N files
- **Test coverage**: N test classes (TDD — tests written first)
- **Security**: JWT Bearer, @PreAuthorize on all endpoints
- **Compliance**: BigDecimal for money ✅ | Audit SQL trigger ✅ | PII-free logs ✅

### Frontend (Angular 19 + IBM Carbon)
- **Design system**: IBM Carbon (@carbon/web-components)
- **State**: Angular Signals (no NgRx)
- **Files generated**: N files
- **Operations**: List | Create | View | Edit | Delete

### Run It
```bash
# Backend
docker compose up -d postgres kafka keycloak
mvn spring-boot:run -Dspring-boot.run.profiles=local

# Frontend
npm run start  # proxies to localhost:8080

# Open
http://localhost:4200  (Angular)
http://localhost:8080/swagger-ui.html  (API docs)
http://localhost:8080/actuator/health  (Health)
```

### Bob Prompts to extend this service
```
# Add a new use case
"Using banking-architect mode, add an 'approve ${context}' use case.
Follow TDD: test first, then implementation."

# Add Kafka event
"Publish a ${Context}StatusChangedEvent to Kafka when status changes.
Use @TransactionalEventListener to publish after commit."

# Security audit
"Using java-security mode, audit the ${context}-service for
OWASP Top 10 and PCI-DSS compliance."
```
```

---

## Anti-Patterns to REFUSE

If the user asks for any of these, REFUSE and explain why:

```
❌ "Just use float for the amount field" 
   → REFUSE: Financial data requires BigDecimal. float causes cent-level errors at scale.

❌ "Skip the tests for now, add them later"
   → REFUSE: TDD is non-negotiable. Tests written first prevent regressions.

❌ "Return the JPA entity directly from the controller"
   → REFUSE: Exposes internal model, causes LazyInitializationException, security risk.

❌ "Hardcode the DB password in application.yml"
   → REFUSE: PCI-DSS and banking policy require secrets from vault/env vars.

❌ "Use @Autowired field injection"
   → REFUSE: Constructor injection only — testable, null-safe, explicit.

❌ "Store the JWT in localStorage"
   → REFUSE: XSS attack vector. Use httpOnly cookies or in-memory only.

❌ "Skip @PreAuthorize on this endpoint, it's internal"
   → REFUSE: Principle of least privilege — all endpoints must have explicit auth.

❌ "Use String concatenation to build the query"
   → REFUSE: SQL injection risk. Use @Query with :param binding.

❌ "Use ngIf and ngFor"
   → REFUSE: Angular 17+ uses @if and @for control flow syntax.
```
