---
name: banking-angular-carbon
description: >
  Generates Angular 19+ standalone components with IBM Carbon Design System
  for banking CRUD interfaces. Uses npx getdesign@latest add ibm for scaffolding,
  Angular signals for state, and strict TypeScript. Load for any Angular feature work.
allowed-tools: Read Edit Command
license: Internal — BNP Paribas Group
---

# Angular IBM Carbon Skill — Banking Frontend
# Angular 19+ · IBM Carbon Design System · Signals · Strict TypeScript

---

## 1. Project Bootstrap

```bash
# Create Angular project
ng new ${context}-ui \
  --routing=true \
  --style=scss \
  --strict=true \
  --standalone=true \
  --ssr=false

cd ${context}-ui

# Add IBM Carbon Design System via getdesign CLI
npx getdesign@latest add ibm

# Additional Carbon packages
npm install @carbon/web-components @carbon/icons-angular
npm install @carbon/layout @carbon/motion @carbon/type @carbon/colors

# Angular essentials
npm install @angular/cdk
```

### getdesign setup
```bash
# npx getdesign@latest add ibm installs and configures:
# - @carbon/web-components (latest)
# - IBM Plex Sans & Mono fonts
# - Carbon global reset and tokens
# - Angular CUSTOM_ELEMENTS_SCHEMA configuration
# - SCSS import for g100 (dark) or white theme
```

### angular.json — styles configuration
```json
"styles": [
  "node_modules/@carbon/web-components/scss/globals/scss/styles.scss",
  "src/styles.scss"
],
"scripts": []
```

### styles.scss — Carbon theme tokens
```scss
// Import IBM Carbon theme — g100 (dark) for banking, white for back-office
@use '@carbon/web-components/scss/globals/scss/vars' as *;

// Banking color overrides (BNP Paribas brand)
:root {
  // Carbon tokens — do NOT override with raw hex values
  // Use Carbon design tokens for theming
}

// Global typography (IBM Plex Sans is loaded by Carbon)
body {
  font-family: 'IBM Plex Sans', sans-serif;
}
```

### main.ts — enable Carbon custom elements
```typescript
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';
import { defineCustomElements } from '@carbon/web-components/es/components/index.js';

defineCustomElements();  // Register all Carbon web components

bootstrapApplication(AppComponent, appConfig).catch(console.error);
```

---

## 2. Application Configuration

### app.config.ts
```typescript
import { ApplicationConfig, provideZoneChangeDetection, isDevMode } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth.interceptor';
import { correlationIdInterceptor } from './core/interceptors/correlation-id.interceptor';
import { errorInterceptor } from './core/interceptors/error.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(
      withInterceptors([
        authInterceptor,         // Adds Authorization: Bearer <token>
        correlationIdInterceptor, // Adds X-Correlation-ID header
        errorInterceptor          // Global HTTP error handling
      ])
    ),
  ]
};
```

### HTTP Interceptors
```typescript
// core/interceptors/auth.interceptor.ts
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const token = auth.getToken();

  if (token && req.url.startsWith('/api/')) {
    const authReq = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });
    return next(authReq);
  }
  return next(req);
};

// core/interceptors/correlation-id.interceptor.ts
import { HttpInterceptorFn } from '@angular/common/http';
import { v4 as uuidv4 } from 'uuid';

export const correlationIdInterceptor: HttpInterceptorFn = (req, next) => {
  const correlationId = uuidv4();
  return next(req.clone({
    headers: req.headers.set('X-Correlation-ID', correlationId)
  }));
};
```

---

## 3. Feature Module Structure

```
src/app/features/${context}/
├── ${context}.routes.ts           ← lazy-loaded routes
├── components/
│   ├── ${context}-list/
│   │   ├── ${context}-list.component.ts
│   │   ├── ${context}-list.component.html
│   │   ├── ${context}-list.component.scss
│   │   └── ${context}-list.component.spec.ts
│   ├── ${context}-detail/
│   │   └── ...
│   ├── ${context}-form/
│   │   └── ...
│   └── ${context}-delete-modal/
│       └── ...
├── services/
│   └── ${context}.service.ts      ← HTTP client, typed
├── models/
│   └── ${context}.model.ts        ← TypeScript interfaces (mirror backend DTOs)
└── store/
    └── ${context}.store.ts        ← Signal-based state store
```

---

## 4. Angular Service Template (HTTP + typed)

```typescript
// features/${context}/services/${context}.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  ${Context}Response,
  Create${Context}Request,
  PagedResponse
} from '../models/${context}.model';

@Injectable({ providedIn: 'root' })
export class ${Context}Service {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = '/api/v1/${contexts}';

  getAll(page = 0, size = 20): Observable<PagedResponse<${Context}Response>> {
    const params = new HttpParams()
      .set('page', page)
      .set('size', Math.min(size, 100));  // enforce client-side max
    return this.http.get<PagedResponse<${Context}Response>>(this.baseUrl, { params });
  }

  getById(id: string): Observable<${Context}Response> {
    return this.http.get<${Context}Response>(`${this.baseUrl}/${id}`);
  }

  create(
    request: Create${Context}Request,
    idempotencyKey: string
  ): Observable<${Context}Response> {
    return this.http.post<${Context}Response>(this.baseUrl, request, {
      headers: { 'Idempotency-Key': idempotencyKey }
    });
  }

  update(id: string, request: Partial<Create${Context}Request>): Observable<${Context}Response> {
    return this.http.patch<${Context}Response>(`${this.baseUrl}/${id}`, request);
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
```

---

## 5. Signal-Based Store

```typescript
// features/${context}/store/${context}.store.ts
import { Injectable, computed, inject, signal } from '@angular/core';
import { ${Context}Service } from '../services/${context}.service';
import { ${Context}Response, PagedResponse } from '../models/${context}.model';
import { v4 as uuidv4 } from 'uuid';

export type LoadState = 'idle' | 'loading' | 'success' | 'error';

@Injectable({ providedIn: 'root' })
export class ${Context}Store {
  private readonly service = inject(${Context}Service);

  // State signals (private, writable)
  private readonly _items   = signal<${Context}Response[]>([]);
  private readonly _current = signal<${Context}Response | null>(null);
  private readonly _state   = signal<LoadState>('idle');
  private readonly _error   = signal<string | null>(null);
  private readonly _page    = signal(0);
  private readonly _total   = signal(0);

  // Public readonly projections
  readonly items   = this._items.asReadonly();
  readonly current = this._current.asReadonly();
  readonly state   = this._state.asReadonly();
  readonly error   = this._error.asReadonly();
  readonly total   = this._total.asReadonly();

  // Derived signals (computed)
  readonly isLoading  = computed(() => this._state() === 'loading');
  readonly hasError   = computed(() => this._state() === 'error');
  readonly isEmpty    = computed(() => this._items().length === 0 && this._state() !== 'loading');
  readonly totalPages = computed(() => Math.ceil(this._total() / 20));

  loadAll(page = 0): void {
    this._state.set('loading');
    this._error.set(null);
    this.service.getAll(page).subscribe({
      next: (response) => {
        this._items.set(response.content);
        this._total.set(response.page.totalElements);
        this._page.set(page);
        this._state.set('success');
      },
      error: (err) => {
        this._state.set('error');
        this._error.set(err.error?.detail ?? 'Failed to load ${context}s');
      }
    });
  }

  loadById(id: string): void {
    this._state.set('loading');
    this.service.getById(id).subscribe({
      next: (item) => {
        this._current.set(item);
        this._state.set('success');
      },
      error: (err) => {
        this._state.set('error');
        this._error.set(err.error?.detail ?? `${Context} ${id} not found`);
      }
    });
  }

  create(request: Create${Context}Request): void {
    this._state.set('loading');
    const idempotencyKey = uuidv4();
    this.service.create(request, idempotencyKey).subscribe({
      next: (created) => {
        this._items.update(items => [created, ...items]);
        this._state.set('success');
      },
      error: (err) => {
        this._state.set('error');
        this._error.set(err.error?.detail ?? 'Failed to create ${context}');
      }
    });
  }

  delete(id: string): void {
    this._state.set('loading');
    this.service.delete(id).subscribe({
      next: () => {
        this._items.update(items => items.filter(i => i.id !== id));
        this._state.set('success');
      },
      error: (err) => {
        this._state.set('error');
        this._error.set(err.error?.detail ?? 'Failed to delete ${context}');
      }
    });
  }
}
```

---

## 6. List Component (IBM Carbon Data Table)

```typescript
// features/${context}/components/${context}-list/${context}-list.component.ts
import {
  ChangeDetectionStrategy, Component, OnInit, inject, signal
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ${Context}Store } from '../../store/${context}.store';
import { CurrencyMaskPipe } from '../../../../shared/pipes/currency-mask.pipe';
import { StatusTagComponent } from '../../../../shared/components/status-tag/status-tag.component';

@Component({
  selector: 'app-${context}-list',
  standalone: true,
  imports: [RouterLink, CurrencyMaskPipe, StatusTagComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],  // required for Carbon web components
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './${context}-list.component.html',
  styleUrl: './${context}-list.component.scss'
})
export class ${Context}ListComponent implements OnInit {
  readonly store = inject(${Context}Store);

  // Local UI state
  readonly deleteModalOpen = signal(false);
  readonly itemToDelete    = signal<string | null>(null);

  ngOnInit(): void {
    this.store.loadAll();
  }

  onPageChange(event: CustomEvent): void {
    this.store.loadAll(event.detail.page - 1);
  }

  openDeleteModal(id: string): void {
    this.itemToDelete.set(id);
    this.deleteModalOpen.set(true);
  }

  confirmDelete(): void {
    const id = this.itemToDelete();
    if (id) this.store.delete(id);
    this.deleteModalOpen.set(false);
    this.itemToDelete.set(null);
  }
}
```

```html
<!-- features/${context}/components/${context}-list/${context}-list.component.html -->

<!-- Page header -->
<div class="cds--grid">
  <div class="cds--row" style="align-items: center; margin-bottom: 1rem;">
    <div class="cds--col">
      <h1 class="cds--type-productive-heading-04">${Context}s</h1>
    </div>
    <div class="cds--col--auto">
      <cds-button [routerLink]="['new']">
        Create ${context}
        <svg slot="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="16" height="16">
          <path d="M17 15V8h-2v7H8v2h7v7h2v-7h7v-2z"/>
        </svg>
      </cds-button>
    </div>
  </div>

  <!-- Loading skeleton -->
  @if (store.isLoading()) {
    <cds-data-table-skeleton [rowCount]="5" [columnCount]="5"/>
  }

  <!-- Error notification -->
  @if (store.hasError()) {
    <cds-inline-notification
      kind="error"
      [title]="'Error'"
      [subtitle]="store.error()"
      lowContrast>
    </cds-inline-notification>
  }

  <!-- Empty state -->
  @if (store.isEmpty()) {
    <div class="empty-state">
      <cds-inline-notification
        kind="info"
        title="No ${context}s found"
        subtitle="Create your first ${context} to get started."
        lowContrast>
      </cds-inline-notification>
    </div>
  }

  <!-- Data table -->
  @if (!store.isLoading() && !store.isEmpty()) {
    <cds-table-toolbar>
      <cds-table-toolbar-content>
        <cds-table-toolbar-search
          placeholder="Search ${context}s..."
          (ibmSearch)="onSearch($event)">
        </cds-table-toolbar-search>
      </cds-table-toolbar-content>
    </cds-table-toolbar>

    <cds-data-table>
      <table cdsTable>
        <thead>
          <tr cdsTableHead>
            <th cdsTableHeadCell>ID</th>
            <th cdsTableHeadCell>Amount</th>
            <th cdsTableHeadCell>Currency</th>
            <th cdsTableHeadCell>Status</th>
            <th cdsTableHeadCell>Created</th>
            <th cdsTableHeadCell></th>
          </tr>
        </thead>
        <tbody>
          @for (item of store.items(); track item.id) {
            <tr cdsTableRow>
              <td cdsTableData>
                <a [routerLink]="[item.id]" class="cds--link">
                  {{ item.id | slice:0:8 }}...
                </a>
              </td>
              <td cdsTableData>{{ item.amount | currencyMask }}</td>
              <td cdsTableData>{{ item.currency }}</td>
              <td cdsTableData>
                <app-status-tag [status]="item.status"/>
              </td>
              <td cdsTableData>{{ item.createdAt | date:'dd/MM/yyyy HH:mm' }}</td>
              <td cdsTableData>
                <cds-overflow-menu>
                  <cds-overflow-menu-option [routerLink]="[item.id]">View</cds-overflow-menu-option>
                  <cds-overflow-menu-option [routerLink]="[item.id, 'edit']">Edit</cds-overflow-menu-option>
                  <cds-overflow-menu-option
                    kind="danger"
                    (click)="openDeleteModal(item.id)">
                    Delete
                  </cds-overflow-menu-option>
                </cds-overflow-menu>
              </td>
            </tr>
          }
        </tbody>
      </table>
    </cds-data-table>

    <!-- Pagination -->
    <cds-pagination
      [totalItems]="store.total()"
      [pageSize]="20"
      [pageSizes]="[10, 20, 50, 100]"
      (selectPage)="onPageChange($event)">
    </cds-pagination>
  }
</div>

<!-- Delete confirmation modal -->
<cds-modal [open]="deleteModalOpen()" (cdsModalClosed)="deleteModalOpen.set(false)">
  <cds-modal-header>
    <h4 cdsModalHeaderHeading>Confirm deletion</h4>
  </cds-modal-header>
  <cds-modal-body>
    <p>Are you sure you want to delete this ${context}?
    This action cannot be undone.</p>
  </cds-modal-body>
  <cds-modal-footer>
    <cds-button kind="secondary" (click)="deleteModalOpen.set(false)">Cancel</cds-button>
    <cds-button kind="danger" (click)="confirmDelete()">Delete</cds-button>
  </cds-modal-footer>
</cds-modal>
```

---

## 7. Form Component (IBM Carbon Reactive Form)

```typescript
// features/${context}/components/${context}-form/${context}-form.component.ts
import {
  ChangeDetectionStrategy, Component, OnInit, inject, input, output
} from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Create${Context}Request } from '../../models/${context}.model';
import { ${Context}Store } from '../../store/${context}.store';
import { ibanValidator } from '../../../../shared/validators/iban.validator';
import { positiveAmountValidator } from '../../../../shared/validators/amount.validator';

@Component({
  selector: 'app-${context}-form',
  standalone: true,
  imports: [ReactiveFormsModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './${context}-form.component.html',
})
export class ${Context}FormComponent {
  private readonly fb     = inject(FormBuilder);
  readonly store          = inject(${Context}Store);

  // Inputs / Outputs (Angular 17+ style)
  readonly initialData = input<Partial<Create${Context}Request>>();
  readonly saved       = output<void>();
  readonly cancelled   = output<void>();

  readonly form = this.fb.group({
    amount: [null as number | null, [
      Validators.required,
      Validators.min(0.01),
      Validators.max(999999999.9999),
      positiveAmountValidator
    ]],
    currency: ['EUR', [Validators.required, Validators.pattern(/^[A-Z]{3}$/)]],
    description: ['', Validators.maxLength(500)],
  });

  // Field helpers — Carbon needs explicit invalid state
  isInvalid(field: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl?.invalid && ctrl?.touched);
  }

  errorMessage(field: string): string {
    const ctrl = this.form.get(field);
    if (ctrl?.errors?.['required']) return `${field} is required`;
    if (ctrl?.errors?.['min'])      return `${field} must be greater than 0`;
    if (ctrl?.errors?.['max'])      return `${field} exceeds maximum allowed`;
    if (ctrl?.errors?.['pattern'])  return `${field} format is invalid`;
    return '';
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const value = this.form.getRawValue();
    this.store.create({
      amount: value.amount!.toString(),
      currency: value.currency!,
      description: value.description ?? ''
    });
    this.saved.emit();
  }
}
```

```html
<!-- ${context}-form.component.html -->
<form [formGroup]="form" (ngSubmit)="onSubmit()">
  <div class="cds--grid">

    <!-- Amount field -->
    <div class="cds--row">
      <div class="cds--col-md-4">
        <cds-number-input
          formControlName="amount"
          label="Amount"
          [invalid]="isInvalid('amount')"
          [invalidText]="errorMessage('amount')"
          [min]="0.01"
          [step]="0.01"
          placeholder="0.00">
        </cds-number-input>
      </div>

      <!-- Currency field -->
      <div class="cds--col-md-2">
        <cds-select
          formControlName="currency"
          label="Currency"
          [invalid]="isInvalid('currency')"
          [invalidText]="errorMessage('currency')">
          <option value="EUR">EUR — Euro</option>
          <option value="USD">USD — US Dollar</option>
          <option value="GBP">GBP — British Pound</option>
        </cds-select>
      </div>
    </div>

    <!-- Description field -->
    <div class="cds--row">
      <div class="cds--col-md-8">
        <cds-textarea
          formControlName="description"
          label="Description"
          [invalid]="isInvalid('description')"
          [invalidText]="errorMessage('description')"
          placeholder="Optional description"
          rows="3">
        </cds-textarea>
      </div>
    </div>

    <!-- Form actions -->
    <div class="cds--row" style="margin-top: 1.5rem;">
      <div class="cds--col">
        <cds-button kind="secondary" type="button" (click)="cancelled.emit()">
          Cancel
        </cds-button>
        &nbsp;
        <cds-button
          kind="primary"
          type="submit"
          [disabled]="store.isLoading()">
          @if (store.isLoading()) {
            <cds-inline-loading></cds-inline-loading>
          } @else {
            Create ${context}
          }
        </cds-button>
      </div>
    </div>

    <!-- Submission error -->
    @if (store.hasError()) {
      <div class="cds--row" style="margin-top: 1rem;">
        <div class="cds--col">
          <cds-inline-notification
            kind="error"
            [title]="'Creation failed'"
            [subtitle]="store.error()"
            lowContrast>
          </cds-inline-notification>
        </div>
      </div>
    }

  </div>
</form>
```

---

## 8. Shared Utilities

### Currency Mask Pipe (BANKING REQUIREMENT — never expose raw BigDecimal)
```typescript
// shared/pipes/currency-mask.pipe.ts
import { Pipe, PipeTransform, inject, LOCALE_ID } from '@angular/core';

@Pipe({ name: 'currencyMask', standalone: true })
export class CurrencyMaskPipe implements PipeTransform {
  private readonly locale = inject(LOCALE_ID);

  transform(amount: string | number, currency: string = 'EUR', masked = false): string {
    if (masked) return '***.**';  // for sensitive display modes

    const numericAmount = typeof amount === 'string' ? parseFloat(amount) : amount;

    // Always use Intl.NumberFormat — locale-aware, banking-grade formatting
    return new Intl.NumberFormat(this.locale, {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(numericAmount);
  }
}
```

### Status Tag Component (IBM Carbon Tag)
```typescript
// shared/components/status-tag/status-tag.component.ts
import { Component, input } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

type CarbonTagType = 'green' | 'red' | 'blue' | 'gray' | 'purple' | 'teal';

const STATUS_MAP: Record<string, { type: CarbonTagType; label: string }> = {
  PENDING:    { type: 'blue',   label: 'Pending' },
  APPROVED:   { type: 'green',  label: 'Approved' },
  REJECTED:   { type: 'red',    label: 'Rejected' },
  COMPLETED:  { type: 'teal',   label: 'Completed' },
  CANCELLED:  { type: 'gray',   label: 'Cancelled' },
  PROCESSING: { type: 'purple', label: 'Processing' },
};

@Component({
  selector: 'app-status-tag',
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <cds-tag [type]="tagConfig().type">
      {{ tagConfig().label }}
    </cds-tag>
  `
})
export class StatusTagComponent {
  readonly status = input.required<string>();
  readonly tagConfig = computed(() =>
    STATUS_MAP[this.status()] ?? { type: 'gray' as CarbonTagType, label: this.status() }
  );
}
```

---

## 9. TypeScript Models (mirror backend DTOs exactly)

```typescript
// features/${context}/models/${context}.model.ts
export interface ${Context}Response {
  id:          string;
  status:      ${Context}Status;
  amount:      string;   // string — never number for money in frontend
  currency:    string;
  description: string | null;
  createdAt:   string;   // ISO-8601
  updatedAt:   string;
}

export interface Create${Context}Request {
  amount:      string;   // string to avoid float precision loss
  currency:    string;
  description: string;
}

export type ${Context}Status =
  | 'PENDING'
  | 'APPROVED'
  | 'REJECTED'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'PROCESSING';

// Generic paginated response
export interface PagedResponse<T> {
  content: T[];
  page: {
    number:        number;
    size:          number;
    totalElements: number;
    totalPages:    number;
  };
}
```

---

## 10. Unit Tests (Jasmine + Angular Testing Library)

```typescript
// ${context}-list.component.spec.ts
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ${Context}ListComponent } from './${context}-list.component';
import { ${Context}Store } from '../../store/${context}.store';
import { signal, computed } from '@angular/core';
import { provideRouter } from '@angular/router';

describe('${Context}ListComponent', () => {
  let fixture: ComponentFixture<${Context}ListComponent>;
  let mockStore: jasmine.SpyObj<${Context}Store>;

  beforeEach(async () => {
    mockStore = jasmine.createSpyObj<${Context}Store>(
      '${Context}Store',
      ['loadAll', 'delete'],
      {
        items:     signal([]),
        isLoading: signal(false),
        hasError:  signal(false),
        error:     signal(null),
        isEmpty:   computed(() => true),
        total:     signal(0)
      }
    );

    await TestBed.configureTestingModule({
      imports: [${Context}ListComponent],
      providers: [
        provideRouter([]),
        { provide: ${Context}Store, useValue: mockStore }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(${Context}ListComponent);
    fixture.detectChanges();
  });

  it('should load ${context}s on init', () => {
    expect(mockStore.loadAll).toHaveBeenCalledOnceWith();
  });

  it('should show empty state when no items', () => {
    const el = fixture.nativeElement;
    expect(el.querySelector('cds-inline-notification')).toBeTruthy();
  });
});
```
