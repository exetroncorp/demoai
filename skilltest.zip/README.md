# banking-microservice-skill

> **IBM Bob Skill Package — Full-Stack Banking Microservice Generator**  
> Spring Boot 3 · Java 21 · Angular 19 · IBM Carbon Design System · TDD · Clean Architecture

---

## What This Generates

One Bob conversation → complete production-ready microservice:

```
backend/
├── domain/               ← Pure Java (no Spring) — entities, value objects, ports
├── application/          ← Use cases (@Service), TDD-tested
├── infrastructure/       ← JPA, Kafka, external clients
└── presentation/         ← REST controllers (thin), DTOs, security

frontend/
├── features/${context}/
│   ├── components/       ← IBM Carbon CRUD (list, form, detail, delete modal)
│   ├── services/         ← HTTP client (typed)
│   ├── store/            ← Angular Signals state
│   └── models/           ← TypeScript interfaces
└── shared/               ← CurrencyMaskPipe, StatusTagComponent, interceptors

infra/
├── docker-compose.yml    ← Postgres + Kafka + Keycloak + OTel + Jaeger + Grafana
├── keycloak/             ← Realm with roles matching @PreAuthorize
├── prometheus/           ← Scrape config
└── grafana/              ← Dashboard JSON
```

---

## Setup (one time per project)

```bash
# 1. Copy modes to project
cp .bob/custom_modes.yaml your-project/.bob/custom_modes.yaml

# 2. Copy skills to project rules
cp skills/*.md your-project/.bob/rules/

# 3. Reload Bob — new modes appear in the dropdown
```

---

## Usage

### Option A — Full stack generation
```
# In Bob, select: 🏦 Banking Architect mode

"Generate a complete payment microservice.
The main entity is Payment with amount (EUR), status, and description.
Use cases: initiate payment, get by ID, list by customer, cancel.
Roles: PAYMENT_INITIATOR, PAYMENT_VIEWER, PAYMENT_ADMIN.
Angular CRUD UI with IBM Carbon."
```

### Option B — TDD one use case at a time
```
# In Bob, select: 🔴 TDD Pair mode

"Implement the 'initiate payment' use case using TDD.
Payment has: customerId, amount (BigDecimal/EUR), description.
Throw InsufficientFundsException if amount > account balance."
```

### Option C — Angular only
```
# In Bob, select: ⬡ Angular Carbon mode

"Generate an IBM Carbon CRUD interface for the Payment entity.
Fields: amount (masked), currency, status (color-coded tag), createdAt.
Operations: list with pagination, create form, view detail, delete with confirmation modal."
```

---

## Architecture Principles Enforced

### Clean Architecture (Hexagonal)
```
   ┌──────────────────────────────────────┐
   │           Presentation               │  HTTP, REST, DTOs
   │  ┌─────────────────────────────────┐ │
   │  │         Application             │ │  Use Cases, @Service, @Transactional
   │  │  ┌──────────────────────────┐   │ │
   │  │  │         Domain           │   │ │  Entities, Value Objects, Policies
   │  │  │  (no Spring, no JPA)     │   │ │  ← PURE JAVA — most important layer
   │  │  └──────────────────────────┘   │ │
   │  └─────────────────────────────────┘ │
   └──────────────────────────────────────┘
   ┌──────────────────────────────────────┐
   │         Infrastructure               │  JPA, Kafka, HTTP clients
   │  implements Domain ports             │  ← depends on Domain, not vice versa
   └──────────────────────────────────────┘
```

**Dependency rule**: Inner layers NEVER depend on outer layers.  
Domain → Application → Infrastructure (never backwards)

### TDD Cycle (enforced by mode)
```
RED   → Write ONE failing test (test class before implementation class)
GREEN → Write minimum code to pass
REFACTOR → Clean without breaking tests
REPEAT
```

### Banking Financial Rules (from banking-bob-rules)
- ✅ `BigDecimal` from `String` — never from `double`
- ✅ `RoundingMode.HALF_UP` specified on every `.divide()`
- ✅ `NUMERIC(19,4)` in PostgreSQL — never `FLOAT` or `DOUBLE`
- ✅ `isEqualByComparingTo()` in tests — never `isEqualTo()` for BigDecimal
- ✅ Amount displayed as formatted string in JSON — never raw number

### IBM Carbon Design System (Angular frontend)
- ✅ `npx getdesign@latest add ibm` to install
- ✅ `cds-data-table` for lists
- ✅ `cds-text-input`, `cds-number-input`, `cds-select` for forms
- ✅ `cds-modal` for confirmations
- ✅ `cds-tag` for status (green=success, red=error, blue=pending)
- ✅ `cds-inline-notification` for errors/success feedback
- ✅ Angular 17+ `@if`/`@for` — never `*ngIf`/`*ngFor`
- ✅ Signals API — never `BehaviorSubject` for component state
- ✅ `inject()` — never constructor injection
- ✅ `Intl.NumberFormat` for currency — never raw `toFixed(2)`

---

## Modes Reference

| Mode | Slug | Use When |
|------|------|----------|
| 🏦 Banking Architect | `banking-architect` | Full service generation |
| 🔴 TDD Pair | `tdd-pair` | Single use case, test-first |
| ⬡ Angular Carbon | `angular-carbon` | Frontend only |
| 🔒 Java Security Auditor | `java-security` | Pre-release security audit |
| ☕ Java Modernizer | `java-modernizer` | Java version upgrades |

---

## Skills Reference

| Skill | Loads Automatically | Purpose |
|-------|--------------------|---------| 
| `SKILL-backend.md` | With `banking-architect` mode | Spring Boot templates |
| `SKILL-angular-carbon.md` | With `angular-carbon` mode | Angular Carbon templates |
| `SKILL-orchestration.md` | With `banking-architect` mode | Full-stack workflow |

Plus all 7 files from `banking-bob-rules` in `.bob/rules/`.

---

## Compliance Guarantees

Every generated service:
- ✅ OWASP Top 10 — `@PreAuthorize` on all endpoints, parameterized queries, no secrets
- ✅ PCI-DSS R3 — BigDecimal for money, no float/double
- ✅ GDPR Art.25 — PII-free logs, audit trigger in SQL migration
- ✅ DORA — Health endpoint with DEGRADED state, structured logging
- ✅ Banking grade — Optimistic locking (`@Version`), idempotency, RFC 7807 errors
