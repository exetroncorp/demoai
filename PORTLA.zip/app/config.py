import os
from datetime import timedelta

# Allow insecure transport for local development (OIDC over HTTP)
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'


class Config:
    """Base configuration."""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL', 
        'postgresql://jupyterhub:jupyterhub@db:5432/jupyterhub_portal'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_recycle': 300,
        'pool_pre_ping': True
    }
    
    # Session
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Authentication mode: 'ldap', 'saml', 'dummy'
    AUTH_MODE = os.environ.get('AUTH_MODE', 'dummy')
    
    # LDAP Configuration
    LDAP_HOST = os.environ.get('LDAP_HOST', 'ldap://localhost:389')
    LDAP_BASE_DN = os.environ.get('LDAP_BASE_DN', 'dc=example,dc=com')
    LDAP_USER_DN = os.environ.get('LDAP_USER_DN', 'ou=users')
    LDAP_BIND_DN = os.environ.get('LDAP_BIND_DN', '')
    LDAP_BIND_PASSWORD = os.environ.get('LDAP_BIND_PASSWORD', '')
    LDAP_USER_SEARCH_FILTER = os.environ.get('LDAP_USER_SEARCH_FILTER', '(uid={username})')
    LDAP_ATTRIBUTES = ['uid', 'cn', 'sn', 'mail', 'manager']
    
    # SAML Configuration
    SAML_METADATA_URL = os.environ.get('SAML_METADATA_URL', '')
    SAML_ENTITY_ID = os.environ.get('SAML_ENTITY_ID', '')
    SAML_ACS_URL = os.environ.get('SAML_ACS_URL', '')
    SAML_ATTRIBUTE_USERNAME = os.environ.get('SAML_ATTRIBUTE_USERNAME', 'uid')
    SAML_ATTRIBUTE_EMAIL = os.environ.get('SAML_ATTRIBUTE_EMAIL', 'email')
    
    # JupyterHub API
    JUPYTERHUB_API_URL = os.environ.get('JUPYTERHUB_API_URL', 'http://jupyterhub:8081/hub/api')
    JUPYTERHUB_API_TOKEN = os.environ.get('JUPYTERHUB_API_TOKEN', '')
    
    # Token settings
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', SECRET_KEY)
    JWT_EXPIRATION_HOURS = int(os.environ.get('JWT_EXPIRATION_HOURS', '8'))

    # OAuth2 Configuration
    OAUTH2_REFRESH_TOKEN_GENERATOR = True
    OAUTH2_ISSUER = os.environ.get('OAUTH2_ISSUER', 'http://localhost:5000')



class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    ENV = 'development'
    FLASK_ENV = 'development'
    SQLALCHEMY_ECHO = True
    
    # SQLite for local development - no PostgreSQL dependency
    # Use absolute path relative to this config file's directory
    _basedir = os.path.abspath(os.path.dirname(__file__))
    # Go up one level to the project root
    _rootdir = os.path.abspath(os.path.join(_basedir, os.pardir))
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        f'sqlite:///{os.path.join(_rootdir, "instance", "jupyterhub_portal.db")}'
    )
    
    # Remove pool settings for SQLite (not supported)
    SQLALCHEMY_ENGINE_OPTIONS = {}
    
    # JWT Secret - MUST match JupyterHub's JWT_SECRET_KEY
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'dev-jwt-secret-key-change-in-production')
    
    # JupyterHub API for local dev (JupyterHub runs in Docker on port 8000)
    JUPYTERHUB_API_URL = os.environ.get('JUPYTERHUB_API_URL', 'http://localhost:30000/hub/api')
    JUPYTERHUB_API_TOKEN = os.environ.get('JUPYTERHUB_API_TOKEN', 'portal-api-token-hub-a')
    JUPYTERHUB_PUBLIC_URL = os.environ.get('JUPYTERHUB_PUBLIC_URL', 'http://localhost:30000')

    # JupyterHub instances
    JUPYTERHUB_A_URL = os.environ.get('JUPYTERHUB_A_URL', 'http://localhost:30000')
    JUPYTERHUB_B_URL = os.environ.get('JUPYTERHUB_B_URL', 'http://localhost:30010')


class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False
    SESSION_COOKIE_SECURE = True


class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


class KubernetesDevConfig(DevelopmentConfig):
    """Kubernetes development configuration with 2 JupyterHub instances."""
    
    # Multiple JupyterHub instances running in Kubernetes
    # Each has its own API URL and token
    JUPYTERHUB_INSTANCES = [
        {
            'name': 'hub-a',
            'api_url': 'http://localhost:30000/hub/api',
            'public_url': 'http://localhost:30000',
            'api_token': 'portal-api-token-hub-a',
        },
        {
            'name': 'hub-b',
            'api_url': 'http://localhost:30010/hub/api',
            'public_url': 'http://localhost:30010',
            'api_token': 'portal-api-token-hub-b',
        },
    ]
    
    # Default to first hub for backward compatibility
    JUPYTERHUB_API_URL = 'http://localhost:30000/hub/api'
    JUPYTERHUB_API_TOKEN = 'portal-api-token-hub-a'
    JUPYTERHUB_PUBLIC_URL = 'http://localhost:30000'


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'kubernetes': KubernetesDevConfig,
    'default': DevelopmentConfig
}
