"""Main Flask application factory."""
import os

# Allow insecure transport for local development (HTTP)
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# Aggressive Monkey-patch for Authlib's InsecureTransportError
try:
    from authlib.oauth2.rfc6749.errors import InsecureTransportError
    InsecureTransportError.check = lambda uri: None
    
    # Also patch the utility function it uses just in case
    import authlib.common.security as authlib_sec
    authlib_sec.is_secure_transport = lambda uri: True
except ImportError:
    pass

from flask import Flask
from flask_cors import CORS

from config import config
from models import db, Entity, Machine, User, OAuth2Client
import secrets

from auth import auth_bp, login_manager, hash_password
from oauth2 import config_oauth
from routes import main_bp


def create_app(config_name=None):
    """Application factory."""
    if config_name is None:
        config_name = os.environ.get('FLASK_CONFIG') or os.environ.get('FLASK_ENV', 'development')
    
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'
    
    config_oauth(app)
    
    CORS(app, supports_credentials=True)
    
    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    
    # Create database tables and seed data
    with app.app_context():
        db.create_all()
        seed_database()
    
    return app


def seed_database():
    """Seed the database with initial data if empty."""
    # Check if already seeded
    if User.query.first():
        return
    
    # Create entities
    default_entity = Entity(name='Default', quota=100)
    dev_entity = Entity(name='Development', quota=50)
    db.session.add(default_entity)
    db.session.add(dev_entity)
    db.session.flush()
    
    # Create sample machines with real demo URLs for testing
    machines = [
        Machine(
            name='JupyterHub-1',
            url='https://jupyter.org/try-jupyter/lab/',
            cluster='cluster-1',
            namespace='jupyter',
            ram_total=32768,
            ram_available=28672,
            cpu_total=16,
            cpu_available=12,
            storage_total=500,
            storage_available=450,
            identity=default_entity.identity
        ),
        Machine(
            name='JupyterHub-2',
            url='https://mybinder.org/',
            cluster='cluster-1',
            namespace='jupyter',
            ram_total=65536,
            ram_available=65536,
            cpu_total=32,
            cpu_available=32,
            storage_total=1000,
            storage_available=1000,
            identity=default_entity.identity
        ),
        Machine(
            name='JupyterHub-Dev',
            url='http://localhost:30000',
            cluster='local-docker',
            namespace='dev',
            ram_total=16384,
            ram_available=8192,
            cpu_total=8,
            cpu_available=4,
            storage_total=200,
            storage_available=150,
            identity=dev_entity.identity
        )
    ]
    for machine in machines:
        db.session.add(machine)
    db.session.flush()
    
    # Create admin user (no machine assigned)
    admin = User(
        uid='admin',
        name='Admin',
        last_name='User',
        email='admin@example.com',
        role='admin',
        identity=default_entity.identity,
        password_hash=hash_password('admin123')
    )
    db.session.add(admin)
    
    # Create multiple dev users with machine assignments
    dev_users = [
        User(
            uid='user',
            name='John',
            last_name='Developer',
            email='john@example.com',
            role='dev',
            identity=default_entity.identity,
            id_machine=machines[0].id_machine,
            cpu=2, ram=2048, stockage=20,
            password_hash=hash_password('user123')
        ),
        User(
            uid='alice',
            name='Alice',
            last_name='Smith',
            email='alice@example.com',
            role='dev',
            identity=default_entity.identity,
            id_machine=machines[0].id_machine,
            cpu=2, ram=2048, stockage=30,
            password_hash=hash_password('alice123')
        ),
        User(
            uid='bob',
            name='Bob',
            last_name='Johnson',
            email='bob@example.com',
            role='dev',
            identity=default_entity.identity,
            id_machine=machines[1].id_machine,
            cpu=4, ram=4096, stockage=50,
            password_hash=hash_password('bob123')
        ),
        User(
            uid='carol',
            name='Carol',
            last_name='Williams',
            email='carol@example.com',
            role='dev',
            identity=dev_entity.identity,
            id_machine=machines[2].id_machine,
            cpu=4, ram=4096, stockage=50,
            password_hash=hash_password('carol123')
        ),
        User(
            uid='dave',
            name='Dave',
            last_name='Coder',
            email='dave@example.com',
            role='dev',
            interface='codeserver',
            auto_connect=True,
            identity=default_entity.identity,
            id_machine=machines[2].id_machine,
            cpu=4, ram=4096, stockage=50,
            password_hash=hash_password('dave123')
        )
    ]
    for user in dev_users:
        db.session.add(user)
    
    # Create default OAuth2 Client for JupyterHub
    if not OAuth2Client.query.filter_by(client_id='jupyterhub-portal').first():
        client = OAuth2Client(
            client_id='jupyterhub-portal',
            client_secret='jupyterhub-secret',
            user_id=admin.id_utilisateur
        )
        client.set_client_metadata({
            'client_name': 'JupyterHub',
            'client_uri': 'http://localhost:5000',
            'grant_types': ['authorization_code', 'refresh_token'],
            'redirect_uris': ['http://localhost:30000/hub/oauth_callback'],
            'response_types': ['code'],
            'scope': 'openid profile email',
            'token_endpoint_auth_method': 'client_secret_post'
        })
        db.session.add(client)
    
    db.session.commit()

    print("Database seeded with mock data")


# Create the application instance
app = create_app()


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
