import os
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

from authlib.integrations.flask_oauth2 import AuthorizationServer, ResourceProtector
from authlib.integrations.sqla_oauth2 import (
    create_query_client_func,
    create_save_token_func,
    create_revocation_endpoint,
    create_bearer_token_validator,
)
from authlib.oauth2.rfc6749 import grants
from authlib.oidc.core import UserInfo
from authlib.oidc.core.grants import (
    OpenIDCode as _OpenIDCode,
    OpenIDImplicitGrant as _OpenIDImplicitGrant,
    OpenIDHybridGrant as _OpenIDHybridGrant,
)
from models import db, User, OAuth2Client, OAuth2AuthorizationCode, OAuth2Token

class AuthorizationCodeGrant(grants.AuthorizationCodeGrant):
    def save_authorization_code(self, code, request):
        auth_code = OAuth2AuthorizationCode(
            code=code,
            client_id=request.client.client_id,
            redirect_uri=request.redirect_uri,
            scope=request.scope,
            user_id=request.user.id_utilisateur,
        )
        db.session.add(auth_code)
        db.session.commit()
        return auth_code

    def query_authorization_code(self, code, client):
        return OAuth2AuthorizationCode.query.filter_by(
            code=code, client_id=client.client_id).first()

    def delete_authorization_code(self, authorization_code):
        db.session.delete(authorization_code)
        db.session.commit()

    def authenticate_user(self, authorization_code):
        return User.query.get(authorization_code.user_id)

class OpenIDCode(_OpenIDCode):
    def exists_nonce(self, nonce, request):
        # In a real app, you should check if nonce exists in database/redis
        return False

    def get_jwt_config(self, grant):
        from flask import current_app
        return {
            'key': current_app.config['JWT_SECRET_KEY'],
            'alg': 'HS256',
            'iss': current_app.config.get('OAUTH2_ISSUER', 'https://portal.example.com'),
            'exp': 3600
        }

    def get_user_info(self, user, scope):
        return UserInfo(
            sub=str(user.id_utilisateur),
            name=user.full_name,
            preferred_username=user.uid,
            email=user.email,
        )

    def generate_user_info(self, user, scope):
        return self.get_user_info(user, scope)

authorization = AuthorizationServer()
require_oauth = ResourceProtector()

def config_oauth(app):
    query_client = create_query_client_func(db.session, OAuth2Client)
    save_token = create_save_token_func(db.session, OAuth2Token)
    authorization.init_app(app, query_client=query_client, save_token=save_token)

    # support all grants
    authorization.register_grant(AuthorizationCodeGrant, [
        OpenIDCode(require_nonce=False),
    ])
    authorization.register_grant(grants.ImplicitGrant)
    authorization.register_grant(grants.RefreshTokenGrant)

    # support revocation
    revocation_cls = create_revocation_endpoint(db.session, OAuth2Token)
    authorization.register_endpoint(revocation_cls)

    # protect resource
    bearer_cls = create_bearer_token_validator(db.session, OAuth2Token)
    require_oauth.register_token_validator(bearer_cls())
