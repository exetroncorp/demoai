import requests

PORTAL_URL = "http://localhost:5000"
CLIENT_ID = "jupyterhub-portal"
CLIENT_SECRET = "jupyterhub-secret"
REDIRECT_URI = "http://localhost:8000/hub/oauth_callback"

def test_oauth_endpoints():
    print("Checking OIDC Configuration...")
    resp = requests.get(f"{PORTAL_URL}/.well-known/openid-configuration")
    if resp.status_code == 200:
        print("✅ OIDC Config found")
        print(resp.json())
    else:
        print(f"❌ OIDC Config failed: {resp.status_code}")

    print("\nNote: To test the full Authorize flow, you need a logged-in session.")
    print("Testing Token endpoint (failure expected without code)...")
    data = {
        'grant_type': 'authorization_code',
        'code': 'fake-code',
        'client_id': CLIENT_ID,
        'client_secret': CLIENT_SECRET,
        'redirect_uri': REDIRECT_URI
    }
    resp = requests.post(f"{PORTAL_URL}/oauth/token", data=data)
    # 400 is actually good here because it means the endpoint exists and rejected the 'fake-code'
    if resp.status_code == 400:
        print("✅ Token endpoint active (rejected invalid code as expected)")
    else:
        print(f"❓ Token endpoint status: {resp.status_code}")

if __name__ == "__main__":
    test_oauth_endpoints()
