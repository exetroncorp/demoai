
import os
import sys

# Ensure we can import from app folder
sys.path.append(os.path.join(os.getcwd(), 'app'))

from app import create_app, db, User, hash_password, Entity

def ensure_admin():
    app = create_app()
    with app.app_context():
        print(f"DB URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
        
        # Check for admin
        admin = User.query.filter_by(uid='admin').first()
        expected = hash_password('admin123')
        
        if admin:
            print("Admin user found.")
            # Update password just in case
            if admin.password_hash != expected:
                print("Updating admin password...")
                admin.password_hash = expected
                db.session.commit()
                print("Password updated.")
        else:
            print("Admin user NOT found. Creating...")
            
            # Ensure Default entity exists
            default_entity = Entity.query.filter_by(name='Default').first()
            if not default_entity:
                default_entity = Entity(name='Default', quota=100)
                db.session.add(default_entity)
                db.session.commit()
            
            admin = User(
                uid='admin',
                name='Admin',
                last_name='User',
                email='admin@example.com',
                role='admin',
                identity=default_entity.identity,
                password_hash=expected
            )
            db.session.add(admin)
            db.session.commit()
            print("Admin user created.")

if __name__ == '__main__':
    ensure_admin()
