<#
.SYNOPSIS
    Deploy JupyterHub instances to Docker Desktop Kubernetes
.DESCRIPTION
    This script builds the JupyterHub KubeSpawner image and deploys
    2 JupyterHub instances (Hub A and Hub B) to Kubernetes.
#>

param(
    [switch]$BuildOnly,
    [switch]$DeployOnly,
    [switch]$Cleanup
)

$ErrorActionPreference = "Stop"

$ProjectRoot = $PSScriptRoot
$K8sDir = Join-Path $ProjectRoot "k8s"
$JupyterhubDir = Join-Path $ProjectRoot "jupyterhub"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "JupyterHub Kubernetes Deployment Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check kubectl is available
if (-not (Get-Command kubectl -ErrorAction SilentlyContinue)) {
    Write-Error "kubectl not found. Please install kubectl and ensure it's in your PATH."
    exit 1
}

# Check Docker Desktop Kubernetes context
$context = kubectl config current-context
if ($context -ne "docker-desktop") {
    Write-Warning "Current kubectl context is '$context', switching to 'docker-desktop'..."
    kubectl config use-context docker-desktop
}

# Cleanup mode
if ($Cleanup) {
    Write-Host "Cleaning up Kubernetes resources..." -ForegroundColor Yellow
    kubectl delete namespace jupyterhub --ignore-not-found
    Write-Host "Cleanup complete!" -ForegroundColor Green
    exit 0
}

# Build the JupyterHub image with KubeSpawner
if (-not $DeployOnly) {
    Write-Host ""
    Write-Host "Step 1: Building JupyterHub KubeSpawner image..." -ForegroundColor Yellow
    
    # Build JupyterHub image
    docker build -t jupyterhub-kubespawner:latest -f "$JupyterhubDir\Dockerfile.kubespawner" $JupyterhubDir
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to build JupyterHub image"
        exit 1
    }
    Write-Host "  JupyterHub image built successfully!" -ForegroundColor Green
    
    # Build user image (VS Code)
    Write-Host ""
    Write-Host "Step 2: Building user VS Code image..." -ForegroundColor Yellow
    docker build -t jupyterhub-user-vscode:latest -f "$JupyterhubDir\Dockerfile.user" $JupyterhubDir
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to build user image"
        exit 1
    }
    Write-Host "  User image built successfully!" -ForegroundColor Green
}

if ($BuildOnly) {
    Write-Host ""
    Write-Host "Build complete! Use -DeployOnly to deploy to Kubernetes." -ForegroundColor Cyan
    exit 0
}

# Deploy to Kubernetes
Write-Host ""
Write-Host "Step 3: Deploying to Kubernetes..." -ForegroundColor Yellow

# Apply namespace first
Write-Host "  Creating namespace..."
kubectl apply -f "$K8sDir\namespace.yaml"

# Apply RBAC
Write-Host "  Applying RBAC..."
kubectl apply -f "$K8sDir\rbac.yaml"

# Apply ConfigMaps
Write-Host "  Applying ConfigMaps..."
kubectl apply -f "$K8sDir\configmap-hub-a.yaml"
kubectl apply -f "$K8sDir\configmap-hub-b.yaml"

# Apply Deployments
Write-Host "  Applying Deployments..."
kubectl apply -f "$K8sDir\deployment-hub-a.yaml"
kubectl apply -f "$K8sDir\deployment-hub-b.yaml"

# Apply Services
Write-Host "  Applying Services..."
kubectl apply -f "$K8sDir\service-hub-a.yaml"
kubectl apply -f "$K8sDir\service-hub-b.yaml"

Write-Host ""
Write-Host "Step 4: Waiting for pods to be ready..." -ForegroundColor Yellow
kubectl wait --for=condition=Ready pod -l app=jupyterhub -n jupyterhub --timeout=120s

# Get pod status
Write-Host ""
Write-Host "Step 5: Checking deployment status..." -ForegroundColor Yellow
kubectl get pods -n jupyterhub
Write-Host ""
kubectl get svc -n jupyterhub

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "Deployment Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "JupyterHub Instances:" -ForegroundColor Cyan
Write-Host "  Hub A: http://localhost:30000 (NodePort)" -ForegroundColor White
Write-Host "  Hub B: http://localhost:30010 (NodePort)" -ForegroundColor White
Write-Host ""
Write-Host "Or use port-forward for localhost:8000 and localhost:8001:" -ForegroundColor Cyan
Write-Host "  kubectl port-forward svc/jupyterhub-a 8000:8000 -n jupyterhub" -ForegroundColor White
Write-Host "  kubectl port-forward svc/jupyterhub-b 8001:8000 -n jupyterhub" -ForegroundColor White
Write-Host ""
Write-Host "Portal (run separately): python -m flask run --port 5000" -ForegroundColor Cyan
Write-Host ""
Write-Host "View logs:" -ForegroundColor Cyan
Write-Host "  kubectl logs -l hub=hub-a -n jupyterhub -f" -ForegroundColor White
Write-Host "  kubectl logs -l hub=hub-b -n jupyterhub -f" -ForegroundColor White
