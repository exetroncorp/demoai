"""
Seed script for Kubernetes JupyterHub setup.
Creates 2 JupyterHub machine entries and test users assigned to each hub.
Uses SQLite database for local development.
"""
import os
import sys

# Add app directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))

# Set development environment
os.environ['FLASK_ENV'] = 'development'

from app import app
from models import db, Entity, Machine, User, OAuth2Client
from auth import hash_password


def seed_k8s_database():
    """Seed the database with 2 JupyterHub instances and users."""
    print("Seeding database for Kubernetes JupyterHub setup...")
    
    with app.app_context():
        # Ensure tables exist
        db.create_all()
        
        # 1. Create Entity
        print("Creating Entity...")
        dev_entity = Entity.query.filter_by(name='Development').first()
        if not dev_entity:
            dev_entity = Entity(name='Development', quota=50)
            db.session.add(dev_entity)
            db.session.commit()
            print(f"  Created entity: Development (ID: {dev_entity.identity})")
        else:
            print(f"  Entity already exists: Development (ID: {dev_entity.identity})")
        
        # 2. Create 2 JupyterHub Machines
        print("\nCreating JupyterHub machines...")
        
        # Hub A - localhost:30000
        hub_a = Machine.query.filter_by(name='JupyterHub A').first()
        if not hub_a:
            hub_a = Machine(
                name='JupyterHub A',
                url='http://localhost:30000',
                cluster='docker-desktop',
                namespace='jupyterhub',
                identity=dev_entity.identity,
                cpu_total=8, cpu_available=8,
                ram_total=16000, ram_available=16000,
                storage_total=100, storage_available=100
            )
            db.session.add(hub_a)
            print("  Created machine: JupyterHub A (http://localhost:30000)")
        else:
            # Update URL if needed
            hub_a.url = 'http://localhost:30000'
            hub_a.namespace = 'jupyterhub'
            hub_a.cluster = 'docker-desktop'
            print("  Updated machine: JupyterHub A")
        
        # Hub B - localhost:30010
        hub_b = Machine.query.filter_by(name='JupyterHub B').first()
        if not hub_b:
            hub_b = Machine(
                name='JupyterHub B',
                url='http://localhost:30010',
                cluster='docker-desktop',
                namespace='jupyterhub',
                identity=dev_entity.identity,
                cpu_total=8, cpu_available=8,
                ram_total=16000, ram_available=16000,
                storage_total=100, storage_available=100
            )
            db.session.add(hub_b)
            print("  Created machine: JupyterHub B (http://localhost:30010)")
        else:
            hub_b.url = 'http://localhost:30010'
            hub_b.namespace = 'jupyterhub'
            hub_b.cluster = 'docker-desktop'
            print("  Updated machine: JupyterHub B")
        
        db.session.commit()
        
        # 3. Create Users
        print("\nCreating users...")
        
        # Superadmin (not assigned to any machine)
        if not User.query.filter_by(uid='superadmin').first():
            u = User(
                uid='superadmin',
                name='System', last_name='Admin',
                email='admin@example.com',
                role='superadmin',
                password_hash=hash_password('admin123'),
                interface='jupyterlab'
            )
            db.session.add(u)
            print("  Created user: superadmin / admin123 (superadmin role)")
        
        # User assigned to Hub A
        user_a = User.query.filter_by(uid='user_hub_a').first()
        if not user_a:
            user_a = User(
                uid='user_hub_a',
                name='Alice', last_name='Developer',
                email='alice@example.com',
                role='dev',
                identity=dev_entity.identity,
                id_machine=hub_a.id_machine,
                password_hash=hash_password('alice123'),
                interface='codeserver',
                cpu=2, ram=4096, stockage=20
            )
            db.session.add(user_a)
            print("  Created user: user_hub_a / alice123 (assigned to Hub A)")
        else:
            user_a.id_machine = hub_a.id_machine
            print("  Updated user: user_hub_a -> Hub A")
        
        # User assigned to Hub B
        user_b = User.query.filter_by(uid='user_hub_b').first()
        if not user_b:
            user_b = User(
                uid='user_hub_b',
                name='Bob', last_name='Engineer',
                email='bob@example.com',
                role='dev',
                identity=dev_entity.identity,
                id_machine=hub_b.id_machine,
                password_hash=hash_password('bob123'),
                interface='codeserver',
                cpu=2, ram=4096, stockage=20
            )
            db.session.add(user_b)
            print("  Created user: user_hub_b / bob123 (assigned to Hub B)")
        else:
            user_b.id_machine = hub_b.id_machine
            print("  Updated user: user_hub_b -> Hub B")
        
        db.session.commit()
        
        # 4. Create OAuth2 Clients for each hub
        print("\nCreating OAuth2 clients...")
        
        # Client for Hub A
        client_a = OAuth2Client.query.filter_by(client_id='jupyterhub-hub-a').first()
        if not client_a:
            client_a = OAuth2Client(
                client_id='jupyterhub-hub-a',
                client_secret='jupyterhub-secret-a',
                client_id_issued_at=0,
                client_secret_expires_at=0,
            )
            client_a.set_client_metadata({
                'client_name': 'JupyterHub Instance A',
                'grant_types': ['authorization_code'],
                'response_types': ['code'],
                'redirect_uris': ['http://localhost:30000/hub/oauth_callback'],
                'scope': 'openid profile email',
                'token_endpoint_auth_method': 'client_secret_post'
            })
            db.session.add(client_a)
            print("  Created OAuth2 client: jupyterhub-hub-a")
        else:
            # Update redirect URI
            client_a.set_client_metadata({
                'client_name': 'JupyterHub Instance A',
                'grant_types': ['authorization_code'],
                'response_types': ['code'],
                'redirect_uris': ['http://localhost:30000/hub/oauth_callback'],
                'scope': 'openid profile email',
                'token_endpoint_auth_method': 'client_secret_post'
            })
            print("  Updated OAuth2 client: jupyterhub-hub-a")
        
        # Client for Hub B
        client_b = OAuth2Client.query.filter_by(client_id='jupyterhub-hub-b').first()
        if not client_b:
            client_b = OAuth2Client(
                client_id='jupyterhub-hub-b',
                client_secret='jupyterhub-secret-b',
                client_id_issued_at=0,
                client_secret_expires_at=0,
            )
            client_b.set_client_metadata({
                'client_name': 'JupyterHub Instance B',
                'grant_types': ['authorization_code'],
                'response_types': ['code'],
                'redirect_uris': ['http://localhost:30010/hub/oauth_callback'],
                'scope': 'openid profile email',
                'token_endpoint_auth_method': 'client_secret_post'
            })
            db.session.add(client_b)
            print("  Created OAuth2 client: jupyterhub-hub-b")
        else:
            client_b.set_client_metadata({
                'client_name': 'JupyterHub Instance B',
                'grant_types': ['authorization_code'],
                'response_types': ['code'],
                'redirect_uris': ['http://localhost:30010/hub/oauth_callback'],
                'scope': 'openid profile email',
                'token_endpoint_auth_method': 'client_secret_post'
            })
            print("  Updated OAuth2 client: jupyterhub-hub-b")
        
        db.session.commit()
        
        # Summary
        print("\n" + "="*60)
        print("Database seeding complete!")
        print("="*60)
        print("\nJupyterHub Instances:")
        print(f"  - Hub A: http://localhost:30000 (Machine ID: {hub_a.id_machine})")
        print(f"  - Hub B: http://localhost:30010 (Machine ID: {hub_b.id_machine})")
        print("\nUsers:")
        print("  - superadmin / admin123 (superadmin)")
        print(f"  - user_hub_a / alice123 (assigned to Hub A)")
        print(f"  - user_hub_b / bob123 (assigned to Hub B)")
        print("\nOAuth2 Clients:")
        print("  - jupyterhub-hub-a (client_secret: jupyterhub-secret-a)")
        print("  - jupyterhub-hub-b (client_secret: jupyterhub-secret-b)")


if __name__ == '__main__':
    seed_k8s_database()
