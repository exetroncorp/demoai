#!/bin/bash
# Development mode startup script for Unix/Linux/Mac
# Run JupyterHub in Docker, Portal backend locally

set -e

echo "=== JupyterHub Portal Development Mode ==="
echo ""

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "Error: Docker is not running. Please start Docker Desktop."
    exit 1
fi

# Create instance directory for SQLite database
mkdir -p app/instance

# Step 1: Build JupyterHub user image
echo "Building JupyterHub user image..."
cd jupyterhub
docker build -t jupyterhub-user-vscode -f Dockerfile.user .
cd ..

# Step 2: Start JupyterHub in Docker
echo "Starting JupyterHub in Docker..."
docker-compose -f docker-compose.dev.yml up -d

echo ""
echo "JupyterHub is starting at http://localhost:8000"

# Step 3: Install Python dependencies
echo ""
echo "Installing Python dependencies..."
pip install -r requirements-dev.txt

# Step 4: Set environment variables
export FLASK_ENV=development
export FLASK_DEBUG=1
export AUTH_MODE=dummy
export SECRET_KEY=dev-secret-key-change-in-production
export JWT_SECRET_KEY=dev-jwt-secret-key-change-in-production
export JUPYTERHUB_API_URL=http://localhost:8000/hub/api
export JUPYTERHUB_API_TOKEN=portal-api-token
export JUPYTERHUB_PUBLIC_URL=http://localhost:8000

# Step 5: Run Flask development server
echo ""
echo "Starting Flask development server..."
echo "Portal will be available at http://localhost:5000"
echo ""
echo "Test credentials:"
echo "  admin/admin123 (Admin user)"
echo "  user/user123 (Developer user)"
echo ""

cd app
python app.py
