# JupyterHub Management Portal

A multi-instance management portal for JupyterHub: user assignment, spawning, and monitoring for JupyterLab and VS Code (code-server) across Docker and Kubernetes.

## Quick Start

**Windows:**

```powershell
.\run_dev.ps1
```

**Unix / Mac:**

```bash
./run_dev.sh
```

- **Portal:** http://localhost:5000  
- **JupyterHub:** http://localhost:30000  

## Features

- **Auth:** Dummy, LDAP, or SAML
- **OIDC provider** for JupyterHub (authorization code flow)
- **Load balancing** of users across machines by resource availability
- **RBAC:** Superadmin, Admin (per-entity), Dev
- **Interfaces:** JupyterLab, code-server (VS Code)

## Project Layout

| Path | Description |
|------|-------------|
| `app/` | Flask app: routes, auth, models, OAuth2, JupyterHub client |
| `jupyterhub/` | Hub image, user image, `jupyterhub_config.py`, logout extension |
| `k8s/` | Kubernetes manifests (multi-hub) |
| `docs/` | Architecture, workflow, diagrams |
| `tools/` | Health checks, DB seeding, smoke tests |

## Docs

- [Development](DEVELOPMENT.md) — run locally, auth, config, troubleshooting
- [Architecture](docs/ARCHITECTURAL_OVERVIEW.md) — data model, RBAC, K8s
- [Workflow](docs/WORKFLOW_SCENARIO.md) — login → spawn → OIDC → code-server

## Test Users (dev, `AUTH_MODE=dummy`)

| User | Password | Role |
|------|----------|------|
| admin | admin123 | Admin |
| user | user123 | Developer |
| alice | alice123 | Developer |
| user_hub_a | alice123 | Developer (Hub/Dev machine) |
| dave | dave123 | Developer (auto-connect to VS Code) |

## Tools

From project root: `python tools/check_hub_health.py`, `python tools/ensure_admin.py`, etc. See [tools/README.md](tools/README.md).
