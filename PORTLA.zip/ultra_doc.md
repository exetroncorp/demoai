-- Active: 1768501624248@@127.0.0.1@3306
# Ultra Documentation: JupyterHub Management Portal

This document provides a comprehensive overview of the architecture, data models, workflows, and production deployment strategies for the JupyterHub Management Portal.

## 1. Project Structure

The project is divided into two main components: the **Management Portal (Flask)** and the **JupyterHub Instance**.

> **Note**: In Development mode, the application uses **SQLite** located at `/instance/jupyterhub_portal.db` (project root). In Production mode, it defaults to **PostgreSQL**.

```text
/workspace
├── app/                        # Management Portal Application
│   ├── templates/              # HTML Templates (Dashboard, Admin, Login)
│   ├── static/                 # Static assets (CSS, JS)
│   ├── routes.py               # Application logic and API endpoints
│   ├── models.py               # Database definitions (SQLAlchemy)
│   ├── auth.py                 # Authentication logic (Local, LDAP, SAML)
│   ├── jupyterhub_client.py    # Client for interacting with JupyterHub API
│   └── ...
├── instance/                   # SQLite Database (Development only)
│   └── jupyterhub_portal.db
├── jupyterhub/                 # JupyterHub Configuration
│   ├── Dockerfile.jupyterhub   # Custom Hub image with DockerSpawner
│   ├── Dockerfile.user         # Single-user image (Code-Server enabled)
│   ├── jupyterhub_config.py    # Main Hub configuration
│   └── logout-extension/       # VS Code extension for logout button
├── docker-compose.dev.yml      # Development orchestration (Hub in Docker, Portal Local)
├── docker-compose.hub.yml      # Production-like orchestration
└── ...
```

---

## 2. Data Models

The system uses a hierarchical Role-Based Access Control (RBAC) system tied to Entities (Organizations) and Machines (Infrastructure).

```mermaid
erDiagram
    Entity ||--|{ User : "contains members"
    Entity ||--|{ Machine : "owns resources"
    Machine ||--|{ User : "hosts environment for"

    Entity {
        int identity PK
        string name "Organization Name"
        int quota "Resource Quota"
    }

    Machine {
        int id_machine PK
        string name "Instance Name"
        string url "JupyterHub URL"
        string cluster "K8s Cluster/Zone"
        int identity FK "Owned by Entity"
    }

    User {
        int id_utilisateur PK
        string uid "Username"
        string role "dev, admin, superadmin"
        string interface "jupyterlab, codeserver"
        int identity FK "Belongs to Entity"
        int id_machine FK
    }
```

### Roles
- **Superadmin**: Global control. 
    - Can create Entities (Instances) and Machines.
    - Can create users and assign them to *any* Entity.
    - **Launch Capability**: Can instantly launch any Machine to verify its status (updates superadmin's machine assignment on the fly).
    - Hidden from standard 'Admin' users in the user list.
- **Admin**: Entity Admin. 
    - Manages users *only* within their assigned Entity.
    - Can only attribute users to Machines that belong to their Entity.
    - Cannot see or manage Superadmins.
- **Dev**: Standard user. 
    - Can launch and use their personal environment (VS Code or JupyterLab).
    - Assigned to a specific Machine and Entity.

---

## 3. Workflow: Authentication & Spawning

The Portal acts as a facade for JupyterHub, handling authentication and seamlessly logging the user into their Code Server environment.

```mermaid
sequenceDiagram
    actor User
    participant Portal as Management Portal
    participant DB as Database
    participant Hub as JupyterHub
    participant Spawner as Docker/K8s Spawner

    User->>Portal: Login (Credentials/SSO)
    Portal->>DB: Verify Credentials & Role
    Portal-->>User: Dashboard (Admin/Dev view)

    User->>Portal: Click "Launch VS Code"
    Portal->>Hub: Check Server Status (API)
    
    alt Server Not Running
        Portal->>Hub: Request Spawn (API)
        Hub->>Spawner: Start Container
        Portal-->>User: Show "Starting..." Screen
        loop Poll Status
            User->>Portal: Poll /api/server/connect
            Portal->>Hub: Check Status
        end
    end

    Portal->>Hub: Generate API Token (Scope: User)
    Hub-->>Portal: Return Token
    Portal-->>User: Redirect to Hub with Token
    User->>Hub: Access /user/{name}/vscode/?token=...
    Hub-->>User: Code Server Interface
```

### Logout Flow

When users log out from code-server or JupyterHub, they are redirected back to the Portal:

```mermaid
sequenceDiagram
    actor User
    participant CodeServer as Code Server (VS Code)
    participant Hub as JupyterHub
    participant Portal as Management Portal

    User->>CodeServer: Click "Logout" button (status bar)
    CodeServer->>Hub: Redirect to /hub/logout
    Hub->>Hub: Clear session & cookies
    Hub->>Portal: Redirect to Portal URL
    Portal-->>User: Show Portal login page
```

**Configuration:**
- `c.GenericOAuthenticator.logout_redirect_url` in `jupyterhub_config.py` defines the Portal URL
- The `logout-extension` provides a visible logout button in the code-server status bar
- `c.JupyterHub.shutdown_on_logout = True` stops the user's container on logout

---

## 4. Production Deployment on Kubernetes (K8s)

Moving from Docker Compose to Kubernetes involves separating the services and leveraging K8s for scalability and persistence.

### Architecture Transition

| Component | Docker Compose | Kubernetes |
|-----------|----------------|------------|
| **Portal** | `app` container | Deployment + Service (ClusterIP) |
| **Database** | `db` container | Cloud SQL / RDS or StatefulSet (Postgres) |
| **JupyterHub** | `jupyterhub` container | **Helm Chart (Zero to JupyterHub)** |
| **User Containers** | DockerSpawner (Sibling containers) | **KubeSpawner** (Pods per user) |
| **Ingress** | N/A (Direct port) | Ingress Controller (Nginx/Traefik) + CertManager |

![Kubernetes Architecture](file:///d:/WhatsApp%20Unknown%202026-01-08%20at%2018.12.40/k8s_architecture.svg)

### Step-by-Step Deployment Guide

#### Phase 1: Infrastructure
1.  **Cluster**: Provision a K8s cluster (GKE, EKS, AKS).
2.  **Database**: Provision a managed PostgreSQL database.
3.  **Storage**: Ensure a default StorageClass is available for Persistent Volumes (User home directories).

#### Phase 2: Deploying JupyterHub
Use the official [Zero to JupyterHub with Kubernetes (Z2JH)](https://z2jh.jupyter.org/) Helm chart. This replaces our manual `Dockerfile.jupyterhub` and `jupyterhub_config.py`.

**`config.yaml` for Helm:**
```yaml
hub:
  config:
    JupyterHub:
      authenticator_class: "dummy" # Or LDAP/SAML
  services:
    portal:
      apiToken: "secure-token-shared-with-portal"
      admin: true

singleuser:
  image:
    name: "your-registry/jupyter-codeserver" # Build and push Dockerfile.user
    tag: "latest"
  defaultUrl: "/lab"
  profileList:
    - display_name: "VS Code"
      default: true
      kubespawner_override:
        default_url: "/vscode"
```

#### Phase 3: Deploying the Management Portal
1.  **Build Image**: Push the `app/` code as a Docker image to your container registry.
2.  **Deployment Manifest (`portal-deployment.yaml`)**:
    ```yaml
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: management-portal
    spec:
      replicas: 2
      selector:
        matchLabels:
          app: portal
      template:
        metadata:
          labels:
            app: portal
        spec:
          containers:
          - name: portal
            image: your-registry/management-portal:latest
            env:
            - name: JUPYTERHUB_API_URL
              value: "http://proxy-public/hub/api" # Internal K8s DNS
            - name: DB_URI
              value: "postgresql://user:pass@db-host/dbname"
    ```
3.  **Service**: Expose the portal via a Service.

#### Phase 4: Ingress & Routing
Configure an Ingress to route traffic. typically:
-   `hub.example.com` -> JupyterHub Proxy
-   `portal.example.com` -> Management Portal Service

#### Phase 5: connecting the pieces
-   Update `routes.py` in the Portal to point to the **internal K8s DNS name** of the JupyterHub API service (e.g., `http://hub:8081`).
-   Ensure the Portal uses the `service` API token defined in the Helm chart `config.yaml`.
-   Update the `User` containers to have network policies allowing access back to the Hub if needed (usually handled by Z2JH).

### Key Production Considerations
-   **Persistence**: Use `PersistentVolumeClaims` (PVCs) for `/home/jovyan` to ensure user data survives restarts.
-   **Autoscaling**: Enable Cluster Autoscaler to spin up nodes as more users spawn servers.
-   **Security**: Use TLS (Let's Encrypt) for all Ingress routes. Store secrets (DB passwords, API tokens) in K8s Secrets, not environment variables.
