$headers = @{ Authorization = "token portal-api-token-hub-a" }
Write-Host "Creating user testuser2..."
try {
    Invoke-RestMethod -Method Post -Uri "http://localhost:30000/hub/api/users/testuser2" -Headers $headers | ConvertTo-Json
} catch {
    Write-Host "Create Error: $_"
}

Start-Sleep -Seconds 1
Write-Host "Spawning server..."
try {
    Invoke-RestMethod -Method Post -Uri "http://localhost:30000/hub/api/users/testuser2/server" -Headers $headers | ConvertTo-Json
} catch {
    Write-Host "Spawn Error: $_"
}
