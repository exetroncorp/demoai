from jupyterhub.handlers import BaseHandler, LogoutHandler
from jupyterhub.auth import Authenticator
from jupyterhub.auth import LocalAuthenticator
from jupyterhub.utils import url_path_join
import jwt
from tornado import (
    gen,
    web,
)
from traitlets import (
    Bool,
    List,
    Unicode,
)
from urllib import parse



import sys
sys.stderr.write("DEBUG: jwtauthenticator module LOADED v2\n")
sys.stderr.flush()

class JSONWebTokenLogoutHandler(LogoutHandler):
    async def get(self):
        sys.stderr.write("DEBUG: JSONWebTokenLogoutHandler ENTERED\n")
        user = self.current_user
        sys.stderr.write(f"DEBUG: User found: {user.name if user else 'None'}\n")
        
        if user:
            if self.shutdown_on_logout:
                 sys.stderr.write(f"DEBUG: Stopping servers for {user.name}\n")
                 await self.stop_servers(user)
                 
            await self.clear_cookie()
            self.clear_cookie(self.authenticator.cookie_name)
        
        # In JupyterHub, logout_redirect_url is typically on the Authenticator or the App
        # Authenticator's logout_redirect_url is what we want if set.
        logout_url = self.authenticator.logout_redirect_url
        if not logout_url:
            logout_url = self.settings.get('logout_redirect_url')
            
        sys.stderr.write(f"DEBUG: Redirecting to logout_url: {logout_url}\n")
        sys.stderr.flush()
        
        if logout_url:
            self.redirect(logout_url)
        else:
            self.redirect(self.get_login_url())

class JSONWebTokenLoginHandler(BaseHandler):
    async def get(self):
        header_name = self.authenticator.header_name
        cookie_name = self.authenticator.cookie_name
        param_name = self.authenticator.param_name
        
        sys.stderr.write(f"DEBUG: Config check - param_name={param_name}, header={header_name}, cookie={cookie_name}\n")
        sys.stderr.write(f"DEBUG: Secret (first 5 chars)={self.authenticator.secret[:5] if self.authenticator.secret else 'None'}\n")
        sys.stderr.write(f"DEBUG: Algorithms={self.authenticator.algorithms}\n")
        sys.stderr.write(f"DEBUG: Audience={self.authenticator.expected_audience}\n")
        sys.stderr.flush()

        auth_header_content = self.request.headers.get(header_name, "") if header_name else None
        auth_cookie_content = self.get_cookie(cookie_name, "") if cookie_name else None
        auth_param_content = self.get_argument(param_name, default="") if param_name else None
        
        sys.stderr.write(f"DEBUG: Token content - Param: {bool(auth_param_content)}, Header: {bool(auth_header_content)}\n")
        if auth_param_content:
             sys.stderr.write(f"DEBUG: Token from param: {auth_param_content}\n")
        sys.stderr.flush()

        signing_certificate = self.authenticator.signing_certificate
        secret = self.authenticator.secret
        algorithms = self.authenticator.algorithms

        username_claim_field = self.authenticator.username_claim_field
        extract_username = self.authenticator.extract_username
        audience = self.authenticator.expected_audience

        auth_url = self.authenticator.auth_url
        retpath_param = self.authenticator.retpath_param

        _url = url_path_join(self.hub.server.base_url, 'home')
        next_url = self.get_argument('next', default=False)
        if next_url:
            _url = next_url
            if param_name:
                auth_param_content_qs = parse.parse_qs(parse.urlparse(next_url).query).get(param_name, "")
                if isinstance(auth_param_content_qs, list):
                    auth_param_content_qs = auth_param_content_qs[0]
                # If we didn't find it in the main args, check the next url query params? 
                # The original code seems to overwrite auth_param_content here if it finds it in next_url??
                if auth_param_content_qs:
                     sys.stderr.write(f"DEBUG: Found token in next_url: {auth_param_content_qs}\n")
                     auth_param_content = auth_param_content_qs

        if auth_url and retpath_param:
            auth_url += ("{prefix}{param}=https://{host}{url}".format(
                prefix='&' if '?' in auth_url else '?',
                param=retpath_param,
                host=self.request.host,
                url=_url,
            ))

        if bool(auth_header_content) + bool(auth_cookie_content) + bool(auth_param_content) > 1:
            raise web.HTTPError(400)
        elif auth_header_content:
            token = auth_header_content
        elif auth_cookie_content:
            token = auth_cookie_content
        elif auth_param_content:
            token = auth_param_content
        else:
            sys.stderr.write("DEBUG: No token found in any source\n")
            sys.stderr.flush()
            return self.auth_failed(auth_url)

        try:
            if secret:
                claims = self.verify_jwt_using_secret(token, secret, algorithms, audience)
            elif signing_certificate:
                claims = self.verify_jwt_with_claims(token, signing_certificate, audience)
            else:
                sys.stderr.write("DEBUG: No secret or cert configured\n")
                sys.stderr.flush()
                return self.auth_failed(auth_url)
        except jwt.exceptions.InvalidTokenError as e:
            sys.stderr.write(f"DEBUG: InvalidTokenError: {e}\n")
            sys.stderr.flush()
            return self.auth_failed(auth_url)
        except Exception as e:
            sys.stderr.write(f"DEBUG: Unknown Error verifying token: {e}\n")
            sys.stderr.flush()
            return self.auth_failed(auth_url)

        username = self.retrieve_username(claims, username_claim_field, extract_username=extract_username)
        user = await self.auth_to_user({'name': username})
        self.set_login_cookie(user)

        self.redirect(_url)

    def auth_failed(self, redirect_url):
        if redirect_url:
            self.redirect(redirect_url)
        else:
            raise web.HTTPError(401)

    @staticmethod
    def verify_jwt_with_claims(token, signing_certificate, audience):
        opts = {}
        if not audience:
            opts = {"verify_aud": False}
        with open(signing_certificate, 'r') as rsa_public_key_file:
            return jwt.decode(token, rsa_public_key_file.read(), audience=audience, options=opts)

    @staticmethod
    def verify_jwt_using_secret(json_web_token, secret, algorithms, audience):
        opts = {}
        if not audience:
            opts = {"verify_aud": False}
        return jwt.decode(json_web_token, secret, algorithms=algorithms, audience=audience, options=opts)

    @staticmethod
    def retrieve_username(claims, username_claim_field, extract_username):
        username = claims[username_claim_field]
        if extract_username:
            if "@" in username:
                return username.split("@")[0]
        return username


class JSONWebTokenAuthenticator(Authenticator):
    """
    Accept the authenticated JSON Web Token from header.
    """
    auth_url = Unicode(
        config=True,
        help="""URL for redirecting to in the case of invalid auth token""")

    retpath_param = Unicode(
        config=True,
        help="""Name of query param for auth_url to pass return URL""")

    header_name = Unicode(
        config=True,
        help="""HTTP header to inspect for the authenticated JSON Web Token.""")

    cookie_name = Unicode(
        config=True,
        help="""The name of the cookie field used to specify the JWT token""")

    param_name = Unicode(
        config=True,
        help="""The name of the query parameter used to specify the JWT token""")

    signing_certificate = Unicode(
        config=True,
        help="""
        The public certificate of the private key used to sign the incoming JSON Web Tokens.

        Should be a path to an X509 PEM format certificate filesystem.
        """
    )

    secret = Unicode(
        config=True,
        help="""Shared secret key for siging JWT token. If defined, it overrides any setting for signing_certificate""")

    algorithms = List(
        default_value=['HS256'],
        config=True,
        help="""Specify which algorithms you would like to permit when validating the JWT""")

    username_claim_field = Unicode(
        default_value='username',
        config=True,
        help="""
        The field in the claims that contains the user name. It can be either a straight username,
        of an email/userPrincipalName.
        """
    )

    extract_username = Bool(
        default_value=True,
        config=True,
        help="""
        Set to true to split username_claim_field and take the part before the first `@`
        """
    )

    expected_audience = Unicode(
        default_value='',
        config=True,
        help="""HTTP header to inspect for the authenticated JSON Web Token."""
    )

    def get_handlers(self, app):
        return [
            (r'/login', JSONWebTokenLoginHandler),
            (r'/logout', JSONWebTokenLogoutHandler),
        ]

    @gen.coroutine
    def authenticate(self, *args):
        raise NotImplementedError()


class JSONWebTokenLocalAuthenticator(JSONWebTokenAuthenticator, LocalAuthenticator):
    """
    A version of JSONWebTokenAuthenticator that mixes in local system user creation
    """
    pass
