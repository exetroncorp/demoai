import os
import dockerspawner

c = get_config()

# ============================================================
# OAuth2 / OIDC Authentication Configuration
# ============================================================

from oauthenticator.generic import GenericOAuthenticator

c.JupyterHub.authenticator_class = GenericOAuthenticator

# Portal URLs
# Internally (container -> host), we use host.docker.internal
# Externally (browser -> portal), we use the public URL
portal_internal = "http://host.docker.internal:5000"
portal_public = "http://localhost:5000"

c.GenericOAuthenticator.client_id = 'jupyterhub-portal'
c.GenericOAuthenticator.client_secret = 'jupyterhub-secret'
c.GenericOAuthenticator.token_url = f'{portal_internal}/oauth/token'
c.GenericOAuthenticator.userdata_url = f'{portal_internal}/oauth/userinfo'
c.GenericOAuthenticator.authorize_url = f'{portal_public}/oauth/authorize'
# c.GenericOAuthenticator.oidc_issuer_url = portal_public # GenericOAuthenticator might not support this directly, passing via extra params if needed
c.GenericOAuthenticator.scope = ['openid', 'profile', 'email']
c.GenericOAuthenticator.username_key = 'preferred_username'

# Logout redirect - sends user to portal after JupyterHub logout
c.GenericOAuthenticator.logout_redirect_url = os.environ.get('PORTAL_LOGOUT_URL', 'http://localhost:5000/')

# Allow all authorized users from the portal to login
c.Authenticator.allow_all = True


# ============================================================
# DockerSpawner Configuration
# ============================================================

# Use DockerSpawner
c.JupyterHub.spawner_class = 'dockerspawner.DockerSpawner'

# Environment variables
c.DockerSpawner.environment = {
    'PASSWORD': 'password123', # Or some default/dynamic password
    'DOCKER_RESOURCE_CPU': '1',
    'DOCKER_RESOURCE_MEMORY': '1024M',
    'JUPYTERHUB_CHECK_HUB_VERSION': 'False',
}



# The image to use for single-user servers
c.DockerSpawner.image = 'jupyterhub-user-vscode'

# JupyterHub needs to be accessible from the spawned containers
network_name = os.environ.get('DOCKER_NETWORK_NAME', 'jupyterhub_network')
c.DockerSpawner.network_name = network_name

# Tell the single-user containers where to find the hub
# Since they are on the same docker network, they can use the hub's container name
c.DockerSpawner.hub_connect_ip = 'jupyterhub'

# The hub's IP address inside the container
c.JupyterHub.hub_ip = '0.0.0.0'

# ============================================================
# Single-User Server Configuration
# ============================================================

# DISABLE authentication on the single-user server to prevent OAuth loops
# Using empty strings without extra quotes, and setting IP
c.DockerSpawner.cmd = ['jupyterhub-singleuser']
c.DockerSpawner.args = [
    '--ServerApp.token=', 
    '--ServerApp.password=', 
    '--ServerApp.disable_check_xsrf=True',
    '--debug'
]



# Persistent storage for users
notebook_dir = os.environ.get('DOCKER_NOTEBOOK_DIR', '/home/coder')
# Ensure the volume is writable by UID 1000 (coder)
c.DockerSpawner.notebook_dir = notebook_dir
c.DockerSpawner.volumes = { 'jupyterhub-user-{username}': notebook_dir }

# Remove containers when they stop - useful for development to avoid stale state
c.DockerSpawner.remove = True

# ============================================================
# Cookie and Session Configuration
# ============================================================

# OAuth state cookie cleanup - prevents cookie explosion causing HTTP 431
# Reduce the OAuth state TTL to clean up cookies faster
c.JupyterHub.cookie_max_age_days = 1 # Expire cookies daily
c.JupyterHub.shutdown_on_logout = True

c.JupyterHub.logout_redirect_url = os.environ.get('PORTAL_LOGOUT_URL', '')


# Increase spawn timeout
c.Spawner.http_timeout = 60
c.Spawner.start_timeout = 60
c.DockerSpawner.http_timeout = 60

# ============================================================
# Debugging
# ============================================================

c.JupyterHub.log_level = 'DEBUG'
c.DockerSpawner.debug = True

# ============================================================
# Service API token for the portal backend
# ============================================================

c.JupyterHub.services = [
    {
        'name': 'portal',
        'api_token': 'portal-api-token',
        'admin': True,
    }
]

