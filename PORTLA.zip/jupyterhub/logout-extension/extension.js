const vscode = require('vscode');

/**
 * @param {vscode.ExtensionContext} context
 */
function activate(context) {
    console.log('JupyterHub Logout extension activated');

    // Create status bar item with logout button
    const logoutButton = vscode.window.createStatusBarItem(
        vscode.StatusBarAlignment.Right,
        0 // Low priority = appears on the right
    );

    logoutButton.text = "$(sign-out) Logout";
    logoutButton.tooltip = "Logout and return to Portal";
    logoutButton.command = "jupyterhub.logout";
    logoutButton.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    logoutButton.show();

    // Register the logout command
    const logoutCommand = vscode.commands.registerCommand('jupyterhub.logout', async () => {
        const selection = await vscode.window.showInformationMessage(
            'Are you sure you want to logout? Click OK, then navigate to the logout URL that opens.',
            'Yes, Logout',
            'Cancel'
        );

        if (selection === 'Yes, Logout') {
            // In code-server browser context, we need to use the workbench command
            // to open a URL in a new browser tab
            try {
                // Try the workbench openUrl command first
                await vscode.commands.executeCommand('vscode.open', vscode.Uri.parse('http://localhost:8000/hub/logout'));
            } catch (e1) {
                try {
                    // Alternative: Use simpleBrowser.api.open
                    await vscode.commands.executeCommand('simpleBrowser.api.open', 'http://localhost:8000/hub/logout', {
                        viewColumn: vscode.ViewColumn.Active
                    });
                } catch (e2) {
                    // Final fallback: show instructions
                    const action = await vscode.window.showWarningMessage(
                        'Unable to open logout URL automatically. Please open this URL in your browser: http://localhost:8000/hub/logout',
                        'Copy URL'
                    );
                    if (action === 'Copy URL') {
                        await vscode.env.clipboard.writeText('http://localhost:8000/hub/logout');
                        vscode.window.showInformationMessage('URL copied to clipboard!');
                    }
                }
            }
        }
    });

    context.subscriptions.push(logoutButton);
    context.subscriptions.push(logoutCommand);
}

function deactivate() { }

module.exports = {
    activate,
    deactivate
};
