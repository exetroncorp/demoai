
import os
import sys

# Ensure we can import from app folder
sys.path.append(os.path.join(os.getcwd(), 'app'))

from app import app, db, User, hash_password

def verify():
    with app.app_context():
        print(f"DB URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
        # print(f"Instance Path: {app.instance_path}")
        
        users = User.query.all()
        print(f"Found {len(users)} users:")
        for u in users:
            print(f"- {u.uid} (Role: {u.role}) | Hash: {u.password_hash[:10]}...")
            
        # Verify superadmin credentials
        salt = os.environ.get('PASSWORD_SALT', 'default-salt')
        expected_hash = hash_password('admin123')
        print(f"\nExpected hash for 'admin123' with salt '{salt}': {expected_hash[:10]}...")
        
        sa = User.query.filter_by(uid='superadmin').first()
        if sa:
            if sa.password_hash == expected_hash:
                print("Superadmin password matches!")
            else:
                print("Superadmin password MISMATCH!")
                print(f"Stored: {sa.password_hash}")
                print(f"Calced: {expected_hash}")
                
        # Also check admin
        ad = User.query.filter_by(uid='admin').first()
        if ad:
            if ad.password_hash == expected_hash:
                print("Admin password matches!")
            else:
                print("Admin password MISMATCH!")

if __name__ == '__main__':
    verify()
