$job = Start-Job -ScriptBlock { kubectl port-forward svc/jupyterhub-a 8094:8000 -n jupyterhub }
Start-Sleep -Seconds 5
$headers = @{ Authorization = "token portal-api-token-hub-a" }
Write-Host "Creating user testuser3..."
try {
    Invoke-RestMethod -Method Post -Uri "http://localhost:8094/hub/api/users/testuser3" -Headers $headers | ConvertTo-Json
} catch {
    Write-Host "Create Error: $_"
}

Start-Sleep -Seconds 1
Write-Host "Spawning server..."
try {
    Invoke-RestMethod -Method Post -Uri "http://localhost:8094/hub/api/users/testuser3/server" -Headers $headers | ConvertTo-Json
} catch {
    Write-Host "Spawn Error: $_"
}
Stop-Job $job
Receive-Job $job
