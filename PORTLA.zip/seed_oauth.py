
import os
import sys

# Ensure we can import from app folder
sys.path.append(os.path.join(os.getcwd(), 'app'))

from app import create_app, db, OAuth2Client, User

def seed_oauth():
    app = create_app()
    with app.app_context():
        print(f"DB URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
        
        # Check if client exists
        client = OAuth2Client.query.filter_by(client_id='jupyterhub-portal').first()
        if client:
            print("Client 'jupyterhub-portal' already exists.")
            return

        # Get admin user
        admin = User.query.filter_by(uid='admin').first()
        if not admin:
            # Fallback to superadmin if admin not found
            admin = User.query.filter_by(uid='superadmin').first()
            if not admin:
                 # Fallback to any user
                 admin = User.query.first()
        
        if not admin:
            print("Error: No users found to attach client to.")
            return

        print(f"Creating OAuth client for user {admin.uid}...")
        client = OAuth2Client(
            client_id='jupyterhub-portal',
            client_secret='jupyterhub-secret',
            user_id=admin.id_utilisateur
        )
        client.set_client_metadata({
            'client_name': 'JupyterHub',
            'client_uri': 'http://localhost:5000',
            'grant_types': ['authorization_code', 'refresh_token'],
            'redirect_uris': ['http://localhost:30000/hub/oauth_callback'],
            'response_types': ['code'],
            'scope': 'openid profile email',
            'token_endpoint_auth_method': 'client_secret_post'
        })
        db.session.add(client)
        db.session.commit()
        print("Success: OAuth client created.")

if __name__ == '__main__':
    seed_oauth()
