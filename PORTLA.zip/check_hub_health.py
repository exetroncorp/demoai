import requests

HUB_URL = "http://localhost:8000"

def check_hub():
    try:
        print(f"Checking {HUB_URL}/hub/health...")
        resp = requests.get(f"{HUB_URL}/hub/health")
        print(f"Health Check: {resp.status_code}")
        
        print(f"Checking {HUB_URL}/hub/oauth_login...")
        resp = requests.get(f"{HUB_URL}/hub/oauth_login", allow_redirects=False)
        print(f"OAuth Login status: {resp.status_code}")
        if resp.status_code == 302:
            print(f"Redirects to: {resp.headers.get('Location')}")
        else:
            print("Did not redirect as expected.")

    except requests.exceptions.ConnectionError:
        print("❌ Connection Refused / Reset - JupyterHub might be down.")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    check_hub()
