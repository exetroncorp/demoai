# Development Mode Setup

This guide explains how to run the JupyterHub Portal in development mode with:
- **SQLite database** (no PostgreSQL required)
- **JWT authentication** for JupyterHub integration
- **Local backend/frontend** (Flask dev server)
- **Docker only for JupyterHub**

## Prerequisites

- Python 3.10+
- Docker Desktop
- Docker Compose

## Quick Start (Windows)

```powershell
.\run_dev.ps1
```

## Quick Start (Unix/Linux/Mac)

```bash
chmod +x run_dev.sh
./run_dev.sh
```

## Manual Setup

### 1. Build JupyterHub User Image

```powershell
cd jupyterhub
docker build -t jupyterhub-user-vscode -f Dockerfile.user .
cd ..
```

### 2. Start JupyterHub in Docker

```powershell
docker-compose -f docker-compose.dev.yml up -d --build
```

### 3. Install Python Dependencies

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
```

### 4. Set Environment Variables

```powershell
$env:FLASK_ENV = "development"
$env:FLASK_DEBUG = "1"
$env:AUTH_MODE = "dummy"
$env:SECRET_KEY = "dev-secret-key-change-in-production"
$env:JWT_SECRET_KEY = "dev-jwt-secret-key-change-in-production"
$env:JUPYTERHUB_API_URL = "http://localhost:8000/hub/api"
$env:JUPYTERHUB_API_TOKEN = "portal-api-token"
$env:JUPYTERHUB_PUBLIC_URL = "http://localhost:8000"
```

### 5. Run Flask Development Server

```powershell
cd app
python app.py
```

## Access the Application

- **Portal**: http://localhost:5000
- **JupyterHub**: http://localhost:8000

## Test Credentials

| Username | Password | Role |
|----------|----------|------|
| admin | admin123 | Admin |
| user | user123 | Developer |
| alice | alice123 | Developer |
| bob | bob123 | Developer |
| carol | carol123 | Developer |
| dave | dave123 | Developer (VS Code) |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Development Mode                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────┐     JWT Token      ┌─────────────────────┐│
│  │   Flask Portal   │  ──────────────►   │    JupyterHub       ││
│  │   (Local)        │   auth_token       │    (Docker)         ││
│  │   Port 5000      │                    │    Port 8000        ││
│  └────────┬─────────┘                    └──────────┬──────────┘│
│           │                                         │            │
│           │                                         │            │
│  ┌────────▼─────────┐                    ┌──────────▼──────────┐│
│  │   SQLite DB      │                    │  User Containers    ││
│  │   (Local)        │                    │  (Docker)           ││
│  └──────────────────┘                    └─────────────────────┘│
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## JWT Authentication Flow

1. User logs into Portal at `http://localhost:5000`
2. Portal authenticates user against SQLite database  
3. On "Launch Environment", Portal generates JWT token containing:
   - `uid`: Username
   - `email`: User's email
   - `name`: Full name
   - `role`: User role (admin/dev)
   - `exp`: Expiration timestamp
4. Portal redirects to JupyterHub with `auth_token` query parameter:
   ```
   http://localhost:8000/hub/login?auth_token=<JWT>&next=/user/<username>/lab
   ```
5. JupyterHub's `jwtauthenticator-v2` validates the JWT
6. User is authenticated and redirected to their notebook/VS Code

## Configuration

### Portal (app/config.py)

| Variable | Description | Default |
|----------|-------------|---------|
| `JWT_SECRET_KEY` | JWT signing key (must match JupyterHub) | `dev-jwt-secret-key-...` |
| `JUPYTERHUB_API_URL` | JupyterHub API endpoint | `http://localhost:8000/hub/api` |
| `JUPYTERHUB_API_TOKEN` | Service API token | `portal-api-token` |
| `JUPYTERHUB_PUBLIC_URL` | Public URL for redirects | `http://localhost:8000` |

### JupyterHub (jupyterhub/jupyterhub_config.py)

| Variable | Description |
|----------|-------------|
| `JWT_SECRET_KEY` | Must match Portal's secret |
| `JSONWebTokenAuthenticator.param_name` | `auth_token` |
| `JSONWebTokenAuthenticator.username_claim_field` | `uid` |

## Troubleshooting

### JupyterHub not starting
```powershell
docker-compose -f docker-compose.dev.yml logs jupyterhub
```

### JWT Authentication failing
1. Ensure `JWT_SECRET_KEY` matches in both Portal and JupyterHub
2. Check JupyterHub logs for JWT validation errors
3. Verify token contains `uid` claim

### SQLite database errors
```powershell
# Delete and recreate the database
rm app/instance/jupyterhub_portal.db
python app/app.py  # Will recreate with seed data
```
