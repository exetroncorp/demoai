from jwtauthenticator.jwtauthenticator import JSONWebTokenAuthenticator
import jwt
import os

secret = os.environ.get('JWT_SECRET_KEY', 'dev-jwt-secret-key-change-in-production')
token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJkYXZlIiwiZW1haWwiOiJkYXZlQGV4YW1wbGUuY29tIiwibmFtZSI6IkRhdmUgQ29kZXIiLCJyb2xlIjoiZGV2IiwiZXhwIjoxNzY4NTA5OTY2LCJpYXQiOjE3Njg0ODExNjZ9.rksdgd2WUyY3heN23iegJ1lDp70Eo5cz8eKHAJpIP9g'

print(f"Testing Token: {token}")
print(f"Secret: {secret}")

try:
    payload = jwt.decode(token, secret, algorithms=['HS256'], audience='', options={'verify_aud': False})
    print("SUCCESS! Payload:", payload)
except Exception as e:
    print(f"FAILURE! Error: {e}")
