import requests
import sys

# The URL provided by the user (with the token)
url = "http://localhost:8000/hub/login?auth_token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJkYXZlIiwiZW1haWwiOiJkYXZlQGV4YW1wbGUuY29tIiwibmFtZSI6IkRhdmUgQ29kZXIiLCJyb2xlIjoiZGV2IiwiZXhwIjoxNzY4NTEwNjQ5LCJpYXQiOjE3Njg0ODE4NDl9.J_QKJB_g4ztxdCLb1v4-aDIpmWOkfJshlenApVjkIkY&next=/user/dave/vsco"

try:
    print(f"Testing URL: {url}")
    session = requests.Session()
    response = session.get(url, allow_redirects=False)
    
    print(f"Status Code: {response.status_code}")
    print(f"Headers: {response.headers}")
    print(f"Cookies: {session.cookies.get_dict()}")
    
    if response.status_code == 302:
        print(f"Redirect Location: {response.headers.get('Location')}")
        # Follow redirect manually to trace
        response2 = session.get(response.headers.get('Location'), allow_redirects=False)
        print(f"Follow-up Status: {response2.status_code}")
        print(f"Follow-up Headers: {response2.headers}")
    else:
        print("Response Content (first 500 chars):")
        print(response.text[:500])

except Exception as e:
    print(f"Error: {e}")
