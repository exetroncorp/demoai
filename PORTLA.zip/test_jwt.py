from jwtauthenticator.jwtauthenticator import JSONWebTokenAuthenticator
j = JSONWebTokenAuthenticator()
print('param_name:', j.param_name)
print('secret:', j.secret[:20] if j.secret else 'NONE')
print('username_claim_field:', j.username_claim_field)
print('expected_audience:', repr(j.expected_audience))
print('signing_certificate:', j.signing_certificate)
