
import os
import sys

# Ensure we can import from app folder
sys.path.append(os.path.join(os.getcwd(), 'app'))

from app import create_app, db, OAuth2Client

def debug_oauth():
    app = create_app()
    with app.app_context():
        print(f"DB URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
        
        clients = OAuth2Client.query.all()
        print(f"Found {len(clients)} OAuth2 clients:")
        for c in clients:
            print(f"\nClient ID: {c.client_id}")
            print(f"Redirect URIs: {c.client_metadata.get('redirect_uris')}")
            print(f"Scopes: {c.client_metadata.get('scope')}")
            print(f"Grants: {c.client_metadata.get('grant_types')}")
            print(f"Auth Method: {c.client_metadata.get('token_endpoint_auth_method')}")
            print("-" * 30)

if __name__ == '__main__':
    debug_oauth()
