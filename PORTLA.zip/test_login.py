
import requests
import sys

BASE_URL = "http://localhost:5000"

def test_login(username, password):
    s = requests.Session()
    # Get login page to grab csrf if needed (flask-wtf usually needs it, but app seems to handle it or disable it?)
    # app/auth.py login route just checks request.form.
    
    data = {
        'username': username,
        'password': password
    }
    
    print(f"Attempting login for {username}...")
    resp = s.post(f"{BASE_URL}/login", data=data, allow_redirects=False)
    
    print(f"Status Code: {resp.status_code}")
    if resp.status_code == 302:
        print(f"Redirect Location: {resp.headers.get('Location')}")
        if resp.headers.get('Location', '').endswith('/dashboard'):
            print("SUCCESS: Logged in and redirected to dashboard.")
            return True
        elif resp.headers.get('Location', '').endswith('/login'):
            print("FAILURE: Redirected back to login (likely failure).")
            return False
        else:
             print(f"Redirected to unknown: {resp.headers.get('Location')}")
             return True # Maybe auto-connect?
    else:
        print("FAILURE: Did not redirect. Checking for flash messages...")
        # Simple extraction of likely flash message
        if "Invalid username or password" in resp.text:
            print("  -> Found 'Invalid username or password' error.")
        elif "Authentication required" in resp.text:
             print("  -> Found 'Authentication required' error.")
        else:
             print("  -> Could not find standard error message. Dumping first 500 chars:")
             print(resp.text[:500])
        return False

if __name__ == "__main__":
    success = True
    if not test_login('admin', 'admin123'):
        success = False
    
    print("-" * 20)
    
    if not test_login('superadmin', 'admin123'):
        success = False

    if not success:
        sys.exit(1)
