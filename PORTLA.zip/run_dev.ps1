# Development mode startup script for Windows
# Run JupyterHub in Docker, Portal backend locally

Write-Host "=== JupyterHub Portal Development Mode ===" -ForegroundColor Cyan
Write-Host ""

# Check if Docker is running
try {
    docker info | Out-Null
} catch {
    Write-Host "Error: Docker is not running. Please start Docker Desktop." -ForegroundColor Red
    exit 1
}

# Create instance directory for SQLite database
if (!(Test-Path "instance")) {
    New-Item -ItemType Directory -Path "instance" -Force | Out-Null
}

# Step 1: Build JupyterHub user image
Write-Host "Building JupyterHub user image..." -ForegroundColor Yellow
Push-Location jupyterhub
docker build -t jupyterhub-user-vscode -f Dockerfile.user .
Pop-Location

# Step 2: Start JupyterHub in Docker
Write-Host "Starting JupyterHub in Docker..." -ForegroundColor Yellow
docker-compose -f docker-compose.dev.yml up -d --build

Write-Host ""
Write-Host "JupyterHub is starting at http://localhost:30000" -ForegroundColor Green

# Step 3: Create a virtual environment if it doesn't exist
if (!(Test-Path "venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv venv
}

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
& .\venv\Scripts\Activate.ps1

# Step 4: Install Python dependencies
Write-Host ""
Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
pip install -r requirements-dev.txt

# Step 5: Set environment variables
$env:FLASK_ENV = "development"
$env:FLASK_DEBUG = "1"
$env:AUTH_MODE = "dummy"
$env:SECRET_KEY = "dev-secret-key-change-in-production"
$env:JWT_SECRET_KEY = "dev-jwt-secret-key-change-in-production"
$env:JUPYTERHUB_API_URL = "http://localhost:30000/hub/api"
$env:JUPYTERHUB_API_TOKEN = "portal-api-token-hub-a"
$env:JUPYTERHUB_PUBLIC_URL = "http://localhost:30000"
$env:OAUTHLIB_INSECURE_TRANSPORT = "1"

# Step 6: Run Flask development server
Write-Host ""
Write-Host "Starting Flask development server..." -ForegroundColor Yellow
Write-Host "Portal will be available at http://localhost:5000" -ForegroundColor Green

# Ensure no conflicting database URL from environment
if (Test-Path Env:\DATABASE_URL) {
    Remove-Item Env:\DATABASE_URL
}

Write-Host "Test credentials:" -ForegroundColor Cyan
Write-Host "  admin/admin123 (Admin user)"
Write-Host "  user/user123 (Developer user)"
Write-Host ""

Set-Location app
python app.py
