import jwt
import sys
import os
from datetime import datetime

token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJkYXZlIiwiZW1haWwiOiJkYXZlQGV4YW1wbGUuY29tIiwibmFtZSI6IkRhdmUgQ29kZXIiLCJyb2xlIjoiZGV2IiwiZXhwIjoxNzY4NTEwNjQ5LCJpYXQiOjE3Njg0ODE4NDl9.J_QKJB_g4ztxdCLb1v4-aDIpmWOkfJshlenApVjkIkY"
secret = "dev-jwt-secret-key-change-in-production"

try:
    print(f"Token: {token}")
    print(f"Secret: {secret}")
    
    # decode without verification first
    unverified_payload = jwt.decode(token, options={"verify_signature": False})
    print(f"Unverified Payload: {unverified_payload}")
    
    # verify signature
    payload = jwt.decode(token, secret, algorithms=["HS256"])
    print(f"Verified Payload: {payload}")
    print("Token is VALID and signature matches the secret.")
    
except jwt.ExpiredSignatureError:
    print("Token is EXPIRED.")
except jwt.InvalidSignatureError:
    print("Token signature is INVALID. The secret might be different.")
except Exception as e:
    print(f"Error: {e}")
