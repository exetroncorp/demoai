
import os
import sys

# Ensure we can import from app folder
sys.path.append(os.path.join(os.getcwd(), 'app'))

from app import create_app, db, User, hash_password

def verify_current():
    app = create_app()
    with app.app_context():
        print(f"DB URI: {app.config['SQLALCHEMY_DATABASE_URI']}")
        
        users = User.query.all()
        print(f"Found {len(users)} users:")
        for u in users:
            print(f"- {u.uid} (Role: {u.role})")
            
        expected = hash_password('admin123')
        sa = User.query.filter_by(uid='superadmin').first()
        if sa:
            print(f"Superadmin found. Hash matches 'admin123'? {sa.password_hash == expected}")
        else:
            print("Superadmin NOT found!")
            
            # Create if missing
            print("Creating superadmin...")
            from models import Entity
            default_entity = Entity.query.filter_by(name='Default').first()
            if not default_entity:
                default_entity = Entity(name='Default', quota=100)
                db.session.add(default_entity)
                db.session.commit()
                
            sa = User(
                uid='superadmin',
                name='Super',
                last_name='Admin',
                role='superadmin',
                identity=default_entity.identity,
                password_hash=expected
            )
            db.session.add(sa)
            db.session.commit()
            print("Superadmin created.")

if __name__ == '__main__':
    verify_current()
