<#
.SYNOPSIS
    Run Portal in Kubernetes Development Mode
.DESCRIPTION
    Starts the Portal backend locally, configured to talk to
    JupyterHub instances running in Kubernetes (via port-forwarding).
#>

Write-Host "=== JupyterHub Portal K8s Development Mode ===" -ForegroundColor Cyan
Write-Host ""

# Check Python environment
if (!(Test-Path "venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv venv
}

# Activate virtual environment
Write-Host "Activating virtual environment..." -ForegroundColor Yellow
& .\venv\Scripts\Activate.ps1

# Install dependencies if needed
Write-Host "Installing/Verifying Python dependencies..." -ForegroundColor Yellow
pip install -r requirements-dev.txt | Out-Null

# Set environment variables for K8s mode
$env:FLASK_ENV = "development"
$env:FLASK_DEBUG = "1"
$env:AUTH_MODE = "dummy"
# IMPORTANT: Use the kubernetes configuration
$env:FLASK_CONFIG = "kubernetes"
$env:OAUTHLIB_INSECURE_TRANSPORT = "1"

# We don't need to set JUPYTERHUB_API_URL etc as they are in the KubernetesDevConfig class

Write-Host ""
Write-Host "Configuration:" -ForegroundColor Cyan
Write-Host "  FLASK_CONFIG: kubernetes"
Write-Host "Hub A: http://localhost:30000" -ForegroundColor Cyan
Write-Host "Hub B: http://localhost:30010" -ForegroundColor Cyan
Write-Host "  Portal: http://localhost:5000"
Write-Host ""
Write-Host "Starting Flask app..." -ForegroundColor Yellow

# Change to app directory so imports work correctly
Set-Location app
python app.py
