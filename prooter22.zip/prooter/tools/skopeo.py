"""Skopeo CLI wrapper for container image operations.

Skopeo is a tool for working with remote container image registries.
It can copy images between registries, inspect images, and more.

For Debian 12: apt-get install skopeo
"""

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Any

from prooter.config import get_config


class SkopeoError(Exception):
    """Exception raised when skopeo command fails."""
    
    def __init__(self, message: str, returncode: int = 1, stderr: str = ""):
        super().__init__(message)
        self.returncode = returncode
        self.stderr = stderr


class Skopeo:
    """Wrapper for skopeo CLI operations.
    
    Provides Python interface for:
    - Copying images between registries/local storage
    - Inspecting image manifests and configs
    - Listing tags from registries
    """
    
    def __init__(self, config=None):
        """Initialize Skopeo wrapper.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or get_config()
        self._binary_path: Optional[Path] = None
    
    @property
    def binary(self) -> Path:
        """Get path to skopeo binary."""
        if self._binary_path:
            return self._binary_path
        
        # Check configured location
        configured = self.config.bin_dir / "skopeo"
        if configured.exists():
            self._binary_path = configured
            return self._binary_path
        
        # Check system PATH
        system_skopeo = shutil.which("skopeo")
        if system_skopeo:
            self._binary_path = Path(system_skopeo)
            return self._binary_path
        
        # Default to configured location (may not exist)
        return configured
    
    def is_available(self) -> bool:
        """Check if skopeo is available."""
        binary = self.binary
        if not binary.exists():
            return False
        
        try:
            result = subprocess.run(
                [str(binary), "--version"],
                capture_output=True,
                timeout=10,
            )
            return result.returncode == 0
        except (subprocess.SubprocessError, OSError):
            return False
    
    def _run(
        self,
        args: List[str],
        capture_output: bool = True,
        timeout: int = 300,
    ) -> subprocess.CompletedProcess:
        """Run skopeo command.
        
        Args:
            args: Command arguments (without 'skopeo' prefix)
            capture_output: Whether to capture stdout/stderr
            timeout: Command timeout in seconds
            
        Returns:
            CompletedProcess result
            
        Raises:
            SkopeoError: If command fails
        """
        if self.is_available():
            cmd = [str(self.binary)] + args
            try:
                result = subprocess.run(
                    cmd,
                    capture_output=capture_output,
                    timeout=timeout,
                    text=True,
                )
                
                if result.returncode != 0:
                    stderr = result.stderr if capture_output else ""
                    raise SkopeoError(
                        f"skopeo command failed: {' '.join(args)}",
                        returncode=result.returncode,
                        stderr=stderr,
                    )
                
                return result
                
            except subprocess.TimeoutExpired:
                raise SkopeoError(f"skopeo command timed out after {timeout}s")
        if self._docker_available():
            return self._run_container(args, capture_output=capture_output, timeout=timeout)
        raise SkopeoError(
            "skopeo not found. Install with: apt-get install skopeo"
        )
    
    def _get_auth_args(self) -> List[str]:
        """Get authentication arguments for skopeo.
        
        Skopeo reads auth from standard locations:
        - ~/.docker/config.json
        - $XDG_RUNTIME_DIR/containers/auth.json
        - ~/.config/containers/auth.json
        
        Returns:
            List of auth-related arguments
        """
        args = []
        
        # Check for prooter auth file
        auth_file = self.config.base_dir / "auth.json"
        if auth_file.exists():
            args.extend(["--authfile", str(auth_file)])
        
        # SSL verification
        if not self.config.verify_ssl:
            args.append("--tls-verify=false")
        
        return args

    def _docker_available(self) -> bool:
        if not shutil.which("docker"):
            return False
        try:
            result = subprocess.run(
                ["docker", "version"],
                capture_output=True,
                timeout=10,
            )
            return result.returncode == 0
        except (subprocess.SubprocessError, OSError):
            return False

    def _run_container(
        self,
        args: List[str],
        capture_output: bool = True,
        timeout: int = 300,
    ) -> subprocess.CompletedProcess:
        base_dir = self.config.base_dir
        container_root = "/prooter"
        container_args = self._translate_args_for_container(args, base_dir, container_root)
        cmd = [
            "docker",
            "run",
            "--rm",
            "-v",
            f"{str(base_dir)}:{container_root}",
            "quay.io/skopeo/stable:latest",
        ] + container_args
        try:
            result = subprocess.run(
                cmd,
                capture_output=capture_output,
                timeout=timeout,
                text=True,
            )
            if result.returncode != 0:
                stderr = result.stderr if capture_output else ""
                raise SkopeoError(
                    f"skopeo command failed: {' '.join(args)}",
                    returncode=result.returncode,
                    stderr=stderr,
                )
            return result
        except subprocess.TimeoutExpired:
            raise SkopeoError(f"skopeo command timed out after {timeout}s")

    def _translate_args_for_container(
        self,
        args: List[str],
        base_dir: Path,
        container_root: str,
    ) -> List[str]:
        translated: List[str] = []
        base_dir = base_dir.resolve()
        i = 0
        while i < len(args):
            arg = args[i]
            if arg == "--authfile" and i + 1 < len(args):
                auth_path = Path(args[i + 1])
                translated.append(arg)
                translated.append(self._map_path(auth_path, base_dir, container_root))
                i += 2
                continue
            if arg.startswith("oci:"):
                translated.append(self._map_oci_arg(arg, base_dir, container_root))
                i += 1
                continue
            translated.append(arg)
            i += 1
        return translated

    def _map_oci_arg(self, arg: str, base_dir: Path, container_root: str) -> str:
        raw = arg[4:]
        if ":" in raw:
            path_part, tag_part = raw.rsplit(":", 1)
            mapped_path = self._map_path(Path(path_part), base_dir, container_root)
            return f"oci:{mapped_path}:{tag_part}"
        mapped_path = self._map_path(Path(raw), base_dir, container_root)
        return f"oci:{mapped_path}"

    def _map_path(self, path: Path, base_dir: Path, container_root: str) -> str:
        try:
            relative = path.resolve().relative_to(base_dir)
        except ValueError:
            raise SkopeoError(f"path outside base dir: {path}")
        return f"{container_root}/{relative.as_posix()}"
    
    def copy(
        self,
        src: str,
        dest: str,
        src_creds: Optional[tuple] = None,
        dest_creds: Optional[tuple] = None,
        insecure: bool = False,
    ) -> None:
        """Copy an image from source to destination.
        
        Args:
            src: Source image reference (e.g., 'docker://alpine:latest')
            dest: Destination reference (e.g., 'oci:/path/to/image:tag')
            src_creds: Optional (username, password) for source
            dest_creds: Optional (username, password) for destination
            insecure: Skip TLS verification
            
        Raises:
            SkopeoError: If copy fails
        """
        args = ["copy"]
        args.extend(self._get_auth_args())
        
        if src_creds:
            args.extend(["--src-creds", f"{src_creds[0]}:{src_creds[1]}"])
        
        if dest_creds:
            args.extend(["--dest-creds", f"{dest_creds[0]}:{dest_creds[1]}"])
        
        if insecure or not self.config.verify_ssl:
            args.append("--src-tls-verify=false")
            args.append("--dest-tls-verify=false")
        
        args.extend([src, dest])
        
        print(f"Copying image: {src} -> {dest}")
        self._run(args, capture_output=False, timeout=600)
    
    def inspect(
        self,
        image: str,
        raw: bool = False,
        config: bool = False,
    ) -> Dict[str, Any]:
        """Inspect an image and return its metadata.
        
        Args:
            image: Image reference (e.g., 'docker://alpine:latest')
            raw: Return raw manifest instead of parsed info
            config: Return config blob instead of manifest
            
        Returns:
            Dictionary with image metadata
            
        Raises:
            SkopeoError: If inspection fails
        """
        args = ["inspect"]
        args.extend(self._get_auth_args())
        
        if raw:
            args.append("--raw")
        if config:
            args.append("--config")
        
        args.append(image)
        
        result = self._run(args)
        return json.loads(result.stdout)
    
    def list_tags(self, image: str) -> List[str]:
        """List available tags for an image.
        
        Args:
            image: Image reference without tag (e.g., 'docker://alpine')
            
        Returns:
            List of available tags
            
        Raises:
            SkopeoError: If listing fails
        """
        args = ["list-tags"]
        args.extend(self._get_auth_args())
        args.append(image)
        
        result = self._run(args)
        data = json.loads(result.stdout)
        return data.get("Tags", [])
    
    def delete(self, image: str) -> None:
        """Delete an image from a registry.
        
        Args:
            image: Image reference to delete
            
        Raises:
            SkopeoError: If deletion fails
        """
        args = ["delete"]
        args.extend(self._get_auth_args())
        args.append(image)
        
        self._run(args)
    
    def pull_to_oci(
        self,
        image_ref: str,
        dest_dir: Path,
        tag: str = "latest",
    ) -> Path:
        """Pull an image to local OCI layout.
        
        Args:
            image_ref: Image reference (e.g., 'alpine:latest' or 'docker://alpine')
            dest_dir: Directory to store OCI image
            tag: Tag name for the OCI reference
            
        Returns:
            Path to the OCI image directory
            
        Raises:
            SkopeoError: If pull fails
        """
        # Normalize image reference
        if not image_ref.startswith(("docker://", "oci:", "dir:")):
            # Assume Docker Hub
            if "/" not in image_ref.split(":")[0]:
                image_ref = f"library/{image_ref}"
            image_ref = f"docker://{image_ref}"
        
        # Parse tag from image_ref if present
        if ":" in image_ref and not image_ref.startswith("docker://"):
            parts = image_ref.rsplit(":", 1)
            if not parts[1].startswith("//"):
                tag = parts[1]
        elif image_ref.startswith("docker://"):
            img_part = image_ref[9:]  # Remove docker://
            if ":" in img_part:
                tag = img_part.split(":")[-1]
        
        # Ensure destination directory exists
        dest_dir.mkdir(parents=True, exist_ok=True)
        
        # Destination in OCI format
        dest = f"oci:{dest_dir}:{tag}"
        
        self.copy(image_ref, dest)
        
        return dest_dir
