"""Docker Registry authentication handling."""

import base64
import json
import os
import requests
from pathlib import Path
from typing import Optional, Dict, Tuple, Any

from prooter.config import get_config


class AuthConfig:
    """Handle persistence of authentication credentials."""
    
    def __init__(self):
        self.config_path = get_config().base_dir / "auth.json"
        
    def load(self) -> Dict[str, Any]:
        """Load auth config from disk."""
        if not self.config_path.exists():
            return {}
        
        try:
            with open(self.config_path, "r") as f:
                return json.load(f)
        except Exception:
            return {}
            
    def save(self, config: Dict[str, Any]) -> None:
        """Save auth config to disk."""
        # Ensure directory exists
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(self.config_path, "w") as f:
            json.dump(config, f, indent=2)
            
    def get_credentials(self, registry: str) -> Optional[Tuple[str, str]]:
        """Get credentials for a registry.
        
        Args:
            registry: Registry hostname
            
        Returns:
            Tuple of (username, password) or None
        """
        # List of config paths to check in order
        config_paths = [
            self.config_path,  # ~/.prooter/auth.json
            Path.home() / ".docker" / "config.json",  # Docker
            Path.home() / ".config" / "containers" / "auth.json",  # Podman/Skopeo (Linux/Unix)
        ]
        
        # Windows specific paths
        if os.name == "nt":
            appdata = os.environ.get("APPDATA")
            if appdata:
                config_paths.append(Path(appdata) / "containers" / "auth.json")
        
        for path in config_paths:
            if not path.exists():
                continue
                
            try:
                with open(path, "r") as f:
                    config = json.load(f)
                    creds = self._extract_creds_from_config(config, registry)
                    if creds:
                        return creds
            except Exception:
                continue
                
        return None

    def _extract_creds_from_config(self, config: Dict[str, Any], registry: str) -> Optional[Tuple[str, str]]:
        """Extract credentials from a config dictionary."""
        auths = config.get("auths", {})
        
        # Check for direct match
        if registry in auths:
            return self._decode_auth(auths[registry].get("auth"))
            
        # Check for docker.io aliases
        if registry == "docker.io" or registry == "registry-1.docker.io":
            for alias in ["https://index.docker.io/v1/", "docker.io", "registry-1.docker.io"]:
                if alias in auths:
                    return self._decode_auth(auths[alias].get("auth"))
                    
        return None
        
    def _decode_auth(self, auth_str: Optional[str]) -> Optional[Tuple[str, str]]:
        """Decode base64 auth string."""
        if not auth_str:
            return None
            
        try:
            decoded = base64.b64decode(auth_str).decode("utf-8")
            if ":" in decoded:
                return tuple(decoded.split(":", 1))
        except Exception:
            pass
        return None

    def set_credentials(self, registry: str, username: str, password: str) -> None:
        """Set credentials for a registry.
        
        Args:
            registry: Registry hostname
            username: Username
            password: Password
        """
        config = self.load()
        if "auths" not in config:
            config["auths"] = {}
            
        auth_str = f"{username}:{password}"
        encoded = base64.b64encode(auth_str.encode("utf-8")).decode("utf-8")
        
        # Normalize docker.io
        if registry in ("docker.io", "registry-1.docker.io"):
            registry = "https://index.docker.io/v1/"
            
        config["auths"][registry] = {"auth": encoded}
        self.save(config)


class RegistryAuth:
    """Handle authentication with Docker registries."""
    
    # Docker Hub auth endpoint
    DOCKER_HUB_AUTH = "https://auth.docker.io/token"
    DOCKER_HUB_SERVICE = "registry.docker.io"
    
    def __init__(self, username: Optional[str] = None, password: Optional[str] = None, verify_ssl: bool = True):
        """Initialize authentication.
        
        Args:
            username: Registry username (optional)
            password: Registry password or token (optional)
            verify_ssl: Whether to verify SSL certificates
        """
        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl
        self.auth_config = AuthConfig()
        self._tokens: Dict[str, str] = {}
        
    def _get_creds(self, registry: str) -> Tuple[Optional[str], Optional[str]]:
        """Get credentials to use, resolving from memory or config."""
        if self.username and self.password:
            return self.username, self.password
            
        return self.auth_config.get_credentials(registry) or (None, None)
    
    def get_token(self, registry: str, repository: str) -> Optional[str]:
        """Get authentication token for a repository.
        
        Args:
            registry: Registry hostname
            repository: Repository name (e.g., 'library/alpine')
            
        Returns:
            Bearer token or None if authentication fails
        """
        cache_key = f"{registry}/{repository}"
        if cache_key in self._tokens:
            return self._tokens[cache_key]
        
        token = self._fetch_token(registry, repository)
        if token:
            self._tokens[cache_key] = token
        return token
    
    def _fetch_token(self, registry: str, repository: str) -> Optional[str]:
        """Fetch a new authentication token.
        
        Args:
            registry: Registry hostname
            repository: Repository name
            
        Returns:
            Bearer token or None
        """
        if registry in ("registry-1.docker.io", "docker.io", ""):
            return self._fetch_docker_hub_token(repository)
        else:
            return self._fetch_generic_token(registry, repository)
    
    def _fetch_docker_hub_token(self, repository: str) -> Optional[str]:
        """Fetch token from Docker Hub.
        
        Args:
            repository: Repository name
            
        Returns:
            Bearer token or None
        """
        params = {
            "service": self.DOCKER_HUB_SERVICE,
            "scope": f"repository:{repository}:pull",
        }
        
        username, password = self._get_creds("docker.io")
        auth = None
        if username and password:
            auth = (username, password)
        
        try:
            response = requests.get(
                self.DOCKER_HUB_AUTH,
                params=params,
                auth=auth,
                timeout=30,
                verify=self.verify_ssl
            )
            response.raise_for_status()
            data = response.json()
            return data.get("token") or data.get("access_token")
        except requests.RequestException as e:
            # Only print warning if we actually tried to authenticate
            if auth:
                print(f"Warning: Failed to get Docker Hub token: {e}")
            return None
    
    def _fetch_generic_token(self, registry: str, repository: str) -> Optional[str]:
        """Fetch token from a generic registry.
        
        Args:
            registry: Registry hostname
            repository: Repository name
            
        Returns:
            Bearer token or None
        """
        # Try to discover auth endpoint from WWW-Authenticate header
        try:
            test_url = f"https://{registry}/v2/"
            # We don't verify SSL for the initial check either if disabled
            response = requests.get(test_url, timeout=10, verify=self.verify_ssl)
            
            if response.status_code == 401:
                auth_header = response.headers.get("WWW-Authenticate", "")
                auth_info = self._parse_www_authenticate(auth_header)
                
                if auth_info:
                    realm, service = auth_info
                    params = {
                        "service": service,
                        "scope": f"repository:{repository}:pull",
                    }
                    
                    username, password = self._get_creds(registry)
                    auth = None
                    if username and password:
                        auth = (username, password)
                    
                    token_response = requests.get(
                        realm,
                        params=params,
                        auth=auth,
                        timeout=30,
                        verify=self.verify_ssl
                    )
                    token_response.raise_for_status()
                    data = token_response.json()
                    return data.get("token") or data.get("access_token")
            
            return None
        except requests.RequestException:
            return None
    
    def _parse_www_authenticate(self, header: str) -> Optional[Tuple[str, str]]:
        """Parse WWW-Authenticate header to extract realm and service.
        
        Args:
            header: WWW-Authenticate header value
            
        Returns:
            Tuple of (realm, service) or None
        """
        if not header.startswith("Bearer "):
            return None
        
        parts = header[7:].split(",")
        params = {}
        
        for part in parts:
            part = part.strip()
            if "=" in part:
                key, value = part.split("=", 1)
                params[key.strip()] = value.strip().strip('"')
        
        realm = params.get("realm")
        service = params.get("service")
        
        if realm and service:
            return (realm, service)
        return None
    
    def get_auth_headers(self, registry: str, repository: str) -> Dict[str, str]:
        """Get authentication headers for API requests.
        
        Args:
            registry: Registry hostname
            repository: Repository name
            
        Returns:
            Dictionary of headers to include in requests
        """
        # First try to get a token (OAuth/Bearer flow)
        token = self.get_token(registry, repository)
        if token:
            return {"Authorization": f"Bearer {token}"}
            
        # Fallback to Basic Auth if no token endpoint found/working
        # (This handles registries that just use Basic Auth directly on v2 API)
        username, password = self._get_creds(registry)
        if username and password:
             auth_str = f"{username}:{password}"
             encoded = base64.b64encode(auth_str.encode("utf-8")).decode("utf-8")
             return {"Authorization": f"Basic {encoded}"}
             
        return {}
