"""Fakechroot-based execution engine using LD_PRELOAD."""

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

from prooter.execution.base import BaseEngine, ExecutionMode


class FakechrootEngine(BaseEngine):
    """Execution engine using Fakechroot (LD_PRELOAD-based).
    
    Fakechroot uses LD_PRELOAD to intercept library calls and provides:
    - Chroot-like path translation
    - Combined with fakeroot for uid/gid faking
    
    This is faster than PRoot but has limitations:
    - Does not work with statically linked binaries
    - May have issues with some symlinks
    - Requires compatible fakechroot libraries
    """
    
    mode = ExecutionMode.FAKECHROOT
    
    def __init__(self, config=None):
        """Initialize Fakechroot engine."""
        super().__init__(config)
        self._fakechroot_path: Optional[Path] = None
        self._fakeroot_path: Optional[Path] = None
    
    @property
    def fakechroot_binary(self) -> Optional[Path]:
        """Get path to fakechroot binary."""
        if self._fakechroot_path:
            return self._fakechroot_path
        
        # Check system PATH
        system_fakechroot = shutil.which("fakechroot")
        if system_fakechroot:
            self._fakechroot_path = Path(system_fakechroot)
            return self._fakechroot_path
        
        return None
    
    @property
    def fakeroot_binary(self) -> Optional[Path]:
        """Get path to fakeroot binary."""
        if self._fakeroot_path:
            return self._fakeroot_path
        
        # Check system PATH
        system_fakeroot = shutil.which("fakeroot")
        if system_fakeroot:
            self._fakeroot_path = Path(system_fakeroot)
            return self._fakeroot_path
        
        return None
    
    def is_available(self) -> bool:
        """Check if Fakechroot is available."""
        fakechroot = self.fakechroot_binary
        fakeroot = self.fakeroot_binary
        
        if not fakechroot or not fakeroot:
            return False
        
        # Verify they're executable
        try:
            result1 = subprocess.run(
                [str(fakechroot), "--version"],
                capture_output=True,
                timeout=5,
            )
            result2 = subprocess.run(
                [str(fakeroot), "--version"],
                capture_output=True,
                timeout=5,
            )
            return result1.returncode == 0 and result2.returncode == 0
        except (subprocess.SubprocessError, OSError):
            return False
    
    def run(
        self,
        rootfs: Path,
        command: List[str],
        env: Dict[str, str],
        working_dir: str = "/",
        volumes: Optional[List[tuple]] = None,
        interactive: bool = False,
        tty: bool = False,
        user: Optional[str] = None,
        stdout_path: Optional[Path] = None,
        stderr_path: Optional[Path] = None,
    ) -> int:
        """Run a command using Fakechroot.
        
        Args:
            rootfs: Path to the root filesystem
            command: Command to execute
            env: Environment variables
            working_dir: Working directory inside container
            volumes: List of (host_path, container_path) tuples
            interactive: Keep stdin open
            tty: Allocate a pseudo-TTY
            user: User to run as (ignored, always fakes root)
            
        Returns:
            Exit code of the command
        """
        if not self.is_available():
            raise RuntimeError(
                "Fakechroot is not available. Install fakechroot and fakeroot packages."
            )
        
        fakechroot = self.fakechroot_binary
        fakeroot = self.fakeroot_binary
        
        # Prepare environment
        full_env = self.prepare_env(env, rootfs)
        
        # Set fakechroot environment
        full_env["FAKECHROOT"] = "true"
        full_env["FAKECHROOT_BASE"] = str(rootfs)
        
        # Handle volumes by adding to FAKECHROOT_EXCLUDE_PATH
        validated_volumes = self.validate_volumes(volumes)
        if validated_volumes:
            exclude_paths = [container_path for _, container_path in validated_volumes]
            full_env["FAKECHROOT_EXCLUDE_PATH"] = ":".join(exclude_paths)
        
        # Build command
        # fakeroot -> fakechroot -> chroot -> command
        chroot_args = [
            str(fakeroot),
            str(fakechroot),
            "chroot",
            str(rootfs),
        ]
        
        # Change to working directory
        if working_dir and working_dir != "/":
            # Use sh -c to change directory
            cmd_str = " ".join(
                [f'cd "{working_dir}" &&'] + [f'"{c}"' for c in command]
            )
            chroot_args.extend(["/bin/sh", "-c", cmd_str])
        else:
            chroot_args.extend(command)
        
        # Handle volume bind mounts using shell commands
        # Note: Fakechroot has limited bind mount support
        # We'll create symlinks as a workaround
        for host_path, container_path in validated_volumes:
            container_full_path = rootfs / container_path.lstrip("/")
            container_full_path.parent.mkdir(parents=True, exist_ok=True)
            
            if not container_full_path.exists():
                # Create symlink to host path
                try:
                    container_full_path.symlink_to(host_path)
                except OSError:
                    pass  # May fail if already exists
        
        # Run the command
        try:
            if interactive or tty:
                result = subprocess.run(
                    chroot_args,
                    env=full_env,
                    stdin=sys.stdin if interactive else None,
                )
                return result.returncode
            if stdout_path or stderr_path:
                stdout_handle = open(stdout_path, "ab") if stdout_path else None
                stderr_handle = open(stderr_path, "ab") if stderr_path else None
                try:
                    proc = subprocess.Popen(
                        chroot_args,
                        env=full_env,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                    )
                    import threading
                    
                    def _pipe(src, file_handle, stream):
                        for chunk in iter(lambda: src.read(4096), b""):
                            if file_handle:
                                file_handle.write(chunk)
                                file_handle.flush()
                            if stream:
                                stream.buffer.write(chunk)
                                stream.buffer.flush()
                        src.close()
                    
                    threads = []
                    if proc.stdout:
                        threads.append(
                            threading.Thread(
                                target=_pipe,
                                args=(proc.stdout, stdout_handle, sys.stdout),
                                daemon=True,
                            )
                        )
                    if proc.stderr:
                        threads.append(
                            threading.Thread(
                                target=_pipe,
                                args=(proc.stderr, stderr_handle, sys.stderr),
                                daemon=True,
                            )
                        )
                    for t in threads:
                        t.start()
                    return_code = proc.wait()
                    for t in threads:
                        t.join()
                    return return_code
                finally:
                    if stdout_handle:
                        stdout_handle.close()
                    if stderr_handle:
                        stderr_handle.close()
            result = subprocess.run(
                chroot_args,
                env=full_env,
                capture_output=False,
            )
            return result.returncode
                
        except KeyboardInterrupt:
            return 130
        except Exception as e:
            print(f"Error running command: {e}", file=sys.stderr)
            return 1
