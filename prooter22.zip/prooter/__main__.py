"""Main entry point for running prooter as a module."""

import sys
from prooter.cli import main

if __name__ == "__main__":
    sys.exit(main())
