"""Configuration and path management for Prooter."""

import os
from pathlib import Path
from typing import Optional


import json

class Config:
    """Prooter configuration management."""
    
    def __init__(self, base_dir: Optional[Path] = None):
        """Initialize configuration.
        
        Args:
            base_dir: Base directory for prooter data. Defaults to ~/.prooter
        """
        self.base_dir = base_dir or Path.home() / ".prooter"
        self._ensure_directories()
        self._settings = self._load_settings()
        
    def _ensure_directories(self) -> None:
        """Create required directories if they don't exist."""
        for directory in [
            self.base_dir,
            self.images_dir,
            self.layers_dir,
            self.containers_dir,
            self.networks_dir,
            self.bin_dir,
            self.tmp_dir,
            self.base_dir / "oci",  # OCI image layouts
        ]:
            directory.mkdir(parents=True, exist_ok=True)
            
    def _load_settings(self) -> dict:
        """Load settings from config file."""
        config_path = self.base_dir / "config.json"
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}
    
    @property
    def images_dir(self) -> Path:
        """Directory for storing image metadata."""
        return self.base_dir / "images"
    
    @property
    def layers_dir(self) -> Path:
        """Directory for storing extracted layers."""
        return self.base_dir / "layers"
    
    @property
    def containers_dir(self) -> Path:
        """Directory for container instances."""
        return self.base_dir / "containers"

    @property
    def networks_dir(self) -> Path:
        """Directory for network definitions."""
        return self.base_dir / "networks"
    
    @property
    def bin_dir(self) -> Path:
        """Directory for binary tools (proot, etc.)."""
        return self.base_dir / "bin"
    
    @property
    def tmp_dir(self) -> Path:
        """Temporary directory for downloads and extraction."""
        return self.base_dir / "tmp"
    
    @property
    def proot_binary(self) -> Path:
        """Path to PRoot binary."""
        return self.bin_dir / "proot"
    
    @property
    def fakechroot_lib(self) -> Path:
        """Path to fakechroot library."""
        return self.bin_dir / "libfakechroot.so"
    
    @property
    def skopeo_binary(self) -> Path:
        """Path to skopeo binary."""
        return self.bin_dir / "skopeo"
    
    @property
    def umoci_binary(self) -> Path:
        """Path to umoci binary."""
        return self.bin_dir / "umoci"
    
    @property
    def oci_dir(self) -> Path:
        """Directory for OCI image layouts."""
        return self.base_dir / "oci"
        
    @property
    def registry_mirror(self) -> Optional[str]:
        """Get configured registry mirror."""
        return self._settings.get("registry-mirror")
        
    @property
    def verify_ssl(self) -> bool:
        """Get SSL verification setting (default: True)."""
        return self._settings.get("verify-ssl", True)
        
    @property
    def execution_engine(self) -> Optional[str]:
        """Get configured execution engine (proot or fakechroot)."""
        return self._settings.get("execution-engine")
    
    def save_settings(self) -> None:
        """Save current settings to config file."""
        config_path = self.base_dir / "config.json"
        with open(config_path, "w") as f:
            json.dump(self._settings, f, indent=2)
    
    def set_execution_engine(self, engine: str) -> None:
        """Set the default execution engine.
        
        Args:
            engine: Engine name ('proot' or 'fakechroot')
        """
        if engine not in ("proot", "fakechroot"):
            raise ValueError(f"Invalid engine: {engine}. Must be 'proot' or 'fakechroot'")
        self._settings["execution-engine"] = engine
        self.save_settings()


# Global configuration instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = Config()
    return _config


def init_config(base_dir: Optional[Path] = None) -> Config:
    """Initialize configuration with custom base directory."""
    global _config
    _config = Config(base_dir)
    return _config
