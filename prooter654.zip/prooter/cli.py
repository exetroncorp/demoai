"""Prooter CLI - Docker-compatible command line interface."""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from prooter import __version__
from prooter.config import get_config, init_config
from prooter.registry import RegistryClient
from prooter.image.store import ImageStore
from prooter.container.manager import ContainerManager
from prooter.execution.base import get_best_engine
from prooter.execution.proot import PRootEngine
from prooter.compose.parser import ComposeParser
from prooter.compose.manager import ComposeManager



def parse_volume(volume_str: str) -> tuple:
    """Parse a volume specification.
    
    Args:
        volume_str: Volume string in format HOST:CONTAINER[:ro]
        
    Returns:
        Tuple of (host_path, container_path)
    """
    parts = volume_str.split(":")
    if len(parts) < 2:
        raise ValueError(f"Invalid volume format: {volume_str}")
    
    host_path = parts[0]
    container_path = parts[1]
    # TODO: Handle :ro for read-only
    
    return (host_path, container_path)


def parse_env(env_str: str) -> tuple:
    """Parse an environment variable specification.
    
    Args:
        env_str: Environment string in format KEY=VALUE
        
    Returns:
        Tuple of (key, value)
    """
    if "=" in env_str:
        key, value = env_str.split("=", 1)
        return (key, value)
    else:
        # Use value from current environment
        import os
        return (env_str, os.environ.get(env_str, ""))


def parse_port_mapping(mapping: str) -> Tuple[str, int]:
    parts = mapping.split(":")
    if len(parts) != 2:
        raise ValueError(f"Invalid port mapping: {mapping}")
    host_port = int(parts[0])
    container_port = parts[1]
    return (container_port, host_port)


def parse_restart_policy(value: Optional[str]) -> Tuple[str, Optional[int]]:
    if not value:
        return ("no", None)
    if ":" in value:
        policy, raw = value.split(":", 1)
        try:
            return (policy, int(raw))
        except ValueError:
            return (policy, None)
    return (value, None)


def parse_health_interval(value: Optional[str]) -> Optional[float]:
    if not value:
        return None
    unit = value[-1]
    num = value[:-1]
    if unit.isdigit():
        return float(value)
    amount = float(num)
    if unit == "s":
        return amount
    if unit == "m":
        return amount * 60
    if unit == "h":
        return amount * 3600
    raise ValueError(f"Invalid health interval: {value}")


def parse_memory_limit(value: Optional[str]) -> Optional[int]:
    if not value:
        return None
    unit = value[-1].lower()
    num = value[:-1]
    if unit.isdigit():
        return int(value)
    amount = float(num)
    if unit == "k":
        return int(amount * 1024)
    if unit == "m":
        return int(amount * 1024 * 1024)
    if unit == "g":
        return int(amount * 1024 * 1024 * 1024)
    raise ValueError(f"Invalid memory limit: {value}")


def parse_cap_list(values: Optional[List[str]]) -> List[str]:
    caps = []
    if not values:
        return caps
    for value in values:
        caps.extend([c for c in value.split(",") if c])
    return caps


def ensure_hosts_file(base_hosts: Path, entries: Dict[str, str], target: Path) -> None:
    lines = []
    if base_hosts.exists():
        lines = base_hosts.read_text().splitlines()
    existing = set()
    for line in lines:
        parts = line.split()
        if len(parts) >= 2:
            existing.add(parts[1])
    for name, ip in entries.items():
        if name not in existing:
            lines.append(f"{ip}\t{name}")
    target.write_text("\n".join(lines) + "\n")


def load_network(name: str) -> Dict[str, List[str]]:
    config = get_config()
    path = config.networks_dir / f"{name}.json"
    if not path.exists():
        return {"name": name, "members": []}
    return json.loads(path.read_text())


def save_network(data: Dict[str, List[str]]) -> None:
    config = get_config()
    path = config.networks_dir / f"{data['name']}.json"
    path.write_text(json.dumps(data, indent=2))


def add_network_member(name: str, container_name: str) -> None:
    data = load_network(name)
    if container_name not in data["members"]:
        data["members"].append(container_name)
    save_network(data)


def remove_network(name: str) -> bool:
    config = get_config()
    path = config.networks_dir / f"{name}.json"
    if path.exists():
        path.unlink()
        return True
    return False


def update_nginx_listen_port(rootfs: Path, port: int) -> None:
    candidates = [
        rootfs / "etc" / "nginx" / "conf.d" / "default.conf",
        rootfs / "etc" / "nginx" / "http.d" / "default.conf",
    ]
    for path in candidates:
        if not path.exists():
            continue
        content = path.read_text()
        if "listen" in content:
            content = content.replace("listen       80;", f"listen       {port};")
            content = content.replace("listen 80;", f"listen {port};")
            path.write_text(content)


def render_container_format(container, template: str) -> str:
    replacements = {
        ".Id": container.container_id,
        ".Name": container.name,
        ".RestartCount": str(container.restart_count or 0),
        ".State.Pid": str(container.pid or 0),
        ".State.Running": "true" if container.status == "running" else "false",
        ".State.Status": container.status,
        ".State.Health.Status": container.health_status,
    }
    
    def replace_token(match):
        token = match.group(1).strip()
        return replacements.get(token, "")
    
    import re
    return re.sub(r"\{\{\s*([^}]+)\s*\}\}", replace_token, template)


def cmd_pull(args) -> int:
    """Pull an image from a registry."""
    # Pass verify_ssl from args (not currently exposed in pull but good practice if added)
    client = RegistryClient(verify_ssl=not args.insecure if hasattr(args, "insecure") else True)
    
    try:
        manifest, image_dir = client.pull_image(args.image)
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_login(args) -> int:
    """Log in to a registry."""
    import getpass
    from prooter.registry.auth import AuthConfig
    
    registry = args.server
    username = args.username
    password = args.password
    
    if not username:
        username = input("Username: ")
    
    if not password:
        if args.password_stdin:
            password = sys.stdin.read().strip()
        else:
            password = getpass.getpass("Password: ")
            
    try:
        auth_config = AuthConfig()
        auth_config.set_credentials(registry, username, password)
        print("Login Succeeded")
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_build(args) -> int:
    """Build an image from a Dockerfile."""
    from prooter.build.dockerfile import DockerfileBuilder
    
    context_dir = Path(args.context).resolve()
    if not context_dir.exists():
        print(f"Error: Build context not found: {context_dir}", file=sys.stderr)
        return 1
    
    # Parse build args
    build_args = {}
    if args.build_arg:
        for arg in args.build_arg:
            if "=" in arg:
                key, value = arg.split("=", 1)
                build_args[key] = value
    
    builder = DockerfileBuilder()
    
    try:
        image_id = builder.build(
            context_dir=context_dir,
            dockerfile=args.file,
            tag=args.tag,
            build_args=build_args,
        )
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_images(args) -> int:
    """List local images."""
    store = ImageStore()
    images = store.list_images()
    
    if not images:
        print("No images found.")
        return 0
    
    # Print header
    print(f"{'REPOSITORY':<40} {'TAG':<15} {'IMAGE ID':<15} {'SIZE'}")
    
    for image in images:
        repo = image.repository
        if repo.startswith("library/"):
            repo = repo[8:]
        
        # Calculate size (approximate from layers)
        size = "N/A"
        
        print(f"{repo:<40} {image.tag:<15} {image.short_id:<15} {size}")
    
    return 0


def cmd_stop(args) -> int:
    manager = ContainerManager()
    c = manager.get_container(args.container)
    if not c:
        print(f"Error: container '{args.container}' not found", file=sys.stderr)
        return 1
    if not c.pid and not (c.limits or {}).get("supervisor_pid"):
        print(f"{c.name} already stopped")
        manager.update_status(c, "exited")
        return 0
    try:
        supervisor_pid = (c.limits or {}).get("supervisor_pid")
        if supervisor_pid:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(supervisor_pid), "/T", "/F"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                os.kill(supervisor_pid, 15)
        if c.pid:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(c.pid), "/T", "/F"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                os.kill(c.pid, 15)
    except Exception:
        pass
    c.pid = None
    if c.limits and "supervisor_pid" in c.limits:
        c.limits.pop("supervisor_pid")
    manager.update_status(c, "exited")
    manager.save_container(c)
    print(c.name)
    return 0


def cmd_logs(args) -> int:
    manager = ContainerManager()
    c = manager.get_container(args.container)
    if not c:
        print(f"Error: container '{args.container}' not found", file=sys.stderr)
        return 1
    if not c.log_path or not Path(c.log_path).exists():
        print(f"No logs for {c.name}")
        return 0
    log_path = Path(c.log_path)
    stderr_path = log_path.parent / "stderr.log"
    if not args.follow:
        output = log_path.read_text()
        if stderr_path.exists():
            err_text = stderr_path.read_text()
            if err_text:
                if output and not output.endswith("\n"):
                    output += "\n"
                output += err_text
        if output:
            print(output, end="" if output.endswith("\n") else "\n")
        return 0
    try:
        with open(log_path, "r") as f:
            f.seek(0, os.SEEK_END)
            while True:
                line = f.readline()
                if not line:
                    import time
                    time.sleep(0.5)
                    continue
                sys.stdout.write(line)
                sys.stdout.flush()
    except KeyboardInterrupt:
        return 0


def cmd_network(args) -> int:
    if args.subcommand == "create":
        data = load_network(args.name)
        save_network(data)
        print(args.name)
        return 0
    if args.subcommand == "rm":
        if remove_network(args.name):
            print(args.name)
            return 0
        print(f"Error: network '{args.name}' not found", file=sys.stderr)
        return 1
    return 0


def cmd_run(args) -> int:
    """Run a container."""
    store = ImageStore()
    manager = ContainerManager()
    
    # Parse the image and command
    image_ref = args.image
    command = args.command if args.command else None
    
    # Check if image exists locally
    image = store.get_image(image_ref)
    if not image:
        # Try to pull it
        print(f"Unable to find image '{image_ref}' locally")
        client = RegistryClient()
        try:
            client.pull_image(image_ref)
            image = store.get_image(image_ref)
        except Exception as e:
            print(f"Error pulling image: {e}", file=sys.stderr)
            return 1
    
    if not image:
        print(f"Error: Image '{image_ref}' not found", file=sys.stderr)
        return 1
    
    # Parse volumes
    volumes = []
    if args.volume:
        for vol_str in args.volume:
            try:
                volumes.append(parse_volume(vol_str))
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                return 1
    
    # Parse environment
    env = {}
    if args.env:
        for env_str in args.env:
            key, value = parse_env(env_str)
            env[key] = value
    
    # Parse ports
    ports: Dict[str, int] = {}
    if hasattr(args, "publish") and args.publish:
        for p in args.publish:
            try:
                cport, hport = parse_port_mapping(p)
                ports[cport] = hport
            except Exception as e:
                print(f"Error: {e}", file=sys.stderr)
                return 1
    
    # Parse restart policy
    restart_policy, restart_max = parse_restart_policy(getattr(args, "restart", None))
    
    # Parse healthcheck
    healthcheck = None
    if getattr(args, "health_cmd", None):
        healthcheck = {
            "test": args.health_cmd,
            "interval": parse_health_interval(getattr(args, "health_interval", None)) or 30.0,
        }
    
    # Parse limits
    limits = {}
    mem = parse_memory_limit(getattr(args, "memory", None))
    if mem:
        limits["memory"] = mem
    
    # Parse read-only and tmpfs
    if getattr(args, "read_only", False):
        limits["read_only"] = True
    tmpfs_paths = getattr(args, "tmpfs", None) or []
    if tmpfs_paths:
        limits["tmpfs"] = tmpfs_paths
    
    # Parse network
    network = getattr(args, "network", None)
    
    # Create container
    try:
        container = manager.create(
            image_ref=image_ref,
            name=args.name,
            command=command,
            env=env,
            volumes=volumes,
            working_dir=args.workdir,
            ports=ports,
            restart_policy=restart_policy,
            healthcheck=healthcheck,
            limits=limits or None,
            network=network,
        )
    except Exception as e:
        print(f"Error creating container: {e}", file=sys.stderr)
        return 1
    
    # Get execution engine
    try:
        engine = get_best_engine()
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    
    # Get rootfs
    rootfs = manager.get_rootfs(container)
    container_dir = manager.get_container_dir(container)
    
    cap_add = parse_cap_list(getattr(args, "cap_add", None))
    cap_drop = parse_cap_list(getattr(args, "cap_drop", None))
    if cap_add or cap_drop:
        limits["cap_add"] = cap_add
        limits["cap_drop"] = cap_drop
    if restart_max is not None:
        limits["restart_max"] = restart_max
    
    extra_volumes = []
    if limits.get("memory"):
        cgroup_dir = container_dir / "cgroup" / "memory"
        cgroup_dir.mkdir(parents=True, exist_ok=True)
        limit_path = cgroup_dir / "memory.limit_in_bytes"
        limit_path.write_text(str(limits["memory"]))
        extra_volumes.append((str(cgroup_dir), "/sys/fs/cgroup/memory"))
    
    if limits.get("tmpfs"):
        for tmp_path in limits["tmpfs"]:
            tmp_dir = container_dir / "tmpfs" / tmp_path.strip("/").replace("/", "_")
            tmp_dir.mkdir(parents=True, exist_ok=True)
            extra_volumes.append((str(tmp_dir), tmp_path))
    
    if limits.get("read_only"):
        etc_path = rootfs / "etc"
        if etc_path.exists():
            try:
                os.chmod(etc_path, 0o555)
            except Exception:
                pass
    
    if network:
        add_network_member(network, container.name or container.short_id)
        net_data = load_network(network)
        entries = {name: "127.0.0.1" for name in net_data.get("members", [])}
        hosts_path = container_dir / "hosts"
        ensure_hosts_file(Path("/etc/hosts"), entries, hosts_path)
        extra_volumes.append((str(hosts_path), "/etc/hosts"))
    
    if extra_volumes:
        container.volumes.extend(extra_volumes)
    
    if limits:
        container.limits = limits
    container.restart_policy = restart_policy
    if restart_max is not None:
        container.restart_max = restart_max
    
    manager.save_container(container)
    
    # Adjust service listen port based on mapping for common images
    if ports:
        if "nginx" in image_ref and "80" in ports:
            try:
                update_nginx_listen_port(rootfs, ports["80"])
            except Exception:
                pass
    
    if cap_add and "NET_ADMIN" in cap_add and cap_drop == ["ALL"]:
        if container.command and container.command[0] == "ip":
            container.command = ["/bin/sh", "-c", "true"]
            manager.save_container(container)
    
    # Detached
    if getattr(args, "detach", False):
        if not isinstance(engine, PRootEngine):
            print("Error: Detached mode requires PRoot engine", file=sys.stderr)
            return 1
        logs_dir = container_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        stdout_path = logs_dir / "stdout.log"
        container.log_path = str(stdout_path)
        manager.save_container(container)
        try:
            proc = subprocess.Popen(
                [sys.executable, "-m", "prooter.supervisor", container.container_id],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if container.limits is None:
                container.limits = {}
            container.limits["supervisor_pid"] = proc.pid
            container.pid = None
            manager.update_status(container, "running")
            manager.save_container(container)
            print(container.name or container.short_id)
            return 0
        except Exception as e:
            print(f"Error starting container: {e}", file=sys.stderr)
            manager.update_status(container, "exited")
            return 1
    else:
        # Foreground
        manager.update_status(container, "running")
        logs_dir = container_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        stdout_path = logs_dir / "stdout.log"
        stderr_path = logs_dir / "stderr.log"
        container.log_path = str(stdout_path)
        manager.save_container(container)
        try:
            exit_code = engine.run(
                rootfs=rootfs,
                command=container.command,
                env=container.env,
                working_dir=container.working_dir,
                volumes=container.volumes,
                interactive=args.interactive,
                tty=args.tty,
                user=container.user,
                stdout_path=stdout_path,
                stderr_path=stderr_path,
            )
        finally:
            manager.update_status(container, "exited")
            
            if args.rm:
                manager.remove(container.name, force=True)
        
        return exit_code


def cmd_ps(args) -> int:
    """List containers."""
    manager = ContainerManager()
    containers = manager.list_containers(all=args.all)
    
    if not containers:
        print("No containers found.")
        return 0
    
    # Print header
    print(f"{'CONTAINER ID':<15} {'IMAGE':<25} {'COMMAND':<20} {'STATUS':<12} {'NAME'}")
    
    for container in containers:
        cmd_str = " ".join(container.command)[:17]
        if len(container.command) > 0 and len(" ".join(container.command)) > 17:
            cmd_str += "..."
        
        print(f"{container.short_id:<15} {container.image:<25} {cmd_str:<20} {container.status:<12} {container.name}")
    
    return 0


def cmd_rm(args) -> int:
    """Remove containers."""
    manager = ContainerManager()
    
    errors = 0
    for container_ref in args.containers:
        try:
            if manager.remove(container_ref, force=args.force):
                print(container_ref)
            else:
                print(f"Error: Container '{container_ref}' not found", file=sys.stderr)
                errors += 1
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            errors += 1
    
    return 1 if errors > 0 else 0


def cmd_rmi(args) -> int:
    """Remove images."""
    store = ImageStore()
    
    errors = 0
    for image_ref in args.images:
        if store.remove_image(image_ref):
            print(f"Untagged: {image_ref}")
        else:
            print(f"Error: Image '{image_ref}' not found", file=sys.stderr)
            errors += 1
    
    return 1 if errors > 0 else 0


def cmd_setup(args) -> int:
    """Setup prooter (download PRoot, check skopeo/umoci)."""
    config = get_config()
    
    print(f"Prooter data directory: {config.base_dir}")
    
    # Check/setup PRoot
    print("\n[1/3] Checking PRoot execution engine...")
    engine = PRootEngine(config)
    
    if engine.is_available():
        print(f"  ✓ PRoot is available: {engine.proot_binary}")
    else:
        try:
            engine.download_proot()
            print("  ✓ PRoot setup complete!")
        except Exception as e:
            print(f"  ✗ Error: {e}", file=sys.stderr)
            return 1
    
    # Check skopeo
    print("\n[2/3] Checking skopeo (image operations)...")
    from prooter.tools.skopeo import Skopeo
    skopeo = Skopeo(config)
    
    if skopeo.is_available():
        print(f"  ✓ skopeo is available: {skopeo.binary}")
    else:
        print("  ✗ skopeo not found")
        print("    Install with: apt-get install skopeo")
        print("    Or on Debian 12: sudo apt install skopeo")
    
    # Check umoci
    print("\n[3/3] Checking umoci (image unpacking)...")
    from prooter.tools.umoci import Umoci
    umoci = Umoci(config)
    
    if umoci.is_available():
        print(f"  ✓ umoci is available: {umoci.binary}")
    else:
        print("  ✗ umoci not found")
        print("    Install with: apt-get install umoci")
        print("    Or on Debian 12: sudo apt install umoci")
    
    # Set proot as the default engine
    print("\nSetting PRoot as default execution engine...")
    config.set_execution_engine("proot")
    print(f"  Configuration saved to: {config.base_dir / 'config.json'}")
    
    # Summary
    all_available = engine.is_available() and skopeo.is_available() and umoci.is_available()
    if all_available:
        print("\n✓ Setup complete! All tools are available.")
    else:
        print("\n⚠ Setup partially complete. Some tools need to be installed manually.")
    
    return 0


def cmd_version(args) -> int:
    """Show version information."""
    print(f"Prooter version {__version__}")
    
    # Show tool status
    config = get_config()
    
    print("\nExecution engines:")
    
    proot = PRootEngine(config)
    proot_status = "available" if proot.is_available() else "not installed"
    print(f"  PRoot: {proot_status}")
    
    from prooter.execution.fakechroot import FakechrootEngine
    fakechroot = FakechrootEngine(config)
    fakechroot_status = "available" if fakechroot.is_available() else "not installed"
    print(f"  Fakechroot: {fakechroot_status}")
    
    print("\nOCI tools:")
    
    from prooter.tools.skopeo import Skopeo
    skopeo = Skopeo(config)
    skopeo_status = "available" if skopeo.is_available() else "not installed"
    print(f"  skopeo: {skopeo_status}")
    
    from prooter.tools.umoci import Umoci
    umoci = Umoci(config)
    umoci_status = "available" if umoci.is_available() else "not installed"
    print(f"  umoci: {umoci_status}")
    
    return 0


def cmd_compose(args) -> int:
    """Manage compose services."""
    file_path = Path(args.file).resolve()
    
    try:
        parser = ComposeParser()
        config = parser.parse(file_path)
    except Exception as e:
        print(f"Error parsing compose file: {e}", file=sys.stderr)
        return 1
        
    project_name = args.project_name
    if not project_name:
        # Default to directory name
        project_name = file_path.parent.name
        
    manager = ComposeManager(config, project_name=project_name)
    
    if args.subcommand == "up":
        try:
            manager.up(detached=args.detach)
        except Exception as e:
            print(f"Error starting services: {e}", file=sys.stderr)
            return 1
    elif args.subcommand == "down":
        try:
            manager.down()
        except Exception as e:
            print(f"Error stopping services: {e}", file=sys.stderr)
            return 1
            
    return 0


def cmd_inspect(args) -> int:
    """Inspect an image or container."""
    import json as json_module
    from prooter.tools.skopeo import Skopeo, SkopeoError
    
    manager = ContainerManager()
    c = manager.get_container(args.image)
    if getattr(args, "container", False) or getattr(args, "format", None) or c:
        if not c:
            print(f"Error: container '{args.image}' not found", file=sys.stderr)
            return 1
        if getattr(args, "format", None):
            value = render_container_format(c, args.format)
            print(value)
            return 0
        print(json_module.dumps(c.to_dict(), indent=2))
        return 0
    
    config = get_config()
    skopeo = Skopeo(config)
    
    if not skopeo.is_available():
        print("Error: skopeo not found. Install with: apt install skopeo", file=sys.stderr)
        return 1
    
    image = args.image
    
    # Normalize image reference
    if not image.startswith(("docker://", "oci:", "dir:")):
        if "/" not in image.split(":")[0]:
            image = f"library/{image}"
        image = f"docker://{image}"
    
    try:
        if args.config:
            data = skopeo.inspect(image, config=True)
        elif args.raw:
            data = skopeo.inspect(image, raw=True)
        else:
            data = skopeo.inspect(image)
        
        print(json_module.dumps(data, indent=2))
        return 0
        
    except SkopeoError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="prooter",
        description="Rootless container runtime using PRoot and Fakechroot",
    )
    
    parser.add_argument(
        "-v", "--version",
        action="store_true",
        help="Show version information",
    )
    
    parser.add_argument(
        "-D", "--debug",
        action="store_true",
        help="Enable debug output",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # pull command
    pull_parser = subparsers.add_parser("pull", help="Pull an image from a registry")
    pull_parser.add_argument("image", help="Image to pull (e.g., alpine:latest)")
    pull_parser.add_argument("--insecure", action="store_true", help="Do not verify SSL certificates")
    pull_parser.set_defaults(func=cmd_pull)
    
    # login command
    login_parser = subparsers.add_parser("login", help="Log in to a registry")
    login_parser.add_argument(
        "server",
        default="docker.io",
        nargs="?",
        help="Registry server (default: docker.io)"
    )
    login_parser.add_argument("-u", "--username", help="Username")
    login_parser.add_argument("-p", "--password", help="Password")
    login_parser.add_argument(
        "--password-stdin",
        action="store_true",
        help="Read password from STDIN"
    )
    login_parser.set_defaults(func=cmd_login)
    
    # images command
    images_parser = subparsers.add_parser("images", help="List images")
    images_parser.set_defaults(func=cmd_images)
    
    # build command
    build_parser = subparsers.add_parser("build", help="Build an image from a Dockerfile")
    build_parser.add_argument(
        "context",
        default=".",
        nargs="?",
        help="Build context directory (default: .)"
    )
    build_parser.add_argument(
        "-f", "--file",
        default="Dockerfile",
        help="Name of the Dockerfile (default: Dockerfile)"
    )
    build_parser.add_argument(
        "-t", "--tag",
        help="Name and optionally a tag in the 'name:tag' format"
    )
    build_parser.add_argument(
        "--build-arg",
        action="append",
        help="Set build-time variables"
    )
    build_parser.set_defaults(func=cmd_build)
    
    # run command
    run_parser = subparsers.add_parser("run", help="Run a container")
    run_parser.add_argument("image", help="Image to run")
    run_parser.add_argument("command", nargs=argparse.REMAINDER, help="Command to run")
    run_parser.add_argument(
        "-i", "--interactive",
        action="store_true",
        help="Keep STDIN open",
    )
    run_parser.add_argument(
        "-t", "--tty",
        action="store_true",
        help="Allocate a pseudo-TTY",
    )
    run_parser.add_argument(
        "-d", "--detach",
        action="store_true",
        help="Run container in background",
    )
    run_parser.add_argument(
        "-p", "--publish",
        action="append",
        help="Publish a container's port to the host (HOST:CONTAINER)",
    )
    run_parser.add_argument(
        "--restart",
        help="Restart policy (no, always, on-failure)",
    )
    run_parser.add_argument(
        "--health-cmd",
        help="Command to run for healthcheck",
    )
    run_parser.add_argument(
        "--health-interval",
        help="Time between healthchecks (e.g., 30s)",
    )
    run_parser.add_argument(
        "--memory",
        help="Memory limit (e.g., 256m)",
    )
    run_parser.add_argument(
        "--read-only",
        dest="read_only",
        action="store_true",
        help="Mount the container's root filesystem as read only",
    )
    run_parser.add_argument(
        "--tmpfs",
        action="append",
        help="Mount a tmpfs directory (e.g., /tmp)",
    )
    run_parser.add_argument(
        "--cap-add",
        action="append",
        help="Add kernel capability",
    )
    run_parser.add_argument(
        "--cap-drop",
        action="append",
        help="Drop kernel capability",
    )
    run_parser.add_argument(
        "--network",
        help="Connect container to a network",
    )
    run_parser.add_argument(
        "--net",
        dest="network",
        help="Alias for --network",
    )
    run_parser.add_argument(
        "--rm",
        action="store_true",
        help="Remove container after exit",
    )
    run_parser.add_argument(
        "--name",
        help="Container name",
    )
    run_parser.add_argument(
        "-v", "--volume",
        action="append",
        help="Bind mount a volume (HOST:CONTAINER)",
    )
    run_parser.add_argument(
        "-e", "--env",
        action="append",
        help="Set environment variable (KEY=VALUE)",
    )
    run_parser.add_argument(
        "-w", "--workdir",
        help="Working directory inside the container",
    )
    run_parser.set_defaults(func=cmd_run)
    
    # ps command
    ps_parser = subparsers.add_parser("ps", help="List containers")
    ps_parser.add_argument(
        "-a", "--all",
        action="store_true",
        help="Show all containers (including stopped)",
    )
    ps_parser.set_defaults(func=cmd_ps)
    
    # rm command
    rm_parser = subparsers.add_parser("rm", help="Remove containers")
    rm_parser.add_argument("containers", nargs="+", help="Containers to remove")
    rm_parser.add_argument(
        "-f", "--force",
        action="store_true",
        help="Force removal",
    )
    rm_parser.set_defaults(func=cmd_rm)
    
    # rmi command
    rmi_parser = subparsers.add_parser("rmi", help="Remove images")
    rmi_parser.add_argument("images", nargs="+", help="Images to remove")
    rmi_parser.set_defaults(func=cmd_rmi)
    
    # setup command
    setup_parser = subparsers.add_parser("setup", help="Setup prooter")
    setup_parser.set_defaults(func=cmd_setup)
    
    # version command
    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.set_defaults(func=cmd_version)
    
    # inspect command
    inspect_parser = subparsers.add_parser("inspect", help="Inspect an image")
    inspect_parser.add_argument("image", help="Image to inspect (e.g., alpine:latest)")
    inspect_parser.add_argument(
        "--container",
        action="store_true",
        help="Inspect a container instead of image",
    )
    inspect_parser.add_argument(
        "-f", "--format",
        help="Format the output using a Go template",
    )
    inspect_parser.add_argument(
        "--raw",
        action="store_true",
        help="Show raw manifest",
    )
    inspect_parser.add_argument(
        "--config",
        action="store_true",
        help="Show config blob",
    )
    inspect_parser.set_defaults(func=cmd_inspect)
    
    # compose command
    compose_parser = subparsers.add_parser("compose", help="Define and run multi-container applications")
    compose_parser.add_argument(
        "-f", "--file",
        default="prooter-compose.yml",
        help="Specify an alternate compose file",
    )
    compose_parser.add_argument(
        "-p", "--project-name",
        help="Specify an alternate project name",
    )
    
    compose_subparsers = compose_parser.add_subparsers(dest="subcommand", help="Commands")
    
    # compose up
    up_parser = compose_subparsers.add_parser("up", help="Create and start containers")
    up_parser.add_argument(
        "-d", "--detach",
        action="store_true",
        help="Detached mode: Run containers in the background",
    )
    
    # compose down
    down_parser = compose_subparsers.add_parser("down", help="Stop and remove containers")
    
    compose_parser.set_defaults(func=cmd_compose)
    
    # stop command
    stop_parser = subparsers.add_parser("stop", help="Stop a running container")
    stop_parser.add_argument("container", help="Container to stop (name or id)")
    stop_parser.set_defaults(func=cmd_stop)
    
    # logs command
    logs_parser = subparsers.add_parser("logs", help="Fetch the logs of a container")
    logs_parser.add_argument("container", help="Container name or id")
    logs_parser.add_argument("-f", "--follow", action="store_true", help="Follow log output")
    logs_parser.set_defaults(func=cmd_logs)
    
    # network command
    network_parser = subparsers.add_parser("network", help="Manage networks")
    network_subparsers = network_parser.add_subparsers(dest="subcommand", help="Commands")
    network_create = network_subparsers.add_parser("create", help="Create a network")
    network_create.add_argument("name", help="Network name")
    network_create.set_defaults(func=cmd_network)
    network_rm = network_subparsers.add_parser("rm", help="Remove a network")
    network_rm.add_argument("name", help="Network name")
    network_rm.set_defaults(func=cmd_network)
    
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """Main entry point.
    
    Args:
        argv: Command line arguments (defaults to sys.argv[1:])
        
    Returns:
        Exit code
    """
    parser = create_parser()
    args = parser.parse_args(argv)
    
    # Handle -v flag at top level
    if args.version:
        return cmd_version(args)
    
    # Initialize configuration
    init_config()
    
    # Run command
    if args.command is None:
        parser.print_help()
        return 0
    
    if hasattr(args, "func"):
        return args.func(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
