"""Container lifecycle management."""

import json
import os
import shutil
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any

from prooter.config import get_config
from prooter.image.store import ImageStore, LocalImage


@dataclass
class Container:
    """Represents a container instance."""
    
    container_id: str
    name: str
    image: str
    image_id: str
    created: str
    status: str = "created"
    command: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    volumes: List[tuple] = field(default_factory=list)
    working_dir: str = "/"
    ports: Dict[str, int] = field(default_factory=dict)
    user: Optional[str] = None
    restart_policy: str = "no"
    restart_max: Optional[int] = None
    healthcheck: Optional[Dict[str, Any]] = None
    limits: Optional[Dict[str, Any]] = None
    network: Optional[str] = None
    pid: Optional[int] = None
    log_path: Optional[str] = None
    restart_count: int = 0
    health_status: str = "none"
    
    @property
    def short_id(self) -> str:
        """Get short container ID."""
        return self.container_id[:12]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "container_id": self.container_id,
            "name": self.name,
            "image": self.image,
            "image_id": self.image_id,
            "created": self.created,
            "status": self.status,
            "command": self.command,
            "env": self.env,
            "volumes": self.volumes,
            "working_dir": self.working_dir,
            "ports": self.ports,
            "user": self.user,
            "restart_policy": self.restart_policy,
            "restart_max": self.restart_max,
            "healthcheck": self.healthcheck,
            "limits": self.limits,
            "network": self.network,
            "pid": self.pid,
            "log_path": self.log_path,
            "restart_count": self.restart_count,
            "health_status": self.health_status,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Container":
        """Create from dictionary."""
        return cls(
            container_id=data["container_id"],
            name=data["name"],
            image=data["image"],
            image_id=data["image_id"],
            created=data["created"],
            status=data.get("status", "created"),
            command=data.get("command", []),
            env=data.get("env", {}),
            volumes=[tuple(v) for v in data.get("volumes", [])],
            working_dir=data.get("working_dir", "/"),
            ports=data.get("ports", {}),
            user=data.get("user"),
            restart_policy=data.get("restart_policy", "no"),
            restart_max=data.get("restart_max"),
            healthcheck=data.get("healthcheck"),
            limits=data.get("limits"),
            network=data.get("network"),
            pid=data.get("pid"),
            log_path=data.get("log_path"),
            restart_count=data.get("restart_count", 0),
            health_status=data.get("health_status", "none"),
        )


class ContainerManager:
    """Manages container lifecycle."""
    
    def __init__(self, config=None):
        """Initialize the container manager.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or get_config()
        self.image_store = ImageStore(self.config)
    
    def _generate_name(self) -> str:
        """Generate a random container name."""
        adjectives = [
            "happy", "brave", "clever", "eager", "fancy",
            "gentle", "jolly", "kind", "lively", "merry",
            "nice", "proud", "quick", "smart", "witty",
        ]
        nouns = [
            "ant", "bear", "cat", "dog", "eagle",
            "fox", "goat", "hawk", "ibis", "jay",
            "koala", "lion", "mouse", "newt", "owl",
        ]
        
        import random
        return f"{random.choice(adjectives)}_{random.choice(nouns)}"
    
    def create(
        self,
        image_ref: str,
        name: Optional[str] = None,
        command: Optional[List[str]] = None,
        env: Optional[Dict[str, str]] = None,
        volumes: Optional[List[tuple]] = None,
        working_dir: Optional[str] = None,
        ports: Optional[Dict[str, int]] = None,
        restart_policy: Optional[str] = None,
        restart_max: Optional[int] = None,
        healthcheck: Optional[Dict[str, Any]] = None,
        limits: Optional[Dict[str, Any]] = None,
        network: Optional[str] = None,
    ) -> Container:
        """Create a new container from an image.
        
        Args:
            image_ref: Image reference
            name: Optional container name
            command: Optional command to run
            env: Optional environment variables
            volumes: Optional volume mounts [(host, container), ...]
            working_dir: Optional working directory
            ports: Optional port mapping {container_port: host_port}
            restart_policy: Optional restart policy ('no', 'always', 'on-failure')
            healthcheck: Optional healthcheck config
            limits: Optional resource limits (e.g., memory)
            
        Returns:
            Created Container object
            
        Raises:
            ValueError: If image not found
        """
        # Find the image
        image = self.image_store.get_image(image_ref)
        if not image:
            raise ValueError(f"Image not found: {image_ref}")
        
        # Get image config for defaults
        config = self.image_store.get_image_config(image)
        container_config = config.get("config", {})
        
        # Generate container ID and name
        container_id = uuid.uuid4().hex
        if not name:
            name = self._generate_name()
        
        # Merge environment
        merged_env = {}
        for env_str in container_config.get("Env", []) or []:
            if "=" in env_str:
                key, value = env_str.split("=", 1)
                merged_env[key] = value
        if env:
            merged_env.update(env)
        
        # Determine command
        if command is None:
            # Use image defaults
            entrypoint = container_config.get("Entrypoint") or []
            cmd = container_config.get("Cmd") or []
            command = entrypoint + cmd
        
        if not command:
            command = ["/bin/sh"]
        
        # Determine working directory
        if working_dir is None:
            working_dir = container_config.get("WorkingDir") or "/"
        
        image_user = container_config.get("User")
        if image_user == "":
            image_user = None
        
        # Create container
        container = Container(
            container_id=container_id,
            name=name,
            image=image_ref,
            image_id=image.image_id,
            created=datetime.utcnow().isoformat(),
            status="created",
            command=command,
            env=merged_env,
            volumes=volumes or [],
            working_dir=working_dir,
            user=image_user,
            ports=ports or {},
            restart_policy=restart_policy or "no",
            restart_max=restart_max,
            healthcheck=healthcheck,
            limits=limits,
        )
        
        # Create container directory
        container_dir = self.get_container_dir(container)
        container_dir.mkdir(parents=True, exist_ok=True)
        
        # Save container config
        config_path = container_dir / "container.json"
        with open(config_path, "w") as f:
            json.dump(container.to_dict(), f, indent=2)
        
        # Create rootfs
        self.image_store.create_rootfs(image, container_dir)
        
        return container
    
    def get_container_dir(self, container: Container) -> Path:
        """Get the directory for a container.
        
        Args:
            container: Container object
            
        Returns:
            Path to container directory
        """
        return self.config.containers_dir / container.container_id
    
    def get_rootfs(self, container: Container) -> Path:
        """Get the rootfs path for a container.
        
        Args:
            container: Container object
            
        Returns:
            Path to rootfs directory
        """
        return self.get_container_dir(container) / "rootfs"
    
    def list_containers(self, all: bool = False) -> List[Container]:
        """List containers.
        
        Args:
            all: If True, include stopped containers
            
        Returns:
            List of Container objects
        """
        containers = []
        
        if not self.config.containers_dir.exists():
            return containers
        
        for container_dir in self.config.containers_dir.iterdir():
            if not container_dir.is_dir():
                continue
            
            config_path = container_dir / "container.json"
            if not config_path.exists():
                continue
            
            try:
                with open(config_path) as f:
                    data = json.load(f)
                
                container = Container.from_dict(data)
                
                if all or container.status == "running":
                    containers.append(container)
            except (json.JSONDecodeError, KeyError) as e:
                print(f"Warning: Failed to load container {container_dir.name}: {e}")
        
        return containers
    
    def get_container(self, reference: str) -> Optional[Container]:
        """Get a container by reference.
        
        Args:
            reference: Container ID or name
            
        Returns:
            Container or None if not found
        """
        containers = self.list_containers(all=True)
        
        for container in containers:
            if container.name == reference:
                return container
            if reference.startswith(container.container_id) or container.container_id.startswith(reference):
                return container
        
        return None
    
    def update_status(self, container: Container, status: str) -> None:
        """Update container status.
        
        Args:
            container: Container object
            status: New status
        """
        container.status = status
        
        self.save_container(container)

    def save_container(self, container: Container) -> None:
        config_path = self.get_container_dir(container) / "container.json"
        with open(config_path, "w") as f:
            json.dump(container.to_dict(), f, indent=2)
    
    def remove(self, reference: str, force: bool = False) -> bool:
        """Remove a container.
        
        Args:
            reference: Container ID or name
            force: Force removal even if running
            
        Returns:
            True if removed, False if not found
        """
        container = self.get_container(reference)
        if not container:
            return False
        
        if container.status == "running" and not force:
            raise ValueError(f"Container {container.name} is running. Use force=True to remove.")
        
        container_dir = self.get_container_dir(container)
        if container_dir.exists():
            def handle_remove_error(func, path, exc_info):
                try:
                    os.chmod(path, 0o700)
                    func(path)
                except Exception:
                    pass
            shutil.rmtree(container_dir, onerror=handle_remove_error)
        
        return True
