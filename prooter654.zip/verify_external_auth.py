
import json
import base64
import os
import shutil
from pathlib import Path
from prooter.registry.auth import AuthConfig

def verify_external_auth():
    print("Verifying external auth config...")
    
    # Setup paths
    home = Path.home()
    prooter_dir = home / ".prooter"
    prooter_auth = prooter_dir / "auth.json"
    
    docker_dir = home / ".docker"
    docker_config = docker_dir / "config.json"
    
    # Ensure directories
    prooter_dir.mkdir(parents=True, exist_ok=True)
    docker_dir.mkdir(parents=True, exist_ok=True)
    
    # Backup existing docker config if any
    docker_backup = None
    if docker_config.exists():
        docker_backup = docker_config.with_suffix(".bak")
        shutil.copy(docker_config, docker_backup)
        
    # Clean prooter auth
    if prooter_auth.exists():
        prooter_auth.unlink()
        
    try:
        # Create dummy docker config
        encoded_auth = base64.b64encode(b"dockeruser:dockerpass").decode("utf-8")
        docker_data = {
            "auths": {
                "https://index.docker.io/v1/": {
                    "auth": encoded_auth
                }
            }
        }
        with open(docker_config, "w") as f:
            json.dump(docker_data, f)
            
        # Test extraction
        print("Test 1: Read from Docker config...", end=" ")
        auth_config = AuthConfig()
        creds = auth_config.get_credentials("docker.io")
        
        if creds == ("dockeruser", "dockerpass"):
            print("PASSED")
        else:
            print(f"FAILED (Got {creds})")
            
        # Test priority (Prooter > Docker)
        print("Test 2: Prooter config priority...", end=" ")
        auth_config.set_credentials("docker.io", "prooteruser", "prooterpass")
        creds = auth_config.get_credentials("docker.io")
        
        if creds == ("prooteruser", "prooterpass"):
            print("PASSED")
        else:
            print(f"FAILED (Got {creds})")
            
    finally:
        # Restore/Cleanup
        if docker_config.exists():
            docker_config.unlink()
        if docker_backup and docker_backup.exists():
            shutil.move(docker_backup, docker_config)
        if prooter_auth.exists():
            prooter_auth.unlink()

if __name__ == "__main__":
    verify_external_auth()
