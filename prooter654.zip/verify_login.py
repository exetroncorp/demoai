import sys
import os
import json
import subprocess
import shutil
from pathlib import Path

def run_prooter(args):
    """Run prooter with args."""
    cmd = [sys.executable, "-m", "prooter"] + args
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result

def verify_login():
    print("Verifying prooter login...")
    
    # Setup paths
    home = Path.home()
    prooter_dir = home / ".prooter"
    auth_file = prooter_dir / "auth.json"
    
    # Clean up
    if auth_file.exists():
        auth_file.unlink()
        
    # Test 1: Login with CLI args
    print("Test 1: Login with CLI args...", end=" ")
    res = run_prooter(["login", "-u", "testuser", "-p", "testpass", "localhost:5000"])
    
    if res.returncode != 0:
        print("FAILED")
        print(res.stderr)
        return
        
    if not auth_file.exists():
        print("FAILED (File not created)")
        return
        
    with open(auth_file) as f:
        data = json.load(f)
        
    auths = data.get("auths", {})
    if "localhost:5000" not in auths:
        print("FAILED (Entry not found)")
        return
        
    print("PASSED")
    
    # Test 2: Login to docker.io (default)
    print("Test 2: Login to default (docker.io)...", end=" ")
    res = run_prooter(["login", "-u", "dockeruser", "-p", "dockerpass"])
    
    if res.returncode != 0:
        print("FAILED")
        print(res.stderr)
        return
        
    with open(auth_file) as f:
        data = json.load(f)
        
    auths = data.get("auths", {})
    # Should normalize to index.docker.io/v1/
    if "https://index.docker.io/v1/" not in auths:
        print("FAILED (Entry not found or not normalized)")
        print(f"Auths: {auths.keys()}")
        return
        
    print("PASSED")
    
    # Test 3: Check --insecure flag existence in pull
    print("Test 3: Check --insecure flag in pull...", end=" ")
    res = run_prooter(["pull", "--help"])
    if "--insecure" in res.stdout:
        print("PASSED")
    else:
        print("FAILED")

if __name__ == "__main__":
    verify_login()
