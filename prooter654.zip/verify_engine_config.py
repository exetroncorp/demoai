
import json
import os
from pathlib import Path
from prooter.config import init_config
from prooter.execution.base import get_best_engine
from prooter.execution.proot import PRootEngine
from prooter.execution.fakechroot import FakechrootEngine

def verify_engine_config():
    print("Verifying engine config...")
    
    # Setup paths
    home = Path.home()
    prooter_dir = home / ".prooter"
    config_file = prooter_dir / "config.json"
    
    # Ensure directory exists
    prooter_dir.mkdir(parents=True, exist_ok=True)
    
    # Test 1: Force PRoot
    print("Test 1: Force PRoot...", end=" ")
    with open(config_file, "w") as f:
        json.dump({"execution-engine": "proot"}, f)
        
    init_config() # Reload config
    engine = get_best_engine()
    
    if isinstance(engine, PRootEngine):
        print("PASSED")
    else:
        print(f"FAILED (Got {type(engine)})")
        
    # Test 2: Force Fakechroot
    print("Test 2: Force Fakechroot...", end=" ")
    with open(config_file, "w") as f:
        json.dump({"execution-engine": "fakechroot"}, f)
        
    init_config() # Reload config
    engine = get_best_engine()
    
    if isinstance(engine, FakechrootEngine):
        print("PASSED")
    else:
        print(f"FAILED (Got {type(engine)})")

    # Clean up
    if config_file.exists():
        config_file.unlink()

if __name__ == "__main__":
    verify_engine_config()
