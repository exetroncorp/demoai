import signal
import sys
import time
from pathlib import Path

from prooter.container.manager import ContainerManager
from prooter.execution.proot import PRootEngine


_stop = False
_child = None


def _handle_signal(signum, frame):
    global _stop
    _stop = True
    if _child and _child.poll() is None:
        try:
            _child.terminate()
        except Exception:
            pass


def _run_healthcheck(engine: PRootEngine, container, rootfs: Path) -> int:
    health = container.healthcheck or {}
    test = health.get("test")
    if not test:
        return 0
    if isinstance(test, list):
        cmd = test
    else:
        cmd = ["/bin/sh", "-c", str(test)]
    return engine.run(
        rootfs=rootfs,
        command=cmd,
        env=container.env,
        working_dir=container.working_dir,
        volumes=container.volumes,
        interactive=False,
        tty=False,
    )


def main(argv=None) -> int:
    argv = argv or sys.argv[1:]
    if not argv:
        return 1
    container_id = argv[0]
    manager = ContainerManager()
    container = manager.get_container(container_id)
    if not container:
        return 1
    rootfs = manager.get_rootfs(container)
    engine = PRootEngine()
    container_dir = manager.get_container_dir(container)
    logs_dir = container_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = Path(container.log_path) if container.log_path else logs_dir / "stdout.log"
    stderr_path = logs_dir / "stderr.log"
    interval = (container.healthcheck or {}).get("interval", 30.0)
    restart_policy = container.restart_policy or "no"
    restart_count = container.restart_count or 0
    restart_max = container.restart_max
    if restart_max is None and container.limits:
        restart_max = container.limits.get("restart_max")
    
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)
    
    global _child
    while True:
        if _stop:
            break
        _child = engine.run_detached(
            rootfs=rootfs,
            command=container.command,
            env=container.env,
            working_dir=container.working_dir,
            volumes=container.volumes,
            stdout_path=stdout_path,
            stderr_path=stderr_path,
        )
        container.pid = _child.pid
        container.status = "running"
        manager.save_container(container)
        last_health = 0.0
        while _child.poll() is None and not _stop:
            if container.healthcheck:
                now = time.time()
                if now - last_health >= interval:
                    code = _run_healthcheck(engine, container, rootfs)
                    container.health_status = "healthy" if code == 0 else "unhealthy"
                    manager.save_container(container)
                    last_health = now
            time.sleep(1)
        exit_code = _child.poll()
        container.pid = None
        container.status = "exited"
        manager.save_container(container)
        if _stop:
            break
        should_restart = False
        if restart_policy == "always":
            should_restart = True
        if restart_policy == "on-failure" and exit_code and exit_code != 0:
            should_restart = True
        if restart_max is not None and restart_count >= restart_max:
            should_restart = False
        if should_restart:
            restart_count += 1
            container.restart_count = restart_count
            manager.save_container(container)
            time.sleep(1)
            continue
        break
    
    if container.limits and "supervisor_pid" in container.limits:
        container.limits.pop("supervisor_pid")
    manager.save_container(container)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
