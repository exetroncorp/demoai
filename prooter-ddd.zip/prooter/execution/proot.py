"""PRoot-based execution engine using ptrace syscall interception."""

import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional

from prooter.execution.base import BaseEngine, ExecutionMode


class PRootEngine(BaseEngine):
    """Execution engine using PRoot (ptrace-based).
    
    PRoot uses ptrace to intercept syscalls and provides:
    - Fake root user (uid=0) emulation
    - Path translation (chroot-like behavior)
    - Bind mount emulation
    
    This works without any privileges and doesn't require namespaces.
    """
    
    mode = ExecutionMode.PROOT
    
    # PRoot release URLs for static binaries
    # Using proot-static-build releases which provide prebuilt binaries
    PROOT_URLS = {
        "x86_64": "https://proot.gitlab.io/proot/bin/proot",
        "aarch64": "https://proot.gitlab.io/proot/bin/proot",
    }
    
    # Fallback to building from Alpine package
    ALPINE_PROOT_URL = "https://dl-cdn.alpinelinux.org/alpine/v3.19/community/x86_64/"
    
    def __init__(self, config=None):
        """Initialize PRoot engine."""
        super().__init__(config)
        self._proot_path: Optional[Path] = None
    
    @property
    def proot_binary(self) -> Path:
        """Get path to PRoot binary."""
        if self._proot_path:
            return self._proot_path
        
        # Check configured location (~/.prooter/bin/proot)
        if self.config.proot_binary.exists():
            self._proot_path = self.config.proot_binary
            return self._proot_path
        
        # Check bundled proot-dist folder (shipped with package)
        bundled_proot = Path(__file__).parent.parent / "proot-dist" / "proot"
        if bundled_proot.exists():
            self._proot_path = bundled_proot
            return self._proot_path
        
        # Check system PATH
        system_proot = shutil.which("proot")
        if system_proot:
            self._proot_path = Path(system_proot)
            return self._proot_path
        
        return self.config.proot_binary
    
    def is_available(self) -> bool:
        """Check if PRoot is available."""
        binary = self.proot_binary
        if binary.exists():
            # Verify it's executable
            try:
                result = subprocess.run(
                    [str(binary), "--version"],
                    capture_output=True,
                    timeout=5,
                )
                return result.returncode == 0
            except (subprocess.SubprocessError, OSError):
                return False
        return False
    
    def download_proot(self) -> Path:
        """Download PRoot binary.
        
        Returns:
            Path to downloaded binary
        """
        import platform
        
        # Determine architecture
        arch = platform.machine().lower()
        if arch in ("x86_64", "amd64"):
            arch_key = "x86_64"
        elif arch in ("aarch64", "arm64"):
            arch_key = "aarch64"
        else:
            raise RuntimeError(f"Unsupported architecture: {arch}")
        
        target = self.config.proot_binary
        target.parent.mkdir(parents=True, exist_ok=True)
        
        # Try multiple download sources
        urls = [
            self.PROOT_URLS.get(arch_key),
            f"https://github.com/proot-me/proot-static-build/releases/download/v5.3.0/proot-v5.3.0-{arch_key}-static",
            f"https://github.com/proot-me/proot/releases/latest/download/proot-{arch_key}",
        ]
        
        tmp_path = target.with_suffix(".tmp")
        
        for url in urls:
            if not url:
                continue
                
            print(f"Downloading PRoot from {url}...")
            
            # Download with progress
            def reporthook(block_num, block_size, total_size):
                if total_size > 0:
                    downloaded = block_num * block_size
                    pct = min(100, downloaded * 100 // total_size)
                    print(f"\r  Progress: {pct}%", end="", flush=True)
            
            try:
                urllib.request.urlretrieve(url, tmp_path, reporthook)
                print()  # Newline after progress
                
                # Make executable
                os.chmod(tmp_path, 0o755)
                
                # Verify it works
                result = subprocess.run(
                    [str(tmp_path), "--version"],
                    capture_output=True,
                    timeout=5,
                )
                
                if result.returncode == 0:
                    # Rename to final location
                    tmp_path.rename(target)
                    
                    print(f"PRoot installed to {target}")
                    self._proot_path = target
                    return target
                else:
                    print(f"  Downloaded binary not working, trying next source...")
                    tmp_path.unlink()
                    
            except Exception as e:
                print(f"  Failed: {e}")
                if tmp_path.exists():
                    tmp_path.unlink()
                continue
        
        # If all downloads failed, try to install via package manager
        raise RuntimeError(
            "Failed to download PRoot from any source. "
            "Please install PRoot manually: apt-get install proot"
        )

    
    def run(
        self,
        rootfs: Path,
        command: List[str],
        env: Dict[str, str],
        working_dir: str = "/",
        volumes: Optional[List[tuple]] = None,
        interactive: bool = False,
        tty: bool = False,
        user: Optional[str] = None,
    ) -> int:
        """Run a command using PRoot.
        
        Args:
            rootfs: Path to the root filesystem
            command: Command to execute
            env: Environment variables
            working_dir: Working directory inside container
            volumes: List of (host_path, container_path) tuples
            interactive: Keep stdin open
            tty: Allocate a pseudo-TTY
            user: User to run as (ignored, always fakes root)
            
        Returns:
            Exit code of the command
        """
        if not self.is_available():
            # Try to download PRoot
            self.download_proot()
        
        binary = self.proot_binary
        if not binary.exists():
            raise RuntimeError("PRoot binary not found")
        
        proot_args = self.build_proot_args(
            binary=binary,
            rootfs=rootfs,
            command=command,
            working_dir=working_dir,
            volumes=volumes,
        )
        
        # Prepare environment
        full_env = self.prepare_env(env, rootfs)
        
        # Run the command
        try:
            if interactive or tty:
                # Interactive mode - connect to terminal
                result = subprocess.run(
                    proot_args,
                    env=full_env,
                    stdin=sys.stdin if interactive else None,
                )
                return result.returncode
            else:
                # Non-interactive mode
                result = subprocess.run(
                    proot_args,
                    env=full_env,
                    capture_output=False,
                )
                return result.returncode
                
        except KeyboardInterrupt:
            return 130  # Standard exit code for SIGINT
        except Exception as e:
            print(f"Error running command: {e}", file=sys.stderr)
            return 1

    def build_proot_args(
        self,
        binary: Path,
        rootfs: Path,
        command: List[str],
        working_dir: str = "/",
        volumes: Optional[List[tuple]] = None,
    ) -> List[str]:
        proot_args = [
            str(binary),
            "-0",
            "-r", str(rootfs),
            "-w", working_dir,
        ]
        
        system_binds = [
            "/etc/resolv.conf",
            "/etc/hosts",
            "/proc",
            "/dev",
            "/sys",
        ]
        
        for sys_path in system_binds:
            if Path(sys_path).exists():
                proot_args.extend(["-b", sys_path])
        
        validated_volumes = self.validate_volumes(volumes)
        for host_path, container_path in validated_volumes:
            proot_args.extend(["-b", f"{host_path}:{container_path}"])
        
        proot_args.extend(command)
        return proot_args

    def run_detached(
        self,
        rootfs: Path,
        command: List[str],
        env: Dict[str, str],
        working_dir: str = "/",
        volumes: Optional[List[tuple]] = None,
        stdout_path: Optional[Path] = None,
        stderr_path: Optional[Path] = None,
    ) -> subprocess.Popen:
        if not self.is_available():
            self.download_proot()
        
        binary = self.proot_binary
        if not binary.exists():
            raise RuntimeError("PRoot binary not found")
        
        proot_args = self.build_proot_args(
            binary=binary,
            rootfs=rootfs,
            command=command,
            working_dir=working_dir,
            volumes=volumes,
        )
        
        full_env = self.prepare_env(env, rootfs)
        
        stdout_handle = open(stdout_path, "ab") if stdout_path else subprocess.DEVNULL
        stderr_handle = open(stderr_path, "ab") if stderr_path else subprocess.DEVNULL
        
        return subprocess.Popen(
            proot_args,
            env=full_env,
            stdin=subprocess.DEVNULL,
            stdout=stdout_handle,
            stderr=stderr_handle,
        )
    
    def run_bundle(
        self,
        bundle_path: Path,
        container_id: Optional[str] = None,
        interactive: bool = False,
        tty: bool = False,
    ) -> int:
        """Run a container from an OCI runtime bundle.
        
        This provides runc-like functionality using PRoot.
        The bundle should contain:
        - rootfs/ directory with the container filesystem
        - config.json with OCI runtime spec
        
        Args:
            bundle_path: Path to OCI runtime bundle directory
            container_id: Optional container ID (for logging)
            interactive: Keep stdin open
            tty: Allocate a pseudo-TTY
            
        Returns:
            Exit code of the container process
        """
        import json
        
        rootfs = bundle_path / "rootfs"
        config_path = bundle_path / "config.json"
        
        if not rootfs.exists():
            raise RuntimeError(f"Bundle rootfs not found: {rootfs}")
        
        # Read OCI runtime config if available
        command = ["/bin/sh"]
        env = {}
        working_dir = "/"
        volumes = []
        
        if config_path.exists():
            try:
                with open(config_path) as f:
                    config = json.load(f)
                
                # Extract process config
                process = config.get("process", {})
                
                # Command (args in OCI spec)
                args = process.get("args", [])
                if args:
                    command = args
                
                # Environment
                env_list = process.get("env", [])
                for env_str in env_list:
                    if "=" in env_str:
                        key, value = env_str.split("=", 1)
                        env[key] = value
                
                # Working directory (cwd in OCI spec)
                working_dir = process.get("cwd", "/")
                
                # Mounts (convert to volumes)
                mounts = config.get("mounts", [])
                for mount in mounts:
                    source = mount.get("source")
                    destination = mount.get("destination")
                    if source and destination and Path(source).exists():
                        # Skip special mounts that PRoot handles
                        if destination not in ["/proc", "/dev", "/sys"]:
                            volumes.append((source, destination))
                            
            except (json.JSONDecodeError, KeyError) as e:
                print(f"Warning: Failed to parse bundle config: {e}")
        
        # Use the existing run method
        return self.run(
            rootfs=rootfs,
            command=command,
            env=env,
            working_dir=working_dir,
            volumes=volumes,
            interactive=interactive,
            tty=tty,
        )

