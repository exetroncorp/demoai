#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════
//  YACINE BANK — Spring Boot DDD/Hexagonal Project Scaffold
//  "make money great again"
// ═══════════════════════════════════════════════════════════
import fs from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

// ── Sub-module imports ──
import { generatePom } from "./templates/pom.mjs";
import { generateBackend } from "./templates/backend.mjs";
import { generateDocker } from "./templates/docker.mjs";
import { generateTests } from "./templates/tests.mjs";
import { generateFrontendConfig } from "./templates/frontend-config.mjs";
import { generateFrontendCore } from "./templates/frontend-core.mjs";
import { generateFrontendUI } from "./templates/frontend-ui.mjs";

// ── Args ──
const args = process.argv.slice(2);
if (args.length < 3) {
  console.error("Usage: node scaffold.mjs <groupId> <artifactId> <basePackage>");
  console.error("Example: node scaffold.mjs com.yacine yacine-bank com.yacine.bank");
  process.exit(1);
}
const [groupId, artifactId, basePackage] = args;
const root = join(process.cwd(), artifactId);

if (!/^[a-z0-9.]+$/.test(groupId) || !/^[a-z0-9-]+$/.test(artifactId) || !/^[a-z0-9.]+$/.test(basePackage)) {
  console.error("❌ Invalid naming format."); process.exit(1);
}

const __dirname = dirname(fileURLToPath(import.meta.url));
const { mkdirSync, writeFileSync, existsSync, copyFileSync } = fs;

console.log(`\n🏦 Scaffolding YACINE BANK project "${artifactId}" in ${root}...\n`);

// ── Directory paths ──
const srcJava = join(root, "src/main/java", basePackage.replace(/\./g, "/"));
const srcRes  = join(root, "src/main/resources");
const testJava = join(root, "src/test/java", basePackage.replace(/\./g, "/"));
const testRes  = join(root, "src/test/resources");
const fe = join(root, "frontend");

// ── Create directory structure ──
[
  join(srcJava,"domain/model"), join(srcJava,"domain/port/in"), join(srcJava,"domain/port/out"),
  join(srcJava,"application/service"),
  join(srcJava,"infrastructure/adapter/in/web"), join(srcJava,"infrastructure/adapter/out/persistence"),
  join(srcJava,"infrastructure/config"), srcRes,
  join(testJava,"domain/model"), join(testJava,"application/service"),
  join(testJava,"infrastructure/adapter/in/web"), join(testJava,"bdd/steps"), join(testRes,"features"),
  join(fe,"public"), join(fe,"src/components/ui"), join(fe,"src/components/layout"),
  join(fe,"src/components/shared"), join(fe,"src/hooks"), join(fe,"src/pages"), join(fe,"src/lib")
].forEach(d => mkdirSync(d, { recursive: true }));

// ── File writer helper ──
function file(path, content) { writeFileSync(path, content.trim() + "\n"); }

// ── Copy logo if available ──
const logoSrc = join(__dirname, "..", "resources", "logo.png");
if (existsSync(logoSrc)) {
  copyFileSync(logoSrc, join(fe, "public", "logo.png"));
  console.log("  ✓ Copied logo.png");
}

// ── Shared context ──
const ctx = { root, srcJava, srcRes, testJava, testRes, fe, groupId, artifactId, basePackage };

// ── Generate everything ──
generatePom(file, ctx);            console.log("  ✓ pom.xml");
generateBackend(file, ctx);        console.log("  ✓ Backend (Application, Config, ExceptionHandler)");
generateDocker(file, ctx);         console.log("  ✓ Docker (Dockerfile, docker-compose.yml)");
generateTests(file, ctx);          console.log("  ✓ Tests (JUnit, Cucumber BDD)");
generateFrontendConfig(file, ctx); console.log("  ✓ Frontend config (Vite, Tailwind, TypeScript)");
generateFrontendCore(file, ctx);   console.log("  ✓ Frontend core (CSS theme, Router, API hooks)");
generateFrontendUI(file, ctx);     console.log("  ✓ Frontend UI (Sidebar, TopBar, CRUD components, Dashboard)");

// ── README ──
file(join(root,"README.md"),`# ${artifactId}

> **YACINE BANK** — *make money great again*

## Quick Start

\`\`\`bash
# Backend (H2 in-memory, port 8080)
mvn clean verify
mvn spring-boot:run

# Frontend (Vite, port 5173, proxied to backend)
cd frontend && npm install && npm run dev
\`\`\`

## Add a Domain Entity

\`\`\`bash
node scripts/add-entity.mjs . ${basePackage} Account name:String balance:BigDecimal status:String
\`\`\`

## Architecture

DDD / Hexagonal (Ports & Adapters). See SKILL.md for full documentation.

## Production

\`\`\`bash
docker compose up --build
\`\`\`
`);

// ── .gitignore ──
file(join(root,".gitignore"),`target/
!.mvn/wrapper/maven-wrapper.jar
*.class
*.jar
*.war
*.log
.idea/
*.iml
.vscode/
.DS_Store
*.swp
.env
application-local.properties
frontend/node_modules/
frontend/dist/`);

console.log(`\n✅ YACINE BANK project scaffolded: ${root}`);
console.log(`\nNext steps:`);
console.log(`  cd ${artifactId}`);
console.log(`  mvn clean verify`);
console.log(`  cd frontend && npm install && npm run dev\n`);
