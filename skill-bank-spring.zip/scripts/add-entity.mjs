#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════
//  YACINE BANK — Add Entity Generator
//  Generates full backend + frontend CRUD for a domain entity
// ═══════════════════════════════════════════════════════════
import fs from "node:fs";
import { join } from "node:path";

const args = process.argv.slice(2);
if (args.length < 4) {
  console.error("Usage: node add-entity.mjs <projectDir> <basePackage> <EntityName> <field:Type> [field:Type ...]");
  console.error("Example: node add-entity.mjs ./yacine-bank com.yacine.bank Account name:String balance:BigDecimal status:String");
  console.error("\nSupported types: String, Integer, Long, Double, BigDecimal, Boolean, Instant, LocalDate");
  process.exit(1);
}

const [projectDir, basePackage, entityName, ...rawFields] = args;
const root = projectDir;

// ── Parse fields ──
const fields = rawFields.map(f => {
  const [name, type] = f.split(":");
  if (!name || !type) { console.error(`❌ Invalid field: ${f}. Use name:Type format.`); process.exit(1); }
  return { name, type };
});

// ── Naming helpers ──
const Entity = entityName;                                     // Account
const entity = Entity.charAt(0).toLowerCase() + Entity.slice(1); // account
const entities = entity + "s";                                    // accounts
const ENTITY_TABLE = entity.replace(/([A-Z])/g, '_$1').toLowerCase() + "s"; // accounts
const apiPath = "/" + entities;                                    // /accounts

const pkgPath = basePackage.replace(/\./g, "/");
const srcJava = join(root, "src/main/java", pkgPath);
const testJava = join(root, "src/test/java", pkgPath);
const fe = join(root, "frontend/src");

const { mkdirSync, writeFileSync } = fs;
function file(p, c) { writeFileSync(p, c.trim() + "\n"); }
function ensureDir(d) { mkdirSync(d, { recursive: true }); }

console.log(`\n🏗️  Generating CRUD for entity "${Entity}"...\n`);

// ── Java Import map ──
const typeImports = new Set();
fields.forEach(f => {
  if (f.type === "BigDecimal") typeImports.add("import java.math.BigDecimal;");
  if (f.type === "Instant")    typeImports.add("import java.time.Instant;");
  if (f.type === "LocalDate")  typeImports.add("import java.time.LocalDate;");
});
const importBlock = [...typeImports].join("\n");

// ═══════════════════════════════════════
//  BACKEND
// ═══════════════════════════════════════

// Entity
ensureDir(join(srcJava, "domain/model"));
file(join(srcJava, `domain/model/${Entity}.java`),
`package ${basePackage}.domain.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
${importBlock}

@Entity
@Table(name = "${ENTITY_TABLE}")
public class ${Entity} {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

${fields.map(f => `    @Column
    private ${f.type} ${f.name};`).join("\n\n")}

    protected ${Entity}() {} // JPA

    public ${Entity}(${fields.map(f => `${f.type} ${f.name}`).join(", ")}) {
${fields.map(f => `        this.${f.name} = ${f.name};`).join("\n")}
    }

    public Long getId() { return id; }
${fields.map(f => {
  const cap = f.name.charAt(0).toUpperCase() + f.name.slice(1);
  return `    public ${f.type} get${cap}() { return ${f.name}; }\n    public void set${cap}(${f.type} ${f.name}) { this.${f.name} = ${f.name}; }`;
}).join("\n")}
}`);

// Use Case Port (in)
ensureDir(join(srcJava, "domain/port/in"));
file(join(srcJava, `domain/port/in/Manage${Entity}UseCase.java`),
`package ${basePackage}.domain.port.in;

import ${basePackage}.domain.model.${Entity};
import java.util.List;

public interface Manage${Entity}UseCase {
    ${Entity} create(${fields.map(f => `${f.type} ${f.name}`).join(", ")});
    List<${Entity}> listAll();
    ${Entity} getById(Long id);
    ${Entity} update(Long id, ${fields.map(f => `${f.type} ${f.name}`).join(", ")});
    void delete(Long id);
}`);

// Repository Port (out)
ensureDir(join(srcJava, "domain/port/out"));
file(join(srcJava, `domain/port/out/${Entity}Repository.java`),
`package ${basePackage}.domain.port.out;

import ${basePackage}.domain.model.${Entity};
import java.util.List;
import java.util.Optional;

public interface ${Entity}Repository {
    ${Entity} save(${Entity} entity);
    Optional<${Entity}> findById(Long id);
    List<${Entity}> findAll();
    void deleteById(Long id);
}`);

// Service
ensureDir(join(srcJava, "application/service"));
file(join(srcJava, `application/service/${Entity}Service.java`),
`package ${basePackage}.application.service;

import ${basePackage}.domain.model.${Entity};
import ${basePackage}.domain.port.in.Manage${Entity}UseCase;
import ${basePackage}.domain.port.out.${Entity}Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
${importBlock}

@Service
@Transactional
public class ${Entity}Service implements Manage${Entity}UseCase {

    private final ${Entity}Repository repository;

    public ${Entity}Service(${Entity}Repository repository) {
        this.repository = repository;
    }

    @Override
    public ${Entity} create(${fields.map(f => `${f.type} ${f.name}`).join(", ")}) {
        return repository.save(new ${Entity}(${fields.map(f => f.name).join(", ")}));
    }

    @Override
    public List<${Entity}> listAll() { return repository.findAll(); }

    @Override
    public ${Entity} getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("${Entity} not found: " + id));
    }

    @Override
    public ${Entity} update(Long id, ${fields.map(f => `${f.type} ${f.name}`).join(", ")}) {
        ${Entity} e = getById(id);
${fields.map(f => {
  const cap = f.name.charAt(0).toUpperCase() + f.name.slice(1);
  return `        e.set${cap}(${f.name});`;
}).join("\n")}
        return repository.save(e);
    }

    @Override
    public void delete(Long id) { repository.deleteById(id); }
}`);

// JPA Repository
ensureDir(join(srcJava, "infrastructure/adapter/out/persistence"));
file(join(srcJava, `infrastructure/adapter/out/persistence/Jpa${Entity}Repository.java`),
`package ${basePackage}.infrastructure.adapter.out.persistence;

import ${basePackage}.domain.model.${Entity};
import ${basePackage}.domain.port.out.${Entity}Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Jpa${Entity}Repository extends JpaRepository<${Entity}, Long>, ${Entity}Repository {
}`);

// REST Controller
ensureDir(join(srcJava, "infrastructure/adapter/in/web"));
file(join(srcJava, `infrastructure/adapter/in/web/${Entity}Controller.java`),
`package ${basePackage}.infrastructure.adapter.in.web;

import ${basePackage}.domain.model.${Entity};
import ${basePackage}.domain.port.in.Manage${Entity}UseCase;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;
${importBlock}

@RestController
@RequestMapping("/api${apiPath}")
public class ${Entity}Controller {

    private final Manage${Entity}UseCase useCase;

    public ${Entity}Controller(Manage${Entity}UseCase useCase) {
        this.useCase = useCase;
    }

    record ${Entity}Request(${fields.map(f => `${f.type} ${f.name}`).join(", ")}) {}

    @GetMapping
    public List<${Entity}> list() { return useCase.listAll(); }

    @GetMapping("/{id}")
    public ${Entity} get(@PathVariable Long id) { return useCase.getById(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ${Entity} create(@RequestBody @Valid ${Entity}Request req) {
        return useCase.create(${fields.map(f => `req.${f.name}()`).join(", ")});
    }

    @PutMapping("/{id}")
    public ${Entity} update(@PathVariable Long id, @RequestBody @Valid ${Entity}Request req) {
        return useCase.update(id, ${fields.map(f => `req.${f.name}()`).join(", ")});
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { useCase.delete(id); }
}`);

// Unit Test
ensureDir(join(testJava, "application/service"));
file(join(testJava, `application/service/${Entity}ServiceTest.java`),
`package ${basePackage}.application.service;

import ${basePackage}.domain.model.${Entity};
import ${basePackage}.domain.port.out.${Entity}Repository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ${Entity}ServiceTest {

    @Mock private ${Entity}Repository repository;
    @InjectMocks private ${Entity}Service service;

    @Test
    void shouldCreate() {
        ${Entity} e = new ${Entity}(${fields.map(f => defaultVal(f.type)).join(", ")});
        when(repository.save(any())).thenReturn(e);
        ${Entity} result = service.create(${fields.map(f => defaultVal(f.type)).join(", ")});
        assertThat(result).isNotNull();
        verify(repository).save(any());
    }

    @Test
    void shouldThrowWhenNotFound() {
        when(repository.findById(99L)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> service.getById(99L))
                .isInstanceOf(IllegalArgumentException.class);
    }
}`);

// ═══════════════════════════════════════
//  FRONTEND
// ═══════════════════════════════════════

// API hook
ensureDir(join(fe, "hooks"));
file(join(fe, `hooks/use${Entity}.ts`),
`import { useList, useDetail, apiCreate, apiUpdate, apiDelete } from "./useApi"

export interface ${Entity} {
  id: number;
${fields.map(f => `  ${f.name}: ${tsType(f.type)};`).join("\n")}
}

const BASE = "/api${apiPath}"

export function use${Entity}List() { return useList<${Entity}>(BASE) }
export function use${Entity}Detail(id: string) { return useDetail<${Entity}>(BASE + "/" + id) }

export async function create${Entity}(data: Omit<${Entity}, "id">) { return apiCreate<${Entity}>(BASE, data) }
export async function update${Entity}(id: string, data: Omit<${Entity}, "id">) { return apiUpdate<${Entity}>(BASE + "/" + id, data) }
export async function delete${Entity}(id: string) { return apiDelete(BASE + "/" + id) }
`);

// List Page
ensureDir(join(fe, "pages"));
file(join(fe, `pages/${Entity}ListPage.tsx`),
`import { useNavigate } from "react-router-dom"
import DataTable, { type Column } from "../components/shared/DataTable"
import { use${Entity}List, delete${Entity}, type ${Entity} } from "../hooks/use${Entity}"

const columns: Column<${Entity}>[] = [
${fields.map(f => `  { key: "${f.name}", label: "${f.name.charAt(0).toUpperCase() + f.name.slice(1)}" },`).join("\n")}
]

export default function ${Entity}ListPage() {
  const { data, loading, reload } = use${Entity}List()
  const navigate = useNavigate()
  return (
    <DataTable
      columns={columns}
      data={data}
      loading={loading}
      entityLabel="${entity}"
      createPath="/${entities}/new"
      createLabel="New ${Entity}"
      onRowClick={(row) => navigate("/${entities}/" + row.id)}
      onDelete={async (row) => { await delete${Entity}(String(row.id)); reload(); }}
    />
  )
}`);

// Detail Page
file(join(fe, `pages/${Entity}DetailPage.tsx`),
`import { useParams, useNavigate } from "react-router-dom"
import DetailView, { type Field } from "../components/shared/DetailView"
import { use${Entity}Detail, delete${Entity}, type ${Entity} } from "../hooks/use${Entity}"

const fields: Field<${Entity}>[] = [
  { key: "id", label: "ID" },
${fields.map(f => `  { key: "${f.name}", label: "${f.name.charAt(0).toUpperCase() + f.name.slice(1)}" },`).join("\n")}
]

export default function ${Entity}DetailPage() {
  const { id } = useParams<{ id: string }>()
  const { data, loading } = use${Entity}Detail(id!)
  const navigate = useNavigate()
  return (
    <DetailView
      title="${Entity} Details"
      fields={fields}
      data={data}
      loading={loading}
      backPath="/${entities}"
      editPath={"/${entities}/" + id + "/edit"}
      onDelete={async () => { await delete${Entity}(id!); navigate("/${entities}"); }}
    />
  )
}`);

// Form Page (Create + Edit)
file(join(fe, `pages/${Entity}FormPage.tsx`),
`import { useParams, useNavigate } from "react-router-dom"
import CreateEditForm, { type FormField } from "../components/shared/CreateEditForm"
import { use${Entity}Detail, create${Entity}, update${Entity} } from "../hooks/use${Entity}"

const formFields: FormField[] = [
${fields.map(f => {
  const ft = f.type === "Integer" || f.type === "Long" || f.type === "Double" || f.type === "BigDecimal" ? "number" : "text";
  return `  { key: "${f.name}", label: "${f.name.charAt(0).toUpperCase() + f.name.slice(1)}", type: "${ft}", required: true },`;
}).join("\n")}
]

export default function ${Entity}FormPage() {
  const { id } = useParams<{ id: string }>()
  const isEdit = Boolean(id)
  const { data } = isEdit ? use${Entity}Detail(id!) : { data: null }
  const navigate = useNavigate()

  const handleSubmit = async (form: Record<string, any>) => {
    if (isEdit) await update${Entity}(id!, form as any)
    else await create${Entity}(form as any)
    navigate("/${entities}")
  }

  return (
    <CreateEditForm
      title={isEdit ? "Edit ${Entity}" : "New ${Entity}"}
      fields={formFields}
      initialData={data ?? undefined}
      onSubmit={handleSubmit}
      cancelPath="/${entities}"
      submitLabel={isEdit ? "Update" : "Create"}
    />
  )
}`);

// ═══════════════════════════════════════
//  DONE
// ═══════════════════════════════════════

console.log(`  ✓ Backend: ${Entity}.java, Manage${Entity}UseCase, ${Entity}Repository, ${Entity}Service, Jpa${Entity}Repository, ${Entity}Controller`);
console.log(`  ✓ Test:    ${Entity}ServiceTest.java`);
console.log(`  ✓ Frontend: use${Entity}.ts, ${Entity}ListPage.tsx, ${Entity}DetailPage.tsx, ${Entity}FormPage.tsx`);
console.log(`\n📝 Manual steps remaining:`);
console.log(`  1. Add routes to frontend/src/App.tsx:`);
console.log(`     import ${Entity}ListPage from "./pages/${Entity}ListPage"`);
console.log(`     import ${Entity}DetailPage from "./pages/${Entity}DetailPage"`);
console.log(`     import ${Entity}FormPage from "./pages/${Entity}FormPage"`);
console.log(`     <Route path="/${entities}" element={<${Entity}ListPage />} />`);
console.log(`     <Route path="/${entities}/:id" element={<${Entity}DetailPage />} />`);
console.log(`     <Route path="/${entities}/new" element={<${Entity}FormPage />} />`);
console.log(`     <Route path="/${entities}/:id/edit" element={<${Entity}FormPage />} />`);
console.log(`  2. Add nav item in frontend/src/components/layout/Sidebar.tsx:`);
console.log(`     { icon: "🏦", label: "${Entity}s", path: "/${entities}" },`);
console.log(`  3. Re-run: mvn clean compile && cd frontend && npm run dev\n`);

// ── Helpers ──
function defaultVal(type) {
  switch(type) {
    case "String": return '"test"';
    case "Integer": case "Long": return "1L";
    case "Double": return "1.0";
    case "BigDecimal": return "java.math.BigDecimal.ONE";
    case "Boolean": return "true";
    case "Instant": return "java.time.Instant.now()";
    case "LocalDate": return "java.time.LocalDate.now()";
    default: return "null";
  }
}
function tsType(type) {
  switch(type) {
    case "String": return "string";
    case "Integer": case "Long": case "Double": case "BigDecimal": return "number";
    case "Boolean": return "boolean";
    default: return "string";
  }
}
