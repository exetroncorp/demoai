// Test files generation: unit test, BDD/Cucumber, health steps
import { join } from "node:path";

export function generateTests(file, { testJava, testRes, basePackage }) {

  file(join(testJava,"ApplicationTest.java"),`package ${basePackage};
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class ApplicationTest { @Test void contextLoads() {} }`);

  file(join(testJava,"bdd/CucumberTest.java"),`package ${basePackage}.bdd;
import org.junit.platform.suite.api.*;
import static io.cucumber.junit.platform.engine.Constants.*;
@Suite @IncludeEngines("cucumber") @SelectClasspathResource("features")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "${basePackage}.bdd.steps")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "pretty")
public class CucumberTest {}`);

  file(join(testJava,"bdd/steps/SpringIntegrationTest.java"),`package ${basePackage}.bdd.steps;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
@CucumberContextConfiguration
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class SpringIntegrationTest {}`);

  file(join(testRes,"features/placeholder.feature"),`Feature: Application health check
  Scenario: Health endpoint returns UP
    Given the application is running
    When I check the health endpoint
    Then the status should be "UP"`);

  file(join(testJava,"bdd/steps/HealthSteps.java"),`package ${basePackage}.bdd.steps;
import io.cucumber.java.en.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.assertj.core.api.Assertions.assertThat;
public class HealthSteps {
    @Autowired private MockMvc mockMvc;
    private MvcResult result;
    @Given("the application is running") public void running() {}
    @When("I check the health endpoint") public void check() throws Exception {
        result = mockMvc.perform(get("/actuator/health")).andExpect(status().isOk()).andReturn();
    }
    @Then("the status should be {string}") public void verify(String expected) throws Exception {
        assertThat(result.getResponse().getContentAsString()).contains(expected);
    }
}`);
}
