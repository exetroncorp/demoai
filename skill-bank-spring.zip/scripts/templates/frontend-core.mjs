// YACINE BANK theme CSS + core files (main.tsx, App.tsx, lib/utils, theme-provider)
import { join } from "node:path";

export function generateFrontendCore(file, { fe, basePackage }) {

// ── CSS Theme ──
file(join(fe,"src/index.css"),`@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 210 40% 98%;
    --foreground: 222 47% 11%;
    --card: 0 0% 100%;
    --card-foreground: 222 47% 11%;
    --popover: 0 0% 100%;
    --popover-foreground: 222 47% 11%;
    --primary: 217 91% 53%;
    --primary-foreground: 0 0% 100%;
    --secondary: 214 32% 91%;
    --secondary-foreground: 222 47% 11%;
    --muted: 214 32% 91%;
    --muted-foreground: 215 16% 47%;
    --accent: 250 83% 58%;
    --accent-foreground: 0 0% 100%;
    --destructive: 0 84% 60%;
    --destructive-foreground: 0 0% 98%;
    --border: 214 32% 88%;
    --input: 214 32% 88%;
    --ring: 217 91% 53%;
    --radius: 0.75rem;
    --chart-1: 217 91% 53%;
    --chart-2: 250 83% 58%;
    --chart-3: 142 71% 45%;
    --chart-4: 43 96% 56%;
    --chart-5: 0 84% 60%;
  }
  .dark {
    --background: 240 20% 5%;
    --foreground: 240 20% 93%;
    --card: 240 17% 8%;
    --card-foreground: 240 20% 93%;
    --popover: 240 17% 8%;
    --popover-foreground: 240 20% 93%;
    --primary: 248 90% 69%;
    --primary-foreground: 240 20% 5%;
    --secondary: 240 19% 13%;
    --secondary-foreground: 240 20% 93%;
    --muted: 240 19% 13%;
    --muted-foreground: 240 14% 60%;
    --accent: 164 84% 62%;
    --accent-foreground: 240 20% 5%;
    --destructive: 331 84% 68%;
    --destructive-foreground: 240 20% 93%;
    --border: 240 18% 20%;
    --input: 240 18% 20%;
    --ring: 248 90% 69%;
    --chart-1: 248 90% 69%;
    --chart-2: 164 84% 62%;
    --chart-3: 32 85% 62%;
    --chart-4: 331 84% 68%;
    --chart-5: 240 20% 93%;
  }
  .theme-nord {
    --background: 220 16% 22%;
    --foreground: 218 27% 92%;
    --card: 222 16% 28%;
    --card-foreground: 218 27% 92%;
    --popover: 222 16% 28%;
    --popover-foreground: 218 27% 92%;
    --primary: 193 43% 67%;
    --primary-foreground: 220 16% 22%;
    --secondary: 220 17% 32%;
    --secondary-foreground: 218 27% 92%;
    --muted: 220 17% 32%;
    --muted-foreground: 218 22% 51%;
    --accent: 311 20% 63%;
    --accent-foreground: 220 16% 22%;
    --destructive: 354 42% 56%;
    --destructive-foreground: 218 27% 92%;
    --border: 220 17% 32%;
    --input: 220 17% 32%;
    --ring: 193 43% 67%;
    --chart-1: 193 43% 67%;
    --chart-2: 311 20% 63%;
    --chart-3: 163 41% 60%;
    --chart-4: 43 77% 76%;
    --chart-5: 354 42% 56%;
  }
  .theme-dracula {
    --background: 231 15% 18%;
    --foreground: 60 30% 96%;
    --card: 232 14% 21%;
    --card-foreground: 60 30% 96%;
    --popover: 232 14% 21%;
    --popover-foreground: 60 30% 96%;
    --primary: 326 100% 74%;
    --primary-foreground: 231 15% 18%;
    --secondary: 232 14% 31%;
    --secondary-foreground: 60 30% 96%;
    --muted: 232 14% 31%;
    --muted-foreground: 225 27% 51%;
    --accent: 135 94% 65%;
    --accent-foreground: 231 15% 18%;
    --destructive: 0 100% 67%;
    --destructive-foreground: 60 30% 96%;
    --border: 232 14% 31%;
    --input: 232 14% 31%;
    --ring: 326 100% 74%;
    --chart-1: 326 100% 74%;
    --chart-2: 135 94% 65%;
    --chart-3: 265 89% 78%;
    --chart-4: 41 100% 69%;
    --chart-5: 0 100% 67%;
  }
  * { @apply border-border; }
  body { @apply bg-background text-foreground font-sans; font-family: 'Syne', sans-serif; line-height: 1.6; }
  h1,h2,h3,h4,h5,h6 { font-family: 'Syne', sans-serif; }
  pre, code, .font-mono { font-family: 'JetBrains Mono', monospace; }
}

@layer components {
  .glass-card {
    @apply rounded-xl border;
    background: var(--surface);
    border-color: var(--border);
  }
  .hover-lift { @apply transition-all duration-200; }
  .hover-lift:hover { transform: translateY(-2px); box-shadow: 0 8px 25px -5px hsl(var(--primary) / 0.15); }
  .sidebar-gradient { background: transparent; }
  .light .sidebar-gradient { background: transparent; }
  .btn-primary {
    @apply bg-primary text-primary-foreground px-4 py-2 rounded-lg font-medium text-sm
     transition-all duration-200 hover:brightness-110 active:scale-[0.97];
  }
  .btn-secondary {
    @apply bg-secondary text-secondary-foreground px-4 py-2 rounded-lg font-medium text-sm
     transition-all duration-200 hover:bg-muted;
  }
  .btn-destructive {
    @apply bg-destructive text-destructive-foreground px-4 py-2 rounded-lg font-medium text-sm
     transition-all duration-200 hover:brightness-110;
  }
  .form-input {
    @apply w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground
     placeholder:text-muted-foreground outline-none transition-all duration-200
     focus:ring-2 focus:ring-primary/50 focus:border-primary;
  }
}

@layer utilities {
  @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
  @keyframes slideIn { from { opacity:0; transform:translateX(-12px); } to { opacity:1; transform:translateX(0); } }
  @keyframes pulse-glow { 0%,100% { box-shadow:0 0 8px hsl(var(--primary)/0.3); } 50% { box-shadow:0 0 20px hsl(var(--primary)/0.5); } }
  .animate-in { animation: fadeIn 0.35s ease-out; }
  .animate-slide-in { animation: slideIn 0.3s ease-out; }
  .animate-glow { animation: pulse-glow 2s infinite; }
}`);

// ── Utils ──
file(join(fe,"src/lib/utils.ts"),`import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)) }`);

// ── Theme Provider ──
file(join(fe,"src/components/theme-provider.tsx"),`import React, { createContext, useContext, useEffect, useState } from "react"
export type Theme = string
type Ctx = { theme: Theme; setTheme: (t: Theme) => void }
const ThemeCtx = createContext<Ctx>({ theme: "dark", setTheme: () => {} })
export function ThemeProvider({ children, defaultTheme = "dark" }: { children: React.ReactNode; defaultTheme?: Theme }) {
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem("yb-theme") as Theme) || defaultTheme)
  useEffect(() => {
    const root = document.documentElement
    root.classList.remove("light","dark","theme-nord","theme-dracula")
    if (theme && theme !== "light") root.classList.add(theme)
    localStorage.setItem("yb-theme", theme)
  }, [theme])
  return <ThemeCtx.Provider value={{ theme, setTheme }}>{children}</ThemeCtx.Provider>
}
export const useTheme = () => useContext(ThemeCtx)`);

// ── Auth Provider ──
file(join(fe,"src/components/auth-provider.tsx"),`import React, { createContext, useContext, useState } from "react"
import { useNavigate } from "react-router-dom"

interface AuthCtx { token: string | null; username: string | null; login: (t: string, u: string) => void; logout: () => void; }
const AuthContext = createContext<AuthCtx>({ token: null, username: null, login: () => {}, logout: () => {} })

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(localStorage.getItem("yb-token"))
  const [username, setUsername] = useState<string | null>(localStorage.getItem("yb-username"))
  const navigate = useNavigate()

  const login = (t: string, u: string) => { setToken(t); setUsername(u); localStorage.setItem("yb-token", t); localStorage.setItem("yb-username", u); navigate("/"); }
  const logout = () => { setToken(null); setUsername(null); localStorage.removeItem("yb-token"); localStorage.removeItem("yb-username"); navigate("/login"); }

  return <AuthContext.Provider value={{ token, username, login, logout }}>{children}</AuthContext.Provider>
}
export const useAuth = () => useContext(AuthContext)`);

// ── Search Provider ──
file(join(fe,"src/components/search-provider.tsx"),`import React, { createContext, useContext, useState } from "react"

interface SearchCtx { query: string; setQuery: (q: string) => void; }
const SearchContext = createContext<SearchCtx>({ query: "", setQuery: () => {} })

export function SearchProvider({ children }: { children: React.ReactNode }) {
  const [query, setQuery] = useState("")
  return <SearchContext.Provider value={{ query, setQuery }}>{children}</SearchContext.Provider>
}
export const useSearch = () => useContext(SearchContext)`);

// ── Protected Route ──
file(join(fe,"src/components/ProtectedRoute.tsx"),`import { Navigate, Outlet } from "react-router-dom"
import { useAuth } from "./auth-provider"
export default function ProtectedRoute() {
  const { token } = useAuth()
  return token ? <Outlet /> : <Navigate to="/login" replace />
}`);

// ── Login Page ──
file(join(fe,"src/pages/LoginPage.tsx"),`import { useState, type FormEvent } from "react"
import { useAuth } from "../components/auth-provider"

export default function LoginPage() {
  const [username, setUsername] = useState("demo")
  const [password, setPassword] = useState("demo")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { login } = useAuth()

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault(); setLoading(true); setError("");
    try {
      const r = await fetch("/api/auth/login", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      })
      if (!r.ok) throw new Error("Invalid credentials")
      const data = await r.json()
      login(data.token, data.username)
    } catch(err: any) { setError(err.message) }
    finally { setLoading(false) }
  }

  return (
    <div className="flex h-screen items-center justify-center bg-background">
      <div className="w-full max-w-sm p-8 glass-card animate-in">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold tracking-wide text-primary" style={{fontFamily:'Syne,sans-serif'}}>YACINE BANK</h1>
          <p className="text-xs text-muted-foreground tracking-wider uppercase mt-1">make money great again</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="p-3 text-sm text-destructive-foreground bg-destructive/80 rounded-lg">{error}</div>}
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-1">Username</label>
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="form-input" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-muted-foreground mb-1">Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="form-input" required />
          </div>
          <button type="submit" className="w-full btn-primary mt-2" disabled={loading}>
            {loading ? "Authenticating..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  )
}`);

// ── Main entry ──
file(join(fe,"src/main.tsx"),`import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import './index.css'
import { ThemeProvider } from './components/theme-provider'
import { AuthProvider } from './components/auth-provider'
import { SearchProvider } from './components/search-provider'
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <ThemeProvider defaultTheme="dark">
        <AuthProvider>
          <SearchProvider>
            <App />
          </SearchProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  </React.StrictMode>
)`);

// ── App with router ──
file(join(fe,"src/App.tsx"),`import { Routes, Route } from "react-router-dom"
import Sidebar from "./components/layout/Sidebar"
import TopBar from "./components/layout/TopBar"
import LoginPage from "./pages/LoginPage"
import ProtectedRoute from "./components/ProtectedRoute"

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedRoute />}>
        <Route path="/*" element={
          <div className="flex h-screen overflow-hidden">
            <Sidebar />
            <div className="flex-1 flex flex-col min-w-0">
              <TopBar />
              <main className="flex-1 overflow-auto p-6">
                <Routes>
                  <Route path="/" element={<div className="flex items-center justify-center h-full text-muted-foreground">Select an item from the sidebar to begin</div>} />
                  {/* Add entity routes here */}
                </Routes>
              </main>
            </div>
          </div>
        } />
      </Route>
    </Routes>
  )
}`);

// ── API hooks ──
file(join(fe,"src/hooks/useApi.ts"),`import { useState, useEffect, useCallback } from "react"

function authHeaders(): Record<string, string> {
  const token = localStorage.getItem("yb-token")
  return token ? { "Authorization": "Bearer " + token } : {}
}

export function useList<T>(url: string) {
  const [data, setData] = useState<T[]>([])
  const [loading, setLoading] = useState(true)
  const reload = useCallback(() => {
    setLoading(true)
    fetch(url, { headers: authHeaders() }).then(r => r.json()).then(setData).finally(() => setLoading(false))
  }, [url])
  useEffect(reload, [reload])
  return { data, loading, reload }
}

export function useDetail<T>(url: string) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    setLoading(true)
    fetch(url, { headers: authHeaders() }).then(r => { if(!r.ok) throw new Error(); return r.json(); })
      .then(setData).catch(() => setData(null)).finally(() => setLoading(false))
  }, [url])
  return { data, loading }
}

export async function apiCreate<T>(url: string, body: Record<string, any>): Promise<T> {
  const r = await fetch(url, { method:"POST", headers:{ "Content-Type":"application/json", ...authHeaders() }, body:JSON.stringify(body) })
  if (!r.ok) throw new Error("Create failed"); return r.json()
}
export async function apiUpdate<T>(url: string, body: Record<string, any>): Promise<T> {
  const r = await fetch(url, { method:"PUT", headers:{ "Content-Type":"application/json", ...authHeaders() }, body:JSON.stringify(body) })
  if (!r.ok) throw new Error("Update failed"); return r.json()
}
export async function apiDelete(url: string): Promise<void> {
  const r = await fetch(url, { method:"DELETE", headers: authHeaders() }); if (!r.ok) throw new Error("Delete failed")
}`);
}
