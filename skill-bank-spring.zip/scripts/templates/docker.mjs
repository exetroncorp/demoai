// Docker + docker-compose generation
import { join } from "node:path";

export function generateDocker(file, { root, artifactId }) {

  file(join(root,"Dockerfile"),`FROM node:20-alpine AS frontend-build
WORKDIR /app
COPY frontend/package*.json ./
RUN npm install
COPY frontend ./
RUN npm run build

FROM maven:3.9.6-eclipse-temurin-21-jammy AS backend-build
WORKDIR /app
COPY pom.xml ./
RUN mvn dependency:go-offline -B
COPY src ./src
COPY --from=frontend-build /app/dist ./src/main/resources/static
RUN mvn clean package -DskipTests

FROM eclipse-temurin:21-jre-jammy
WORKDIR /app
COPY --from=backend-build /app/target/${artifactId}-0.0.1-SNAPSHOT.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","app.jar","--spring.profiles.active=prod"]`);

  file(join(root,"docker-compose.yml"),`services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: ${artifactId}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports: ["5432:5432"]
    volumes: [postgres_data:/var/lib/postgresql/data]
    healthcheck:
      test: ["CMD-SHELL","pg_isready -U postgres"]
      interval: 10s
      timeout: 5s
      retries: 5
  app:
    build: .
    ports: ["8080:8080"]
    environment:
      POSTGRES_URL: jdbc:postgresql://postgres:5432/${artifactId}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    depends_on:
      postgres: { condition: service_healthy }
volumes:
  postgres_data:`);
}
