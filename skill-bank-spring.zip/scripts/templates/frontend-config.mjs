// Frontend config files: package.json, vite, tailwind, tsconfig, etc.
import { join } from "node:path";

export function generateFrontendConfig(file, { fe, artifactId }) {

  file(join(fe,"package.json"),`{
  "name": "${artifactId}-frontend",
  "private": true, "version": "0.0.0", "type": "module",
  "scripts": { "dev": "vite", "build": "tsc -b && vite build", "preview": "vite preview" },
  "dependencies": {
    "class-variance-authority": "^0.7.0", "clsx": "^2.1.1",
    "lucide-react": "^0.441.0",
    "react": "^18.3.1", "react-dom": "^18.3.1",
    "react-router-dom": "^6.26.0",
    "tailwind-merge": "^2.5.2", "tailwindcss-animate": "^1.0.7"
  },
  "devDependencies": {
    "@eslint/js": "^9.9.0", "@types/node": "^22.5.5",
    "@types/react": "^18.3.3", "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.3.1", "autoprefixer": "^10.4.20",
    "eslint": "^9.9.0", "eslint-plugin-react-hooks": "^5.1.0-rc.0",
    "eslint-plugin-react-refresh": "^0.4.9", "globals": "^15.9.0",
    "postcss": "^8.4.47", "tailwindcss": "^3.4.11",
    "typescript": "^5.5.3", "typescript-eslint": "^8.0.1", "vite": "^5.4.1"
  }
}`);

  file(join(fe,"vite.config.ts"),`import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, "./src") } },
  server: { proxy: { '/api': { target: 'http://localhost:8080', changeOrigin: true } } }
})`);

  file(join(fe,"tailwind.config.js"),`import tailwindcssAnimate from "tailwindcss-animate";
/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: ["./index.html","./src/**/*.{ts,tsx,js,jsx}"],
  theme: { extend: {
    borderRadius: { lg:'var(--radius)', md:'calc(var(--radius) - 2px)', sm:'calc(var(--radius) - 4px)' },
    colors: {
      background:'hsl(var(--background))', foreground:'hsl(var(--foreground))',
      card:{ DEFAULT:'hsl(var(--card))', foreground:'hsl(var(--card-foreground))' },
      popover:{ DEFAULT:'hsl(var(--popover))', foreground:'hsl(var(--popover-foreground))' },
      primary:{ DEFAULT:'hsl(var(--primary))', foreground:'hsl(var(--primary-foreground))' },
      secondary:{ DEFAULT:'hsl(var(--secondary))', foreground:'hsl(var(--secondary-foreground))' },
      muted:{ DEFAULT:'hsl(var(--muted))', foreground:'hsl(var(--muted-foreground))' },
      accent:{ DEFAULT:'hsl(var(--accent))', foreground:'hsl(var(--accent-foreground))' },
      destructive:{ DEFAULT:'hsl(var(--destructive))', foreground:'hsl(var(--destructive-foreground))' },
      border:'hsl(var(--border))', input:'hsl(var(--input))', ring:'hsl(var(--ring))',
      chart:{ '1':'hsl(var(--chart-1))','2':'hsl(var(--chart-2))','3':'hsl(var(--chart-3))','4':'hsl(var(--chart-4))','5':'hsl(var(--chart-5))' }
    }
  }},
  plugins: [tailwindcssAnimate],
}`);

  file(join(fe,"tsconfig.json"),`{
  "compilerOptions": {
    "target":"ES2020","useDefineForClassFields":true,
    "lib":["ES2020","DOM","DOM.Iterable"],"module":"ESNext","skipLibCheck":true,
    "moduleResolution":"bundler","allowImportingTsExtensions":true,
    "resolveJsonModule":true,"isolatedModules":true,"noEmit":true,"jsx":"react-jsx",
    "strict":true,"noUnusedLocals":false,"noUnusedParameters":false,
    "noFallthroughCasesInSwitch":true,"baseUrl":".","paths":{"@/*":["./src/*"]}
  },
  "include":["src"],"references":[{"path":"./tsconfig.node.json"}]
}`);

  file(join(fe,"tsconfig.node.json"),`{
  "compilerOptions":{"composite":true,"skipLibCheck":true,"module":"ESNext","moduleResolution":"bundler","allowSyntheticDefaultImports":true,"strict":true},
  "include":["vite.config.ts"]
}`);

  file(join(fe,"components.json"),`{
  "$schema":"https://ui.shadcn.com/schema.json","style":"new-york","rsc":false,
  "tailwind":{"config":"tailwind.config.js","css":"src/index.css","baseColor":"slate","cssVariables":true,"prefix":""},
  "aliases":{"components":"@/components","utils":"@/lib/utils","ui":"@/components/ui","lib":"@/lib","hooks":"@/hooks"}
}`);

  file(join(fe,"postcss.config.js"),`export default { plugins: { tailwindcss: {}, autoprefixer: {} } }`);

  file(join(fe,"index.html"),`<!doctype html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="description" content="YACINE BANK — make money great again"/>
  <link rel="icon" href="/logo.png" type="image/png"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet"/>
  <title>YACINE BANK</title>
</head>
<body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body>
</html>`);
}
