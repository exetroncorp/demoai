// Layout + shared CRUD components + pages
import { join } from "node:path";

export function generateFrontendUI(file, { fe, basePackage }) {

// ═══════════════════════════════════════
//  LAYOUT
// ═══════════════════════════════════════

file(join(fe,"src/components/layout/Sidebar.tsx"),`import { NavLink } from "react-router-dom"
import { useTheme } from "../theme-provider"
import { LayoutDashboard, Moon, Sun, Palette } from "lucide-react"

const LOGO_SVG = '<svg viewBox="0 0 48 56" fill="none" xmlns="http://www.w3.org/2000/svg">' +
  '<defs><linearGradient id="sg" x1="24" y1="0" x2="24" y2="56" gradientUnits="userSpaceOnUse">' +
  '<stop offset="0%" stop-color="#4af0c4"/><stop offset="100%" stop-color="#7c6af7"/>' +
  '</linearGradient></defs>' +
  '<path d="M24 2L4 14v16c0 14 10 22 20 26 10-4 20-12 20-26V14L24 2z" fill="url(#sg)"/>' +
  '<path d="M16 16l8 14 8-14M24 30v12" stroke="#e8e8f0" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>' +
  '</svg>'

const navItems: { icon: React.ReactNode; label: string; path: string }[] = [
  // Add entity nav items here, e.g.:
  // { icon: <LayoutDashboard size={20} />, label: "Accounts", path: "/accounts" },
]

export default function Sidebar() {
  const { theme, setTheme } = useTheme()
  return (
    <aside className="sidebar-gradient w-64 border-r border-border/50 flex flex-col shrink-0">
      <div className="p-5 border-b border-border/30">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="" className="w-10 h-12 object-contain"
            onError={(e) => {
              e.currentTarget.style.display='none';
              const sib = e.currentTarget.nextElementSibling as HTMLElement;
              if(sib) sib.style.display='block';
            }}/>
          <div style={{display:'none'}} dangerouslySetInnerHTML={{__html: LOGO_SVG}} className="w-10 h-12" />
          <div>
            <h1 className="text-lg font-bold tracking-wide" style={{fontFamily:'Syne,sans-serif'}}>YACINE BANK</h1>
            <p className="text-[10px] text-muted-foreground tracking-wider uppercase font-semibold text-accent2">Corporate</p>
          </div>
        </div>
      </div>
      <nav className="flex-1 p-3 space-y-1 overflow-auto">
        {navItems.map((item) => (
          <NavLink key={item.path} to={item.path} end={item.path === "/"}
            className={({ isActive }) =>
              "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 " +
              (isActive ? "bg-primary/10 text-primary border border-primary/20" : "text-muted-foreground hover:text-foreground hover:bg-secondary/50")
            }>
            <span className="text-base flex items-center">{item.icon}</span>
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="p-4 border-t border-border/30">
        <label className="text-xs font-medium text-muted-foreground ml-1 mb-2 block flex items-center gap-2">
          <Palette size={14} /> Theme
        </label>
        <select 
          value={theme} 
          onChange={(e) => setTheme(e.target.value)}
          className="w-full bg-secondary/30 border border-border/30 rounded-lg px-3 py-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-primary/50 transition-all cursor-pointer font-medium"
        >
          <option value="dark">Yacine Dark</option>
          <option value="light">Yacine Light</option>
          <option value="theme-nord">Nord</option>
          <option value="theme-dracula">Dracula</option>
        </select>
      </div>
    </aside>
  )
}`);

file(join(fe,"src/components/layout/TopBar.tsx"),`import { useLocation } from "react-router-dom"
import { Search, Bell } from "lucide-react"

import { Search, Bell, LogOut } from "lucide-react"
import { useLocation } from "react-router-dom"
import { useAuth } from "../auth-provider"
import { useSearch } from "../search-provider"

export default function TopBar() {
  const loc = useLocation()
  const path = loc.pathname.substring(1)
  const title = path ? path.charAt(0).toUpperCase() + path.slice(1).split("/")[0] : "Welcome"
  const { logout, username } = useAuth()
  const { query, setQuery } = useSearch()

  return (
    <header className="h-16 border-b border-border/50 bg-background/50 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-10">
      <h2 className="text-xl font-bold tracking-tight lowercase" style={{fontFamily:'Syne,sans-serif'}}>{title}</h2>
      <div className="flex items-center gap-6">
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors" size={16} />
          <input type="text" placeholder="Search everywhere..."
            value={query} onChange={e => setQuery(e.target.value)}
            className="pl-9 pr-4 py-2 bg-secondary/40 border border-border/50 rounded-full text-sm outline-none w-64 focus:w-80 transition-all duration-300 focus:ring-2 focus:ring-primary/20 focus:border-primary/50" />
        </div>
        <div className="flex items-center gap-4">
          <button className="relative text-muted-foreground hover:text-foreground transition-colors">
            <Bell size={20} />
            <span className="absolute top-0 right-0 w-2 h-2 bg-primary rounded-full animate-pulse-glow" />
          </button>
          <div className="h-8 w-px bg-border/50" />
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm border border-primary/30 uppercase">{username?.charAt(0) || "U"}</div>
            <div className="text-sm font-medium mr-2">{username}</div>
            <button onClick={logout} className="text-muted-foreground hover:text-destructive transition-colors" title="Logout">
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}`);

// ═══════════════════════════════════════
//  SHARED CRUD COMPONENTS
// ═══════════════════════════════════════

file(join(fe,"src/components/shared/StatsCard.tsx"),`interface Props { icon: React.ReactNode; label: string; value: string; trend?: string; trendUp?: boolean }
export default function StatsCard({ icon, label, value, trend, trendUp }: Props) {
  return (
    <div className="glass-card hover-lift p-5 space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xl flex items-center text-primary">{icon}</span>
        {trend && <span className={"text-xs font-medium " + (trendUp ? "text-green-400" : "text-red-400")}>{trend}</span>}
      </div>
      <p className="text-2xl font-bold" style={{fontFamily:'Syne,sans-serif'}}>{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}`);

file(join(fe,"src/components/shared/EmptyState.tsx"),`import { PackageOpen } from "lucide-react"

interface Props { title?: string; message?: string; action?: React.ReactNode }
export default function EmptyState({ title = "No data yet", message = "Create your first item to get started.", action }: Props) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-in">
      <div className="flex justify-center mb-4 opacity-40 text-muted-foreground"><PackageOpen size={48} strokeWidth={1.5} /></div>
      <h3 className="text-lg font-semibold mb-1" style={{fontFamily:'Syne,sans-serif'}}>{title}</h3>
      <p className="text-sm text-muted-foreground mb-4 max-w-sm">{message}</p>
      {action}
    </div>
  )
}`);

file(join(fe,"src/components/shared/DataTable.tsx"),`import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Plus, Trash2, LayoutGrid, List } from "lucide-react"
import EmptyState from "./EmptyState"
import { useSearch } from "../search-provider"

export interface Column<T> { key: keyof T & string; label: string; render?: (val: any, row: T) => React.ReactNode }

interface Props<T extends { id: number | string }> {
  columns: Column<T>[]
  data: T[]
  loading?: boolean
  createPath?: string
  createLabel?: string
  onRowClick?: (row: T) => void
  onDelete?: (row: T) => void
  entityLabel?: string
}

export default function DataTable<T extends { id: number | string }>({
  columns, data, loading, createPath, createLabel = "Create New", onRowClick, onDelete, entityLabel = "item"
}: Props<T>) {
  const navigate = useNavigate()
  const { query } = useSearch()
  const [viewMode, setViewMode] = useState<"table"| "grid">("table")

  const filteredData = data.filter(row => {
    if (!query) return true;
    const q = query.toLowerCase();
    return columns.some(col => String((row as any)[col.key] || "").toLowerCase().includes(q));
  });

  if (loading) return (
    <div className="space-y-3 animate-in">{[1,2,3].map(i =>
      <div key={i} className="h-14 bg-secondary/50 rounded-lg animate-pulse" />
    )}</div>
  )
  return (
    <div className="animate-in space-y-4">
      <div className="flex justify-between items-center mb-4">
        <div className="flex bg-secondary p-1 rounded-lg border border-border/50">
          <button onClick={() => setViewMode("table")} className={"p-2 rounded-md transition-all " + (viewMode === "table" ? "bg-background shadow-sm text-primary" : "text-muted-foreground hover:text-foreground")} title="Table View"><List size={16} /></button>
          <button onClick={() => setViewMode("grid")} className={"p-2 rounded-md transition-all " + (viewMode === "grid" ? "bg-background shadow-sm text-primary" : "text-muted-foreground hover:text-foreground")} title="Grid View"><LayoutGrid size={16} /></button>
        </div>
        {createPath && (
          <button onClick={() => navigate(createPath)} className="btn-primary flex items-center gap-2">
            <Plus size={16} /> {createLabel}
          </button>
        )}
      </div>
      {filteredData.length === 0 ? (
        <EmptyState title={"No " + entityLabel + "s found"} message={query ? "No items matched your search." : "Create your first " + entityLabel + " to see it here."}
          action={createPath && !query ? <button onClick={() => navigate(createPath)} className="btn-primary">{createLabel}</button> : undefined} />
      ) : (
        <div className="overflow-hidden">
          {viewMode === "table" ? (
            <div className="glass-card overflow-x-auto overflow-y-hidden border border-border/50 rounded-xl">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border/50 bg-secondary/20">
                    {columns.map(col => (
                      <th key={col.key} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{col.label}</th>
                    ))}
                    {onDelete && <th className="w-12" />}
                  </tr>
                </thead>
                <tbody>
                  {filteredData.map((row, i) => (
                    <tr key={String(row.id)}
                      onClick={() => onRowClick?.(row)}
                      className={"border-b border-border/30 last:border-0 transition-colors " + (onRowClick ? "cursor-pointer hover:bg-secondary/40" : "")}
                      style={{ animationDelay: i * 30 + "ms" }}>
                      {columns.map(col => (
                        <td key={col.key} className="px-4 py-3 text-sm font-medium">
                          {col.render ? col.render((row as any)[col.key], row) : String((row as any)[col.key] ?? "")}
                        </td>
                      ))}
                      {onDelete && (
                        <td className="px-2">
                          <button onClick={(e) => { e.stopPropagation(); if(confirm("Delete?")) onDelete(row); }}
                            className="text-destructive/60 hover:text-destructive transition-colors p-1.5 rounded-md flex items-center opacity-0 group-hover:opacity-100 focus:opacity-100">
                            <Trash2 size={16} />
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pb-4">
              {filteredData.map((row, i) => (
                <div key={String(row.id)} className={"glass-card p-5 hover-lift relative group " + (onRowClick ? "cursor-pointer" : "")} onClick={() => onRowClick?.(row)} style={{ animationDelay: i * 30 + "ms" }}>
                  <div className="space-y-3">
                    {columns.map(col => (
                      <div key={col.key}>
                        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1 font-semibold">{col.label}</p>
                        <div className="text-sm font-medium">{col.render ? col.render((row as any)[col.key], row) : String((row as any)[col.key] ?? "")}</div>
                      </div>
                    ))}
                  </div>
                  {onDelete && (
                     <button onClick={(e) => { e.stopPropagation(); if(confirm("Delete?")) onDelete(row); }}
                       className="absolute top-4 right-4 text-destructive/50 hover:text-destructive hover:bg-destructive/10 transition-colors p-2 rounded-md">
                       <Trash2 size={16} />
                     </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}`);

file(join(fe,"src/components/shared/DetailView.tsx"),`import { useNavigate } from "react-router-dom"
import { ArrowLeft, Pencil, Trash2 } from "lucide-react"

export interface Field<T> { key: keyof T & string; label: string; render?: (val: any) => React.ReactNode }

interface Props<T> {
  title: string; fields: Field<T>[]; data: T | null; loading?: boolean
  editPath?: string; onDelete?: () => void; backPath: string
}

export default function DetailView<T>({ title, fields, data, loading, editPath, onDelete, backPath }: Props<T>) {
  const navigate = useNavigate()
  if (loading) return <div className="space-y-4 animate-in">{[1,2,3,4].map(i => <div key={i} className="h-10 bg-secondary/50 rounded-lg animate-pulse" />)}</div>
  if (!data) return <p className="text-muted-foreground">Not found.</p>
  return (
    <div className="animate-in space-y-6 max-w-2xl">
      <button onClick={() => navigate(backPath)} className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1.5 transition-colors font-medium">
        <ArrowLeft size={16} /> Back
      </button>
      <div className="glass-card p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold" style={{fontFamily:'Syne,sans-serif'}}>{title}</h2>
          <div className="flex gap-2">
            {editPath && <button onClick={() => navigate(editPath)} className="btn-primary flex items-center gap-1.5 text-xs"><Pencil size={14} /> Edit</button>}
            {onDelete && <button onClick={() => { if(confirm("Are you sure?")) onDelete(); }} className="btn-destructive flex items-center gap-1.5 text-xs"><Trash2 size={14} /> Delete</button>}
          </div>
        </div>
        <div className="divide-y divide-border/30">
          {fields.map(f => (
            <div key={f.key} className="flex py-3 gap-4">
              <span className="text-sm text-muted-foreground w-40 shrink-0 font-medium">{f.label}</span>
              <span className="text-sm font-medium">{f.render ? f.render((data as any)[f.key]) : String((data as any)[f.key] ?? "—")}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}`);

file(join(fe,"src/components/shared/CreateEditForm.tsx"),`import { useState, useEffect, type FormEvent } from "react"
import { useNavigate } from "react-router-dom"
import { ArrowLeft } from "lucide-react"

export interface FormField {
  key: string; label: string;
  type?: "text" | "number" | "email" | "select" | "textarea";
  required?: boolean; placeholder?: string; options?: string[];
}

interface Props {
  title: string; fields: FormField[]; initialData?: Record<string, any>
  onSubmit: (data: Record<string, any>) => void | Promise<void>
  cancelPath: string; submitLabel?: string; loading?: boolean
}

export default function CreateEditForm({ title, fields, initialData, onSubmit, cancelPath, submitLabel = "Save", loading }: Props) {
  const navigate = useNavigate()
  const [form, setForm] = useState<Record<string, any>>({})
  
  useEffect(() => {
    if (initialData) {
      const init: Record<string, any> = {}
      fields.forEach(f => { init[f.key] = initialData[f.key] ?? "" })
      setForm(init)
    }
  }, [initialData, fields])
  const handleSubmit = async (e: FormEvent) => { e.preventDefault(); await onSubmit(form); }

  return (
    <div className="animate-in max-w-lg">
      <button onClick={() => navigate(cancelPath)} className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1.5 transition-colors mb-4 font-medium">
        <ArrowLeft size={16} /> Back
      </button>
      <div className="glass-card p-6">
        <h2 className="text-xl font-bold mb-6" style={{fontFamily:'Syne,sans-serif'}}>{title}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          {fields.map(f => (
            <div key={f.key}>
              <label className="block text-sm font-medium text-muted-foreground mb-1.5">{f.label}{f.required && <span className="text-destructive ml-0.5">*</span>}</label>
              {f.type === "select" ? (
                <select value={form[f.key]} onChange={e => setForm(p => ({...p,[f.key]:e.target.value}))} className="form-input" required={f.required}>
                  <option value="">Select…</option>
                  {f.options?.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : f.type === "textarea" ? (
                <textarea value={form[f.key]} onChange={e => setForm(p => ({...p,[f.key]:e.target.value}))}
                  className="form-input min-h-[80px]" placeholder={f.placeholder} required={f.required} />
              ) : (
                <input type={f.type || "text"} value={form[f.key]}
                  onChange={e => setForm(p => ({...p,[f.key]: f.type === "number" ? e.target.valueAsNumber || "" : e.target.value}))}
                  className="form-input" placeholder={f.placeholder} required={f.required}
                  step={f.type === "number" ? "any" : undefined} />
              )}
            </div>
          ))}
          <div className="flex gap-3 pt-2">
            <button type="submit" className="btn-primary" disabled={loading}>{loading ? "Saving…" : submitLabel}</button>
            <button type="button" onClick={() => navigate(cancelPath)} className="btn-secondary">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  )
}`);

}
