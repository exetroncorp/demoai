---
name: skill-bank-spring
description: "Scaffolds a YACINE BANK neo-bank app with DDD/Hexagonal Spring Boot backend, PostgreSQL+H2, TDD+BDD, and a premium dark-themed React frontend with built-in CRUD components. Run scaffold first, then add entities with the entity generator."
---

# YACINE BANK — Spring Boot DDD/Hexagonal Skill

> **YACINE BANK** — *make money great again*

## Quick Start

```bash
# 1. Scaffold the project
node scripts/scaffold.mjs <groupId> <artifactId> <basePackage>

# Example:
node scripts/scaffold.mjs com.yacine yacine-bank com.yacine.bank

# 2. Backend — compile & test
cd yacine-bank
mvn clean verify

# 3. Backend — run dev server (H2 in-memory, port 8080)
mvn spring-boot:run

# 4. Frontend — install & run (port 5173, proxied to 8080)
cd frontend && npm install && npm run dev
```

## Prerequisites

- Java 17+ (pre-installed in pod)
- Maven 3.8+ (pre-installed in pod)
- Node.js 18+ (for scaffold script and frontend)
- **No Docker, no sudo required** for dev

## Project Structure

The scaffold generates a modular structure split into sub-templates for maintainability:

```
scripts/
├── scaffold.mjs              # Main orchestrator
├── add-entity.mjs             # Entity CRUD generator
└── templates/
    ├── pom.mjs                # Maven POM
    ├── backend.mjs            # Application.java, CorsConfig, ExceptionHandler
    ├── docker.mjs             # Dockerfile, docker-compose.yml
    ├── tests.mjs              # JUnit, Cucumber BDD
    ├── frontend-config.mjs    # Vite, Tailwind, TypeScript, Shadcn config
    ├── frontend-core.mjs      # CSS theme, Router, API hooks, ThemeProvider
    └── frontend-ui.mjs        # Sidebar, TopBar, CRUD components, Dashboard
```

## Architecture: DDD + Hexagonal (Ports & Adapters)

```
src/main/java/<basePackage>/
├── domain/
│   ├── model/                 # Entities, Value Objects
│   └── port/
│       ├── in/                # DRIVING ports (use case interfaces)
│       └── out/               # DRIVEN ports (repository interfaces)
├── application/
│   └── service/               # Use case implementations
└── infrastructure/
    ├── adapter/
    │   ├── in/web/            # REST controllers
    │   └── out/persistence/   # JPA repositories
    └── config/                # CORS, exception handler
```

### Layer Rules

| Layer | Depends on | Never depends on |
|-------|-----------|----|
| `domain` | nothing | application, infrastructure |
| `application` | domain ports | infrastructure |
| `infrastructure` | domain ports, application | — |

## Adding Entities (CRUD Generator)

The `add-entity.mjs` script generates **full-stack CRUD** for any domain entity:

```bash
node scripts/add-entity.mjs <projectDir> <basePackage> <EntityName> <field:Type> [field:Type ...]

# Example:
node scripts/add-entity.mjs . com.yacine.bank Account name:String balance:BigDecimal status:String
```

**Supported types:** `String`, `Integer`, `Long`, `Double`, `BigDecimal`, `Boolean`, `Instant`, `LocalDate`

### What gets generated

| Layer | Files |
|-------|-------|
| Domain | `Account.java`, `ManageAccountUseCase.java`, `AccountRepository.java` |
| Application | `AccountService.java` |
| Infrastructure | `JpaAccountRepository.java`, `AccountController.java` |
| Test | `AccountServiceTest.java` |
| Frontend Hook | `useAccount.ts` |
| Frontend Pages | `AccountListPage.tsx`, `AccountDetailPage.tsx`, `AccountFormPage.tsx` |

### Manual wiring after generation

**1. Register routes** in `frontend/src/App.tsx`:
```tsx
import AccountListPage from "./pages/AccountListPage"
import AccountDetailPage from "./pages/AccountDetailPage"
import AccountFormPage from "./pages/AccountFormPage"

// Inside <Routes>:
<Route path="/accounts" element={<AccountListPage />} />
<Route path="/accounts/:id" element={<AccountDetailPage />} />
<Route path="/accounts/new" element={<AccountFormPage />} />
<Route path="/accounts/:id/edit" element={<AccountFormPage />} />
```

**2. Add nav item** in `frontend/src/components/layout/Sidebar.tsx`:
```tsx
const navItems = [
  { icon: "📊", label: "Dashboard", path: "/" },
  { icon: "🏦", label: "Accounts", path: "/accounts" },  // ← add
]
```

## Frontend Component Library

The scaffold generates reusable CRUD components. Use them for every entity:

### DataTable — List view with actions
```tsx
import DataTable, { type Column } from "@/components/shared/DataTable"

const columns: Column<Account>[] = [
  { key: "name", label: "Name" },
  { key: "balance", label: "Balance", render: (v) => `$${v.toFixed(2)}` },
]

<DataTable
  columns={columns}
  data={accounts}
  loading={loading}
  createPath="/accounts/new"
  onRowClick={(row) => navigate(`/accounts/${row.id}`)}
  onDelete={async (row) => { await deleteAccount(String(row.id)); reload() }}
/>
```

### DetailView — Single entity display
```tsx
import DetailView, { type Field } from "@/components/shared/DetailView"

const fields: Field<Account>[] = [
  { key: "name", label: "Account Name" },
  { key: "balance", label: "Balance", render: (v) => `$${v.toFixed(2)}` },
]

<DetailView
  title="Account Details"
  fields={fields}
  data={account}
  backPath="/accounts"
  editPath={`/accounts/${id}/edit`}
  onDelete={handleDelete}
/>
```

### CreateEditForm — Create/Edit form
```tsx
import CreateEditForm, { type FormField } from "@/components/shared/CreateEditForm"

const formFields: FormField[] = [
  { key: "name", label: "Name", type: "text", required: true },
  { key: "balance", label: "Balance", type: "number" },
  { key: "status", label: "Status", type: "select", options: ["ACTIVE","CLOSED"] },
]

<CreateEditForm
  title="New Account"
  fields={formFields}
  onSubmit={handleSubmit}
  cancelPath="/accounts"
/>
```

### API Hooks
```tsx
import { useList, useDetail, apiCreate, apiUpdate, apiDelete } from "@/hooks/useApi"

// Pre-built per entity by add-entity.mjs:
import { useAccountList, useAccountDetail, createAccount, updateAccount, deleteAccount } from "@/hooks/useAccount"
```

## Theme & Branding

- **Dark mode default** with light mode toggle in sidebar
- **Color palette**: Deep navy background, bright blue primary, purple accent
- **Fonts**: Inter (body), Outfit (headings) via Google Fonts
- **Glass-morphism** cards with backdrop-blur
- **Micro-animations**: fade-in, slide-in, hover-lift, pulse-glow
- CSS utility classes: `.glass-card`, `.hover-lift`, `.btn-primary`, `.btn-secondary`, `.btn-destructive`, `.form-input`, `.animate-in`
- Logo: SVG fallback + `/logo.png` from `resources/`

## Configuration

| Profile | Database | `ddl-auto` | H2 Console |
|---------|----------|-----------|------------|
| default (dev) | H2 in-memory | `update` | enabled at `/h2-console` |
| `prod` | PostgreSQL | `validate` | disabled |

## Agent Workflow (post-scaffold)

1. **Run scaffold**: `node scripts/scaffold.mjs <groupId> <artifactId> <basePackage>`
2. **Add entities**: `node scripts/add-entity.mjs <dir> <pkg> <Name> <fields...>`
3. **Wire routes**: Add `<Route>` entries in `App.tsx`
4. **Wire nav**: Add nav item in `Sidebar.tsx`
5. **Install frontend deps**: `cd frontend && npm install`
6. **Add Shadcn components** (optional): `npx -y shadcn@latest add button card table -y`
7. **Customize**: Edit generated pages, add business logic to services
8. **Validate**: `mvn clean verify` + `cd frontend && npm run build`

## Validation

| # | What | Command |
|---|------|---------|
| 1 | Compile backend | `mvn clean compile` |
| 2 | Unit + BDD tests | `mvn clean verify` |
| 3 | Run backend | `mvn spring-boot:run` |
| 4 | Frontend dev | `cd frontend && npm run dev` |
| 5 | Frontend build | `cd frontend && npm run build` |
| 6 | Production | `docker compose up --build` |
