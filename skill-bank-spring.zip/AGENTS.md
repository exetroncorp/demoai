# Agent Guard-Rails for skill-bank-spring

## Scaffold & Structure
- **Always scaffold first**: Run `node scripts/scaffold.mjs <groupId> <artifactId> <basePackage>` before writing any Java code.
- **Use add-entity.mjs** for new domain entities: `node scripts/add-entity.mjs <dir> <pkg> <EntityName> <fields...>` — then wire routes in `App.tsx` and nav in `Sidebar.tsx`.
- **Maven only** — no Gradle. **`.properties` format only** — no YAML config files.
- **No Docker required** for development — H2 in-memory is the dev database.
- **No `sudo`** — all commands must work in a rootless container.

## Architecture
- **DDD layer discipline** — the `domain` package must never import from `infrastructure` or `application`.
- **Ports & Adapters** — business logic depends on interfaces (ports), never on implementations (adapters).
- **No Lombok, no MapStruct** — use explicit constructors and getters/setters. Keep dependencies minimal.
- **No Flyway / Liquibase** — use `spring.jpa.hibernate.ddl-auto` for schema management.

## YACINE BANK Branding (MUST preserve)
- **Brand name**: "YACINE BANK" (uppercase in logo/sidebar, title case elsewhere)
- **Slogan**: "make money great again" (lowercase italic)
- **Logo**: `/logo.png` in `frontend/public/` + inline SVG fallback in Sidebar
- **Color palette**: Deep navy background, bright blue primary (#3B82F6), purple accent (#7C3AED)
- **Fonts**: Inter (body), Outfit (headings) — loaded from Google Fonts in `index.html`
- **Dark mode by default** — light mode available via sidebar toggle
- Do NOT change the brand colors, logo, or slogan without user approval.

## Frontend Patterns
- **Use the scaffold's component library** — `DataTable`, `DetailView`, `CreateEditForm`, `StatsCard`, `EmptyState`. Do not reinvent these.
- **API hooks** go in `src/hooks/use<Entity>.ts` — use `useList`, `useDetail`, `apiCreate`, `apiUpdate`, `apiDelete` from `useApi.ts`.
- For each new entity, generate (or manually create): **list page + detail page + form page + route registration + nav item**.
- **CSS utilities**: use `.glass-card`, `.hover-lift`, `.btn-primary`, `.btn-secondary`, `.btn-destructive`, `.form-input`, `.animate-in` — not ad-hoc Tailwind.

## Testing
- **Test naming**: unit tests end with `Test`, integration tests end with `IT`.
- **Cucumber features** go in `src/test/resources/features/`, step defs in `<basePackage>.bdd.steps`.

## Other
- **Ask the user** before running `git init` or any git commands.
