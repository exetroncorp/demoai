-- Add picture_url column to developers table
ALTER TABLE developers ADD COLUMN picture_url VARCHAR(255);
