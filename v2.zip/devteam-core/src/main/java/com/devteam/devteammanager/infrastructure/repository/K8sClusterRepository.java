package com.devteam.devteammanager.infrastructure.repository;

import com.devteam.devteammanager.domain.model.K8sCluster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface K8sClusterRepository extends JpaRepository<K8sCluster, Long> {
}
