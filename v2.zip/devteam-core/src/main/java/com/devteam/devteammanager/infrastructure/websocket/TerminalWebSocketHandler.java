package com.devteam.devteammanager.infrastructure.websocket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class TerminalWebSocketHandler extends TextWebSocketHandler {
    private static final Logger logger = LoggerFactory.getLogger(TerminalWebSocketHandler.class);

    private final Map<String, Process> processes = new ConcurrentHashMap<>();
    private final Map<String, OutputStream> outputStreams = new ConcurrentHashMap<>();
    private final ExecutorService executorService = Executors.newCachedThreadPool();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String sessionId = session.getId();
        logger.info("WebSocket connection established: {}", sessionId);

        try {
            // Start a new shell process
            ProcessBuilder processBuilder = new ProcessBuilder();

            // Use cmd.exe for Windows or bash for Unix-like systems
            if (System.getProperty("os.name").toLowerCase().contains("win")) {
                processBuilder.command("cmd.exe");
            } else {
                processBuilder.command("/bin/bash");
            }

            Process process = processBuilder.start();
            processes.put(sessionId, process);
            outputStreams.put(sessionId, process.getOutputStream());

            // Read process output and send it to the WebSocket client
            executorService.submit(() -> {
                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                    int c;
                    StringBuilder buffer = new StringBuilder();
                    while ((c = reader.read()) != -1 && session.isOpen()) {
                        buffer.append((char) c);
                        if (buffer.length() >= 128) {
                            if (session.isOpen()) {
                                session.sendMessage(new TextMessage(buffer.toString()));
                            }
                            buffer.setLength(0);
                        }
                    }
                    if (buffer.length() > 0 && session.isOpen()) {
                        session.sendMessage(new TextMessage(buffer.toString()));
                    }
                } catch (IOException e) {
                    logger.error("Error reading process output", e);
                    try {
                        if (session.isOpen()) {
                            session.sendMessage(
                                    new TextMessage("Error reading process output: " + e.getMessage() + "\r\n"));
                        }
                    } catch (IOException ex) {
                        logger.error("Error sending error message to client", ex);
                    }
                }
            });

            // Read process error and send it to the WebSocket client
            executorService.submit(() -> {
                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
                    int c;
                    StringBuilder buffer = new StringBuilder();
                    while ((c = reader.read()) != -1 && session.isOpen()) {
                        buffer.append((char) c);
                        if (buffer.length() >= 128) {
                            if (session.isOpen()) {
                                session.sendMessage(new TextMessage(buffer.toString()));
                            }
                            buffer.setLength(0);
                        }
                    }
                    if (buffer.length() > 0 && session.isOpen()) {
                        session.sendMessage(new TextMessage(buffer.toString()));
                    }
                } catch (IOException e) {
                    logger.error("Error reading process error", e);
                    try {
                        if (session.isOpen()) {
                            session.sendMessage(
                                    new TextMessage("Error reading process error: " + e.getMessage() + "\r\n"));
                        }
                    } catch (IOException ex) {
                        logger.error("Error sending error message to client", ex);
                    }
                }
            });

            // Send welcome message
            session.sendMessage(new TextMessage("\r\n===== Real Terminal Connected =====\r\n\r\n"));

        } catch (IOException e) {
            logger.error("Error starting shell process", e);
            session.sendMessage(new TextMessage("Error starting shell process: " + e.getMessage() + "\r\n"));
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String sessionId = session.getId();
        String command = message.getPayload();

        logger.debug("Received command from session {}: {}", sessionId, command);

        OutputStream outputStream = outputStreams.get(sessionId);
        if (outputStream != null) {
            try {
                // Send the command to the process
                outputStream.write(command.getBytes());
                outputStream.flush();
            } catch (IOException e) {
                logger.error("Error sending command to process", e);
                session.sendMessage(new TextMessage("Error sending command to process: " + e.getMessage() + "\r\n"));
            }
        } else {
            logger.error("No output stream found for session {}", sessionId);
            session.sendMessage(new TextMessage("No terminal session found. Please reconnect.\r\n"));
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        String sessionId = session.getId();
        logger.info("WebSocket connection closed: {}, status: {}", sessionId, status);

        // Clean up resources
        Process process = processes.remove(sessionId);
        if (process != null) {
            process.destroy();
        }

        outputStreams.remove(sessionId);
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        String sessionId = session.getId();
        logger.error("Transport error for session {}", sessionId, exception);

        // Clean up resources
        Process process = processes.remove(sessionId);
        if (process != null) {
            process.destroy();
        }

        outputStreams.remove(sessionId);
    }
}
