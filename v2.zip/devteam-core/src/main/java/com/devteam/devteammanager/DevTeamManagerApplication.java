package com.devteam.devteammanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevTeamManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(DevTeamManagerApplication.class, args);
    }
}
