package com.devteam.devteammanager.application.controller;

import com.devteam.devteammanager.application.dto.K8sClusterDTO;
import com.devteam.devteammanager.application.dto.PodDTO;
import com.devteam.devteammanager.domain.service.K8sService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/k8s")
@CrossOrigin(origins = "http://localhost:4200")
public class K8sController {

    private final K8sService k8sService;

    @Autowired
    public K8sController(K8sService k8sService) {
        this.k8sService = k8sService;
    }

    @GetMapping("/clusters/{clusterId}/pods")
    public ResponseEntity<List<PodDTO>> getPods(@PathVariable Long clusterId) {
        return ResponseEntity.ok(k8sService.getPods(clusterId));
    }

    @GetMapping("/clusters/{clusterId}/pods/{podName}/logs")
    public ResponseEntity<String> getPodLogs(@PathVariable Long clusterId, @PathVariable String podName) {
        return ResponseEntity.ok(k8sService.getPodLogs(clusterId, podName));
    }

    @PostMapping("/clusters/{clusterId}/pods/{podName}/exec")
    public ResponseEntity<String> executeCommand(
            @PathVariable Long clusterId,
            @PathVariable String podName,
            @RequestBody Map<String, String> commandRequest) {
        
        String command = commandRequest.get("command");
        if (command == null || command.isEmpty()) {
            return ResponseEntity.badRequest().body("Command cannot be empty");
        }
        
        return ResponseEntity.ok(k8sService.executeCommand(clusterId, podName, command));
    }

    @GetMapping("/clusters/{id}")
    public ResponseEntity<K8sClusterDTO> getClusterById(@PathVariable Long id) {
        return ResponseEntity.ok(k8sService.getClusterById(id));
    }

    @PostMapping("/clusters")
    public ResponseEntity<K8sClusterDTO> createCluster(@RequestBody K8sClusterDTO clusterDTO) {
        return new ResponseEntity<>(k8sService.createCluster(clusterDTO), HttpStatus.CREATED);
    }

    @PutMapping("/clusters/{id}")
    public ResponseEntity<K8sClusterDTO> updateCluster(@PathVariable Long id, @RequestBody K8sClusterDTO clusterDTO) {
        return ResponseEntity.ok(k8sService.updateCluster(id, clusterDTO));
    }

    @DeleteMapping("/clusters/{id}")
    public ResponseEntity<Void> deleteCluster(@PathVariable Long id) {
        k8sService.deleteCluster(id);
        return ResponseEntity.noContent().build();
    }
}
