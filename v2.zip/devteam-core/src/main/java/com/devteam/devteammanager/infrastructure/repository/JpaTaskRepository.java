package com.devteam.devteammanager.infrastructure.repository;

import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.model.TaskStatus;
import com.devteam.devteammanager.domain.repository.TaskRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * JPA implementation of the TaskRepository interface.
 * This is an adapter in the hexagonal architecture.
 */
@Repository
public interface JpaTaskRepository extends JpaRepository<Task, Long>, TaskRepository {
    
    /**
     * Finds tasks by project ID
     *
     * @param projectId the project ID
     * @return a list of tasks for the specified project
     */
    @Query("SELECT t FROM Task t WHERE t.project.id = :projectId")
    List<Task> findByProjectId(Long projectId);
    
    /**
     * Finds tasks by assignee ID
     *
     * @param developerId the developer ID
     * @return a list of tasks assigned to the specified developer
     */
    @Query("SELECT t FROM Task t WHERE t.assignee.id = :developerId")
    List<Task> findByAssigneeId(Long developerId);
    
    /**
     * Finds tasks by status
     *
     * @param status the task status
     * @return a list of tasks with the specified status
     */
    List<Task> findByStatus(TaskStatus status);
}
