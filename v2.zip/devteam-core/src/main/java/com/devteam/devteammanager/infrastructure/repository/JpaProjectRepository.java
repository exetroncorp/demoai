package com.devteam.devteammanager.infrastructure.repository;

import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.ProjectStatus;
import com.devteam.devteammanager.domain.repository.ProjectRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * JPA implementation of the ProjectRepository interface.
 * This is an adapter in the hexagonal architecture.
 */
@Repository
public interface JpaProjectRepository extends JpaRepository<Project, Long>, ProjectRepository {
    
    /**
     * Finds projects by team ID
     *
     * @param teamId the team ID
     * @return a list of projects for the specified team
     */
    @Query("SELECT p FROM Project p WHERE p.team.id = :teamId")
    List<Project> findByTeamId(Long teamId);
    
    /**
     * Finds projects by status
     *
     * @param status the project status
     * @return a list of projects with the specified status
     */
    List<Project> findByStatus(ProjectStatus status);
}
