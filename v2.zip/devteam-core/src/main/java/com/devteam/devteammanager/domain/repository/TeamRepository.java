package com.devteam.devteammanager.domain.repository;

import com.devteam.devteammanager.domain.model.Team;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Team entity.
 * This is a port in the hexagonal architecture.
 */
public interface TeamRepository {
    
    /**
     * Saves a team
     *
     * @param team the team to save
     * @return the saved team
     */
    Team save(Team team);
    
    /**
     * Finds a team by ID
     *
     * @param id the team ID
     * @return an Optional containing the team if found, or empty if not found
     */
    Optional<Team> findById(Long id);
    
    /**
     * Finds all teams
     *
     * @return a list of all teams
     */
    List<Team> findAll();
    
    /**
     * Finds a team by name
     *
     * @param name the team name
     * @return an Optional containing the team if found, or empty if not found
     */
    Optional<Team> findByName(String name);
    
    /**
     * Finds teams by department
     *
     * @param department the department name
     * @return a list of teams in the specified department
     */
    List<Team> findByDepartment(String department);
    
    /**
     * Deletes a team
     *
     * @param team the team to delete
     */
    void delete(Team team);
    
    /**
     * Deletes a team by ID
     *
     * @param id the ID of the team to delete
     */
    void deleteById(Long id);
    
    /**
     * Checks if a team exists by ID
     *
     * @param id the team ID
     * @return true if the team exists, false otherwise
     */
    boolean existsById(Long id);
    
    /**
     * Checks if a team exists by name
     *
     * @param name the team name
     * @return true if the team exists, false otherwise
     */
    boolean existsByName(String name);
}
