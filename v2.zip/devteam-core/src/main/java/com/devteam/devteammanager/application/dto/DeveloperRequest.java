package com.devteam.devteammanager.application.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * DTO for developer creation and update requests.
 */
public class DeveloperRequest {

    @NotBlank(message = "Developer name is required")
    @Size(min = 2, max = 100, message = "Developer name must be between 2 and 100 characters")
    private String name;

    @NotBlank(message = "Role is required")
    @Size(max = 100, message = "Role must be less than 100 characters")
    private String role;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be valid")
    private String email;

    @Size(max = 50, message = "Skill level must be less than 50 characters")
    private String skillLevel;

    @Size(max = 255, message = "Picture URL must be less than 255 characters")
    private String pictureUrl;

    // Default constructor for JSON deserialization
    public DeveloperRequest() {
    }

    public DeveloperRequest(String name, String role, String email, String skillLevel, String pictureUrl) {
        this.name = name;
        this.role = role;
        this.email = email;
        this.skillLevel = skillLevel;
        this.pictureUrl = pictureUrl;
    }

    public DeveloperRequest(String name, String role, String email, String skillLevel) {
        this(name, role, email, skillLevel, null);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(String skillLevel) {
        this.skillLevel = skillLevel;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }
}
