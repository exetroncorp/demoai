package com.devteam.devteammanager.application.dto;

import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.ProjectStatus;
import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.model.Team;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * DTO for project responses.
 */
public class ProjectResponse {

    private Long id;
    private String name;
    private String description;
    private LocalDate startDate;
    private LocalDate endDate;
    private ProjectStatus status;
    private TeamSummaryResponse team;
    private List<TaskSummaryResponse> tasks;

    // Default constructor for JSON serialization
    public ProjectResponse() {
    }

    public ProjectResponse(Project project) {
        this.id = project.getId();
        this.name = project.getName();
        this.description = project.getDescription();
        this.startDate = project.getStartDate();
        this.endDate = project.getEndDate();
        this.status = project.getStatus();
        
        if (project.getTeam() != null) {
            this.team = new TeamSummaryResponse(project.getTeam());
        }
        
        if (project.getTasks() != null && !project.getTasks().isEmpty()) {
            this.tasks = project.getTasks().stream()
                    .map(TaskSummaryResponse::new)
                    .collect(Collectors.toList());
        }
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public ProjectStatus getStatus() {
        return status;
    }

    public TeamSummaryResponse getTeam() {
        return team;
    }

    public List<TaskSummaryResponse> getTasks() {
        return tasks;
    }

    /**
     * Nested class for summarized team information in project responses.
     */
    public static class TeamSummaryResponse {
        private Long id;
        private String name;

        public TeamSummaryResponse(Team team) {
            this.id = team.getId();
            this.name = team.getName();
        }

        public Long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }

    /**
     * Nested class for summarized task information in project responses.
     */
    public static class TaskSummaryResponse {
        private Long id;
        private String title;
        private String status;

        public TaskSummaryResponse(Task task) {
            this.id = task.getId();
            this.title = task.getTitle();
            this.status = task.getStatus().toString();
        }

        public Long getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public String getStatus() {
            return status;
        }
    }
}
