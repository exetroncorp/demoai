package com.devteam.devteammanager.domain.service.impl;

import com.devteam.devteammanager.application.dto.K8sClusterDTO;
import com.devteam.devteammanager.application.dto.PodDTO;
import com.devteam.devteammanager.domain.model.K8sCluster;
import com.devteam.devteammanager.domain.service.K8sService;
import com.devteam.devteammanager.infrastructure.repository.K8sClusterRepository;
import io.fabric8.kubernetes.api.model.Pod;
import io.fabric8.kubernetes.client.Config;
import io.fabric8.kubernetes.client.ConfigBuilder;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.client.KubernetesClientBuilder;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class K8sServiceImpl implements K8sService {

    private final K8sClusterRepository k8sClusterRepository;

    @Autowired
    public K8sServiceImpl(K8sClusterRepository k8sClusterRepository) {
        this.k8sClusterRepository = k8sClusterRepository;
    }

    @Override
    public List<PodDTO> getPods(Long clusterId) {
        K8sCluster cluster = getClusterEntity(clusterId);

        try (KubernetesClient client = createK8sClient(cluster)) {
            return client.pods().inAnyNamespace().list().getItems().stream()
                    .map(this::convertToPodDTO)
                    .collect(Collectors.toList());
        }
    }

    @Override
    public String getPodLogs(Long clusterId, String podName) {
        K8sCluster cluster = getClusterEntity(clusterId);

        try (KubernetesClient client = createK8sClient(cluster)) {
            // Find the pod in all namespaces
            Pod pod = client.pods().inAnyNamespace().list().getItems().stream()
                    .filter(p -> p.getMetadata().getName().equals(podName))
                    .findFirst()
                    .orElseThrow(() -> new EntityNotFoundException("Pod not found: " + podName));

            String namespace = pod.getMetadata().getNamespace();
            return client.pods().inNamespace(namespace).withName(podName).getLog();
        }
    }

    @Override
    public String executeCommand(Long clusterId, String podName, String command) {
        K8sCluster cluster = getClusterEntity(clusterId);

        try (KubernetesClient client = createK8sClient(cluster)) {
            // Find the pod in all namespaces
            Pod pod = client.pods().inAnyNamespace().list().getItems().stream()
                    .filter(p -> p.getMetadata().getName().equals(podName))
                    .findFirst()
                    .orElseThrow(() -> new EntityNotFoundException("Pod not found: " + podName));

            String namespace = pod.getMetadata().getNamespace();

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ByteArrayOutputStream err = new ByteArrayOutputStream();

            String[] commandArray = command.split("\\s+");

            client.pods().inNamespace(namespace)
                    .withName(podName)
                    .writingOutput(out)
                    .writingError(err)
                    .exec(commandArray);

            String output = out.toString();
            String error = err.toString();

            return error.isEmpty() ? output : "Error: " + error;
        }
    }

    @Override
    public K8sClusterDTO getClusterById(Long id) {
        K8sCluster cluster = getClusterEntity(id);
        return convertToDTO(cluster);
    }

    @Override
    @Transactional
    public K8sClusterDTO createCluster(K8sClusterDTO clusterDTO) {
        K8sCluster cluster = convertToEntity(clusterDTO);
        K8sCluster savedCluster = k8sClusterRepository.save(cluster);
        return convertToDTO(savedCluster);
    }

    @Override
    @Transactional
    public K8sClusterDTO updateCluster(Long id, K8sClusterDTO clusterDTO) {
        K8sCluster existingCluster = getClusterEntity(id);

        existingCluster.setName(clusterDTO.getName());
        existingCluster.setApiEndpoint(clusterDTO.getApiEndpoint());
        existingCluster.setApiKey(clusterDTO.getApiKey());
        existingCluster.setVip(clusterDTO.getVip());

        K8sCluster updatedCluster = k8sClusterRepository.save(existingCluster);
        return convertToDTO(updatedCluster);
    }

    @Override
    @Transactional
    public void deleteCluster(Long id) {
        if (!k8sClusterRepository.existsById(id)) {
            throw new EntityNotFoundException("K8s Cluster not found with id: " + id);
        }
        k8sClusterRepository.deleteById(id);
    }

    private K8sCluster getClusterEntity(Long clusterId) {
        return k8sClusterRepository.findById(clusterId)
                .orElseThrow(() -> new EntityNotFoundException("K8s Cluster not found with id: " + clusterId));
    }

    private KubernetesClient createK8sClient(K8sCluster cluster) {
        Config config = new ConfigBuilder()
                .withMasterUrl(cluster.getApiEndpoint())
                .withOauthToken(cluster.getApiKey())
                .withTrustCerts(true)
                .build();

        return new KubernetesClientBuilder().withConfig(config).build();
    }

    private PodDTO convertToPodDTO(Pod pod) {
        return PodDTO.builder()
                .name(pod.getMetadata().getName())
                .namespace(pod.getMetadata().getNamespace())
                .status(pod.getStatus().getPhase())
                .creationTimestamp(pod.getMetadata().getCreationTimestamp())
                .ip(pod.getStatus().getPodIP())
                .nodeName(pod.getSpec().getNodeName())
                .build();
    }

    private K8sClusterDTO convertToDTO(K8sCluster cluster) {
        return K8sClusterDTO.builder()
                .id(cluster.getId())
                .name(cluster.getName())
                .apiEndpoint(cluster.getApiEndpoint())
                .apiKey(cluster.getApiKey())
                .vip(cluster.getVip())
                .build();
    }

    private K8sCluster convertToEntity(K8sClusterDTO clusterDTO) {
        K8sCluster cluster = new K8sCluster();
        cluster.setName(clusterDTO.getName());
        cluster.setApiEndpoint(clusterDTO.getApiEndpoint());
        cluster.setApiKey(clusterDTO.getApiKey());
        cluster.setVip(clusterDTO.getVip());
        return cluster;
    }
}
