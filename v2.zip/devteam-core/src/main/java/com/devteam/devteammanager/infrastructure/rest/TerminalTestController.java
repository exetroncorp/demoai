package com.devteam.devteammanager.infrastructure.rest;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devteam.devteammanager.domain.service.TerminalService;

@RestController
@RequestMapping("/api/terminal-test")
@CrossOrigin(origins = "*")
public class TerminalTestController {

    private static final Logger logger = LoggerFactory.getLogger(TerminalTestController.class);
    private final TerminalService terminalService;
    private final List<String> output = new ArrayList<>();
    private final String TEST_SESSION_ID = "test-session";

    @Autowired
    public TerminalTestController(TerminalService terminalService) {
        this.terminalService = terminalService;
        // Start a shell for testing
        terminalService.startShell(TEST_SESSION_ID, line -> {
            logger.info("Test terminal output: {}", line);
            output.add(line);
        });
    }

    @GetMapping("/status")
    public ResponseEntity<String> testStatus() {
        logger.info("Terminal test status endpoint called");
        return ResponseEntity.ok("Terminal test endpoint is working!");
    }

    @PostMapping("/execute")
    public ResponseEntity<List<String>> executeCommand(@RequestBody String command) {
        logger.info("Executing test command: {}", command);
        output.clear();
        
        terminalService.executeCommand(TEST_SESSION_ID, command, line -> {
            logger.info("Test command output: {}", line);
            output.add(line);
        });
        
        // Wait a bit for the command to execute
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        return ResponseEntity.ok(new ArrayList<>(output));
    }
}
