package com.devteam.devteammanager.domain.service.impl;

import com.devteam.devteammanager.application.dto.CloudIDEDTO;
import com.devteam.devteammanager.application.dto.K8sClusterDTO;
import com.devteam.devteammanager.domain.model.CloudIDE;
import com.devteam.devteammanager.domain.model.K8sCluster;
import com.devteam.devteammanager.domain.model.User;
import com.devteam.devteammanager.domain.service.CloudIDEService;
import com.devteam.devteammanager.infrastructure.repository.CloudIDERepository;
import com.devteam.devteammanager.infrastructure.repository.K8sClusterRepository;
import com.devteam.devteammanager.infrastructure.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CloudIDEServiceImpl implements CloudIDEService {

    private final CloudIDERepository cloudIDERepository;
    private final K8sClusterRepository k8sClusterRepository;
    private final UserRepository userRepository;

    @Autowired
    public CloudIDEServiceImpl(CloudIDERepository cloudIDERepository, 
                              K8sClusterRepository k8sClusterRepository,
                              UserRepository userRepository) {
        this.cloudIDERepository = cloudIDERepository;
        this.k8sClusterRepository = k8sClusterRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<CloudIDEDTO> getAllCloudIDEs() {
        return cloudIDERepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CloudIDEDTO getCloudIDEById(Long id) {
        CloudIDE cloudIDE = cloudIDERepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("CloudIDE not found with id: " + id));
        return convertToDTO(cloudIDE);
    }

    @Override
    @Transactional
    public CloudIDEDTO createCloudIDE(CloudIDEDTO cloudIDEDTO) {
        CloudIDE cloudIDE = convertToEntity(cloudIDEDTO);
        CloudIDE savedCloudIDE = cloudIDERepository.save(cloudIDE);
        return convertToDTO(savedCloudIDE);
    }

    @Override
    @Transactional
    public CloudIDEDTO updateCloudIDE(Long id, CloudIDEDTO cloudIDEDTO) {
        CloudIDE existingCloudIDE = cloudIDERepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("CloudIDE not found with id: " + id));
        
        existingCloudIDE.setName(cloudIDEDTO.getName());
        existingCloudIDE.setUrl(cloudIDEDTO.getUrl());
        existingCloudIDE.setMetier(cloudIDEDTO.getMetier());
        
        // Update K8s cluster if provided
        if (cloudIDEDTO.getK8sCluster() != null) {
            K8sCluster k8sCluster = existingCloudIDE.getK8sCluster();
            if (k8sCluster == null) {
                k8sCluster = new K8sCluster();
                k8sCluster.setCloudIDE(existingCloudIDE);
            }
            
            k8sCluster.setName(cloudIDEDTO.getK8sCluster().getName());
            k8sCluster.setApiEndpoint(cloudIDEDTO.getK8sCluster().getApiEndpoint());
            k8sCluster.setApiKey(cloudIDEDTO.getK8sCluster().getApiKey());
            k8sCluster.setVip(cloudIDEDTO.getK8sCluster().getVip());
            
            existingCloudIDE.setK8sCluster(k8sCluster);
        }
        
        // Update admin if provided
        if (cloudIDEDTO.getAdminId() != null) {
            User admin = userRepository.findById(cloudIDEDTO.getAdminId())
                    .orElseThrow(() -> new EntityNotFoundException("Admin user not found with id: " + cloudIDEDTO.getAdminId()));
            existingCloudIDE.setAdmin(admin);
        }
        
        CloudIDE updatedCloudIDE = cloudIDERepository.save(existingCloudIDE);
        return convertToDTO(updatedCloudIDE);
    }

    @Override
    @Transactional
    public void deleteCloudIDE(Long id) {
        if (!cloudIDERepository.existsById(id)) {
            throw new EntityNotFoundException("CloudIDE not found with id: " + id);
        }
        cloudIDERepository.deleteById(id);
    }

    @Override
    public List<CloudIDEDTO> getCloudIDEsByAdminId(Long adminId) {
        return cloudIDERepository.findByAdminId(adminId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CloudIDEDTO> getCloudIDEsByUserId(Long userId) {
        return cloudIDERepository.findByUsersId(userId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void addUserToCloudIDE(Long cloudIdeId, Long userId) {
        CloudIDE cloudIDE = cloudIDERepository.findById(cloudIdeId)
                .orElseThrow(() -> new EntityNotFoundException("CloudIDE not found with id: " + cloudIdeId));
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));
        
        cloudIDE.getUsers().add(user);
        cloudIDERepository.save(cloudIDE);
    }

    @Override
    @Transactional
    public void removeUserFromCloudIDE(Long cloudIdeId, Long userId) {
        CloudIDE cloudIDE = cloudIDERepository.findById(cloudIdeId)
                .orElseThrow(() -> new EntityNotFoundException("CloudIDE not found with id: " + cloudIdeId));
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));
        
        cloudIDE.getUsers().remove(user);
        cloudIDERepository.save(cloudIDE);
    }

    private CloudIDEDTO convertToDTO(CloudIDE cloudIDE) {
        Set<Long> userIds = cloudIDE.getUsers().stream()
                .map(User::getId)
                .collect(Collectors.toSet());
        
        K8sClusterDTO k8sClusterDTO = null;
        if (cloudIDE.getK8sCluster() != null) {
            K8sCluster cluster = cloudIDE.getK8sCluster();
            k8sClusterDTO = K8sClusterDTO.builder()
                    .id(cluster.getId())
                    .name(cluster.getName())
                    .apiEndpoint(cluster.getApiEndpoint())
                    .apiKey(cluster.getApiKey())
                    .vip(cluster.getVip())
                    .build();
        }
        
        String adminUsername = cloudIDE.getAdmin() != null ? cloudIDE.getAdmin().getUsername() : null;
        
        return CloudIDEDTO.builder()
                .id(cloudIDE.getId())
                .name(cloudIDE.getName())
                .url(cloudIDE.getUrl())
                .metier(cloudIDE.getMetier())
                .k8sCluster(k8sClusterDTO)
                .userIds(userIds)
                .adminId(cloudIDE.getAdmin() != null ? cloudIDE.getAdmin().getId() : null)
                .adminUsername(adminUsername)
                .build();
    }

    private CloudIDE convertToEntity(CloudIDEDTO cloudIDEDTO) {
        CloudIDE cloudIDE = new CloudIDE();
        cloudIDE.setName(cloudIDEDTO.getName());
        cloudIDE.setUrl(cloudIDEDTO.getUrl());
        cloudIDE.setMetier(cloudIDEDTO.getMetier());
        
        // Set K8s cluster if provided
        if (cloudIDEDTO.getK8sCluster() != null) {
            K8sCluster k8sCluster = new K8sCluster();
            k8sCluster.setName(cloudIDEDTO.getK8sCluster().getName());
            k8sCluster.setApiEndpoint(cloudIDEDTO.getK8sCluster().getApiEndpoint());
            k8sCluster.setApiKey(cloudIDEDTO.getK8sCluster().getApiKey());
            k8sCluster.setVip(cloudIDEDTO.getK8sCluster().getVip());
            k8sCluster.setCloudIDE(cloudIDE);
            
            cloudIDE.setK8sCluster(k8sCluster);
        }
        
        // Set admin if provided
        if (cloudIDEDTO.getAdminId() != null) {
            User admin = userRepository.findById(cloudIDEDTO.getAdminId())
                    .orElseThrow(() -> new EntityNotFoundException("Admin user not found with id: " + cloudIDEDTO.getAdminId()));
            cloudIDE.setAdmin(admin);
        }
        
        // Set users if provided
        if (cloudIDEDTO.getUserIds() != null && !cloudIDEDTO.getUserIds().isEmpty()) {
            Set<User> users = new HashSet<>();
            for (Long userId : cloudIDEDTO.getUserIds()) {
                User user = userRepository.findById(userId)
                        .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));
                users.add(user);
            }
            cloudIDE.setUsers(users);
        }
        
        return cloudIDE;
    }
}
