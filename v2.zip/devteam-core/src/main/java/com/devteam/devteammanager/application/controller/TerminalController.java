package com.devteam.devteammanager.application.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import com.devteam.devteammanager.domain.service.TerminalService;

@Controller
public class TerminalController {

    private static final Logger logger = LoggerFactory.getLogger(TerminalController.class);

    private final TerminalService terminalService;
    private final SimpMessagingTemplate messagingTemplate;

    @Autowired
    public TerminalController(TerminalService terminalService, SimpMessagingTemplate messagingTemplate) {
        this.terminalService = terminalService;
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/terminal.connect")
    public void connect(SimpMessageHeaderAccessor headerAccessor) {
        String sessionId = headerAccessor.getSessionId();
        logger.info("Terminal connect request received for session: {}", sessionId);

        if (sessionId != null) {
            terminalService.startShell(sessionId, output -> {
                logger.debug("Sending terminal output to session {}: {}", sessionId, output);

                // Send to both user-specific and general topics for debugging
                messagingTemplate.convertAndSendToUser(sessionId, "/topic/terminal.output", Map.of("output", output));
                messagingTemplate.convertAndSend("/topic/terminal.output", Map.of(
                        "output", output,
                        "sessionId", sessionId));

                // Also send to a simpler topic for testing
                messagingTemplate.convertAndSend("/topic/terminal", output);
            });
            logger.info("Terminal session started for session: {}", sessionId);
        } else {
            logger.error("Cannot start terminal session: session ID is null");
        }
    }

    @MessageMapping("/terminal.send")
    public void sendCommand(@Payload Map<String, String> payload, SimpMessageHeaderAccessor headerAccessor) {
        String sessionId = headerAccessor.getSessionId();
        String command = payload.get("command");

        logger.info("Terminal command received from session {}: {}", sessionId, command);

        if (sessionId != null && command != null) {
            terminalService.executeCommand(sessionId, command, output -> {
                logger.debug("Sending command output to session {}: {}", sessionId, output);

                // Send to both user-specific and general topics for debugging
                messagingTemplate.convertAndSendToUser(sessionId, "/topic/terminal.output", Map.of("output", output));
                messagingTemplate.convertAndSend("/topic/terminal.output", Map.of(
                        "output", output,
                        "sessionId", sessionId,
                        "command", command));

                // Also send to a simpler topic for testing
                messagingTemplate.convertAndSend("/topic/terminal", output);
            });
            logger.info("Command executed for session: {}", sessionId);
        } else {
            logger.error("Cannot execute command: session ID or command is null. Session ID: {}, Command: {}",
                    sessionId, command);
        }
    }

    @MessageMapping("/terminal.disconnect")
    public void disconnect(SimpMessageHeaderAccessor headerAccessor) {
        String sessionId = headerAccessor.getSessionId();
        logger.info("Terminal disconnect request received for session: {}", sessionId);

        if (sessionId != null) {
            terminalService.terminateSession(sessionId);
            logger.info("Terminal session terminated for session: {}", sessionId);
        } else {
            logger.error("Cannot terminate terminal session: session ID is null");
        }
    }
}
