package com.devteam.devteammanager.domain.repository;

import com.devteam.devteammanager.domain.model.Developer;
import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Developer entity.
 * This is a port in the hexagonal architecture.
 */
public interface DeveloperRepository {
    
    /**
     * Saves a developer
     *
     * @param developer the developer to save
     * @return the saved developer
     */
    Developer save(Developer developer);
    
    /**
     * Finds a developer by ID
     *
     * @param id the developer ID
     * @return an Optional containing the developer if found, or empty if not found
     */
    Optional<Developer> findById(Long id);
    
    /**
     * Finds all developers
     *
     * @return a list of all developers
     */
    List<Developer> findAll();
    
    /**
     * Finds developers by team ID
     *
     * @param teamId the team ID
     * @return a list of developers in the specified team
     */
    List<Developer> findByTeamId(Long teamId);
    
    /**
     * Deletes a developer
     *
     * @param developer the developer to delete
     */
    void delete(Developer developer);
    
    /**
     * Deletes a developer by ID
     *
     * @param id the ID of the developer to delete
     */
    void deleteById(Long id);
    
    /**
     * Checks if a developer exists by ID
     *
     * @param id the developer ID
     * @return true if the developer exists, false otherwise
     */
    boolean existsById(Long id);
}
