package com.devteam.devteammanager.infrastructure.repository;

import com.devteam.devteammanager.domain.model.CloudIDE;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CloudIDERepository extends JpaRepository<CloudIDE, Long> {
    List<CloudIDE> findByAdminId(Long adminId);
    List<CloudIDE> findByUsersId(Long userId);
}
