package com.devteam.devteammanager.infrastructure.rest;

import com.devteam.devteammanager.application.dto.DeveloperRequest;
import com.devteam.devteammanager.application.dto.DeveloperResponse;
import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.service.DeveloperService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * REST controller for Developer-related operations.
 */
@RestController
@RequestMapping("/api/developers")
public class DeveloperController {

    private final DeveloperService developerService;

    public DeveloperController(DeveloperService developerService) {
        this.developerService = developerService;
    }

    /**
     * Creates a new developer
     *
     * @param request the developer creation request
     * @return the created developer
     */
    @PostMapping
    public ResponseEntity<DeveloperResponse> createDeveloper(@Valid @RequestBody DeveloperRequest request) {
        Developer developer = developerService.createDeveloper(
                request.getName(),
                request.getRole(),
                request.getEmail(),
                request.getSkillLevel(),
                request.getPictureUrl()
        );
        return new ResponseEntity<>(new DeveloperResponse(developer), HttpStatus.CREATED);
    }

    /**
     * Updates an existing developer
     *
     * @param id      the developer ID
     * @param request the developer update request
     * @return the updated developer
     */
    @PutMapping("/{id}")
    public ResponseEntity<DeveloperResponse> updateDeveloper(
            @PathVariable Long id,
            @Valid @RequestBody DeveloperRequest request
    ) {
        try {
            Developer developer = developerService.updateDeveloper(
                    id,
                    request.getName(),
                    request.getRole(),
                    request.getEmail(),
                    request.getSkillLevel(),
                    request.getPictureUrl()
            );
            return ResponseEntity.ok(new DeveloperResponse(developer));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Gets a developer by ID
     *
     * @param id the developer ID
     * @return the developer if found, or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<DeveloperResponse> getDeveloper(@PathVariable Long id) {
        return developerService.findDeveloperById(id)
                .map(developer -> ResponseEntity.ok(new DeveloperResponse(developer)))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Gets all developers
     *
     * @return a list of all developers
     */
    @GetMapping
    public ResponseEntity<List<DeveloperResponse>> getAllDevelopers() {
        List<DeveloperResponse> developers = developerService.findAllDevelopers().stream()
                .map(DeveloperResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(developers);
    }

    /**
     * Gets developers by team ID
     *
     * @param teamId the team ID
     * @return a list of developers in the specified team
     */
    @GetMapping("/team/{teamId}")
    public ResponseEntity<List<DeveloperResponse>> getDevelopersByTeam(@PathVariable Long teamId) {
        List<DeveloperResponse> developers = developerService.findDevelopersByTeamId(teamId).stream()
                .map(DeveloperResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(developers);
    }

    /**
     * Deletes a developer
     *
     * @param id the developer ID
     * @return 204 if deleted, 404 if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDeveloper(@PathVariable Long id) {
        try {
            developerService.deleteDeveloper(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
