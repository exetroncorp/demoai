package com.devteam.devteammanager.infrastructure.repository;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.repository.DeveloperRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * JPA implementation of the DeveloperRepository interface.
 * This is an adapter in the hexagonal architecture.
 */
@Repository
public interface JpaDeveloperRepository extends JpaRepository<Developer, Long>, DeveloperRepository {
    
    /**
     * Finds developers by team ID
     *
     * @param teamId the team ID
     * @return a list of developers in the specified team
     */
    @Query("SELECT d FROM Developer d WHERE d.team.id = :teamId")
    List<Developer> findByTeamId(Long teamId);
}
