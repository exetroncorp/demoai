package com.devteam.devteammanager.domain.model;

/**
 * Enum representing the possible states of a task.
 */
public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE,
    BLOCKED
}
