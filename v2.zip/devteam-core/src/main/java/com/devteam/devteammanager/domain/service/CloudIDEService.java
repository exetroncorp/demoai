package com.devteam.devteammanager.domain.service;

import com.devteam.devteammanager.application.dto.CloudIDEDTO;

import java.util.List;

public interface CloudIDEService {
    List<CloudIDEDTO> getAllCloudIDEs();
    CloudIDEDTO getCloudIDEById(Long id);
    CloudIDEDTO createCloudIDE(CloudIDEDTO cloudIDEDTO);
    CloudIDEDTO updateCloudIDE(Long id, CloudIDEDTO cloudIDEDTO);
    void deleteCloudIDE(Long id);
    List<CloudIDEDTO> getCloudIDEsByAdminId(Long adminId);
    List<CloudIDEDTO> getCloudIDEsByUserId(Long userId);
    void addUserToCloudIDE(Long cloudIdeId, Long userId);
    void removeUserFromCloudIDE(Long cloudIdeId, Long userId);
}
