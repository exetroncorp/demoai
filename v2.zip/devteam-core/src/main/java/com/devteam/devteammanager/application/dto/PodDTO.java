package com.devteam.devteammanager.application.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PodDTO {
    private String name;
    private String namespace;
    private String status;
    private String creationTimestamp;
    private String ip;
    private String nodeName;
}
