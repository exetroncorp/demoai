package com.devteam.devteammanager.domain.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class TerminalService {

    private static final Logger logger = LoggerFactory.getLogger(TerminalService.class);

    private final ConcurrentHashMap<String, Process> activeProcesses = new ConcurrentHashMap<>();
    private final ExecutorService executorService = Executors.newCachedThreadPool();

    public void startShell(String sessionId, Consumer<String> outputConsumer) {
        logger.info("Starting shell for session: {}", sessionId);
        try {
            ProcessBuilder processBuilder = new ProcessBuilder();

            // Use cmd.exe for Windows or bash for Unix-like systems
            String osName = System.getProperty("os.name").toLowerCase();
            if (osName.contains("win")) {
                processBuilder.command("cmd.exe");
                logger.info("Using cmd.exe for Windows OS: {}", osName);
            } else {
                processBuilder.command("/bin/bash");
                logger.info("Using /bin/bash for non-Windows OS: {}", osName);
            }

            Process process = processBuilder.start();
            activeProcesses.put(sessionId, process);
            logger.info("Process started and added to active processes for session: {}", sessionId);

            // Send initial prompt
            outputConsumer.accept("Terminal ready. Type commands and press Enter.\n$ ");

            // Handle process output
            executorService.submit(() -> {
                logger.info("Starting output reader thread for session: {}", sessionId);
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        logger.debug("Process output for session {}: {}", sessionId, line);
                        outputConsumer.accept(line + "\n");

                        // Add a small delay to ensure output is processed in order
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }

                    // Send a prompt after all output
                    outputConsumer.accept("$ ");
                    logger.info("Process output stream closed for session: {}", sessionId);
                } catch (IOException e) {
                    logger.error("Error reading process output for session {}: {}", sessionId, e.getMessage(), e);
                    outputConsumer.accept("Error reading process output: " + e.getMessage() + "\n$ ");
                }
            });

            // Handle process error
            executorService.submit(() -> {
                logger.info("Starting error reader thread for session: {}", sessionId);
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        logger.debug("Process error output for session {}: {}", sessionId, line);
                        outputConsumer.accept(line + "\n");

                        // Add a small delay to ensure output is processed in order
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }

                    // Send a prompt after all error output
                    outputConsumer.accept("$ ");
                    logger.info("Process error stream closed for session: {}", sessionId);
                } catch (IOException e) {
                    logger.error("Error reading process error for session {}: {}", sessionId, e.getMessage(), e);
                    outputConsumer.accept("Error reading process error: " + e.getMessage() + "\n$ ");
                }
            });

        } catch (IOException e) {
            logger.error("Failed to start shell for session {}: {}", sessionId, e.getMessage(), e);
            outputConsumer.accept("Failed to start shell: " + e.getMessage() + "\n$ ");
        }
    }

    public void executeCommand(String sessionId, String command, Consumer<String> outputConsumer) {
        logger.info("Executing command for session {}: {}", sessionId, command);
        Process process = activeProcesses.get(sessionId);
        if (process == null) {
            logger.warn("No active shell session found for session: {}", sessionId);
            outputConsumer.accept("No active shell session found. Starting a new one...\n");
            startShell(sessionId, outputConsumer);
            process = activeProcesses.get(sessionId);
            logger.info("New shell session started for session: {}", sessionId);
        }

        try {
            // Echo the command with prompt
            outputConsumer.accept("$ " + command + "\n");

            // Send the command to the process
            process.getOutputStream().write((command + "\n").getBytes());
            process.getOutputStream().flush();
            logger.info("Command sent to process for session: {}", sessionId);

            // Add a small delay to ensure the command is processed
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            // Send a prompt after command execution
            outputConsumer.accept("$ ");
        } catch (IOException e) {
            logger.error("Failed to execute command for session {}: {}", sessionId, e.getMessage(), e);
            outputConsumer.accept("Failed to execute command: " + e.getMessage() + "\n$ ");
        }
    }

    public void terminateSession(String sessionId) {
        logger.info("Terminating session: {}", sessionId);
        Process process = activeProcesses.remove(sessionId);
        if (process != null) {
            process.destroy();
            logger.info("Process destroyed for session: {}", sessionId);
        } else {
            logger.warn("No active process found for session: {}", sessionId);
        }
    }
}
