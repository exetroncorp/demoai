package com.devteam.devteammanager.domain.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "cloud_ides")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CloudIDE {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(nullable = false)
    private String url;
    
    @Column(nullable = false)
    private String metier;
    
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "k8s_cluster_id", referencedColumnName = "id")
    private K8sCluster k8sCluster;
    
    @ManyToMany
    @JoinTable(
        name = "cloud_ide_users",
        joinColumns = @JoinColumn(name = "cloud_ide_id"),
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private Set<User> users = new HashSet<>();
    
    @ManyToOne
    @JoinColumn(name = "admin_id")
    private User admin;
}
