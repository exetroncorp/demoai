package com.devteam.devteammanager.domain.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "k8s_clusters")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class K8sCluster {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(nullable = false)
    private String apiEndpoint;
    
    @Column(nullable = false)
    private String apiKey;
    
    @Column(nullable = false)
    private String vip;
    
    @OneToOne(mappedBy = "k8sCluster")
    private CloudIDE cloudIDE;
}
