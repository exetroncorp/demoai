package com.devteam.devteammanager.application.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CloudIDEDTO {
    private Long id;
    private String name;
    private String url;
    private String metier;
    private K8sClusterDTO k8sCluster;
    private Set<Long> userIds;
    private Long adminId;
    private String adminUsername;
}
