package com.devteam.devteammanager.domain.service;

import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.model.TaskStatus;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Service interface for Task-related operations.
 * This is a port in the hexagonal architecture.
 */
public interface TaskService {

    /**
     * Creates a new task
     *
     * @param title       the task title
     * @param description the task description
     * @param dueDate     the task due date
     * @param priority    the task priority
     * @param projectId   the project ID
     * @return the created task
     * @throws IllegalArgumentException if the project does not exist
     */
    Task createTask(String title, String description, LocalDate dueDate, Integer priority, Long projectId);

    /**
     * Updates an existing task
     *
     * @param id          the task ID
     * @param title       the new title
     * @param description the new description
     * @param dueDate     the new due date
     * @param priority    the new priority
     * @return the updated task
     * @throws IllegalArgumentException if the task does not exist
     */
    Task updateTask(Long id, String title, String description, LocalDate dueDate, Integer priority);

    /**
     * Finds a task by ID
     *
     * @param id the task ID
     * @return an Optional containing the task if found, or empty if not found
     */
    Optional<Task> findTaskById(Long id);

    /**
     * Finds all tasks
     *
     * @return a list of all tasks
     */
    List<Task> findAllTasks();

    /**
     * Finds tasks by project ID
     *
     * @param projectId the project ID
     * @return a list of tasks for the specified project
     */
    List<Task> findTasksByProjectId(Long projectId);

    /**
     * Finds tasks by assignee ID
     *
     * @param developerId the developer ID
     * @return a list of tasks assigned to the specified developer
     */
    List<Task> findTasksByAssigneeId(Long developerId);

    /**
     * Finds tasks by status
     *
     * @param status the task status
     * @return a list of tasks with the specified status
     */
    List<Task> findTasksByStatus(TaskStatus status);

    /**
     * Deletes a task
     *
     * @param id the ID of the task to delete
     * @throws IllegalArgumentException if the task does not exist
     */
    void deleteTask(Long id);

    /**
     * Assigns a task to a developer
     *
     * @param taskId      the task ID
     * @param developerId the developer ID
     * @throws IllegalArgumentException if the task or developer does not exist
     */
    void assignTaskToDeveloper(Long taskId, Long developerId);

    /**
     * Unassigns a task from its current developer
     *
     * @param taskId the task ID
     * @throws IllegalArgumentException if the task does not exist
     */
    void unassignTask(Long taskId);

    /**
     * Starts a task
     *
     * @param id the task ID
     * @return the updated task
     * @throws IllegalArgumentException if the task does not exist
     * @throws IllegalStateException    if the task cannot be started
     */
    Task startTask(Long id);

    /**
     * Completes a task
     *
     * @param id the task ID
     * @return the updated task
     * @throws IllegalArgumentException if the task does not exist
     * @throws IllegalStateException    if the task cannot be completed
     */
    Task completeTask(Long id);

    /**
     * Reopens a task
     *
     * @param id the task ID
     * @return the updated task
     * @throws IllegalArgumentException if the task does not exist
     * @throws IllegalStateException    if the task cannot be reopened
     */
    Task reopenTask(Long id);

    /**
     * Blocks a task
     *
     * @param id the task ID
     * @return the updated task
     * @throws IllegalArgumentException if the task does not exist
     * @throws IllegalStateException    if the task cannot be blocked
     */
    Task blockTask(Long id);

    /**
     * Unblocks a task
     *
     * @param id the task ID
     * @return the updated task
     * @throws IllegalArgumentException if the task does not exist
     * @throws IllegalStateException    if the task cannot be unblocked
     */
    Task unblockTask(Long id);
}
