package com.devteam.devteammanager.application.service;

import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.ProjectStatus;
import com.devteam.devteammanager.domain.model.Team;
import com.devteam.devteammanager.domain.repository.ProjectRepository;
import com.devteam.devteammanager.domain.repository.TeamRepository;
import com.devteam.devteammanager.domain.service.ProjectService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of the ProjectService interface.
 */
@Service
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;
    private final TeamRepository teamRepository;

    public ProjectServiceImpl(ProjectRepository projectRepository, TeamRepository teamRepository) {
        this.projectRepository = projectRepository;
        this.teamRepository = teamRepository;
    }

    @Override
    @Transactional
    public Project createProject(String name, String description, LocalDate startDate, LocalDate endDate) {
        Project project = new Project(name, description, startDate, endDate);
        return projectRepository.save(project);
    }

    @Override
    @Transactional
    public Project updateProject(Long id, String name, String description, LocalDate startDate, LocalDate endDate) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + id));

        project.setName(name);
        project.setDescription(description);
        // Only update dates if they are provided and the project is not already completed or cancelled
        if (startDate != null && project.getStatus() != ProjectStatus.COMPLETED && project.getStatus() != ProjectStatus.CANCELLED) {
            // We don't directly set start date as it's managed by the domain model
            // through the start() method
        }

        if (endDate != null && project.getStatus() != ProjectStatus.COMPLETED && project.getStatus() != ProjectStatus.CANCELLED) {
            // We don't directly set end date as it's managed by the domain model
            // through the complete() or cancel() methods
        }

        return projectRepository.save(project);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Project> findProjectById(Long id) {
        return projectRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Project> findAllProjects() {
        return projectRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Project> findProjectsByTeamId(Long teamId) {
        return projectRepository.findByTeamId(teamId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Project> findProjectsByStatus(ProjectStatus status) {
        return projectRepository.findByStatus(status);
    }

    @Override
    @Transactional
    public void deleteProject(Long id) {
        if (!projectRepository.existsById(id)) {
            throw new IllegalArgumentException("Project not found with id: " + id);
        }
        projectRepository.deleteById(id);
    }

    @Override
    @Transactional
    public void assignProjectToTeam(Long projectId, Long teamId) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + projectId));

        Team team = teamRepository.findById(teamId)
                .orElseThrow(() -> new IllegalArgumentException("Team not found with id: " + teamId));

        team.addProject(project);
        teamRepository.save(team);
    }

    @Override
    @Transactional
    public Project startProject(Long id) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + id));

        project.start();
        return projectRepository.save(project);
    }

    @Override
    @Transactional
    public Project completeProject(Long id) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + id));

        project.complete();
        return projectRepository.save(project);
    }

    @Override
    @Transactional
    public Project cancelProject(Long id) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + id));

        project.cancel();
        return projectRepository.save(project);
    }

    @Override
    @Transactional
    public Project updateProjectStatus(Long id, ProjectStatus status) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + id));

        // Handle status transitions based on the current status
        switch (status) {
            case PLANNED:
                // Only allow transition to PLANNED if the project is not already completed or cancelled
                if (project.getStatus() != ProjectStatus.COMPLETED && project.getStatus() != ProjectStatus.CANCELLED) {
                    // Reset the project to planned state
                    project = new Project(project.getName(), project.getDescription(), project.getStartDate(), project.getEndDate());
                    project.setId(id); // Preserve the ID
                    if (project.getTeam() != null) {
                        Team team = project.getTeam();
                        project.assignToTeam(team);
                    }
                } else {
                    throw new IllegalStateException("Cannot change status to PLANNED for a completed or cancelled project");
                }
                break;
            case IN_PROGRESS:
                if (project.getStatus() == ProjectStatus.PLANNED) {
                    project.start();
                } else if (project.getStatus() != ProjectStatus.IN_PROGRESS) {
                    throw new IllegalStateException("Project can only be started from PLANNED state");
                }
                break;
            case COMPLETED:
                if (project.getStatus() == ProjectStatus.IN_PROGRESS) {
                    project.complete();
                } else {
                    throw new IllegalStateException("Project can only be completed from IN_PROGRESS state");
                }
                break;
            case CANCELLED:
                if (project.getStatus() != ProjectStatus.COMPLETED) {
                    project.cancel();
                } else {
                    throw new IllegalStateException("Completed projects cannot be cancelled");
                }
                break;
            default:
                throw new IllegalArgumentException("Unsupported project status: " + status);
        }

        return projectRepository.save(project);
    }
}
