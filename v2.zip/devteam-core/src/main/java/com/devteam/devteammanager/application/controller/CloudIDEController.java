package com.devteam.devteammanager.application.controller;

import com.devteam.devteammanager.application.dto.CloudIDEDTO;
import com.devteam.devteammanager.domain.service.CloudIDEService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cloud-ides")
@CrossOrigin(origins = "http://localhost:4200")
public class CloudIDEController {

    private final CloudIDEService cloudIDEService;

    @Autowired
    public CloudIDEController(CloudIDEService cloudIDEService) {
        this.cloudIDEService = cloudIDEService;
    }

    @GetMapping
    public ResponseEntity<List<CloudIDEDTO>> getAllCloudIDEs() {
        return ResponseEntity.ok(cloudIDEService.getAllCloudIDEs());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CloudIDEDTO> getCloudIDEById(@PathVariable Long id) {
        return ResponseEntity.ok(cloudIDEService.getCloudIDEById(id));
    }

    @PostMapping
    public ResponseEntity<CloudIDEDTO> createCloudIDE(@RequestBody CloudIDEDTO cloudIDEDTO) {
        return new ResponseEntity<>(cloudIDEService.createCloudIDE(cloudIDEDTO), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CloudIDEDTO> updateCloudIDE(@PathVariable Long id, @RequestBody CloudIDEDTO cloudIDEDTO) {
        return ResponseEntity.ok(cloudIDEService.updateCloudIDE(id, cloudIDEDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCloudIDE(@PathVariable Long id) {
        cloudIDEService.deleteCloudIDE(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/admin/{adminId}")
    public ResponseEntity<List<CloudIDEDTO>> getCloudIDEsByAdminId(@PathVariable Long adminId) {
        return ResponseEntity.ok(cloudIDEService.getCloudIDEsByAdminId(adminId));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<CloudIDEDTO>> getCloudIDEsByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(cloudIDEService.getCloudIDEsByUserId(userId));
    }

    @PostMapping("/{cloudIdeId}/users/{userId}")
    public ResponseEntity<Void> addUserToCloudIDE(@PathVariable Long cloudIdeId, @PathVariable Long userId) {
        cloudIDEService.addUserToCloudIDE(cloudIdeId, userId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{cloudIdeId}/users/{userId}")
    public ResponseEntity<Void> removeUserFromCloudIDE(@PathVariable Long cloudIdeId, @PathVariable Long userId) {
        cloudIDEService.removeUserFromCloudIDE(cloudIdeId, userId);
        return ResponseEntity.noContent().build();
    }
}
