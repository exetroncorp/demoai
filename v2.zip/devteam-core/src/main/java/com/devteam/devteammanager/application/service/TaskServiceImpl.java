package com.devteam.devteammanager.application.service;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.model.Project;
import com.devteam.devteammanager.domain.model.Task;
import com.devteam.devteammanager.domain.model.TaskStatus;
import com.devteam.devteammanager.domain.repository.DeveloperRepository;
import com.devteam.devteammanager.domain.repository.ProjectRepository;
import com.devteam.devteammanager.domain.repository.TaskRepository;
import com.devteam.devteammanager.domain.service.TaskService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of the TaskService interface.
 */
@Service
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final ProjectRepository projectRepository;
    private final DeveloperRepository developerRepository;

    public TaskServiceImpl(TaskRepository taskRepository, ProjectRepository projectRepository, DeveloperRepository developerRepository) {
        this.taskRepository = taskRepository;
        this.projectRepository = projectRepository;
        this.developerRepository = developerRepository;
    }

    @Override
    @Transactional
    public Task createTask(String title, String description, LocalDate dueDate, Integer priority, Long projectId) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new IllegalArgumentException("Project not found with id: " + projectId));

        Task task = new Task(title, description, dueDate, priority);
        project.addTask(task);
        return taskRepository.save(task);
    }

    @Override
    @Transactional
    public Task updateTask(Long id, String title, String description, LocalDate dueDate, Integer priority) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + id));

        task.setTitle(title);
        task.setDescription(description);
        task.setDueDate(dueDate);
        task.setPriority(priority);

        return taskRepository.save(task);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Task> findTaskById(Long id) {
        return taskRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Task> findAllTasks() {
        return taskRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Task> findTasksByProjectId(Long projectId) {
        return taskRepository.findByProjectId(projectId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Task> findTasksByAssigneeId(Long developerId) {
        return taskRepository.findByAssigneeId(developerId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Task> findTasksByStatus(TaskStatus status) {
        return taskRepository.findByStatus(status);
    }

    @Override
    @Transactional
    public void deleteTask(Long id) {
        if (!taskRepository.existsById(id)) {
            throw new IllegalArgumentException("Task not found with id: " + id);
        }
        taskRepository.deleteById(id);
    }

    @Override
    @Transactional
    public void assignTaskToDeveloper(Long taskId, Long developerId) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + taskId));

        Developer developer = developerRepository.findById(developerId)
                .orElseThrow(() -> new IllegalArgumentException("Developer not found with id: " + developerId));

        task.assignToDeveloper(developer);
        taskRepository.save(task);
    }

    @Override
    @Transactional
    public void unassignTask(Long taskId) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + taskId));

        task.unassignFromDeveloper();
        taskRepository.save(task);
    }

    @Override
    @Transactional
    public Task startTask(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + id));

        task.start();
        return taskRepository.save(task);
    }

    @Override
    @Transactional
    public Task completeTask(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + id));

        task.complete();
        return taskRepository.save(task);
    }

    @Override
    @Transactional
    public Task reopenTask(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + id));

        task.reopen();
        return taskRepository.save(task);
    }

    @Override
    @Transactional
    public Task blockTask(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + id));

        task.block();
        return taskRepository.save(task);
    }

    @Override
    @Transactional
    public Task unblockTask(Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Task not found with id: " + id));

        task.unblock();
        return taskRepository.save(task);
    }
}
