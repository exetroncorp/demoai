package com.devteam.devteammanager.domain.service;

import com.devteam.devteammanager.application.dto.K8sClusterDTO;
import com.devteam.devteammanager.application.dto.PodDTO;

import java.util.List;

public interface K8sService {
    List<PodDTO> getPods(Long clusterId);
    String getPodLogs(Long clusterId, String podName);
    String executeCommand(Long clusterId, String podName, String command);
    K8sClusterDTO getClusterById(Long id);
    K8sClusterDTO createCluster(K8sClusterDTO clusterDTO);
    K8sClusterDTO updateCluster(Long id, K8sClusterDTO clusterDTO);
    void deleteCluster(Long id);
}
