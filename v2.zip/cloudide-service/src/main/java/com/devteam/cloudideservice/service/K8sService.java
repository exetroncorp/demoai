package com.devteam.cloudideservice.service;

import com.devteam.cloudideservice.model.CommandResponse;
import com.devteam.cloudideservice.model.K8sCluster;
import com.devteam.cloudideservice.model.Pod;
import io.fabric8.kubernetes.api.model.PodList;
import io.fabric8.kubernetes.client.Config;
import io.fabric8.kubernetes.client.ConfigBuilder;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.client.KubernetesClientBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class K8sService {

    public List<Pod> getPods(K8sCluster cluster) {
        try (KubernetesClient client = createK8sClient(cluster)) {
            PodList podList = client.pods().inAnyNamespace().list();
            return podList.getItems().stream()
                    .map(pod -> Pod.builder()
                            .name(pod.getMetadata().getName())
                            .namespace(pod.getMetadata().getNamespace())
                            .status(pod.getStatus().getPhase())
                            .creationTimestamp(pod.getMetadata().getCreationTimestamp())
                            .ip(pod.getStatus().getPodIP())
                            .nodeName(pod.getSpec().getNodeName())
                            .build())
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("Error getting pods from Kubernetes cluster", e);
            throw new RuntimeException("Failed to get pods: " + e.getMessage());
        }
    }

    public String getPodLogs(K8sCluster cluster, String podName, String namespace) {
        try (KubernetesClient client = createK8sClient(cluster)) {
            return client.pods().inNamespace(namespace).withName(podName).getLog();
        } catch (Exception e) {
            log.error("Error getting pod logs", e);
            throw new RuntimeException("Failed to get pod logs: " + e.getMessage());
        }
    }

    public CommandResponse executeCommand(K8sCluster cluster, String podName, String namespace, String command) {
        try (KubernetesClient client = createK8sClient(cluster)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ByteArrayOutputStream err = new ByteArrayOutputStream();
            
            String[] commandArray = command.split("\\s+");
            
            client.pods().inNamespace(namespace)
                    .withName(podName)
                    .writingOutput(out)
                    .writingError(err)
                    .exec(commandArray);
            
            String output = out.toString();
            String error = err.toString();
            
            return CommandResponse.builder()
                    .output(output)
                    .success(error.isEmpty())
                    .error(error)
                    .build();
        } catch (Exception e) {
            log.error("Error executing command in pod", e);
            return CommandResponse.builder()
                    .output("")
                    .success(false)
                    .error("Failed to execute command: " + e.getMessage())
                    .build();
        }
    }

    private KubernetesClient createK8sClient(K8sCluster cluster) {
        Config config = new ConfigBuilder()
                .withMasterUrl(cluster.getApiEndpoint())
                .withOauthToken(cluster.getApiKey())
                .withTrustCerts(true)
                .build();
        
        return new KubernetesClientBuilder().withConfig(config).build();
    }
}
