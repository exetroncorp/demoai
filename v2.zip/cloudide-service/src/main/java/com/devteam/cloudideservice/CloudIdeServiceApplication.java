package com.devteam.cloudideservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudIdeServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CloudIdeServiceApplication.class, args);
    }
}
