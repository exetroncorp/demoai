package com.devteam.cloudideservice.controller;

import com.devteam.cloudideservice.model.CommandRequest;
import com.devteam.cloudideservice.model.CommandResponse;
import com.devteam.cloudideservice.model.K8sCluster;
import com.devteam.cloudideservice.model.Pod;
import com.devteam.cloudideservice.service.K8sService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/k8s")
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
public class K8sController {

    private final K8sService k8sService;

    @Autowired
    public K8sController(K8sService k8sService) {
        this.k8sService = k8sService;
    }

    @PostMapping("/pods")
    public ResponseEntity<List<Pod>> getPods(@RequestBody K8sCluster cluster) {
        log.info("Getting pods for cluster: {}", cluster.getName());
        return ResponseEntity.ok(k8sService.getPods(cluster));
    }

    @PostMapping("/pods/{podName}/logs")
    public ResponseEntity<String> getPodLogs(
            @RequestBody K8sCluster cluster,
            @PathVariable String podName,
            @RequestParam String namespace) {
        log.info("Getting logs for pod: {} in namespace: {}", podName, namespace);
        return ResponseEntity.ok(k8sService.getPodLogs(cluster, podName, namespace));
    }

    @PostMapping("/pods/{podName}/exec")
    public ResponseEntity<CommandResponse> executeCommand(
            @RequestBody CommandRequest commandRequest,
            @PathVariable String podName,
            @RequestParam String namespace,
            @RequestHeader("X-K8s-Api-Endpoint") String apiEndpoint,
            @RequestHeader("X-K8s-Api-Key") String apiKey,
            @RequestHeader("X-K8s-Cluster-Name") String clusterName) {
        
        log.info("Executing command in pod: {} in namespace: {}", podName, namespace);
        
        K8sCluster cluster = K8sCluster.builder()
                .name(clusterName)
                .apiEndpoint(apiEndpoint)
                .apiKey(apiKey)
                .build();
        
        return ResponseEntity.ok(k8sService.executeCommand(cluster, podName, namespace, commandRequest.getCommand()));
    }

    @PostMapping("/test-connection")
    public ResponseEntity<String> testConnection(@RequestBody K8sCluster cluster) {
        log.info("Testing connection to cluster: {}", cluster.getName());
        try {
            k8sService.getPods(cluster);
            return ResponseEntity.ok("Connection successful");
        } catch (Exception e) {
            log.error("Connection test failed", e);
            return ResponseEntity.badRequest().body("Connection failed: " + e.getMessage());
        }
    }
}
