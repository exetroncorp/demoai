package com.devteam.devteammanager.application.service;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.repository.DeveloperRepository;
import com.devteam.devteammanager.domain.service.DeveloperService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of the DeveloperService interface.
 */
@Service
public class DeveloperServiceImpl implements DeveloperService {

    private final DeveloperRepository developerRepository;

    public DeveloperServiceImpl(DeveloperRepository developerRepository) {
        this.developerRepository = developerRepository;
    }

    @Override
    @Transactional
    public Developer createDeveloper(String name, String role, String email, String skillLevel) {
        Developer developer = new Developer(name, role, email, skillLevel);
        return developerRepository.save(developer);
    }

    @Override
    @Transactional
    public Developer updateDeveloper(Long id, String name, String role, String email, String skillLevel) {
        Developer developer = developerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Developer not found with id: " + id));
        
        developer.setName(name);
        developer.setRole(role);
        developer.setEmail(email);
        developer.setSkillLevel(skillLevel);
        
        return developerRepository.save(developer);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Developer> findDeveloperById(Long id) {
        return developerRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Developer> findAllDevelopers() {
        return developerRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Developer> findDevelopersByTeamId(Long teamId) {
        return developerRepository.findByTeamId(teamId);
    }

    @Override
    @Transactional
    public void deleteDeveloper(Long id) {
        if (!developerRepository.existsById(id)) {
            throw new IllegalArgumentException("Developer not found with id: " + id);
        }
        developerRepository.deleteById(id);
    }
}
