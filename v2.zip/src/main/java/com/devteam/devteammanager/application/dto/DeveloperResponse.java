package com.devteam.devteammanager.application.dto;

import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.model.Team;

/**
 * DTO for developer responses.
 */
public class DeveloperResponse {

    private Long id;
    private String name;
    private String role;
    private String email;
    private String skillLevel;
    private TeamSummaryResponse team;

    // Default constructor for JSON serialization
    public DeveloperResponse() {
    }

    public DeveloperResponse(Developer developer) {
        this.id = developer.getId();
        this.name = developer.getName();
        this.role = developer.getRole();
        this.email = developer.getEmail();
        this.skillLevel = developer.getSkillLevel();
        
        if (developer.getTeam() != null) {
            this.team = new TeamSummaryResponse(developer.getTeam());
        }
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }

    public String getEmail() {
        return email;
    }

    public String getSkillLevel() {
        return skillLevel;
    }

    public TeamSummaryResponse getTeam() {
        return team;
    }

    /**
     * Nested class for summarized team information in developer responses.
     */
    public static class TeamSummaryResponse {
        private Long id;
        private String name;

        public TeamSummaryResponse(Team team) {
            this.id = team.getId();
            this.name = team.getName();
        }

        public Long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }
}
