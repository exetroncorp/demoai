package com.devteam.devteammanager.domain.model;

import jakarta.persistence.*;
import java.util.Objects;

/**
 * Developer entity representing a software developer in the team.
 * This is a domain model following DDD principles.
 */
@Entity
@Table(name = "developers")
public class Developer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String role;

    @Column(nullable = false)
    private String email;

    @Column(name = "skill_level")
    private String skillLevel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id")
    private Team team;

    /**
     * Default constructor required by JPA
     */
    protected Developer() {
    }

    /**
     * Constructor for creating a new Developer
     *
     * @param name       the developer's name
     * @param role       the developer's role (e.g., "Software Engineer", "QA Engineer")
     * @param email      the developer's email
     * @param skillLevel the developer's skill level (e.g., "Junior", "Senior")
     */
    public Developer(String name, String role, String email, String skillLevel) {
        this.name = name;
        this.role = role;
        this.email = email;
        this.skillLevel = skillLevel;
    }

    /**
     * Assigns the developer to a team
     *
     * @param team the team to assign the developer to
     */
    public void assignToTeam(Team team) {
        this.team = team;
    }

    /**
     * Removes the developer from their current team
     */
    public void removeFromTeam() {
        this.team = null;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(String skillLevel) {
        this.skillLevel = skillLevel;
    }

    public Team getTeam() {
        return team;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Developer developer = (Developer) o;
        return Objects.equals(id, developer.id) &&
                Objects.equals(email, developer.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, email);
    }

    @Override
    public String toString() {
        return "Developer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                ", email='" + email + '\'' +
                ", skillLevel='" + skillLevel + '\'' +
                ", team=" + (team != null ? team.getName() : "none") +
                '}';
    }
}
