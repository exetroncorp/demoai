package com.example.demo.application.dto;

import com.example.demo.domain.Team;

public class TeamResponse {
    private Long id;
    private String name;

    public TeamResponse(Team team) {
        this.id = team.getId();
        this.name = team.getName();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
