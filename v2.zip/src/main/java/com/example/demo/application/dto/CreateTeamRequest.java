package com.example.demo.application.dto;

public class CreateTeamRequest {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}