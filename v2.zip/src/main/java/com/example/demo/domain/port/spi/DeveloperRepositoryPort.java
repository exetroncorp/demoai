package com.example.demo.domain.port.spi;

import com.example.demo.domain.Developer;

import java.util.Optional;

public interface DeveloperRepositoryPort {
    Developer save(Developer developer);
    Optional<Developer> findById(Long id);
    void deleteById(Long id);
}
