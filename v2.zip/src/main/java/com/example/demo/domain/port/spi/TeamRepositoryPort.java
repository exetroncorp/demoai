package com.example.demo.domain.port.spi;

import com.example.demo.domain.Team;

import java.util.Optional;

public interface TeamRepositoryPort {
    Team save(Team team);
    Optional<Team> findById(Long id);
    void deleteById(Long id);
}
