package com.example.demo.domain.port.api;

public interface AssignDeveloperToTeamUseCase {
    void assignDeveloperToTeam(Long developerId, Long teamId);
}
