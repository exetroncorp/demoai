package com.example.demo.application;

import com.example.demo.domain.Developer;
import com.example.demo.domain.DeveloperRepository;
import com.example.demo.domain.Team;
import com.example.demo.domain.TeamRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TeamServiceTest {

    @Mock
    private TeamRepository teamRepository;

    @Mock
    private DeveloperRepository developerRepository;

    @InjectMocks
    private TeamService teamService;

    @Test
    void assignDeveloperToTeam_shouldAssignDeveloperToTeam_whenDeveloperAndTeamExist() {
        // Arrange
        Long developerId = 1L;
        Long teamId = 2L;
        Developer developer = new Developer("John Doe", "Software Engineer", null);
        developer.setId(developerId);
        Team team = new Team("Team A", null);
        team.setId(teamId);

        when(developerRepository.findById(developerId)).thenReturn(Optional.of(developer));
        when(teamRepository.findById(teamId)).thenReturn(Optional.of(team));
        when(developerRepository.save(any(Developer.class))).thenReturn(developer);
        when(teamRepository.save(any(Team.class))).thenReturn(team);

        // Act
        teamService.assignDeveloperToTeam(developerId, teamId);

        // Assert
        verify(developerRepository, times(1)).findById(developerId);
        verify(teamRepository, times(1)).findById(teamId);
        verify(developerRepository, times(1)).save(developer);
        verify(teamRepository, times(1)).save(team);
    }

    @Test
    void assignDeveloperToTeam_shouldThrowException_whenDeveloperDoesNotExist() {
        // Arrange
        Long developerId = 1L;
        Long teamId = 2L;

        when(developerRepository.findById(developerId)).thenReturn(Optional.empty());
        when(teamRepository.findById(teamId)).thenReturn(Optional.of(new Team()));

        // Act & Assert
        try {
            teamService.assignDeveloperToTeam(developerId, teamId);
        } catch (IllegalArgumentException e) {
            assert e.getMessage().equals("Developer or Team not found");
        }

        verify(developerRepository, times(1)).findById(developerId);
        verify(teamRepository, times(1)).findById(teamId);
        verify(developerRepository, never()).save(any(Developer.class));
        verify(teamRepository, never()).save(any(Team.class));
    }

    @Test
    void assignDeveloperToTeam_shouldThrowException_whenTeamDoesNotExist() {
        // Arrange
        Long developerId = 1L;
        Long teamId = 2L;

        when(developerRepository.findById(developerId)).thenReturn(Optional.of(new Developer()));
        when(teamRepository.findById(teamId)).thenReturn(Optional.empty());

        // Act & Assert
        try {
            teamService.assignDeveloperToTeam(developerId, teamId);
        } catch (IllegalArgumentException e) {
            assert e.getMessage().equals("Developer or Team not found");
        }

        verify(developerRepository, times(1)).findById(developerId);
        verify(teamRepository, times(1)).findById(teamId);
        verify(developerRepository, never()).save(any(Developer.class));
        verify(teamRepository, never()).save(any(Team.class));
    }
}
