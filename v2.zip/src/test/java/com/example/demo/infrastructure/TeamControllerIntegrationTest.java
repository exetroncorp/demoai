package com.example.demo.infrastructure;

import com.example.demo.application.TeamService;
import com.example.demo.domain.Developer;
import com.example.demo.domain.DeveloperRepository;
import com.example.demo.domain.Team;
import com.example.demo.domain.TeamRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class TeamControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private DeveloperRepository developerRepository;

    @Autowired
    private TeamService teamService;

    @Test
    public void assignDeveloperToTeam_shouldReturnNoContent_whenDeveloperAndTeamExist() throws Exception {
        // Arrange
        Team team = new Team("Team A", null);
        team = teamRepository.save(team);
        Developer developer = new Developer("John Doe", "Software Engineer", null);
        developer = developerRepository.save(developer);

        // Act & Assert
        mockMvc.perform(MockMvcRequestBuilders.post("/teams/{teamId}/developers/{developerId}", team.getId(), developer.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    public void assignDeveloperToTeam_shouldReturnNotFound_whenDeveloperOrTeamDoesNotExist() throws Exception {
        // Arrange
        Long nonExistingId = 999L;

        // Act & Assert
        mockMvc.perform(MockMvcRequestBuilders.post("/teams/{teamId}/developers/{developerId}", nonExistingId, nonExistingId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

}
