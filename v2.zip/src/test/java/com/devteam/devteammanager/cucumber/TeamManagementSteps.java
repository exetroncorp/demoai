package com.devteam.devteammanager.cucumber;

import com.devteam.devteammanager.application.dto.TeamRequest;
import com.devteam.devteammanager.domain.model.Developer;
import com.devteam.devteammanager.domain.model.Team;
import com.devteam.devteammanager.domain.repository.DeveloperRepository;
import com.devteam.devteammanager.domain.repository.TeamRepository;
import com.devteam.devteammanager.domain.service.TeamService;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class TeamManagementSteps {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private DeveloperRepository developerRepository;

    @Autowired
    private TeamService teamService;

    private Team team;
    private Developer developer;
    private ResponseEntity<?> response;
    private String baseUrl;

    @Before
    public void setup() {
        baseUrl = "http://localhost:" + port + "/api";
    }

    @Given("the system has no existing teams")
    public void theSystemHasNoExistingTeams() {
        teamRepository.findAll().forEach(teamRepository::delete);
    }

    @Given("a team exists with name {string} and department {string}")
    public void aTeamExistsWithNameAndDepartment(String name, String department) {
        team = new Team(name, department);
        team = teamRepository.save(team);
        assertNotNull(team.getId());
    }

    @Given("a developer exists with name {string} and role {string}")
    public void aDeveloperExistsWithNameAndRole(String name, String role) {
        developer = new Developer(name, role, name.toLowerCase() + "@example.com", "Mid-level");
        developer = developerRepository.save(developer);
        assertNotNull(developer.getId());
    }

    @Given("the developer is assigned to the team")
    public void theDeveloperIsAssignedToTheTeam() {
        teamService.assignDeveloperToTeam(developer.getId(), team.getId());
        
        // Refresh entities from database
        team = teamRepository.findById(team.getId()).orElseThrow();
        developer = developerRepository.findById(developer.getId()).orElseThrow();
        
        assertEquals(team.getId(), developer.getTeam().getId());
        assertTrue(team.getDevelopers().contains(developer));
    }

    @When("I create a team with name {string} and department {string}")
    public void iCreateATeamWithNameAndDepartment(String name, String department) {
        TeamRequest request = new TeamRequest(name, department);
        response = restTemplate.postForEntity(baseUrl + "/teams", request, Object.class);
    }

    @When("I update the team with new name {string} and department {string}")
    public void iUpdateTheTeamWithNewNameAndDepartment(String name, String department) {
        TeamRequest request = new TeamRequest(name, department);
        response = restTemplate.exchange(
                baseUrl + "/teams/" + team.getId(),
                HttpMethod.PUT,
                new HttpEntity<>(request),
                Object.class);
    }

    @When("I delete the team")
    public void iDeleteTheTeam() {
        response = restTemplate.exchange(
                baseUrl + "/teams/" + team.getId(),
                HttpMethod.DELETE,
                null,
                Object.class);
    }

    @When("I assign the developer to the team")
    public void iAssignTheDeveloperToTheTeam() {
        response = restTemplate.postForEntity(
                baseUrl + "/teams/" + team.getId() + "/developers/" + developer.getId(),
                null,
                Object.class);
    }

    @When("I remove the developer from the team")
    public void iRemoveTheDeveloperFromTheTeam() {
        response = restTemplate.exchange(
                baseUrl + "/teams/" + team.getId() + "/developers/" + developer.getId(),
                HttpMethod.DELETE,
                null,
                Object.class);
    }

    @Then("the team should be created successfully")
    public void theTeamShouldBeCreatedSuccessfully() {
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Then("the team should be updated successfully")
    public void theTeamShouldBeUpdatedSuccessfully() {
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Then("the team should be deleted successfully")
    public void theTeamShouldBeDeletedSuccessfully() {
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Then("the team should have the name {string}")
    public void theTeamShouldHaveTheName(String name) {
        if (team == null || team.getId() == null) {
            // If we don't have a team reference yet, find by name
            Optional<Team> foundTeam = teamRepository.findByName(name);
            assertTrue(foundTeam.isPresent());
            team = foundTeam.get();
        } else {
            // Refresh from database
            team = teamRepository.findById(team.getId()).orElseThrow();
        }
        
        assertEquals(name, team.getName());
    }

    @Then("the team should belong to the {string} department")
    public void theTeamShouldBelongToTheDepartment(String department) {
        team = teamRepository.findById(team.getId()).orElseThrow();
        assertEquals(department, team.getDepartment());
    }

    @Then("the team should no longer exist in the system")
    public void theTeamShouldNoLongerExistInTheSystem() {
        assertFalse(teamRepository.existsById(team.getId()));
    }

    @Then("the developer should be assigned to the team successfully")
    public void theDeveloperShouldBeAssignedToTheTeamSuccessfully() {
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Then("the team should have the developer as a member")
    public void theTeamShouldHaveTheDeveloperAsAMember() {
        team = teamRepository.findById(team.getId()).orElseThrow();
        developer = developerRepository.findById(developer.getId()).orElseThrow();
        
        List<Developer> teamDevelopers = team.getDevelopers();
        assertTrue(teamDevelopers.stream().anyMatch(d -> d.getId().equals(developer.getId())));
        assertEquals(team.getId(), developer.getTeam().getId());
    }

    @Then("the developer should be removed from the team successfully")
    public void theDeveloperShouldBeRemovedFromTheTeamSuccessfully() {
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Then("the team should not have the developer as a member")
    public void theTeamShouldNotHaveTheDeveloperAsAMember() {
        team = teamRepository.findById(team.getId()).orElseThrow();
        developer = developerRepository.findById(developer.getId()).orElseThrow();
        
        List<Developer> teamDevelopers = team.getDevelopers();
        assertFalse(teamDevelopers.stream().anyMatch(d -> d.getId().equals(developer.getId())));
        assertNull(developer.getTeam());
    }
}
