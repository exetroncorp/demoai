import { db } from "../server/db";
import { 
  users, accounts, cards, transactions, documents, notifications, sql
} from "../shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

function generateIBAN() {
  const countryCode = "FR";
  const checkDigits = Math.floor(Math.random() * 90 + 10).toString();
  const bankCode = Math.floor(Math.random() * 90000 + 10000).toString();
  const branchCode = Math.floor(Math.random() * 90000 + 10000).toString();
  const accountNumber = Math.floor(Math.random() * 90000000000 + 10000000000).toString();
  return `${countryCode}${checkDigits}${bankCode}${branchCode}${accountNumber}`;
}

function generateBIC() {
  const bankCode = ["BNPA", "SOGT", "CMBT", "AGFB", "CRCF"][Math.floor(Math.random() * 5)];
  const countryCode = "FR";
  const locationCode = ["PP", "PR", "PL", "PC"][Math.floor(Math.random() * 4)];
  const branchCode = Math.floor(Math.random() * 900 + 100).toString();
  return `${bankCode}${countryCode}${locationCode}${branchCode}`;
}

function generateCardNumber() {
  const prefix = ["4", "5"][Math.floor(Math.random() * 2)]; // 4 for Visa, 5 for Mastercard
  let number = prefix;
  for (let i = 0; i < 15; i++) {
    number += Math.floor(Math.random() * 10);
  }
  return `${number.slice(0, 4)}****${number.slice(-4)}`;
}

function generateExpiryDate() {
  const month = Math.floor(Math.random() * 12 + 1)
    .toString()
    .padStart(2, "0");
  const year = (new Date().getFullYear() + Math.floor(Math.random() * 5 + 1))
    .toString()
    .slice(-2);
  return `${month}/${year}`;
}

function generateCVV() {
  return Math.floor(Math.random() * 900 + 100).toString();
}

async function seedDatabase() {
  console.log("Checking if default user exists...");
  
  // Check if user already exists
  const existingUser = await db.select().from(users).where(sql`username = 'zoubida'`);
  
  if (existingUser.length > 0) {
    console.log("Default user already exists, skipping seed data creation");
    return;
  }
  
  console.log("Creating default user and sample data...");

  // Insert default user
  const [user] = await db.insert(users).values({
    username: "zoubida",
    password: await hashPassword("zoubida21"),
    firstName: "Zoubida",
    lastName: "Benarbia",
    email: "zoubida@example.com",
  }).returning();

  // Insert sample accounts
  const accountTypes = ["CURRENT", "SAVINGS", "TERM"];
  const accountNames = ["Compte Courant", "Compte Épargne", "Compte à Terme"];
  const accountData = [];
  
  for (let i = 0; i < 3; i++) {
    accountData.push({
      userId: user.id,
      name: accountNames[i],
      type: accountTypes[i],
      iban: generateIBAN(),
      bic: generateBIC(),
      balance: Math.floor(Math.random() * 10000 + 1000) * 100 / 100,
      status: "ACTIVE"
    });
  }
  
  const insertedAccounts = await db.insert(accounts).values(accountData).returning();
  
  // Insert sample cards
  const cardTypes = ["MASTERCARD", "VISA", "VISA_PREMIER"];
  const cardNetworks = ["MASTERCARD", "VISA", "VISA"];
  const cardData = [];
  
  for (let i = 0; i < 2; i++) {
    cardData.push({
      userId: user.id,
      accountId: insertedAccounts[0].id, // Associate with current account
      type: cardTypes[i],
      maskedNumber: generateCardNumber(),
      cardholderName: `${user.firstName} ${user.lastName}`,
      expiryDate: generateExpiryDate(),
      cvv: generateCVV(),
      network: cardNetworks[i],
      limit: 3000,
      accountName: insertedAccounts[0].name,
      blocked: false,
      onlinePaymentsEnabled: true,
      foreignPaymentsEnabled: i === 1, // Enable for the second card
      contactlessEnabled: true
    });
  }
  
  await db.insert(cards).values(cardData).returning();
  
  // Insert sample transactions
  const transactionCategories = ["FOOD", "INCOME", "HOUSING", "TELECOM", "RESTAURANT", "TRANSPORT", "TRAVEL", "HEALTH", "EDUCATION", "SHOPPING", "OTHER"];
  const transactionDescriptions = [
    "Supermarché Carrefour", 
    "Salaire", 
    "Loyer Appartement", 
    "Facture Internet", 
    "Restaurant Le Bistrot", 
    "SNCF Billet", 
    "Agence de Voyage", 
    "Pharmacie", 
    "Frais Universitaires", 
    "Amazon", 
    "Virement"
  ];
  const transactionTypes = ["DEBIT", "CREDIT"];
  const transactionData = [];
  
  // Generate 20 random transactions for the current account
  for (let i = 0; i < 20; i++) {
    const categoryIndex = Math.floor(Math.random() * transactionCategories.length);
    const isCredit = categoryIndex === 1; // INCOME category is CREDIT type
    const type = isCredit ? "CREDIT" : "DEBIT";
    
    const amount = Math.floor(Math.random() * 500 + 10) * 100 / 100;
    
    // Date between 1 and 30 days ago
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * 30));
    
    transactionData.push({
      accountId: insertedAccounts[0].id,
      userId: user.id,
      amount: isCredit ? amount : -amount,
      description: transactionDescriptions[categoryIndex],
      reference: `REF${Math.floor(Math.random() * 1000000)}`,
      category: transactionCategories[categoryIndex],
      type: type,
      date: date.toISOString(),
    });
  }
  
  await db.insert(transactions).values(transactionData).returning();
  
  // Insert sample documents
  const documentTypes = ["RIB", "STATEMENT", "CONTRACT", "OTHER"];
  const documentNames = ["Relevé d'Identité Bancaire", "Relevé de Compte Mars 2023", "Contrat Carte Bancaire", "Mandat SEPA"];
  const documentData = [];
  
  for (let i = 0; i < 4; i++) {
    documentData.push({
      userId: user.id,
      accountId: insertedAccounts[i % 3].id,
      name: documentNames[i],
      type: documentTypes[i],
      url: `/documents/document_${i+1}.pdf`,
      accountName: insertedAccounts[i % 3].name,
    });
  }
  
  await db.insert(documents).values(documentData).returning();
  
  // Insert sample notifications
  const notificationTypes = ["TRANSFER", "ACCOUNT", "CARD", "DOCUMENT", "OTHER"];
  const notificationTitles = ["Virement effectué", "Compte activé", "Carte bientôt expirée", "Nouveau relevé disponible", "Alerte sécurité"];
  const notificationMessages = [
    "Votre virement de 250€ a été effectué avec succès", 
    "Votre compte épargne est maintenant actif", 
    "Votre carte va expirer le mois prochain", 
    "Votre relevé de compte est disponible", 
    "Connexion inhabituelle détectée"
  ];
  const notificationData = [];
  
  for (let i = 0; i < 5; i++) {
    notificationData.push({
      userId: user.id,
      title: notificationTitles[i],
      message: notificationMessages[i],
      type: notificationTypes[i],
      read: i < 2, // First 2 are read
    });
  }
  
  await db.insert(notifications).values(notificationData).returning();
  
  console.log("Sample data created successfully!");
}

// Run the seed function
seedDatabase()
  .then(() => process.exit(0))
  .catch(error => {
    console.error("Error seeding database:", error);
    process.exit(1);
  });