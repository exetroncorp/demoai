import Database from 'better-sqlite3';
import path from 'path';
import crypto from 'crypto';

// Create database connection
const dbPath = path.resolve('./data/neobank.db');
const db = new Database(dbPath);

// Helpers
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${hash}.${salt}`;
}

function generateIBAN() {
  const countryCode = "FR";
  const checkDigits = Math.floor(Math.random() * 90 + 10).toString();
  const bankCode = Math.floor(Math.random() * 90000 + 10000).toString();
  const branchCode = Math.floor(Math.random() * 90000 + 10000).toString();
  const accountNumber = Math.floor(Math.random() * 90000000000 + 10000000000).toString();
  return `${countryCode}${checkDigits}${bankCode}${branchCode}${accountNumber}`;
}

function generateBIC() {
  const bankCode = ["BNPA", "SOGT", "CMBT", "AGFB", "CRCF"][Math.floor(Math.random() * 5)];
  const countryCode = "FR";
  const locationCode = ["PP", "PR", "PL", "PC"][Math.floor(Math.random() * 4)];
  const branchCode = Math.floor(Math.random() * 900 + 100).toString();
  return `${bankCode}${countryCode}${locationCode}${branchCode}`;
}

function generateCardNumber() {
  const prefix = ["4", "5"][Math.floor(Math.random() * 2)]; // 4 for Visa, 5 for Mastercard
  let number = prefix;
  for (let i = 0; i < 15; i++) {
    number += Math.floor(Math.random() * 10);
  }
  return `${number.slice(0, 4)}****${number.slice(-4)}`;
}

function generateExpiryDate() {
  const month = Math.floor(Math.random() * 12 + 1)
    .toString()
    .padStart(2, "0");
  const year = (new Date().getFullYear() + Math.floor(Math.random() * 5 + 1))
    .toString()
    .slice(-2);
  return `${month}/${year}`;
}

function generateCVV() {
  return Math.floor(Math.random() * 900 + 100).toString();
}

// Seeding function
function seedDatabase() {
  console.log("Checking if default user exists...");
  
  // Check if user already exists
  const existingUser = db.prepare("SELECT * FROM users WHERE username = ?").get("zoubida");
  
  if (existingUser) {
    console.log("Default user already exists, skipping seed data creation");
    return;
  }
  
  console.log("Creating default user and sample data...");

  // Start a transaction
  db.exec("BEGIN TRANSACTION;");
  
  try {
    // Insert default user
    const userInsert = db.prepare(`
      INSERT INTO users (username, password, first_name, last_name, email)
      VALUES (?, ?, ?, ?, ?);
    `);
    
    userInsert.run("zoubida", hashPassword("zoubida21"), "Zoubida", "Benarbia", "zoubida@example.com");
    const userId = db.prepare("SELECT last_insert_rowid() as id").get().id;
    
    console.log("Created user with ID:", userId);
    
    // Insert sample accounts
    const accountTypes = ["CURRENT", "SAVINGS", "TERM"];
    const accountNames = ["Compte Courant", "Compte Épargne", "Compte à Terme"];
    const accountIds = [];
    
    const accountInsert = db.prepare(`
      INSERT INTO accounts (user_id, name, type, iban, bic, balance, status)
      VALUES (?, ?, ?, ?, ?, ?, ?);
    `);
    
    for (let i = 0; i < 3; i++) {
      const balance = Math.floor(Math.random() * 10000 + 1000) * 100 / 100;
      accountInsert.run(
        userId,
        accountNames[i],
        accountTypes[i],
        generateIBAN(),
        generateBIC(),
        balance,
        "ACTIVE"
      );
      
      accountIds.push(db.prepare("SELECT last_insert_rowid() as id").get().id);
    }
    
    console.log("Created accounts with IDs:", accountIds);
    
    // Insert sample cards
    const cardTypes = ["MASTERCARD", "VISA"];
    const cardNetworks = ["MASTERCARD", "VISA"];
    
    const cardInsert = db.prepare(`
      INSERT INTO cards (user_id, account_id, type, masked_number, cardholder_name, expiry_date, cvv, network, "limit", account_name, blocked, online_payments_enabled, foreign_payments_enabled, contactless_enabled)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    `);
    
    for (let i = 0; i < 2; i++) {
      cardInsert.run(
        userId,
        accountIds[0], // Associate with current account
        cardTypes[i],
        generateCardNumber(),
        "Zoubida Benarbia",
        generateExpiryDate(),
        generateCVV(),
        cardNetworks[i],
        3000,
        accountNames[0],
        0, // not blocked
        1, // online payments enabled
        i, // foreign payments enabled only for the second card
        1  // contactless enabled
      );
    }
    
    console.log("Created cards");
    
    // Insert sample transactions
    const transactionCategories = ["FOOD", "INCOME", "HOUSING", "TELECOM", "RESTAURANT", "TRANSPORT", "TRAVEL", "HEALTH", "EDUCATION", "SHOPPING", "OTHER"];
    const transactionDescriptions = [
      "Supermarché Carrefour", 
      "Salaire", 
      "Loyer Appartement", 
      "Facture Internet", 
      "Restaurant Le Bistrot", 
      "SNCF Billet", 
      "Agence de Voyage", 
      "Pharmacie", 
      "Frais Universitaires", 
      "Amazon", 
      "Virement"
    ];
    
    const transactionInsert = db.prepare(`
      INSERT INTO transactions (account_id, user_id, amount, description, reference, category, type, date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?);
    `);
    
    // Generate 20 random transactions for the current account
    for (let i = 0; i < 20; i++) {
      const categoryIndex = Math.floor(Math.random() * transactionCategories.length);
      const isCredit = categoryIndex === 1; // INCOME category is CREDIT type
      const type = isCredit ? "CREDIT" : "DEBIT";
      
      const amount = Math.floor(Math.random() * 500 + 10) * 100 / 100;
      
      // Date between 1 and 30 days ago
      const date = new Date();
      date.setDate(date.getDate() - Math.floor(Math.random() * 30));
      
      transactionInsert.run(
        accountIds[0],
        userId,
        isCredit ? amount : -amount,
        transactionDescriptions[categoryIndex],
        `REF${Math.floor(Math.random() * 1000000)}`,
        transactionCategories[categoryIndex],
        type,
        date.toISOString()
      );
    }
    
    console.log("Created transactions");
    
    // Insert sample documents
    const documentTypes = ["RIB", "STATEMENT", "CONTRACT", "OTHER"];
    const documentNames = ["Relevé d'Identité Bancaire", "Relevé de Compte Mars 2023", "Contrat Carte Bancaire", "Mandat SEPA"];
    
    const documentInsert = db.prepare(`
      INSERT INTO documents (user_id, account_id, name, type, url, account_name)
      VALUES (?, ?, ?, ?, ?, ?);
    `);
    
    for (let i = 0; i < 4; i++) {
      documentInsert.run(
        userId,
        accountIds[i % 3],
        documentNames[i],
        documentTypes[i],
        `/documents/document_${i+1}.pdf`,
        accountNames[i % 3]
      );
    }
    
    console.log("Created documents");
    
    // Insert sample notifications
    const notificationTypes = ["TRANSFER", "ACCOUNT", "CARD", "DOCUMENT", "OTHER"];
    const notificationTitles = ["Virement effectué", "Compte activé", "Carte bientôt expirée", "Nouveau relevé disponible", "Alerte sécurité"];
    const notificationMessages = [
      "Votre virement de 250€ a été effectué avec succès", 
      "Votre compte épargne est maintenant actif", 
      "Votre carte va expirer le mois prochain", 
      "Votre relevé de compte est disponible", 
      "Connexion inhabituelle détectée"
    ];
    
    const notificationInsert = db.prepare(`
      INSERT INTO notifications (user_id, title, message, type, read)
      VALUES (?, ?, ?, ?, ?);
    `);
    
    for (let i = 0; i < 5; i++) {
      notificationInsert.run(
        userId,
        notificationTitles[i],
        notificationMessages[i],
        notificationTypes[i],
        i < 2 ? 1 : 0 // First 2 are read
      );
    }
    
    console.log("Created notifications");
    
    // Commit transaction
    db.exec("COMMIT;");
    console.log("Sample data created successfully!");
  
  } catch (error) {
    // Rollback on error
    db.exec("ROLLBACK;");
    console.error("Error seeding database:", error);
    process.exit(1);
  }
}

// Run the seed function
seedDatabase();