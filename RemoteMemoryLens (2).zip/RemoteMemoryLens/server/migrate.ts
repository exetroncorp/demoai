import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import { db } from "./db";

// This script pushes the schema to the SQLite database
async function main() {
  console.log("Migrating database...");
  
  // Apply migrations - this will create the tables based on our schema
  await migrate(db, { migrationsFolder: "./migrations" });
  
  console.log("Database migration complete");
}

main().catch((e) => {
  console.error("Migration failed");
  console.error(e);
  process.exit(1);
});