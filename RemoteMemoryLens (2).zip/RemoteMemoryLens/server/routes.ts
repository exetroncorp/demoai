import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertAccountSchema, 
  insertTransferSchema,
  InsertAccount, 
  InsertTransfer
} from "@shared/schema";
import { z } from "zod";
import fs from 'fs';
import path from 'path';

// Middleware to ensure user is authenticated
function isAuthenticated(req: Request, res: Response, next: any) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Non authentifié" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Account routes
  app.get("/api/accounts", isAuthenticated, async (req, res) => {
    const userId = req.user!.id;
    const accounts = await storage.getAccounts(userId);
    res.json(accounts);
  });

  app.get("/api/accounts/:id", isAuthenticated, async (req, res) => {
    const accountId = parseInt(req.params.id);
    const account = await storage.getAccount(accountId);
    
    if (!account) {
      return res.status(404).json({ message: "Compte non trouvé" });
    }
    
    if (account.userId !== req.user!.id) {
      return res.status(403).json({ message: "Accès non autorisé" });
    }
    
    res.json(account);
  });

  app.post("/api/accounts", isAuthenticated, async (req, res) => {
    try {
      const parsedData = insertAccountSchema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ message: "Données invalides" });
      }
      
      const userId = req.user!.id;
      const accountData: InsertAccount = parsedData.data;
      
      const account = await storage.createAccount(userId, accountData);
      res.status(201).json(account);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la création du compte" });
    }
  });

  // Transaction routes
  app.get("/api/transactions", isAuthenticated, async (req, res) => {
    const userId = req.user!.id;
    const accountId = req.query.accountId ? parseInt(req.query.accountId as string) : undefined;
    
    const transactions = await storage.getTransactions(userId, accountId);
    res.json(transactions);
  });

  // Card routes
  app.get("/api/cards", isAuthenticated, async (req, res) => {
    const userId = req.user!.id;
    const cards = await storage.getCards(userId);
    res.json(cards);
  });

  app.patch("/api/cards/:id", isAuthenticated, async (req, res) => {
    const cardId = parseInt(req.params.id);
    const card = await storage.getCard(cardId);
    
    if (!card) {
      return res.status(404).json({ message: "Carte non trouvée" });
    }
    
    if (card.userId !== req.user!.id) {
      return res.status(403).json({ message: "Accès non autorisé" });
    }
    
    const updateSchema = z.object({
      blocked: z.boolean().optional(),
      onlinePaymentsEnabled: z.boolean().optional(),
      foreignPaymentsEnabled: z.boolean().optional(),
      contactlessEnabled: z.boolean().optional(),
    });
    
    const parsedData = updateSchema.safeParse(req.body);
    if (!parsedData.success) {
      return res.status(400).json({ message: "Données invalides" });
    }
    
    const updatedCard = await storage.updateCard(cardId, parsedData.data);
    res.json(updatedCard);
  });

  // Document routes
  app.get("/api/documents", isAuthenticated, async (req, res) => {
    const userId = req.user!.id;
    const documents = await storage.getDocuments(userId);
    res.json(documents);
  });

  app.post("/api/documents/generate", isAuthenticated, async (req, res) => {
    try {
      const generateSchema = z.object({
        type: z.enum(["RIB", "STATEMENT", "CONTRACT", "OTHER"]),
        accountId: z.number(),
      });
      
      const parsedData = generateSchema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ message: "Données invalides" });
      }
      
      const { type, accountId } = parsedData.data;
      const userId = req.user!.id;
      
      const account = await storage.getAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "Compte non trouvé" });
      }
      
      if (account.userId !== userId) {
        return res.status(403).json({ message: "Accès non autorisé" });
      }
      
      const documentName = type === "RIB" 
        ? `RIB - ${account.name}`
        : type === "STATEMENT"
        ? `Relevé - ${account.name} - ${new Date().toLocaleDateString("fr-FR")}`
        : `Document - ${account.name} - ${new Date().toLocaleDateString("fr-FR")}`;
      
      const document = await storage.createDocument({
        userId,
        accountId,
        name: documentName,
        type,
        url: `/documents/${type.toLowerCase()}_${accountId}_${Date.now()}.pdf`,
        accountName: account.name,
      });
      
      res.status(201).json(document);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la génération du document" });
    }
  });

  // Transfer routes
  app.get("/api/transfers", isAuthenticated, async (req, res) => {
    const userId = req.user!.id;
    const transfers = await storage.getTransfers(userId);
    res.json(transfers);
  });

  app.post("/api/transfers", isAuthenticated, async (req, res) => {
    try {
      const parsedData = insertTransferSchema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ message: "Données invalides" });
      }
      
      const userId = req.user!.id;
      const transferData: InsertTransfer = parsedData.data;
      
      // Validate account ownership
      const account = await storage.getAccount(transferData.fromAccountId);
      if (!account) {
        return res.status(404).json({ message: "Compte non trouvé" });
      }
      
      if (account.userId !== userId) {
        return res.status(403).json({ message: "Accès non autorisé" });
      }
      
      // Check for sufficient funds
      if (account.balance < transferData.amount) {
        return res.status(400).json({ message: "Fonds insuffisants" });
      }
      
      const transfer = await storage.createTransfer(userId, transferData);
      res.status(201).json(transfer);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la création du virement" });
    }
  });

  // Notification routes
  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    const userId = req.user!.id;
    const notifications = await storage.getNotifications(userId);
    res.json(notifications);
  });

  app.patch("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    const notificationId = parseInt(req.params.id);
    const notification = await storage.getNotification(notificationId);
    
    if (!notification) {
      return res.status(404).json({ message: "Notification non trouvée" });
    }
    
    if (notification.userId !== req.user!.id) {
      return res.status(403).json({ message: "Accès non autorisé" });
    }
    
    const updatedNotification = await storage.markNotificationAsRead(notificationId);
    res.json(updatedNotification);
  });

  app.post("/api/notifications/mark-all-read", isAuthenticated, async (req, res) => {
    const userId = req.user!.id;
    await storage.markAllNotificationsAsRead(userId);
    res.sendStatus(200);
  });

  // Theme routes
  app.post("/api/theme", async (req, res) => {
    try {
      const themeSchema = z.object({
        appearance: z.enum(["light", "dark"]),
        variant: z.enum(["professional", "tint", "vibrant"]).optional(),
        primary: z.string().optional(),
        radius: z.number().optional(),
      });
      
      const parsedData = themeSchema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ message: "Données de thème invalides" });
      }
      
      const themeFilePath = path.resolve('./theme.json');
      
      // Lire le fichier theme.json actuel
      const currentTheme = JSON.parse(fs.readFileSync(themeFilePath, 'utf-8'));
      
      // Mettre à jour le thème avec les nouvelles valeurs
      const updatedTheme = {
        ...currentTheme,
        ...parsedData.data
      };
      
      // Écrire le thème mis à jour
      fs.writeFileSync(themeFilePath, JSON.stringify(updatedTheme, null, 2));
      
      res.json(updatedTheme);
    } catch (error) {
      console.error('Erreur lors de la mise à jour du thème:', error);
      res.status(500).json({ message: "Erreur lors de la mise à jour du thème" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
