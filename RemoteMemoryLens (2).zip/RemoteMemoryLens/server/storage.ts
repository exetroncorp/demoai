import { 
  User, InsertUser, Account, InsertAccount, Transaction, InsertTransaction,
  Card, InsertCard, Document, InsertDocument, Transfer, InsertTransfer,
  Notification, InsertNotification,
  users, accounts, transactions, cards, documents, transfers, notifications
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import { randomBytes } from "crypto";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);

function generateIBAN() {
  // Generate a mock French IBAN (FR + 2 check digits + 23 digits)
  const countryCode = 'FR';
  const checkDigits = Math.floor(Math.random() * 90 + 10).toString();
  const bankCode = Math.floor(Math.random() * 90000 + 10000).toString();
  const branchCode = Math.floor(Math.random() * 90000 + 10000).toString();
  const accountNumber = randomBytes(9).toString('hex').slice(0, 11).toUpperCase();
  
  return `${countryCode}${checkDigits}${bankCode}${branchCode}${accountNumber}`;
}

function generateBIC() {
  // Generate a mock BIC (Bank Identifier Code)
  const bankCode = ['BNPA', 'SOGE', 'CMCI', 'AGRI', 'BARC'][Math.floor(Math.random() * 5)];
  const countryCode = 'FR';
  const locationCode = ['PP', 'MM', 'TT'][Math.floor(Math.random() * 3)];
  const branchCode = ['XXX', Math.floor(Math.random() * 900 + 100).toString()][Math.floor(Math.random() * 2)];
  
  return `${bankCode}${countryCode}${locationCode}${branchCode}`;
}

export interface IStorage {
  // Session store
  sessionStore: session.Store;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastLogin(id: number): Promise<User | undefined>;
  
  // Account methods
  getAccounts(userId: number): Promise<Account[]>;
  getAccount(id: number): Promise<Account | undefined>;
  createAccount(userId: number, account: InsertAccount): Promise<Account>;
  updateAccount(id: number, data: Partial<Account>): Promise<Account | undefined>;
  
  // Transaction methods
  getTransactions(userId: number, accountId?: number): Promise<Transaction[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Card methods
  getCards(userId: number): Promise<Card[]>;
  getCard(id: number): Promise<Card | undefined>;
  createCard(card: InsertCard): Promise<Card>;
  updateCard(id: number, data: Partial<Card>): Promise<Card | undefined>;
  
  // Document methods
  getDocuments(userId: number): Promise<Document[]>;
  getDocument(id: number): Promise<Document | undefined>;
  createDocument(document: InsertDocument): Promise<Document>;
  
  // Transfer methods
  getTransfers(userId: number): Promise<Transfer[]>;
  getTransfer(id: number): Promise<Transfer | undefined>;
  createTransfer(userId: number, transfer: InsertTransfer): Promise<Transfer>;
  
  // Notification methods
  getNotifications(userId: number): Promise<Notification[]>;
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  markAllNotificationsAsRead(userId: number): Promise<void>;
}

// SQLite storage implementation
export class SQLiteStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    // Create tables if they don't exist
    this.initDatabase();
  }
  
  private async initDatabase() {
    // The tables will be created automatically by Drizzle ORM
    // We can perform any additional initialization if needed
  }

  async getUser(id: number): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.username, username));
    return results.length > 0 ? results[0] : undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const results = await db.insert(users).values({
      ...userData,
      createdAt: new Date().toISOString(),
      lastLogin: null
    }).returning();
    return results[0];
  }

  async updateUserLastLogin(id: number): Promise<User | undefined> {
    const results = await db.update(users)
      .set({ lastLogin: new Date().toISOString() })
      .where(eq(users.id, id))
      .returning();
    return results.length > 0 ? results[0] : undefined;
  }

  async getAccounts(userId: number): Promise<Account[]> {
    return await db.select().from(accounts).where(eq(accounts.userId, userId));
  }

  async getAccount(id: number): Promise<Account | undefined> {
    const results = await db.select().from(accounts).where(eq(accounts.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async createAccount(userId: number, accountData: InsertAccount): Promise<Account> {
    const newAccount = {
      ...accountData,
      userId,
      iban: generateIBAN(),
      bic: generateBIC(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const results = await db.insert(accounts).values(newAccount).returning();
    const account = results[0];
    
    // Create a notification for the new account
    await this.createNotification({
      userId,
      title: "Nouveau compte créé",
      message: `Votre compte ${account.name} a été créé avec succès.`,
      type: "ACCOUNT",
      read: false,
    });
    
    return account;
  }

  async updateAccount(id: number, data: Partial<Account>): Promise<Account | undefined> {
    const results = await db.update(accounts)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(accounts.id, id))
      .returning();
    return results.length > 0 ? results[0] : undefined;
  }

  async getTransactions(userId: number, accountId?: number): Promise<Transaction[]> {
    if (accountId !== undefined) {
      return await db.select().from(transactions)
        .where(and(
          eq(transactions.userId, userId),
          eq(transactions.accountId, accountId)
        ));
    }
    return await db.select().from(transactions).where(eq(transactions.userId, userId));
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    const results = await db.select().from(transactions).where(eq(transactions.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async createTransaction(transactionData: InsertTransaction): Promise<Transaction> {
    const newTransaction = {
      ...transactionData,
      createdAt: new Date().toISOString(),
    };
    
    const results = await db.insert(transactions).values(newTransaction).returning();
    const transaction = results[0];
    
    // Update account balance
    const account = await this.getAccount(transaction.accountId);
    if (account) {
      const currentBalance = parseFloat(account.balance.toString());
      const amount = parseFloat(transaction.amount.toString());
      const newBalance = (transaction.type === "CREDIT") 
        ? currentBalance + amount 
        : currentBalance - amount;
      
      await this.updateAccount(account.id, { balance: newBalance });
      
      // Create a notification for the transaction
      await this.createNotification({
        userId: transaction.userId,
        title: "Nouvelle transaction",
        message: `Une transaction de ${transaction.amount}€ a été ${transaction.type === "CREDIT" ? "créditée" : "débitée"} de votre compte.`,
        type: "TRANSACTION",
        read: false,
      });
    }
    
    return transaction;
  }

  async getCards(userId: number): Promise<Card[]> {
    return await db.select().from(cards).where(eq(cards.userId, userId));
  }

  async getCard(id: number): Promise<Card | undefined> {
    const results = await db.select().from(cards).where(eq(cards.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async createCard(cardData: InsertCard): Promise<Card> {
    const newCard = {
      ...cardData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const results = await db.insert(cards).values(newCard).returning();
    const card = results[0];
    
    // Create a notification for the new card
    await this.createNotification({
      userId: card.userId,
      title: "Nouvelle carte créée",
      message: `Votre carte se terminant par ${card.maskedNumber.slice(-4)} a été créée.`,
      type: "CARD",
      read: false,
    });
    
    return card;
  }

  async updateCard(id: number, data: Partial<Card>): Promise<Card | undefined> {
    const results = await db.update(cards)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(cards.id, id))
      .returning();
    return results.length > 0 ? results[0] : undefined;
  }

  async getDocuments(userId: number): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.userId, userId));
  }

  async getDocument(id: number): Promise<Document | undefined> {
    const results = await db.select().from(documents).where(eq(documents.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async createDocument(documentData: InsertDocument): Promise<Document> {
    const newDocument = {
      ...documentData,
      createdAt: new Date().toISOString(),
    };
    
    const results = await db.insert(documents).values(newDocument).returning();
    const document = results[0];
    
    // Create a notification for the new document
    await this.createNotification({
      userId: document.userId,
      title: "Nouveau document disponible",
      message: `Un document de type ${document.type.toLowerCase()} est maintenant disponible.`,
      type: "DOCUMENT",
      read: false,
    });
    
    return document;
  }

  async getTransfers(userId: number): Promise<Transfer[]> {
    return await db.select().from(transfers).where(eq(transfers.userId, userId));
  }

  async getTransfer(id: number): Promise<Transfer | undefined> {
    const results = await db.select().from(transfers).where(eq(transfers.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async createTransfer(userId: number, transferData: InsertTransfer): Promise<Transfer> {
    const newTransfer = {
      ...transferData,
      userId,
      status: "COMPLETED", // For simplicity, transfers are always completed
      date: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };
    
    const results = await db.insert(transfers).values(newTransfer).returning();
    const transfer = results[0];
    
    // Create a transaction for source account (debit)
    await this.createTransaction({
      userId,
      accountId: transfer.fromAccountId,
      amount: transfer.amount,
      type: "DEBIT",
      description: `Virement vers ${transfer.beneficiaryName}`,
      category: "TRANSFER",
      date: transfer.date,
    });
    
    // Create a notification for the transfer
    await this.createNotification({
      userId,
      title: "Virement effectué",
      message: `Votre virement de ${transfer.amount}€ vers ${transfer.beneficiaryName} a été effectué.`,
      type: "TRANSFER",
      read: false,
    });
    
    return transfer;
  }

  async getNotifications(userId: number): Promise<Notification[]> {
    return await db.select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async getNotification(id: number): Promise<Notification | undefined> {
    const results = await db.select().from(notifications).where(eq(notifications.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const newNotification = {
      ...notificationData,
      createdAt: new Date().toISOString(),
    };
    
    const results = await db.insert(notifications).values(newNotification).returning();
    return results[0];
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const results = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    return results.length > 0 ? results[0] : undefined;
  }

  async markAllNotificationsAsRead(userId: number): Promise<void> {
    await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.userId, userId));
  }
}

export const storage = new SQLiteStorage();