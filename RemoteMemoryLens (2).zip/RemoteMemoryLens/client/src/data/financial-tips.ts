// Banque de conseils financiers pour les différentes sections de l'application
export type FinancialTipCategory = 
  | 'dashboard' 
  | 'accounts' 
  | 'transfers' 
  | 'cards' 
  | 'budget' 
  | 'savings' 
  | 'investments'
  | 'security'
  | 'general';

export interface FinancialTip {
  id: string;
  content: string;
  category: FinancialTipCategory;
  mascot?: 'panda' | 'fox' | 'owl';
  level?: 'beginner' | 'intermediate' | 'advanced';
}

export const financialTips: FinancialTip[] = [
  // Tableau de bord
  {
    id: 'dashboard-1',
    content: "Votre tableau de bord vous offre une vue d'ensemble de vos finances. Consultez-le régulièrement pour rester informé de vos mouvements bancaires.",
    category: 'dashboard',
    mascot: 'panda',
    level: 'beginner'
  },
  {
    id: 'dashboard-2',
    content: "Les graphiques montrent l'évolution de vos dépenses. Identifiez les périodes où vous dépensez le plus pour mieux planifier votre budget.",
    category: 'dashboard',
    mascot: 'owl',
    level: 'intermediate'
  },

  // Comptes
  {
    id: 'accounts-1',
    content: "Savez-vous que vous pouvez avoir plusieurs comptes avec des objectifs différents ? Un compte pour les dépenses courantes, un autre pour les projets, etc.",
    category: 'accounts',
    mascot: 'fox',
    level: 'beginner'
  },
  {
    id: 'accounts-2',
    content: "Vérifiez régulièrement les mouvements sur vos comptes pour détecter rapidement toute opération inhabituelle.",
    category: 'accounts',
    mascot: 'owl',
    level: 'beginner'
  },
  {
    id: 'accounts-3',
    content: "Avoir un fond d'urgence équivalent à 3-6 mois de dépenses est recommandé pour faire face aux imprévus.",
    category: 'accounts',
    mascot: 'panda',
    level: 'intermediate'
  },

  // Virements
  {
    id: 'transfers-1',
    content: "Utilisez les virements programmés pour automatiser vos paiements récurrents et ne jamais rater une échéance.",
    category: 'transfers',
    mascot: 'fox',
    level: 'beginner'
  },
  {
    id: 'transfers-2',
    content: "Pensez à vérifier deux fois les coordonnées bancaires avant d'effectuer un virement, surtout pour un nouveau bénéficiaire.",
    category: 'transfers',
    mascot: 'owl',
    level: 'beginner'
  },
  {
    id: 'transfers-3',
    content: "Programmez un virement automatique vers votre compte épargne le jour de votre salaire pour économiser sans y penser.",
    category: 'transfers',
    mascot: 'panda',
    level: 'intermediate'
  },

  // Cartes
  {
    id: 'cards-1',
    content: "Désactivez les paiements à l'étranger quand vous n'en avez pas besoin pour renforcer la sécurité de votre carte.",
    category: 'cards',
    mascot: 'owl',
    level: 'beginner'
  },
  {
    id: 'cards-2',
    content: "Vous pouvez bloquer temporairement votre carte en cas de perte, puis la débloquer si vous la retrouvez.",
    category: 'cards',
    mascot: 'fox',
    level: 'beginner'
  },
  {
    id: 'cards-3',
    content: "Ajustez vos plafonds de paiement et de retrait selon vos besoins réels pour limiter les risques en cas de fraude.",
    category: 'cards',
    mascot: 'panda',
    level: 'intermediate'
  },

  // Budget
  {
    id: 'budget-1',
    content: "La règle 50/30/20 peut vous aider : 50% pour les besoins essentiels, 30% pour les envies, 20% pour l'épargne.",
    category: 'budget',
    mascot: 'owl',
    level: 'beginner'
  },
  {
    id: 'budget-2',
    content: "Catégoriser vos dépenses vous permet d'identifier facilement où votre argent est dépensé et où vous pouvez économiser.",
    category: 'budget',
    mascot: 'fox',
    level: 'intermediate'
  },

  // Épargne
  {
    id: 'savings-1',
    content: "Même une petite somme épargnée régulièrement peut devenir importante grâce aux intérêts composés.",
    category: 'savings',
    mascot: 'panda',
    level: 'beginner'
  },
  {
    id: 'savings-2',
    content: "Fixez-vous des objectifs d'épargne spécifiques, mesurables et temporels pour rester motivé.",
    category: 'savings',
    mascot: 'fox',
    level: 'intermediate'
  },

  // Investissements
  {
    id: 'investments-1',
    content: "Diversifier vos investissements aide à réduire les risques face aux fluctuations des marchés.",
    category: 'investments',
    mascot: 'owl',
    level: 'intermediate'
  },
  {
    id: 'investments-2',
    content: "Le meilleur moment pour commencer à investir était hier, le deuxième meilleur moment est aujourd'hui !",
    category: 'investments',
    mascot: 'fox',
    level: 'beginner'
  },

  // Sécurité
  {
    id: 'security-1',
    content: "Ne partagez jamais vos identifiants bancaires, même avec votre banque. Nous ne vous les demanderons jamais par email ou téléphone.",
    category: 'security',
    mascot: 'owl',
    level: 'beginner'
  },
  {
    id: 'security-2',
    content: "Changez régulièrement votre mot de passe et utilisez l'authentification à deux facteurs pour une sécurité renforcée.",
    category: 'security',
    mascot: 'fox',
    level: 'beginner'
  },

  // Général
  {
    id: 'general-1',
    content: "Besoin d'aide ? Notre service client est disponible 24/7 pour répondre à vos questions.",
    category: 'general',
    mascot: 'panda',
    level: 'beginner'
  },
  {
    id: 'general-2',
    content: "Prenez l'habitude de consulter votre application bancaire régulièrement pour garder le contrôle sur vos finances.",
    category: 'general',
    mascot: 'fox',
    level: 'beginner'
  }
];

// Fonction utilitaire pour obtenir un conseil aléatoire pour une catégorie donnée
export function getRandomTip(category: FinancialTipCategory): FinancialTip {
  const categoryTips = financialTips.filter(tip => tip.category === category);
  const randomIndex = Math.floor(Math.random() * categoryTips.length);
  return categoryTips[randomIndex];
}

// Fonction pour obtenir un conseil spécifique par ID
export function getTipById(id: string): FinancialTip | undefined {
  return financialTips.find(tip => tip.id === id);
}

// Fonction pour obtenir tous les conseils d'une catégorie
export function getTipsByCategory(category: FinancialTipCategory): FinancialTip[] {
  return financialTips.filter(tip => tip.category === category);
}