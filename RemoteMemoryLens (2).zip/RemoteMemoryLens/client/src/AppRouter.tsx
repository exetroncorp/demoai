import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import AccountsPage from "@/pages/accounts-page";
import TransfersPage from "@/pages/transfers-page";
import CardsPage from "@/pages/cards-page";
import DocumentsPage from "@/pages/documents-page";
import NotificationsPage from "@/pages/notifications-page";
import SettingsPage from "@/pages/settings-page";
import { useAuth } from "./hooks/use-auth";
import { Loader2 } from "lucide-react";

// A simpler protected route implementation
function ProtectedRouteWrapper({
  component: Component,
}: {
  component: () => React.JSX.Element;
}) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/auth");
      return;
    }
  }, [isLoading, user]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return <Component />;
}

export default function AppRouter() {
  return (
    <Switch>
      <Route path="/auth">
        <AuthPage />
      </Route>
      <Route path="/">
        <ProtectedRouteWrapper component={DashboardPage} />
      </Route>
      <Route path="/accounts">
        <ProtectedRouteWrapper component={AccountsPage} />
      </Route>
      <Route path="/transfers">
        <ProtectedRouteWrapper component={TransfersPage} />
      </Route>
      <Route path="/cards">
        <ProtectedRouteWrapper component={CardsPage} />
      </Route>
      <Route path="/documents">
        <ProtectedRouteWrapper component={DocumentsPage} />
      </Route>
      <Route path="/notifications">
        <ProtectedRouteWrapper component={NotificationsPage} />
      </Route>
      <Route path="/settings">
        <ProtectedRouteWrapper component={SettingsPage} />
      </Route>
      <Route>
        <NotFound />
      </Route>
    </Switch>
  );
}