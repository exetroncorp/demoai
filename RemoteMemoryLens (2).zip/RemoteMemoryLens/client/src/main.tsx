import React, { useEffect } from "react";
import { createRoot } from "react-dom/client";
import AuthApp from "./AuthApp";
import "./index.css";

// Fonction pour appliquer le thème initial
function applyTheme() {
  // Vérifier si un thème est déjà stocké dans le localStorage
  const savedTheme = localStorage.getItem('theme');
  
  // Si un thème est stocké, l'appliquer
  if (savedTheme === 'dark') {
    document.documentElement.classList.add('dark');
    document.documentElement.style.colorScheme = 'dark';
  } else if (savedTheme === 'light') {
    document.documentElement.classList.remove('dark');
    document.documentElement.style.colorScheme = 'light';
  } else {
    // Si aucun thème n'est stocké, utiliser le thème sombre par défaut
    localStorage.setItem('theme', 'dark');
    document.documentElement.classList.add('dark');
    document.documentElement.style.colorScheme = 'dark';
  }
}

// Appliquer le thème avant le rendu
applyTheme();

// Composant wrapper pour gérer les effets globaux
function App() {
  return <AuthApp />;
}

// Render with all providers handled by AuthApp
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
