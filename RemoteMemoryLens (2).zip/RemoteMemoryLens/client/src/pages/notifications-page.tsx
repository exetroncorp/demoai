import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import DashboardLayout from "@/components/layout/dashboard-layout";
import { Notification } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Bell, Check, MailOpen, CreditCard, FileText, Wallet, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export default function NotificationsPage() {
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState<"all" | "unread">("all");
  
  const { data: notifications, isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });
  
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const res = await apiRequest("PATCH", `/api/notifications/${notificationId}/read`, {});
      return await res.json() as Notification;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/notifications/mark-all-read", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      toast({
        title: "Succès",
        description: "Toutes les notifications ont été marquées comme lues.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleMarkAsRead = (notificationId: number) => {
    markAsReadMutation.mutate(notificationId);
  };
  
  const handleMarkAllAsRead = () => {
    markAllAsReadMutation.mutate();
  };
  
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "TRANSFER":
        return <ExternalLink className="h-5 w-5 text-blue-500" />;
      case "ACCOUNT":
        return <Wallet className="h-5 w-5 text-green-500" />;
      case "CARD":
        return <CreditCard className="h-5 w-5 text-purple-500" />;
      case "DOCUMENT":
        return <FileText className="h-5 w-5 text-red-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      const hours = Math.floor(diffTime / (1000 * 60 * 60));
      if (hours === 0) {
        const minutes = Math.floor(diffTime / (1000 * 60));
        return `Il y a ${minutes} minute${minutes > 1 ? 's' : ''}`;
      }
      return `Il y a ${hours} heure${hours > 1 ? 's' : ''}`;
    } else if (diffDays === 1) {
      return "Hier";
    } else if (diffDays < 7) {
      return `Il y a ${diffDays} jour${diffDays > 1 ? 's' : ''}`;
    } else {
      return date.toLocaleDateString("fr-FR");
    }
  };
  
  const unreadCount = notifications?.filter(n => !n.read).length || 0;
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Notifications</h1>
            <p className="text-gray-500 text-sm mt-1">
              Restez informé des activités de votre compte
            </p>
          </div>
          {unreadCount > 0 && (
            <Button onClick={handleMarkAllAsRead} disabled={markAllAsReadMutation.isPending}>
              {markAllAsReadMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <MailOpen className="mr-2 h-4 w-4" />
              )}
              Tout marquer comme lu
            </Button>
          )}
        </div>

        <Tabs defaultValue="all" value={selectedTab} onValueChange={(v) => setSelectedTab(v as "all" | "unread")}>
          <TabsList className="mb-6">
            <TabsTrigger value="all">Toutes</TabsTrigger>
            <TabsTrigger value="unread" className="relative">
              Non lues
              {unreadCount > 0 && (
                <Badge className="ml-2 bg-primary text-white">{unreadCount}</Badge>
              )}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            {isLoading ? (
              <div className="flex justify-center p-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : notifications && notifications.length > 0 ? (
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <Card 
                    key={notification.id}
                    className={cn(
                      "border-l-4",
                      notification.read 
                        ? "border-l-gray-200" 
                        : notification.type === "TRANSFER" 
                        ? "border-l-blue-500" 
                        : notification.type === "ACCOUNT" 
                        ? "border-l-green-500"
                        : notification.type === "CARD"
                        ? "border-l-purple-500"
                        : notification.type === "DOCUMENT"
                        ? "border-l-red-500"
                        : "border-l-primary"
                    )}
                  >
                    <CardHeader className="py-4 px-6">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center">
                          <div className={cn(
                            "rounded-full p-2 mr-4",
                            notification.type === "TRANSFER" ? "bg-blue-100" :
                            notification.type === "ACCOUNT" ? "bg-green-100" :
                            notification.type === "CARD" ? "bg-purple-100" :
                            notification.type === "DOCUMENT" ? "bg-red-100" :
                            "bg-gray-100"
                          )}>
                            {getNotificationIcon(notification.type)}
                          </div>
                          <div>
                            <CardTitle className="text-base font-medium">{notification.title}</CardTitle>
                            <CardDescription>{formatDate(notification.createdAt)}</CardDescription>
                          </div>
                        </div>
                        {!notification.read && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleMarkAsRead(notification.id)}
                            disabled={markAsReadMutation.isPending}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="py-0 px-6">
                      <p className="text-gray-700">{notification.message}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="bg-gray-100 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
                  <Bell className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune notification</h3>
                <p className="text-gray-500">Vous n'avez pas encore reçu de notifications.</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="unread">
            {isLoading ? (
              <div className="flex justify-center p-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : notifications && notifications.filter(n => !n.read).length > 0 ? (
              <div className="space-y-4">
                {notifications
                  .filter(notification => !notification.read)
                  .map((notification) => (
                    <Card 
                      key={notification.id}
                      className={cn(
                        "border-l-4",
                        notification.type === "TRANSFER" ? "border-l-blue-500" :
                        notification.type === "ACCOUNT" ? "border-l-green-500" :
                        notification.type === "CARD" ? "border-l-purple-500" :
                        notification.type === "DOCUMENT" ? "border-l-red-500" :
                        "border-l-primary"
                      )}
                    >
                      <CardHeader className="py-4 px-6">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center">
                            <div className={cn(
                              "rounded-full p-2 mr-4",
                              notification.type === "TRANSFER" ? "bg-blue-100" :
                              notification.type === "ACCOUNT" ? "bg-green-100" :
                              notification.type === "CARD" ? "bg-purple-100" :
                              notification.type === "DOCUMENT" ? "bg-red-100" :
                              "bg-gray-100"
                            )}>
                              {getNotificationIcon(notification.type)}
                            </div>
                            <div>
                              <CardTitle className="text-base font-medium">{notification.title}</CardTitle>
                              <CardDescription>{formatDate(notification.createdAt)}</CardDescription>
                            </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleMarkAsRead(notification.id)}
                            disabled={markAsReadMutation.isPending}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="py-0 px-6">
                        <p className="text-gray-700">{notification.message}</p>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="bg-gray-100 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-4">
                  <MailOpen className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune notification non lue</h3>
                <p className="text-gray-500">Toutes vos notifications ont été lues.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
