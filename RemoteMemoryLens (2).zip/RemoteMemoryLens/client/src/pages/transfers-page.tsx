import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/components/layout/dashboard-layout";
import TransferForm from "@/components/transfers/transfer-form";
import { Transfer } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function TransfersPage() {
  const { data: transfers, isLoading } = useQuery<Transfer[]>({
    queryKey: ["/api/transfers"],
  });

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("fr-FR");
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case "COMPLETED":
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">Effectué</Badge>;
      case "PENDING":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">En cours</Badge>;
      case "FAILED":
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">Échoué</Badge>;
      default:
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">{status}</Badge>;
    }
  };
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Virements</h1>
        
        <Tabs defaultValue="new">
          <TabsList className="mb-6">
            <TabsTrigger value="new">Nouveau virement</TabsTrigger>
            <TabsTrigger value="history">Historique</TabsTrigger>
          </TabsList>
          
          <TabsContent value="new">
            <Card>
              <CardHeader>
                <CardTitle>Effectuer un virement</CardTitle>
                <CardDescription>
                  Remplissez les informations ci-dessous pour créer un nouveau virement SEPA.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <TransferForm />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Historique des virements</CardTitle>
                <CardDescription>
                  Consultez l'historique de vos virements effectués.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center p-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : transfers && transfers.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Bénéficiaire</TableHead>
                          <TableHead>Référence</TableHead>
                          <TableHead className="text-right">Montant</TableHead>
                          <TableHead>Statut</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {transfers.map((transfer) => (
                          <TableRow key={transfer.id}>
                            <TableCell className="font-medium">
                              {formatDate(transfer.date)}
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="font-medium">{transfer.beneficiaryName}</p>
                                <p className="text-xs text-gray-500">{transfer.toIBAN}</p>
                              </div>
                            </TableCell>
                            <TableCell>{transfer.reference || "-"}</TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(transfer.amount)}
                            </TableCell>
                            <TableCell>
                              {getStatusBadge(transfer.status)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun virement</h3>
                    <p className="text-gray-500">Vous n'avez pas encore effectué de virement.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
