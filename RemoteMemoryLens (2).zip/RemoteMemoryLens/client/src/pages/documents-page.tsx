import { useQuery, useMutation } from "@tanstack/react-query";
import DashboardLayout from "@/components/layout/dashboard-layout";
import { Document, Account } from "@shared/schema";
import { Loader2, Download, FileText } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState } from "react";
import { 
  Dialog,
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";

export default function DocumentsPage() {
  const { toast } = useToast();
  const [selectedAccount, setSelectedAccount] = useState<string>("");
  const [showRibDialog, setShowRibDialog] = useState(false);
  
  const { data: documents, isLoading: isLoadingDocuments } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });

  const { data: accounts, isLoading: isLoadingAccounts } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  });
  
  const generateDocumentMutation = useMutation({
    mutationFn: async ({ type, accountId }: { type: string; accountId: number }) => {
      const res = await apiRequest("POST", "/api/documents/generate", { type, accountId });
      return await res.json() as Document;
    },
    onSuccess: () => {
      toast({
        title: "Document généré",
        description: "Votre document a été généré avec succès.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("fr-FR");
  };
  
  const handleDownload = (documentId: number) => {
    // In a real implementation, this would trigger a document download
    window.open(`/api/documents/${documentId}/download`, '_blank');
  };
  
  const handleGenerateRib = () => {
    if (!selectedAccount) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un compte",
        variant: "destructive",
      });
      return;
    }
    
    generateDocumentMutation.mutate({ 
      type: "RIB",
      accountId: parseInt(selectedAccount)
    });
    setShowRibDialog(false);
  };
  
  const handleGenerateStatement = () => {
    if (!selectedAccount) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un compte",
        variant: "destructive",
      });
      return;
    }
    
    generateDocumentMutation.mutate({ 
      type: "STATEMENT",
      accountId: parseInt(selectedAccount)
    });
  };

  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Mes documents</h1>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowRibDialog(true)}>
              <FileText className="mr-2 h-4 w-4" />
              Générer RIB
            </Button>
            <Button variant="outline" onClick={handleGenerateStatement}>
              <FileText className="mr-2 h-4 w-4" />
              Relevé de compte
            </Button>
          </div>
        </div>
        
        {/* RIB Dialog */}
        <Dialog open={showRibDialog} onOpenChange={setShowRibDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Générer un RIB</DialogTitle>
              <DialogDescription>
                Veuillez sélectionner le compte pour lequel vous souhaitez générer un RIB.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label htmlFor="account" className="text-sm font-medium">
                  Compte
                </label>
                {isLoadingAccounts ? (
                  <div className="flex items-center">
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Chargement des comptes...
                  </div>
                ) : (
                  <Select
                    value={selectedAccount}
                    onValueChange={setSelectedAccount}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez un compte" />
                    </SelectTrigger>
                    <SelectContent>
                      {accounts?.map((account) => (
                        <SelectItem key={account.id} value={account.id.toString()}>
                          {account.name} - {account.iban}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowRibDialog(false)}>
                Annuler
              </Button>
              <Button 
                onClick={handleGenerateRib}
                disabled={generateDocumentMutation.isPending || !selectedAccount}
              >
                {generateDocumentMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <>
                    <FileText className="mr-2 h-4 w-4" />
                    Générer
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        <Tabs defaultValue="all">
          <TabsList className="mb-6">
            <TabsTrigger value="all">Tous les documents</TabsTrigger>
            <TabsTrigger value="statements">Relevés de compte</TabsTrigger>
            <TabsTrigger value="rib">RIB</TabsTrigger>
            <TabsTrigger value="other">Autres</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>Tous mes documents</CardTitle>
                <CardDescription>
                  Liste de tous vos documents bancaires disponibles.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingDocuments ? (
                  <div className="flex justify-center p-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : documents && documents.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Document</TableHead>
                          <TableHead>Compte</TableHead>
                          <TableHead>Date de création</TableHead>
                          <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {documents.map((doc) => (
                          <TableRow key={doc.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="bg-gray-100 p-2 rounded-md mr-3">
                                  <FileText className="h-5 w-5 text-red-500" />
                                </div>
                                <div>
                                  <div className="font-medium">{doc.name}</div>
                                  <div className="text-xs text-gray-500">{doc.type}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{doc.accountName}</TableCell>
                            <TableCell>{formatDate(doc.createdAt)}</TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDownload(doc.id)}
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun document</h3>
                    <p className="text-gray-500">Vous n'avez pas encore de document.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="statements">
            <Card>
              <CardHeader>
                <CardTitle>Relevés de compte</CardTitle>
                <CardDescription>
                  Vos relevés de compte mensuels.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingDocuments ? (
                  <div className="flex justify-center p-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : documents && documents.filter(d => d.type === "STATEMENT").length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Document</TableHead>
                          <TableHead>Compte</TableHead>
                          <TableHead>Date de création</TableHead>
                          <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {documents
                          .filter(d => d.type === "STATEMENT")
                          .map((doc) => (
                            <TableRow key={doc.id}>
                              <TableCell>
                                <div className="flex items-center">
                                  <div className="bg-gray-100 p-2 rounded-md mr-3">
                                    <FileText className="h-5 w-5 text-red-500" />
                                  </div>
                                  <div>
                                    <div className="font-medium">{doc.name}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>{doc.accountName}</TableCell>
                              <TableCell>{formatDate(doc.createdAt)}</TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDownload(doc.id)}
                                >
                                  <Download className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun relevé de compte</h3>
                    <p className="text-gray-500">Vous n'avez pas encore de relevé de compte.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="rib">
            <Card>
              <CardHeader>
                <CardTitle>RIB (Relevé d'Identité Bancaire)</CardTitle>
                <CardDescription>
                  Vos RIB disponibles pour chaque compte.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingDocuments ? (
                  <div className="flex justify-center p-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : documents && documents.filter(d => d.type === "RIB").length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Document</TableHead>
                          <TableHead>Compte</TableHead>
                          <TableHead>Date de création</TableHead>
                          <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {documents
                          .filter(d => d.type === "RIB")
                          .map((doc) => (
                            <TableRow key={doc.id}>
                              <TableCell>
                                <div className="flex items-center">
                                  <div className="bg-gray-100 p-2 rounded-md mr-3">
                                    <FileText className="h-5 w-5 text-red-500" />
                                  </div>
                                  <div>
                                    <div className="font-medium">{doc.name}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>{doc.accountName}</TableCell>
                              <TableCell>{formatDate(doc.createdAt)}</TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDownload(doc.id)}
                                >
                                  <Download className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun RIB</h3>
                    <p className="text-gray-500">Vous n'avez pas encore de RIB généré.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="other">
            <Card>
              <CardHeader>
                <CardTitle>Autres documents</CardTitle>
                <CardDescription>
                  Autres documents bancaires.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingDocuments ? (
                  <div className="flex justify-center p-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : documents && documents.filter(d => d.type !== "RIB" && d.type !== "STATEMENT").length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Document</TableHead>
                          <TableHead>Compte</TableHead>
                          <TableHead>Date de création</TableHead>
                          <TableHead className="text-right">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {documents
                          .filter(d => d.type !== "RIB" && d.type !== "STATEMENT")
                          .map((doc) => (
                            <TableRow key={doc.id}>
                              <TableCell>
                                <div className="flex items-center">
                                  <div className="bg-gray-100 p-2 rounded-md mr-3">
                                    <FileText className="h-5 w-5 text-red-500" />
                                  </div>
                                  <div>
                                    <div className="font-medium">{doc.name}</div>
                                    <div className="text-xs text-gray-500">{doc.type}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>{doc.accountName}</TableCell>
                              <TableCell>{formatDate(doc.createdAt)}</TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDownload(doc.id)}
                                >
                                  <Download className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun document</h3>
                    <p className="text-gray-500">Vous n'avez pas d'autres types de documents.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
