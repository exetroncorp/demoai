import { useQuery, useMutation } from "@tanstack/react-query";
import DashboardLayout from "@/components/layout/dashboard-layout";
import BankCard from "@/components/dashboard/bank-card";
import { Card as BankCardType } from "@shared/schema";
import { Loader2, Lock, Unlock, AlertCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";

export default function CardsPage() {
  const { toast } = useToast();
  const { data: cards, isLoading } = useQuery<BankCardType[]>({
    queryKey: ["/api/cards"],
  });

  const blockCardMutation = useMutation({
    mutationFn: async ({ cardId, blocked }: { cardId: number; blocked: boolean }) => {
      const res = await apiRequest("PATCH", `/api/cards/${cardId}`, { blocked });
      return await res.json() as BankCardType;
    },
    onSuccess: () => {
      toast({
        title: "Carte mise à jour",
        description: "Le statut de votre carte a été mis à jour avec succès."
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleToggleCardBlock = (cardId: number, currentlyBlocked: boolean) => {
    blockCardMutation.mutate({ cardId, blocked: !currentlyBlocked });
  };

  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Mes cartes bancaires</h1>

        {isLoading ? (
          <div className="flex justify-center p-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : cards && cards.length > 0 ? (
          <div className="grid grid-cols-1 gap-8">
            {cards.map((card, index) => (
              <Card key={card.id} className="overflow-hidden">
                <CardHeader>
                  <CardTitle>{card.type}</CardTitle>
                  <CardDescription>
                    {card.blocked ? (
                      <span className="flex items-center text-red-500">
                        <Lock className="h-4 w-4 mr-1" />
                        Carte bloquée
                      </span>
                    ) : (
                      <span className="flex items-center text-green-600">
                        <Unlock className="h-4 w-4 mr-1" />
                        Carte active
                      </span>
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <BankCard card={card} variant={index % 2 === 0 ? "primary" : "dark"} />
                  </div>

                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="details">
                      <AccordionTrigger>Détails de la carte</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2 text-sm">
                          <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                            <div className="text-gray-500">Numéro de carte:</div>
                            <div>{card.maskedNumber}</div>
                            
                            <div className="text-gray-500">Type de carte:</div>
                            <div>{card.type}</div>
                            
                            <div className="text-gray-500">Réseau:</div>
                            <div>{card.network}</div>
                            
                            <div className="text-gray-500">Date d'expiration:</div>
                            <div>{card.expiryDate}</div>
                            
                            <div className="text-gray-500">Plafond mensuel:</div>
                            <div>{new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(card.limit)}</div>
                            
                            <div className="text-gray-500">Compte associé:</div>
                            <div>{card.accountName}</div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                    
                    <AccordionItem value="options">
                      <AccordionTrigger>Options de paiement</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Paiements en ligne</p>
                              <p className="text-sm text-gray-500">Autoriser les paiements sur internet</p>
                            </div>
                            <Button size="sm" variant={card.onlinePaymentsEnabled ? "default" : "outline"}>
                              {card.onlinePaymentsEnabled ? "Activés" : "Désactivés"}
                            </Button>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Paiements à l'étranger</p>
                              <p className="text-sm text-gray-500">Autoriser les paiements hors zone Euro</p>
                            </div>
                            <Button size="sm" variant={card.foreignPaymentsEnabled ? "default" : "outline"}>
                              {card.foreignPaymentsEnabled ? "Activés" : "Désactivés"}
                            </Button>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">Paiements sans contact</p>
                              <p className="text-sm text-gray-500">Autoriser les paiements sans contact</p>
                            </div>
                            <Button size="sm" variant={card.contactlessEnabled ? "default" : "outline"}>
                              {card.contactlessEnabled ? "Activés" : "Désactivés"}
                            </Button>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
                <CardFooter className="flex justify-between pt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline">Voir code PIN</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Code PIN</DialogTitle>
                        <DialogDescription>
                          Pour des raisons de sécurité, veuillez ne pas partager ce code.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="flex items-center justify-center py-4">
                        <div className="bg-gray-100 rounded-lg px-6 py-3 text-center">
                          <p className="text-lg font-mono tracking-widest">••••</p>
                          <p className="text-xs text-gray-500 mt-2">Le code PIN n'est pas affiché pour des raisons de sécurité</p>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button>Fermer</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant={card.blocked ? "default" : "destructive"}
                        className={card.blocked ? "bg-green-600 hover:bg-green-700" : ""}
                      >
                        {card.blocked ? (
                          <>
                            <Unlock className="mr-2 h-4 w-4" />
                            Débloquer la carte
                          </>
                        ) : (
                          <>
                            <Lock className="mr-2 h-4 w-4" />
                            Bloquer la carte
                          </>
                        )}
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle className="flex items-center">
                          <AlertCircle className={cn(
                            "mr-2 h-5 w-5", 
                            card.blocked ? "text-green-500" : "text-red-500"
                          )} />
                          {card.blocked ? "Débloquer la carte" : "Bloquer la carte"}
                        </DialogTitle>
                        <DialogDescription>
                          {card.blocked 
                            ? "Êtes-vous sûr de vouloir débloquer cette carte ? Elle pourra à nouveau être utilisée pour des paiements." 
                            : "Êtes-vous sûr de vouloir bloquer cette carte ? Elle ne pourra plus être utilisée pour des paiements jusqu'à son déblocage."
                          }
                        </DialogDescription>
                      </DialogHeader>
                      <DialogFooter>
                        <Button 
                          variant="outline" 
                          onClick={() => {}}
                        >
                          Annuler
                        </Button>
                        <Button 
                          variant={card.blocked ? "default" : "destructive"}
                          className={card.blocked ? "bg-green-600 hover:bg-green-700" : ""}
                          onClick={() => handleToggleCardBlock(card.id, card.blocked)}
                          disabled={blockCardMutation.isPending}
                        >
                          {blockCardMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : card.blocked ? (
                            "Débloquer"
                          ) : (
                            "Bloquer"
                          )}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune carte trouvée</h3>
            <p className="text-gray-500 mb-6">Vous n'avez pas encore de carte bancaire associée à vos comptes.</p>
            <Button>Demander une carte</Button>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
