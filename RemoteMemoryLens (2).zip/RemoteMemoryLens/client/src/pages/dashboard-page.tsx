import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import DashboardLayout from "@/components/layout/dashboard-layout";
import AccountCard from "@/components/dashboard/account-card";
import BankCard from "@/components/dashboard/bank-card";
import TransactionList from "@/components/dashboard/transaction-list";
import QuickActions from "@/components/dashboard/quick-actions";
import DocumentList from "@/components/dashboard/document-list";
import MascotTipCard from "@/components/dashboard/mascot-tip-card";
import { MascotTooltip } from "@/components/ui/mascot-tooltip";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, Download, HelpCircle } from "lucide-react";
import { Account, Transaction, Card, Document } from "@shared/schema";

export default function DashboardPage() {
  const { user } = useAuth();
  
  const { data: accounts, isLoading: isLoadingAccounts } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  });
  
  const { data: cards, isLoading: isLoadingCards } = useQuery<Card[]>({
    queryKey: ["/api/cards"],
  });
  
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });
  
  const { data: documents, isLoading: isLoadingDocuments } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });
  
  const formatDateTime = (date: string) => {
    return new Date(date).toLocaleString("fr-FR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        {/* Welcome Header */}
        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-100 flex items-center">
              Bonjour, {user?.firstName || 'Utilisateur'}
              <MascotTooltip 
                content="Bienvenue sur votre tableau de bord! Suivez vos comptes, vos dépenses et gérez vos finances en un seul endroit."
                mascotName="panda"
                position="right"
              >
                <HelpCircle className="h-4 w-4 ml-2 text-primary/70" />
              </MascotTooltip>
            </h1>
            <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
              Dernière connexion le {user?.lastLogin ? formatDateTime(user.lastLogin) : 'N/A'}
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex">
            <Button asChild className="mr-2">
              <Link href="/transfers">
                <Plus className="mr-2 h-4 w-4" />
                <span>Nouveau virement</span>
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/documents/rib">
                <Download className="mr-2 h-4 w-4" />
                <span>RIB</span>
              </Link>
            </Button>
          </div>
        </div>
        
        {/* Mascot Tips Card */}
        <div className="mb-6">
          <MascotTipCard category="dashboard" className="bg-gray-50 dark:bg-gray-800" />
        </div>

        {/* Account Summary */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4 flex items-center">
            Mes comptes
            <MascotTooltip
              content="Visualisez tous vos comptes et leur solde. Un fond d'urgence équivalent à 3-6 mois de dépenses est recommandé."
              mascotName="owl"
              position="top"
            >
              <HelpCircle className="h-4 w-4 ml-2 text-primary/70" />
            </MascotTooltip>
          </h2>
          {isLoadingAccounts ? (
            <div className="flex justify-center p-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {accounts?.map((account) => (
                <AccountCard key={account.id} account={account} />
              ))}
            </div>
          )}
        </div>

        {/* Payment Cards */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 flex items-center">
              Mes cartes
              <MascotTooltip
                content="Gérez vos cartes bancaires et leurs paramètres de sécurité. Vous pouvez activer ou désactiver les paiements à l'étranger selon vos besoins."
                mascotName="fox"
                position="top"
              >
                <HelpCircle className="h-4 w-4 ml-2 text-primary/70" />
              </MascotTooltip>
            </h2>
            <Link href="/cards" className="text-primary text-sm font-medium">
              Voir toutes
            </Link>
          </div>

          {isLoadingCards ? (
            <div className="flex justify-center p-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {cards?.slice(0, 2).map((card, index) => (
                <BankCard 
                  key={card.id} 
                  card={card} 
                  variant={index % 2 === 0 ? "primary" : "dark"} 
                />
              ))}
            </div>
          )}
        </div>

        {/* Transaction History */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Dernières opérations</h2>
            <Link href="/accounts/transactions" className="text-primary text-sm font-medium">
              Voir toutes
            </Link>
          </div>

          {isLoadingTransactions ? (
            <div className="flex justify-center p-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <TransactionList transactions={transactions?.slice(0, 5) || []} />
          )}
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <div className="mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Actions rapides</h2>
          </div>
          <QuickActions />
        </div>

        {/* Documents Section */}
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Mes documents</h2>
            <Link href="/documents" className="text-primary text-sm font-medium">
              Voir tous
            </Link>
          </div>

          {isLoadingDocuments ? (
            <div className="flex justify-center p-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <DocumentList documents={documents || []} maxItems={3} />
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
