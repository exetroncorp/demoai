import { Transaction } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { 
  ShoppingBag, 
  Building, 
  Home, 
  Smartphone,
  Utensils,
  Car,
  Plane,
  Stethoscope,
  GraduationCap,
  Gift,
  CreditCard
} from "lucide-react";

interface TransactionListProps {
  transactions: Transaction[];
}

const categoryIcons: Record<string, JSX.Element> = {
  FOOD: <ShoppingBag className="text-red-500 text-xs" />,
  INCOME: <Building className="text-green-500 text-xs" />,
  HOUSING: <Home className="text-blue-500 text-xs" />,
  TELECOM: <Smartphone className="text-purple-500 text-xs" />,
  RESTAURANT: <Utensils className="text-yellow-500 text-xs" />,
  TRANSPORT: <Car className="text-cyan-500 text-xs" />,
  TRAVEL: <Plane className="text-indigo-500 text-xs" />,
  HEALTH: <Stethoscope className="text-pink-500 text-xs" />,
  EDUCATION: <GraduationCap className="text-emerald-500 text-xs" />,
  SHOPPING: <Gift className="text-amber-500 text-xs" />,
  OTHER: <CreditCard className="text-gray-500 text-xs" />
};

const categoryColors: Record<string, { bg: string, text: string }> = {
  FOOD: { bg: "bg-red-100", text: "text-red-800" },
  INCOME: { bg: "bg-green-100", text: "text-green-800" },
  HOUSING: { bg: "bg-blue-100", text: "text-blue-800" },
  TELECOM: { bg: "bg-purple-100", text: "text-purple-800" },
  RESTAURANT: { bg: "bg-yellow-100", text: "text-yellow-800" },
  TRANSPORT: { bg: "bg-cyan-100", text: "text-cyan-800" },
  TRAVEL: { bg: "bg-indigo-100", text: "text-indigo-800" },
  HEALTH: { bg: "bg-pink-100", text: "text-pink-800" },
  EDUCATION: { bg: "bg-emerald-100", text: "text-emerald-800" },
  SHOPPING: { bg: "bg-amber-100", text: "text-amber-800" },
  OTHER: { bg: "bg-gray-100", text: "text-gray-800" }
};

const categoryLabels: Record<string, string> = {
  FOOD: "Alimentation",
  INCOME: "Revenus",
  HOUSING: "Logement",
  TELECOM: "Télécom",
  RESTAURANT: "Restaurant",
  TRANSPORT: "Transport",
  TRAVEL: "Voyage",
  HEALTH: "Santé",
  EDUCATION: "Éducation",
  SHOPPING: "Shopping",
  OTHER: "Autre"
};

export default function TransactionList({ transactions }: TransactionListProps) {
  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("fr-FR");
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              <TableHead className="w-[100px]">Date</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Catégorie</TableHead>
              <TableHead className="text-right">Montant</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell className="text-sm text-gray-500">
                  {formatDate(transaction.date)}
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <div className={cn(
                      "flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center",
                      transaction.amount > 0 ? "bg-green-100" : 
                        categoryColors[transaction.category]?.bg || "bg-gray-100"
                    )}>
                      {transaction.amount > 0 
                        ? <Building className="text-green-500 text-xs" />
                        : categoryIcons[transaction.category] || <CreditCard className="text-gray-500 text-xs" />
                      }
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{transaction.description}</div>
                      <div className="text-xs text-gray-500">{transaction.reference}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <span className={cn(
                    "px-2 inline-flex text-xs leading-5 font-semibold rounded-full",
                    transaction.amount > 0 
                      ? "bg-green-100 text-green-800" 
                      : categoryColors[transaction.category]?.bg || "bg-gray-100",
                    transaction.amount > 0 
                      ? "text-green-800" 
                      : categoryColors[transaction.category]?.text || "text-gray-800"
                  )}>
                    {transaction.amount > 0 
                      ? "Revenus" 
                      : categoryLabels[transaction.category] || "Autre"}
                  </span>
                </TableCell>
                <TableCell className={cn(
                  "text-sm font-medium text-right",
                  transaction.amount > 0 ? "text-green-600" : "text-red-600"
                )}>
                  {transaction.amount > 0 ? "+" : ""}
                  {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(transaction.amount)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
