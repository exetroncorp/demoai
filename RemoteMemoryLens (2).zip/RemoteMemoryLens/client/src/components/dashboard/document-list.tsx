import { Document } from "@shared/schema";
import { FileText, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DocumentListProps {
  documents: Document[];
  maxItems?: number;
}

export default function DocumentList({ documents, maxItems }: DocumentListProps) {
  const displayDocuments = maxItems ? documents.slice(0, maxItems) : documents;
  
  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("fr-FR");
  };
  
  const handleDownload = (documentId: number) => {
    // In a real implementation, this would trigger a document download
    window.open(`/api/documents/${documentId}/download`, '_blank');
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <ul className="divide-y divide-gray-200">
        {displayDocuments.map((document) => (
          <li key={document.id} className="p-4 hover:bg-gray-50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="bg-gray-100 p-2 rounded-md mr-4">
                  <FileText className="h-5 w-5 text-red-500" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-800">{document.name}</h4>
                  <p className="text-xs text-gray-500">
                    {document.accountName} - {formatDate(document.createdAt)}
                  </p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => handleDownload(document.id)}
                className="text-primary hover:text-primary-dark"
              >
                <Download className="h-5 w-5" />
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
