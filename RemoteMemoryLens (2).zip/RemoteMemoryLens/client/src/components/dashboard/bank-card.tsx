import { Card as BankCardType } from "@shared/schema";
import { cn } from "@/lib/utils";
import { CreditCard as CardIcon, Milestone } from "lucide-react";

interface BankCardProps {
  card: BankCardType;
  variant?: "primary" | "dark";
}

export default function BankCard({ card, variant = "primary" }: BankCardProps) {
  return (
    <div 
      className={cn(
        "rounded-xl p-5 text-white shadow-lg relative overflow-hidden",
        variant === "primary" 
          ? "bg-gradient-to-r from-primary to-blue-600" 
          : "bg-gradient-to-r from-gray-700 to-gray-900"
      )}
    >
      <div className="absolute top-0 right-0 w-40 h-40 bg-white opacity-5 rounded-full -mt-10 -mr-10"></div>
      <div className="absolute bottom-0 left-0 w-30 h-30 bg-white opacity-5 rounded-full -mb-10 -ml-10"></div>
      
      <div className="flex justify-between items-center mb-12">
        <div>
          <h3 className="font-bold text-lg">{card.type}</h3>
          <p className="text-white/70 text-sm">Plafond: {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(card.limit)}/mois</p>
        </div>
        {card.network === "MASTERCARD" ? (
          <Milestone className="h-7 w-7" />
        ) : (
          <CardIcon className="h-7 w-7" />
        )}
      </div>
      
      <div className="mb-6">
        <p className="text-sm text-white/70 mb-1">Numéro de carte</p>
        <p className="font-mono tracking-wider text-lg">{card.maskedNumber}</p>
      </div>
      
      <div className="flex justify-between">
        <div>
          <p className="text-xs text-white/70 mb-1">Titulaire</p>
          <p className="font-medium">{card.cardholderName}</p>
        </div>
        <div>
          <p className="text-xs text-white/70 mb-1">Expire</p>
          <p className="font-medium">{card.expiryDate}</p>
        </div>
      </div>
    </div>
  );
}
