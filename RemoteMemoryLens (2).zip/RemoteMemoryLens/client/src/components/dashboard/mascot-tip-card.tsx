import { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { getRandomTip, type FinancialTipCategory } from "@/data/financial-tips";

interface MascotTipCardProps {
  category: FinancialTipCategory;
  className?: string;
}

export default function MascotTipCard({ category, className }: MascotTipCardProps) {
  const [tip, setTip] = useState(() => getRandomTip(category));
  
  const refreshTip = () => {
    setTip(getRandomTip(category));
  };
  
  // Change de conseil toutes les 60 secondes
  useEffect(() => {
    const interval = setInterval(() => {
      refreshTip();
    }, 60000);
    
    return () => clearInterval(interval);
  }, [category]);
  
  const getMascotEmoji = () => {
    switch (tip.mascot) {
      case 'panda':
        return '🐼';
      case 'fox':
        return '🦊';
      case 'owl':
        return '🦉';
      default:
        return '🐼';
    }
  };
  
  const getMascotName = () => {
    switch (tip.mascot) {
      case 'panda':
        return 'Bambo';
      case 'fox':
        return 'Foxy';
      case 'owl':
        return 'Wisely';
      default:
        return 'Bambo';
    }
  };

  return (
    <Card className={`shadow-sm overflow-hidden ${className}`}>
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <div className="text-3xl flex-shrink-0">{getMascotEmoji()}</div>
          <div className="space-y-2 flex-1">
            <div className="flex justify-between items-start">
              <h3 className="font-semibold text-gray-800 dark:text-gray-100">
                {getMascotName()} dit :
              </h3>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-gray-500 hover:text-primary"
                onClick={refreshTip}
                title="Nouveau conseil"
              >
                <RefreshCw size={14} />
              </Button>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">{tip.content}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}