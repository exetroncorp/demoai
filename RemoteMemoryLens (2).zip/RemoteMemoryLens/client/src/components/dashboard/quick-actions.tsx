import { useLocation } from "wouter";
import { RefreshCw, ArrowDown01, CreditCard, Headphones } from "lucide-react";

export default function QuickActions() {
  const [_, navigate] = useLocation();
  
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div 
        onClick={() => navigate("/transfers")}
        className="bg-gray-800 dark:bg-zinc-800 rounded-lg shadow-sm border border-gray-700 p-4 flex flex-col items-center hover:border-primary transition-colors cursor-pointer"
      >
        <div className="bg-primary/20 h-12 w-12 rounded-full flex items-center justify-center mb-3">
          <RefreshCw className="h-5 w-5 text-primary" />
        </div>
        <span className="text-sm font-medium text-white">Virement</span>
      </div>
      
      <div 
        onClick={() => navigate("/documents/rib")}
        className="bg-gray-800 dark:bg-zinc-800 rounded-lg shadow-sm border border-gray-700 p-4 flex flex-col items-center hover:border-blue-500 transition-colors cursor-pointer"
      >
        <div className="bg-blue-600/20 h-12 w-12 rounded-full flex items-center justify-center mb-3">
          <ArrowDown01 className="h-5 w-5 text-blue-400" />
        </div>
        <span className="text-sm font-medium text-white">RIB</span>
      </div>
      
      <div 
        onClick={() => navigate("/cards")}
        className="bg-gray-800 dark:bg-zinc-800 rounded-lg shadow-sm border border-gray-700 p-4 flex flex-col items-center hover:border-cyan-500 transition-colors cursor-pointer"
      >
        <div className="bg-cyan-500/20 h-12 w-12 rounded-full flex items-center justify-center mb-3">
          <CreditCard className="h-5 w-5 text-cyan-400" />
        </div>
        <span className="text-sm font-medium text-white">Gérer cartes</span>
      </div>
      
      <div 
        onClick={() => navigate("/settings/support")}
        className="bg-gray-800 dark:bg-zinc-800 rounded-lg shadow-sm border border-gray-700 p-4 flex flex-col items-center hover:border-amber-500 transition-colors cursor-pointer"
      >
        <div className="bg-amber-500/20 h-12 w-12 rounded-full flex items-center justify-center mb-3">
          <Headphones className="h-5 w-5 text-amber-400" />
        </div>
        <span className="text-sm font-medium text-white">Support</span>
      </div>
    </div>
  );
}
