
import { Account } from "@shared/schema";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface AccountCardProps {
  account: Account;
}

export default function AccountCard({ account }: AccountCardProps) {
  const [, navigate] = useLocation();

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div className="p-4 border-b border-gray-100">
          <div className="flex justify-between items-center">
            <h3 className="font-medium text-gray-800">{account.name}</h3>
            <Badge 
              variant="outline" 
              className={cn(
                "text-xs font-medium px-2 py-1 rounded-full",
                account.status === "ACTIVE" ? "bg-green-100 text-green-800 border-green-200" : 
                account.status === "INACTIVE" ? "bg-gray-100 text-gray-800 border-gray-200" : 
                "bg-yellow-100 text-yellow-800 border-yellow-200"
              )}
            >
              {account.status === "ACTIVE" ? "Actif" : 
               account.status === "INACTIVE" ? "Inactif" : 
               "En attente"}
            </Badge>
          </div>
          <p className="text-xs text-gray-500 mt-1">{account.iban}</p>
        </div>
        <div className="p-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-500 text-sm">Solde disponible</span>
            <span className="text-2xl font-semibold text-gray-800">
              {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(account.balance)}
            </span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 px-4 py-3 flex justify-between border-t border-gray-100">
        <button 
          onClick={() => navigate(`/accounts/${account.id}`)}
          className="text-primary text-sm font-medium hover:underline"
        >
          Voir détails
        </button>
        <button
          onClick={() => navigate(`/accounts/${account.id}/transactions`)}
          className="text-primary text-sm font-medium hover:underline"
        >
          Opérations
        </button>
      </CardFooter>
    </Card>
  );
}
