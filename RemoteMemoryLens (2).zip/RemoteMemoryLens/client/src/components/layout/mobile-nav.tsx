import { Link, useLocation } from "wouter";
import { Home, Wallet, RefreshCw, Bell, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/hooks/use-sidebar";
import { Building } from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();
  const { toggleSidebar } = useSidebar();

  return (
    <>
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between px-4 py-3 bg-white border-b border-gray-200">
        <div className="flex items-center">
          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white mr-2">
            <Building className="h-4 w-4" />
          </div>
          <h1 className="text-lg font-semibold text-gray-800">BanqueNeo</h1>
        </div>
        <button
          className="text-gray-500 focus:outline-none"
          onClick={toggleSidebar}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </button>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 w-full bg-white border-t border-gray-200 z-10">
        <div className="flex justify-around">
          <div
            onClick={() => window.history.pushState({}, "", "/")}
            className={cn(
              "flex flex-1 flex-col items-center py-3 cursor-pointer",
              location === "/" ? "text-primary" : "text-gray-500"
            )}
          >
            <Home className="text-lg" />
            <span className="text-xs mt-1">Accueil</span>
          </div>
          <div
            onClick={() => window.history.pushState({}, "", "/accounts")}
            className={cn(
              "flex flex-1 flex-col items-center py-3 cursor-pointer",
              location === "/accounts" ? "text-primary" : "text-gray-500"
            )}
          >
            <Wallet className="text-lg" />
            <span className="text-xs mt-1">Comptes</span>
          </div>
          <div
            onClick={() => window.history.pushState({}, "", "/transfers")}
            className={cn(
              "flex flex-1 flex-col items-center py-3 cursor-pointer",
              location === "/transfers" ? "text-primary" : "text-gray-500"
            )}
          >
            <RefreshCw className="text-lg" />
            <span className="text-xs mt-1">Virements</span>
          </div>
          <div
            onClick={() => window.history.pushState({}, "", "/notifications")}
            className={cn(
              "flex flex-1 flex-col items-center py-3 relative cursor-pointer",
              location === "/notifications" ? "text-primary" : "text-gray-500"
            )}
          >
            <Bell className="text-lg" />
            <span className="absolute top-2 right-6 h-4 w-4 bg-primary rounded-full flex items-center justify-center text-white text-xs">
              3
            </span>
            <span className="text-xs mt-1">Notifs</span>
          </div>
          <div
            onClick={() => window.history.pushState({}, "", "/settings")}
            className={cn(
              "flex flex-1 flex-col items-center py-3 cursor-pointer",
              location === "/settings" ? "text-primary" : "text-gray-500"
            )}
          >
            <User className="text-lg" />
            <span className="text-xs mt-1">Profil</span>
          </div>
        </div>
      </div>
    </>
  );
}
