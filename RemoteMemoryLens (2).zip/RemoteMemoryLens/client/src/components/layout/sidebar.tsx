import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/hooks/use-sidebar";
import { useAuth } from "@/hooks/use-auth";
import {
  Home,
  Wallet,
  CreditCard,
  FileText,
  Bell,
  Settings,
  LogOut,
  RefreshCw,
  Building,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ThemeSwitcher } from "@/components/ui/theme-switcher";

interface SidebarLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  badge?: number;
}

const SidebarLink = ({ href, icon, children, badge }: SidebarLinkProps) => {
  const [location] = useLocation();
  const { closeSidebar } = useSidebar();
  const isActive = location === href;

  return (
    <li className="mb-1">
      <div 
        onClick={() => {
          // Use manual navigation to avoid nested <a> tags
          window.history.pushState({}, "", href);
          closeSidebar();
        }}
        className={cn(
          "flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors cursor-pointer",
          isActive
            ? "bg-primary/20 text-primary dark:bg-primary/30 dark:text-primary-foreground"
            : "text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800"
        )}
      >
        <span className="w-5 h-5 mr-3">{icon}</span>
        <span>{children}</span>
        {badge && badge > 0 ? (
          <Badge variant="default" className="ml-auto">
            {badge}
          </Badge>
        ) : null}
      </div>
    </li>
  );
};

export default function Sidebar() {
  const { logoutMutation } = useAuth();
  const { isOpen, closeSidebar } = useSidebar();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={closeSidebar}
        ></div>
      )}

      <aside
        className={cn(
          "fixed top-0 left-0 z-50 h-full w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 transition-transform duration-300 ease-in-out md:translate-x-0 md:static md:z-auto",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="p-4 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white mr-2">
              <Building className="h-4 w-4" />
            </div>
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">BanqueNeo</h1>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-4">
          <ul>
            <SidebarLink href="/" icon={<Home className="text-gray-500" />}>
              Tableau de bord
            </SidebarLink>
            <SidebarLink
              href="/accounts"
              icon={<Wallet className="text-gray-500" />}
            >
              Mes comptes
            </SidebarLink>
            <SidebarLink
              href="/transfers"
              icon={<RefreshCw className="text-gray-500" />}
            >
              Virements
            </SidebarLink>
            <SidebarLink
              href="/cards"
              icon={<CreditCard className="text-gray-500" />}
            >
              Mes cartes
            </SidebarLink>
            <SidebarLink
              href="/documents"
              icon={<FileText className="text-gray-500" />}
            >
              Documents
            </SidebarLink>
            <SidebarLink
              href="/notifications"
              icon={<Bell className="text-gray-500" />}
              badge={3}
            >
              Notifications
            </SidebarLink>
          </ul>
        </nav>

        <div className="p-4 border-t border-gray-200 dark:border-gray-800">
          <div className="mb-4">
            <ThemeSwitcher />
          </div>
          <div 
            className="flex items-center text-sm font-medium text-gray-700 dark:text-gray-200 hover:text-primary mb-3 cursor-pointer"
            onClick={() => {
              window.history.pushState({}, "", "/settings");
              closeSidebar();
            }}
          >
            <Settings className="w-5 h-5 mr-3 text-gray-500" />
            <span>Paramètres</span>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center text-sm font-medium text-gray-700 dark:text-gray-200 hover:text-primary w-full"
          >
            <LogOut className="w-5 h-5 mr-3 text-gray-500" />
            <span>Déconnexion</span>
          </button>
        </div>
      </aside>
    </>
  );
}
