import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Account, Transfer } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const transferSchema = z.object({
  fromAccountId: z.number({
    required_error: "Veuillez sélectionner un compte émetteur",
  }),
  toIBAN: z.string().min(15, {
    message: "L'IBAN doit contenir au moins 15 caractères",
  }),
  toBIC: z.string().min(8, {
    message: "Le BIC doit contenir au moins 8 caractères",
  }),
  beneficiaryName: z.string().min(1, {
    message: "Le nom du bénéficiaire est requis",
  }),
  amount: z.number({
    required_error: "Le montant est requis",
    invalid_type_error: "Le montant doit être un nombre",
  }).positive({
    message: "Le montant doit être positif",
  }),
  reference: z.string().optional(),
});

type TransferFormValues = z.infer<typeof transferSchema>;

export default function TransferForm() {
  const { toast } = useToast();
  const [step, setStep] = useState<1 | 2>(1);

  const { data: accounts, isLoading: isLoadingAccounts } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  });

  const form = useForm<TransferFormValues>({
    resolver: zodResolver(transferSchema),
    defaultValues: {
      reference: "",
    },
  });

  const transferMutation = useMutation({
    mutationFn: async (data: TransferFormValues) => {
      const res = await apiRequest("POST", "/api/transfers", data);
      return await res.json() as Transfer;
    },
    onSuccess: () => {
      toast({
        title: "Virement effectué",
        description: "Votre virement a été effectué avec succès.",
      });
      form.reset();
      setStep(1);
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  function onSubmit(data: TransferFormValues) {
    if (step === 1) {
      setStep(2);
    } else {
      transferMutation.mutate(data);
    }
  }

  function formatCurrency(amount: number) {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
  }

  if (isLoadingAccounts) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {step === 1 ? (
          <>
            <FormField
              control={form.control}
              name="fromAccountId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Compte à débiter</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value?.toString()}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez un compte" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {accounts?.map((account) => (
                        <SelectItem key={account.id} value={account.id.toString()}>
                          {account.name} - {formatCurrency(account.balance)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="toIBAN"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>IBAN du bénéficiaire</FormLabel>
                  <FormControl>
                    <Input placeholder="FR76 XXXX XXXX XXXX XXXX XXXX XXX" {...field} />
                  </FormControl>
                  <FormDescription>
                    Format: FR76 XXXX XXXX XXXX XXXX XXXX XXX
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="toBIC"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>BIC / SWIFT</FormLabel>
                  <FormControl>
                    <Input placeholder="BNPAFRPPXXX" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="beneficiaryName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nom du bénéficiaire</FormLabel>
                  <FormControl>
                    <Input placeholder="Nom du bénéficiaire" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Montant</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="0.00" 
                      min="0.01" 
                      step="0.01" 
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      value={field.value || ''}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="reference"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Référence (optionnel)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Référence ou motif du virement" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full">Continuer</Button>
          </>
        ) : (
          <>
            <div className="space-y-4 p-4 border rounded-lg bg-gray-50">
              <h3 className="font-semibold text-gray-800">Résumé du virement</h3>
              
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-gray-500">Compte émetteur:</div>
                <div className="font-medium">
                  {accounts?.find(a => a.id === form.getValues().fromAccountId)?.name}
                </div>
                
                <div className="text-gray-500">Bénéficiaire:</div>
                <div className="font-medium">{form.getValues().beneficiaryName}</div>
                
                <div className="text-gray-500">IBAN:</div>
                <div className="font-medium">{form.getValues().toIBAN}</div>
                
                <div className="text-gray-500">Montant:</div>
                <div className="font-medium">
                  {formatCurrency(form.getValues().amount || 0)}
                </div>
                
                <div className="text-gray-500">Référence:</div>
                <div className="font-medium">{form.getValues().reference || "-"}</div>
              </div>
            </div>
            
            <div className="flex flex-col gap-3 sm:flex-row sm:justify-between">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setStep(1)}
              >
                Retour
              </Button>
              <Button 
                type="submit"
                disabled={transferMutation.isPending}
              >
                {transferMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Traitement en cours...
                  </>
                ) : (
                  "Confirmer le virement"
                )}
              </Button>
            </div>
          </>
        )}
      </form>
    </Form>
  );
}
