import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { HelpCircle, Info } from 'lucide-react';

// Interface pour les propriétés du composant
interface MascotTooltipProps {
  content: React.ReactNode;
  mascotName?: 'panda' | 'fox' | 'owl'; // différentes mascottes possibles
  position?: 'top' | 'bottom' | 'left' | 'right';
  className?: string;
  children?: React.ReactNode;
  trigger?: 'hover' | 'click';
  icon?: React.ReactNode;
  delay?: number; // délai avant que le tooltip n'apparaisse
}

const getMascotEmoji = (mascot: 'panda' | 'fox' | 'owl') => {
  switch (mascot) {
    case 'panda':
      return '🐼';
    case 'fox':
      return '🦊';
    case 'owl':
      return '🦉';
    default:
      return '🐼';
  }
};

const getMascotName = (mascot: 'panda' | 'fox' | 'owl') => {
  switch (mascot) {
    case 'panda':
      return 'Bambo';
    case 'fox':
      return 'Foxy';
    case 'owl':
      return 'Wisely';
    default:
      return 'Bambo';
  }
};

export function MascotTooltip({
  content,
  mascotName = 'panda',
  position = 'top',
  className,
  children,
  trigger = 'hover',
  icon = <HelpCircle className="h-4 w-4" />,
  delay = 300,
}: MascotTooltipProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null);

  const handleMouseEnter = () => {
    if (trigger === 'hover') {
      const id = setTimeout(() => {
        setIsVisible(true);
      }, delay);
      setTimeoutId(id);
    }
  };

  const handleMouseLeave = () => {
    if (trigger === 'hover') {
      if (timeoutId) {
        clearTimeout(timeoutId);
        setTimeoutId(null);
      }
      setIsVisible(false);
    }
  };

  const handleClick = () => {
    if (trigger === 'click') {
      setIsVisible(!isVisible);
    }
  };

  const positionClasses = {
    top: 'bottom-full left-1/2 transform -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 transform -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 transform -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 transform -translate-y-1/2 ml-2',
  };

  const mascotEmoji = getMascotEmoji(mascotName);
  const displayName = getMascotName(mascotName);

  return (
    <div className="relative inline-block">
      <div
        className="cursor-help"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
      >
        {children || (
          <div className="text-primary hover:text-primary/80 transition-colors">
            {icon}
          </div>
        )}
      </div>

      {isVisible && (
        <div
          className={cn(
            'absolute z-50 w-64 p-3 rounded-lg shadow-lg text-sm',
            'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700',
            positionClasses[position],
            className
          )}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          <div className="flex items-start space-x-2">
            <div className="text-xl">{mascotEmoji}</div>
            <div className="space-y-1">
              <p className="font-semibold text-gray-900 dark:text-gray-100">
                {displayName} dit :
              </p>
              <div className="text-gray-700 dark:text-gray-300">{content}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}