import { sqliteTable, text, integer, real, blob } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// User Model
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  lastLogin: text("last_login"),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const loginSchema = z.object({
  username: z.string().min(1, "Le nom d'utilisateur est requis"),
  password: z.string().min(1, "Le mot de passe est requis"),
});

// Account Model
export const accounts = sqliteTable("accounts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  type: text("type").notNull(), // CURRENT, SAVINGS, TERM
  iban: text("iban").notNull().unique(),
  bic: text("bic").notNull(),
  balance: real("balance").notNull().default(0),
  status: text("status").notNull().default("PENDING"), // ACTIVE, INACTIVE, PENDING
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
  userId: true,
  iban: true,
  bic: true,
  balance: true,
  status: true,
  createdAt: true,
  updatedAt: true,
});

// Transaction Model
export const transactions = sqliteTable("transactions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  accountId: integer("account_id").notNull().references(() => accounts.id),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: real("amount").notNull(),
  description: text("description").notNull(),
  reference: text("reference"),
  category: text("category").notNull(), // FOOD, INCOME, HOUSING, TELECOM, RESTAURANT, TRANSPORT, TRAVEL, HEALTH, EDUCATION, SHOPPING, OTHER
  type: text("type").notNull(), // DEBIT, CREDIT
  date: text("date").default(sql`CURRENT_TIMESTAMP`),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

// Card Model
export const cards = sqliteTable("cards", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  accountId: integer("account_id").notNull().references(() => accounts.id),
  type: text("type").notNull(), // MASTERCARD, VISA, VISA_PREMIER
  maskedNumber: text("masked_number").notNull(),
  cardholderName: text("cardholder_name").notNull(),
  expiryDate: text("expiry_date").notNull(),
  cvv: text("cvv").notNull(),
  network: text("network").notNull(), // MASTERCARD, VISA
  limit: real("limit").notNull(),
  accountName: text("account_name").notNull(),
  blocked: integer("blocked", { mode: "boolean" }).notNull().default(false),
  onlinePaymentsEnabled: integer("online_payments_enabled", { mode: "boolean" }).notNull().default(true),
  foreignPaymentsEnabled: integer("foreign_payments_enabled", { mode: "boolean" }).notNull().default(false),
  contactlessEnabled: integer("contactless_enabled", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertCardSchema = createInsertSchema(cards).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Document Model
export const documents = sqliteTable("documents", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  accountId: integer("account_id").notNull().references(() => accounts.id),
  name: text("name").notNull(),
  type: text("type").notNull(), // RIB, STATEMENT, CONTRACT, OTHER
  url: text("url").notNull(),
  accountName: text("account_name").notNull(),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
});

// Transfer Model
export const transfers = sqliteTable("transfers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  fromAccountId: integer("from_account_id").notNull().references(() => accounts.id),
  toIBAN: text("to_iban").notNull(),
  toBIC: text("to_bic").notNull(),
  beneficiaryName: text("beneficiary_name").notNull(),
  amount: real("amount").notNull(),
  reference: text("reference"),
  status: text("status").notNull().default("PENDING"), // COMPLETED, PENDING, FAILED
  date: text("date").default(sql`CURRENT_TIMESTAMP`),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertTransferSchema = createInsertSchema(transfers).omit({
  id: true,
  userId: true,
  status: true,
  date: true,
  createdAt: true,
});

// Notification Model
export const notifications = sqliteTable("notifications", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // TRANSFER, ACCOUNT, CARD, DOCUMENT, OTHER
  read: integer("read", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type Account = typeof accounts.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Card = typeof cards.$inferSelect;
export type Document = typeof documents.$inferSelect;
export type Transfer = typeof transfers.$inferSelect;
export type Notification = typeof notifications.$inferSelect;

export type LoginUser = z.infer<typeof loginSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type InsertCard = z.infer<typeof insertCardSchema>;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type InsertTransfer = z.infer<typeof insertTransferSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;