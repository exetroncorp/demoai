"""Tests for the registry module."""

import pytest
from prooter.registry.manifest import (
    parse_image_reference,
    parse_manifest,
    ImageManifest,
    ManifestList,
    LayerDescriptor,
)


class TestParseImageReference:
    """Tests for parse_image_reference function."""
    
    def test_simple_image(self):
        """Test parsing a simple image name."""
        registry, repo, tag = parse_image_reference("alpine")
        assert registry == "registry-1.docker.io"
        assert repo == "library/alpine"
        assert tag == "latest"
    
    def test_image_with_tag(self):
        """Test parsing image with tag."""
        registry, repo, tag = parse_image_reference("alpine:3.18")
        assert registry == "registry-1.docker.io"
        assert repo == "library/alpine"
        assert tag == "3.18"
    
    def test_namespaced_image(self):
        """Test parsing namespaced image."""
        registry, repo, tag = parse_image_reference("nginx/nginx:latest")
        assert registry == "registry-1.docker.io"
        assert repo == "nginx/nginx"
        assert tag == "latest"
    
    def test_full_reference(self):
        """Test parsing full image reference."""
        registry, repo, tag = parse_image_reference("gcr.io/project/image:v1.0")
        assert registry == "gcr.io"
        assert repo == "project/image"
        assert tag == "v1.0"
    
    def test_digest_reference(self):
        """Test parsing digest reference."""
        registry, repo, tag = parse_image_reference(
            "alpine@sha256:abc123"
        )
        assert registry == "registry-1.docker.io"
        assert repo == "library/alpine"
        assert tag == "sha256:abc123"


class TestParseManifest:
    """Tests for manifest parsing."""
    
    def test_parse_v2_manifest(self):
        """Test parsing a Docker v2 manifest."""
        data = {
            "schemaVersion": 2,
            "mediaType": "application/vnd.docker.distribution.manifest.v2+json",
            "config": {
                "digest": "sha256:config123",
                "size": 1234,
                "mediaType": "application/vnd.docker.container.image.v1+json",
            },
            "layers": [
                {
                    "digest": "sha256:layer1",
                    "size": 10000,
                    "mediaType": "application/vnd.docker.image.rootfs.diff.tar.gzip",
                },
                {
                    "digest": "sha256:layer2",
                    "size": 20000,
                    "mediaType": "application/vnd.docker.image.rootfs.diff.tar.gzip",
                },
            ],
        }
        
        manifest = parse_manifest(data)
        assert isinstance(manifest, ImageManifest)
        assert manifest.schema_version == 2
        assert len(manifest.layers) == 2
        assert manifest.layers[0].digest == "sha256:layer1"
        assert manifest.config.digest == "sha256:config123"
    
    def test_parse_manifest_list(self):
        """Test parsing a manifest list."""
        data = {
            "schemaVersion": 2,
            "mediaType": "application/vnd.docker.distribution.manifest.list.v2+json",
            "manifests": [
                {
                    "digest": "sha256:amd64manifest",
                    "platform": {
                        "os": "linux",
                        "architecture": "amd64",
                    },
                },
                {
                    "digest": "sha256:arm64manifest",
                    "platform": {
                        "os": "linux",
                        "architecture": "arm64",
                    },
                },
            ],
        }
        
        manifest = parse_manifest(data)
        assert isinstance(manifest, ManifestList)
        assert len(manifest.manifests) == 2
        
        # Test platform selection
        amd64 = manifest.get_manifest_for_platform("linux", "amd64")
        assert amd64 is not None
        assert amd64["digest"] == "sha256:amd64manifest"
        
        arm64 = manifest.get_manifest_for_platform("linux", "arm64")
        assert arm64 is not None
        assert arm64["digest"] == "sha256:arm64manifest"
        
        windows = manifest.get_manifest_for_platform("windows", "amd64")
        assert windows is None


class TestLayerDescriptor:
    """Tests for LayerDescriptor."""
    
    def test_from_dict(self):
        """Test creating from dictionary."""
        data = {
            "digest": "sha256:abc123",
            "size": 12345,
            "mediaType": "application/vnd.docker.image.rootfs.diff.tar.gzip",
        }
        
        layer = LayerDescriptor.from_dict(data)
        assert layer.digest == "sha256:abc123"
        assert layer.size == 12345
        assert "tar.gzip" in layer.media_type
