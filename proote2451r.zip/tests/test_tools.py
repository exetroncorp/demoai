"""Tests for OCI tool wrappers (skopeo, umoci)."""

import pytest
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

from prooter.tools.skopeo import Skopeo, SkopeoError
from prooter.tools.umoci import Umoci, UmociError


class TestSkopeo:
    """Tests for Skopeo wrapper."""
    
    @pytest.fixture
    def mock_config(self, tmp_path):
        """Create a mock config."""
        mock = Mock()
        mock.base_dir = tmp_path
        mock.bin_dir = tmp_path / "bin"
        mock.bin_dir.mkdir()
        mock.verify_ssl = True
        return mock
    
    @pytest.fixture
    def skopeo(self, mock_config):
        """Create Skopeo instance with mock config."""
        return Skopeo(mock_config)
    
    def test_is_available_false_when_not_installed(self, skopeo):
        """Test is_available returns False when skopeo not installed."""
        with patch("shutil.which", return_value=None):
            # Binary doesn't exist
            assert not skopeo.binary.exists()
            assert not skopeo.is_available()
    
    def test_is_available_true_with_system_skopeo(self, skopeo, tmp_path):
        """Test is_available returns True when skopeo in PATH."""
        # Create a fake binary
        fake_binary = tmp_path / "skopeo"
        fake_binary.touch()
        
        with patch.object(skopeo, "_binary_path", fake_binary):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = Mock(returncode=0)
                # Must also patch binary property to return existing path
                with patch.object(type(skopeo), "binary", property(lambda self: fake_binary)):
                    assert skopeo.is_available()
    
    def test_inspect_raises_when_unavailable(self, skopeo):
        """Test inspect raises SkopeoError when skopeo unavailable."""
        with patch.object(skopeo, "is_available", return_value=False):
            with pytest.raises(SkopeoError) as exc_info:
                skopeo.inspect("docker://alpine")
            assert "skopeo not found" in str(exc_info.value)
    
    def test_inspect_parses_json_output(self, skopeo):
        """Test inspect correctly parses JSON output."""
        mock_output = '{"Name": "alpine", "Tag": "latest"}'
        
        with patch.object(skopeo, "is_available", return_value=True):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = Mock(
                    returncode=0,
                    stdout=mock_output,
                    stderr="",
                )
                result = skopeo.inspect("docker://alpine")
                
                assert result["Name"] == "alpine"
                assert result["Tag"] == "latest"
    
    def test_copy_builds_correct_command(self, skopeo):
        """Test copy builds correct skopeo command."""
        with patch.object(skopeo, "is_available", return_value=True):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = Mock(returncode=0)
                skopeo.copy("docker://alpine", "oci:/tmp/test:latest")
                
                # Check the command was called
                mock_run.assert_called_once()
                cmd = mock_run.call_args[0][0]
                
                assert "copy" in cmd
                assert "docker://alpine" in cmd
                assert "oci:/tmp/test:latest" in cmd
    
    def test_get_auth_args_with_auth_file(self, skopeo, mock_config):
        """Test auth args include authfile when present."""
        auth_file = mock_config.base_dir / "auth.json"
        auth_file.write_text('{"auths": {}}')
        
        args = skopeo._get_auth_args()
        assert "--authfile" in args
        assert str(auth_file) in args
    
    def test_get_auth_args_without_ssl_verify(self, skopeo, mock_config):
        """Test auth args include tls-verify=false when SSL disabled."""
        mock_config.verify_ssl = False
        skopeo = Skopeo(mock_config)
        
        args = skopeo._get_auth_args()
        assert "--tls-verify=false" in args


class TestUmoci:
    """Tests for Umoci wrapper."""
    
    @pytest.fixture
    def mock_config(self, tmp_path):
        """Create a mock config."""
        mock = Mock()
        mock.base_dir = tmp_path
        mock.bin_dir = tmp_path / "bin"
        mock.bin_dir.mkdir()
        return mock
    
    @pytest.fixture
    def umoci(self, mock_config):
        """Create Umoci instance with mock config."""
        return Umoci(mock_config)
    
    def test_is_available_false_when_not_installed(self, umoci):
        """Test is_available returns False when umoci not installed."""
        with patch("shutil.which", return_value=None):
            assert not umoci.binary.exists()
            assert not umoci.is_available()
    
    def test_is_available_true_with_system_umoci(self, umoci, tmp_path):
        """Test is_available returns True when umoci in PATH."""
        # Create a fake binary
        fake_binary = tmp_path / "umoci"
        fake_binary.touch()
        
        with patch.object(umoci, "_binary_path", fake_binary):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = Mock(returncode=0)
                with patch.object(type(umoci), "binary", property(lambda self: fake_binary)):
                    assert umoci.is_available()
    
    def test_unpack_raises_when_unavailable(self, umoci, tmp_path):
        """Test unpack raises UmociError when umoci unavailable."""
        with patch.object(umoci, "is_available", return_value=False):
            with pytest.raises(UmociError) as exc_info:
                umoci.unpack(tmp_path / "image", tmp_path / "bundle")
            assert "umoci not found" in str(exc_info.value)
    
    def test_unpack_builds_correct_command(self, umoci, tmp_path):
        """Test unpack builds correct umoci command."""
        image_path = tmp_path / "image"
        bundle_path = tmp_path / "bundle"
        
        with patch.object(umoci, "is_available", return_value=True):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = Mock(returncode=0)
                umoci.unpack(image_path, bundle_path, tag="latest")
                
                mock_run.assert_called_once()
                cmd = mock_run.call_args[0][0]
                
                assert "unpack" in cmd
                assert "--rootless" in cmd
                assert "--image" in cmd
                assert str(bundle_path) in cmd
    
    def test_list_tags_reads_index_json(self, umoci, tmp_path):
        """Test list_tags correctly reads OCI index.json."""
        image_path = tmp_path / "image"
        image_path.mkdir()
        
        index_content = {
            "manifests": [
                {
                    "digest": "sha256:abc123",
                    "annotations": {
                        "org.opencontainers.image.ref.name": "latest"
                    }
                },
                {
                    "digest": "sha256:def456",
                    "annotations": {
                        "org.opencontainers.image.ref.name": "v1.0"
                    }
                }
            ]
        }
        
        import json
        (image_path / "index.json").write_text(json.dumps(index_content))
        
        tags = umoci.list_tags(image_path)
        assert "latest" in tags
        assert "v1.0" in tags
    
    def test_list_tags_returns_empty_for_missing_index(self, umoci, tmp_path):
        """Test list_tags returns empty list when index.json missing."""
        empty_path = tmp_path / "empty_image"
        tags = umoci.list_tags(empty_path)
        assert tags == []


class TestRegistry:
    """Tests for refactored registry client."""
    
    @pytest.fixture
    def mock_config(self, tmp_path):
        """Create a mock config."""
        mock = Mock()
        mock.base_dir = tmp_path
        mock.oci_dir = tmp_path / "oci"
        mock.oci_dir.mkdir()
        mock.verify_ssl = True
        return mock
    
    def test_image_exists_locally_false_when_not_present(self, mock_config):
        """Test image_exists_locally returns False for missing images."""
        from prooter.registry.client import RegistryClient
        
        with patch("prooter.registry.client.get_config", return_value=mock_config):
            client = RegistryClient()
            assert not client.image_exists_locally("alpine:latest")
    
    def test_get_oci_path_creates_safe_name(self, mock_config):
        """Test _get_oci_path creates filesystem-safe names."""
        from prooter.registry.client import RegistryClient
        
        with patch("prooter.registry.client.get_config", return_value=mock_config):
            client = RegistryClient()
            
            path = client._get_oci_path("library/alpine:latest")
            # Should not contain slashes
            assert "/" not in path.name
            assert "library_alpine" in str(path)
