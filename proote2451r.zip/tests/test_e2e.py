"""End-to-End tests for Prooter."""

import shutil
import subprocess
import sys
import pytest

# Check if we are running inside the constrained environment or have dependencies
PROOT_AVAILABLE = shutil.which("proot") is not None
SKOPEO_AVAILABLE = shutil.which("skopeo") is not None
UMOCI_AVAILABLE = shutil.which("umoci") is not None

@pytest.mark.skipif(not (PROOT_AVAILABLE and SKOPEO_AVAILABLE and UMOCI_AVAILABLE),
                    reason="Prooter dependencies (proot, skopeo, umoci) not met")
class TestE2E:
    """End-to-End tests for prooter CLI."""

    def run_prooter(self, args):
        """Helper to run prooter command."""
        cmd = [sys.executable, "-m", "prooter"] + args
        result = subprocess.run(
            cmd, 
            capture_output=True, 
            text=True, 
            check=False
        )
        return result

    def test_version(self):
        """Test 'prooter version' command."""
        result = self.run_prooter(["version"])
        assert result.returncode == 0
        assert "Prooter version" in result.stdout
        assert "PRoot: available" in result.stdout

    def test_workflow_alpine(self):
        """Test full workflow with alpine image."""
        # 1. Pull
        print("\nPulling alpine...")
        result = self.run_prooter(["pull", "alpine:latest"])
        if result.returncode != 0:
            pytest.fail(f"Pull failed: {result.stderr}")
        assert result.returncode == 0

        # 2. List images
        print("Listing images...")
        result = self.run_prooter(["images"])
        assert result.returncode == 0
        assert "alpine" in result.stdout

        # 3. Run container (simple echo)
        print("Running echo...")
        result = self.run_prooter([
            "run", "--rm", "alpine:latest", "echo", "Hello E2E"
        ])
        if result.returncode != 0:
            pytest.fail(f"Run echo failed: {result.stderr}")
        assert "Hello E2E" in result.stdout

        # 4. Run container (check user/id)
        # In a rootless proot, typical behavior is that it looks like root (0) inside
        print("Running id...")
        result = self.run_prooter([
            "run", "--rm", "alpine:latest", "id", "-u"
        ])
        # The proot engine should map the current user to root inside, so id -u is 0
        assert result.returncode == 0
        assert "0" in result.stdout.strip()
