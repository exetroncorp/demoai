"""Prooter Compose manager."""

import sys
import subprocess
import time
from pathlib import Path
from typing import List, Dict
import threading

from .parser import ComposeConfig, ServiceConfig

class ComposeManager:
    """Manages lifecycle of compose services."""
    
    def __init__(self, config: ComposeConfig, project_name: str = "prooter"):
        self.config = config
        self.project_name = project_name

    def _get_container_name(self, service_name: str) -> str:
        return f"{self.project_name}_{service_name}_1"

    def up(self, detached: bool = False):
        """Start all services."""
        processes = []
        
        for name, service in self.config.services.items():
            print(f"Starting service '{name}'...")
            
            # Construct command: python -m prooter run ...
            cmd = [sys.executable, "-m", "prooter", "run"]
            
            # Name
            container_name = self._get_container_name(name)
            cmd.extend(["--name", container_name])
            
            # Volumes
            for vol in service.volumes:
                cmd.extend(["-v", vol])
                
            # Env
            for k, v in service.env.items():
                cmd.extend(["-e", f"{k}={v}"])
            
            # Ports
            for port in service.ports:
                cmd.extend(["-p", port])
                
            # Image
            cmd.append(service.image)
            
            # Command override
            if service.command:
                cmd.extend(service.command)
                
            # Launch
            if detached:
                # Detached: launch independent process
                subprocess.Popen(
                    cmd,
                    start_new_session=True,  # Unix only? Windows?
                    # On Windows creationflags=subprocess.DETACHED_PROCESS?
                    # For MVP simplistic Popen is enough?
                )
                print(f"Started {name} (detached)")
            else:
                # Attached: launch and track
                # For attached mode, we want to stream output.
                # Simplest MVP: Launch Popen and keep reference.
                p = subprocess.Popen(
                    cmd,
                    stdout=None, # Inherit stdout
                    stderr=None  # Inherit stderr
                )
                processes.append(p)
                
        if not detached and processes:
            print("Attached to all services. Press Ctrl+C to stop.")
            try:
                # Wait for any process to exit?
                while any(p.poll() is None for p in processes):
                    time.sleep(0.5)
            except KeyboardInterrupt:
                print("\nStopping services...")
                self.down()

    def down(self):
        """Stop all services."""
        print("Stopping services...")
        
        # We need to call `prooter rm -f <container>` for each service
        for name in self.config.services:
            container_name = self._get_container_name(name)
            
            cmd = [sys.executable, "-m", "prooter", "rm", "-f", container_name]
            
            try:
                subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                print(f"Stopped {name}")
            except Exception as e:
                print(f"Error stopping {name}: {e}")
