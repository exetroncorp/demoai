"""Local image storage management using OCI layouts.

This module manages locally stored container images in OCI image layout format,
using umoci for unpacking images to runtime bundles.
"""

import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any

from prooter.config import get_config
from prooter.tools.umoci import Umoci, UmociError


@dataclass
class LocalImage:
    """Represents a locally stored OCI image."""
    
    image_id: str
    repository: str
    tag: str
    registry: str
    oci_path: Path
    config: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def full_name(self) -> str:
        """Get the full image name with tag."""
        if self.registry in ("registry-1.docker.io", "docker.io"):
            # Docker Hub - don't show registry
            if self.repository.startswith("library/"):
                return f"{self.repository[8:]}:{self.tag}"
            return f"{self.repository}:{self.tag}"
        return f"{self.registry}/{self.repository}:{self.tag}"
    
    @property
    def short_id(self) -> str:
        """Get short image ID."""
        return self.image_id[:12]
    
    @classmethod
    def from_oci_path(cls, oci_path: Path) -> Optional["LocalImage"]:
        """Create from OCI image path.
        
        Args:
            oci_path: Path to OCI image directory
            
        Returns:
            LocalImage or None if invalid
        """
        # Read prooter metadata
        metadata_path = oci_path / "prooter_metadata.json"
        if not metadata_path.exists():
            return None
        
        try:
            with open(metadata_path) as f:
                metadata = json.load(f)
            
            # Get image ID from index
            index_path = oci_path / "index.json"
            image_id = "unknown"
            config_data = {}
            
            if index_path.exists():
                with open(index_path) as f:
                    index = json.load(f)
                
                # Get digest of first manifest as ID
                manifests = index.get("manifests", [])
                if manifests:
                    digest = manifests[0].get("digest", "")
                    if digest.startswith("sha256:"):
                        image_id = digest[7:]
            
            return cls(
                image_id=image_id,
                repository=metadata.get("repository", "unknown"),
                tag=metadata.get("tag", "latest"),
                registry=metadata.get("registry", "docker.io"),
                oci_path=oci_path,
                config=config_data,
            )
            
        except (json.JSONDecodeError, KeyError):
            return None


class ImageStore:
    """Manages local OCI image storage."""
    
    def __init__(self, config=None):
        """Initialize the image store.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or get_config()
        self.umoci = Umoci(self.config)
    
    def list_images(self) -> List[LocalImage]:
        """List all locally stored images.
        
        Returns:
            List of LocalImage objects
        """
        images = []
        
        oci_dir = self.config.oci_dir
        if not oci_dir.exists():
            return images
        
        for oci_path in oci_dir.iterdir():
            if not oci_path.is_dir():
                continue
            
            # Check if it's a valid OCI image
            if not (oci_path / "index.json").exists():
                continue
            
            image = LocalImage.from_oci_path(oci_path)
            if image:
                images.append(image)
        
        # Also check legacy images directory for backward compatibility
        if self.config.images_dir.exists():
            for image_dir in self.config.images_dir.iterdir():
                if not image_dir.is_dir():
                    continue
                
                metadata_path = image_dir / "metadata.json"
                if not metadata_path.exists():
                    continue
                
                try:
                    with open(metadata_path) as f:
                        metadata = json.load(f)
                    
                    config_data = {}
                    config_path = image_dir / "config.json"
                    if config_path.exists():
                        with open(config_path) as f:
                            config_data = json.load(f)
                    
                    # Create a LocalImage for legacy format
                    images.append(LocalImage(
                        image_id=metadata.get("image_id", "unknown"),
                        repository=metadata.get("repository", "unknown"),
                        tag=metadata.get("tag", "latest"),
                        registry=metadata.get("registry", "docker.io"),
                        oci_path=image_dir,  # Not really OCI but compatible
                        config=config_data,
                    ))
                except (json.JSONDecodeError, KeyError):
                    continue
        
        return images
    
    def get_image(self, reference: str) -> Optional[LocalImage]:
        """Get a locally stored image by reference.
        
        Args:
            reference: Image reference (name:tag or ID)
            
        Returns:
            LocalImage or None if not found
        """
        images = self.list_images()
        
        # Normalize reference
        search_ref = reference
        if ":" not in reference and not (len(reference) >= 12 and all(c in "0123456789abcdef" for c in reference)):
            search_ref = f"{reference}:latest"
            
        for image in images:
            # Match by full name
            if image.full_name == search_ref or image.full_name == reference:
                return image
            
            # Match by repository:tag
            repo_tag = f"{image.repository}:{image.tag}"
            if repo_tag == search_ref or repo_tag == reference:
                return image
            
            # Match by short name:tag (for Docker Hub)
            if image.repository.startswith("library/"):
                short_name = f"{image.repository[8:]}:{image.tag}"
                if short_name == reference:
                    return image
            
            # Match by ID
            if reference.startswith(image.image_id) or image.image_id.startswith(reference):
                return image
        
        return None
    
    def get_image_dir(self, image: LocalImage) -> Path:
        """Get the directory for an image.
        
        Args:
            image: LocalImage object
            
        Returns:
            Path to image directory (OCI path)
        """
        return image.oci_path
    
    def create_rootfs(self, image: LocalImage, container_dir: Path) -> Path:
        """Create a root filesystem for a container from an image.
        
        Uses umoci to unpack the OCI image to a runtime bundle.
        
        Args:
            image: LocalImage to create rootfs from
            container_dir: Container directory
            
        Returns:
            Path to the rootfs directory
        """
        rootfs = container_dir / "rootfs"
        bundle_path = container_dir / "bundle"
        
        if rootfs.exists():
            # Already exists
            return rootfs
        
        # Check for pre-existing bundle
        if bundle_path.exists() and (bundle_path / "rootfs").exists():
            return bundle_path / "rootfs"
        
        # Check if this is an OCI image (has index.json)
        if (image.oci_path / "index.json").exists():
            print(f"Unpacking OCI image using umoci...")
            
            try:
                # Use umoci to unpack to bundle
                self.umoci.unpack(
                    image_path=image.oci_path,
                    bundle_path=bundle_path,
                    tag=image.tag,
                    rootless=True,
                )
                
                # umoci creates bundle/rootfs
                bundle_rootfs = bundle_path / "rootfs"
                if bundle_rootfs.exists():
                    # Create symlink or copy
                    if not rootfs.exists():
                        rootfs.symlink_to(bundle_rootfs)
                    return rootfs
                    
            except UmociError as e:
                print(f"Warning: umoci unpack failed: {e}")
                print("Falling back to legacy extraction...")
        
        # Fallback: Legacy extraction for non-OCI images
        return self._legacy_create_rootfs(image, container_dir)
    
    def _legacy_create_rootfs(self, image: LocalImage, container_dir: Path) -> Path:
        """Legacy rootfs creation for backward compatibility.
        
        Args:
            image: LocalImage object
            container_dir: Container directory
            
        Returns:
            Path to rootfs directory
        """
        from prooter.image.layer import apply_layers, get_layer_path
        
        rootfs = container_dir / "rootfs"
        
        # Check for pre-built rootfs in image directory
        image_rootfs = image.oci_path / "rootfs"
        if image_rootfs.exists() and image_rootfs.is_dir():
            print(f"Creating rootfs from image directory...")
            shutil.copytree(image_rootfs, rootfs, symlinks=True)
            return rootfs
        
        # Try to read legacy metadata
        metadata_path = image.oci_path / "metadata.json"
        if metadata_path.exists():
            with open(metadata_path) as f:
                metadata = json.load(f)
            
            layers = metadata.get("layers", [])
            if layers:
                print(f"Creating rootfs from {len(layers)} layers...")
                
                layer_paths = [
                    get_layer_path(self.config.layers_dir, digest)
                    for digest in layers
                ]
                
                # Verify layers exist
                for i, path in enumerate(layer_paths):
                    if not path.exists():
                        raise FileNotFoundError(f"Layer not found: {layers[i]}")
                
                def progress(current: int, total: int) -> None:
                    if current < total:
                        print(f"  Extracting layer {current + 1}/{total}...")
                
                apply_layers(layer_paths, rootfs, progress)
                print("  Rootfs created successfully")
                return rootfs
        
        raise RuntimeError(f"Cannot create rootfs: no valid image data in {image.oci_path}")
    
    def remove_image(self, reference: str) -> bool:
        """Remove a locally stored image.
        
        Args:
            reference: Image reference
            
        Returns:
            True if removed, False if not found
        """
        image = self.get_image(reference)
        if not image:
            return False
        
        if image.oci_path.exists():
            shutil.rmtree(image.oci_path)
        
        return True
    
    def get_image_config(self, image: LocalImage) -> Dict[str, Any]:
        """Get the config for an image.
        
        Args:
            image: LocalImage object
            
        Returns:
            Config dictionary
        """
        if image.config:
            return image.config
        
        # Try to read from OCI layout
        if (image.oci_path / "index.json").exists():
            try:
                return self.umoci.get_config(image.oci_path, image.tag)
            except UmociError:
                pass
        
        # Fallback to legacy config.json
        config_path = image.oci_path / "config.json"
        if config_path.exists():
            with open(config_path) as f:
                return json.load(f)
        
        return {}
