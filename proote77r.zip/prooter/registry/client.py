"""Docker Registry client using skopeo for image operations.

This module provides a high-level interface for container image operations,
using skopeo for actual registry communication and umoci for unpacking.
"""

import json
from pathlib import Path
from typing import Optional, Dict, Any, Callable

from prooter.config import get_config
from prooter.tools.skopeo import Skopeo, SkopeoError
from prooter.tools.umoci import Umoci, UmociError
from prooter.image.store import ImageStore
from prooter.registry.manifest import parse_image_reference


class RegistryClient:
    """Client for container image operations using skopeo/umoci.
    
    This is a refactored version that delegates to external OCI tools
    instead of implementing registry protocol directly.
    """
    
    def __init__(
        self,
        verify_ssl: Optional[bool] = None,
    ):
        """Initialize registry client.
        
        Args:
            verify_ssl: Whether to verify SSL certificates (default: from config or True)
        """
        self.config = get_config()
        
        # Resolve verify_ssl: ARG > CONFIG > DEFAULT(True)
        if verify_ssl is None:
            verify_ssl = self.config.verify_ssl
            
        self.verify_ssl = verify_ssl
        self.skopeo = Skopeo(self.config)
        self.umoci = Umoci(self.config)
    
    def _get_oci_path(self, image_ref: str) -> Path:
        """Get local OCI storage path for an image.
        
        Args:
            image_ref: Image reference
            
        Returns:
            Path to OCI image directory
        """
        registry, repository, tag = parse_image_reference(image_ref)
        
        # Create a safe directory name from image reference
        # e.g., library/alpine:latest -> library_alpine
        safe_name = repository.replace("/", "_").replace(":", "_")
        
        return self.config.oci_dir / safe_name
    
    def pull_image(
        self,
        image: str,
        progress_callback: Optional[Callable[[str, int, int], None]] = None,
    ) -> tuple:
        """Pull an image from a registry.
        
        Uses skopeo to copy the image to local OCI storage.
        
        Args:
            image: Image reference (e.g., 'alpine:latest')
            progress_callback: Optional progress callback (not used with skopeo)
            
        Returns:
            Tuple of (manifest_dict, image_dir)
            
        Raises:
            SkopeoError: If pull fails
        """
        registry, repository, tag = parse_image_reference(image)
        
        # Build docker:// reference
        if registry in ("registry-1.docker.io", "docker.io"):
            docker_ref = f"docker://{repository}:{tag}"
        else:
            docker_ref = f"docker://{registry}/{repository}:{tag}"
        
        # Local OCI storage path
        oci_path = self._get_oci_path(image)
        
        print(f"Pulling {image}...")
        
        # Use skopeo to copy image to OCI layout
        try:
            self.skopeo.pull_to_oci(docker_ref, oci_path, tag=tag)
        except SkopeoError as e:
            raise RuntimeError(f"Failed to pull image: {e}") from e
        
        # Get manifest for return value
        manifest = self._read_oci_manifest(oci_path, tag)
        
        # Save metadata for compatibility with existing code
        metadata = {
            "image": image,
            "registry": registry,
            "repository": repository,
            "tag": tag,
            "oci_path": str(oci_path),
        }
        
        metadata_path = oci_path / "prooter_metadata.json"
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)
        
        print(f"Successfully pulled {image}")
        return manifest, oci_path
    
    def push_image(
        self,
        image: str,
    ) -> None:
        """Push a local image to a remote registry.
        
        Uses skopeo to copy the image from local OCI storage to a registry.
        
        Args:
            image: Image reference (e.g., 'nanto2vison/myapp:latest')
            
        Raises:
            RuntimeError: If push fails or image not found locally
        """
        store = ImageStore()
        local_image = store.get_image(image)
        if not local_image:
            raise RuntimeError(f"Image '{image}' not found locally. Use 'prooter images' to list images.")
        
        registry, repository, tag = parse_image_reference(image)
        
        # Source is local OCI layout
        oci_path = local_image.oci_path
        src = f"oci:{oci_path}:{tag}"
        
        # Build docker:// destination reference
        if registry in ("registry-1.docker.io", "docker.io"):
            docker_ref = f"docker://docker.io/{repository}:{tag}"
        else:
            docker_ref = f"docker://{registry}/{repository}:{tag}"
        
        print(f"Pushing {image}...")
        
        try:
            self.skopeo.copy(src, docker_ref)
        except SkopeoError as e:
            raise RuntimeError(f"Failed to push image: {e}") from e
        
        print(f"Successfully pushed {image}")
    
    def _read_oci_manifest(self, oci_path: Path, tag: str) -> Dict[str, Any]:
        """Read manifest from OCI image layout.
        
        Args:
            oci_path: Path to OCI image
            tag: Image tag
            
        Returns:
            Manifest dictionary
        """
        index_path = oci_path / "index.json"
        
        if not index_path.exists():
            return {}
        
        try:
            with open(index_path) as f:
                index = json.load(f)
            
            # Find manifest for tag
            for manifest_entry in index.get("manifests", []):
                annotations = manifest_entry.get("annotations", {})
                ref_name = annotations.get("org.opencontainers.image.ref.name")
                if ref_name == tag:
                    digest = manifest_entry.get("digest")
                    if digest:
                        algo, hash_val = digest.split(":", 1)
                        manifest_path = oci_path / "blobs" / algo / hash_val
                        with open(manifest_path) as mf:
                            return json.load(mf)
            
            return {}
            
        except (json.JSONDecodeError, FileNotFoundError):
            return {}
    
    def get_manifest(
        self,
        image: str,
        platform_os: str = "linux",
        platform_arch: str = "amd64",
    ) -> Dict[str, Any]:
        """Get the manifest for an image.
        
        Uses skopeo inspect to get manifest data.
        
        Args:
            image: Image reference
            platform_os: Target OS (for multi-arch images)
            platform_arch: Target architecture
            
        Returns:
            Manifest dictionary
        """
        registry, repository, tag = parse_image_reference(image)
        
        if registry in ("registry-1.docker.io", "docker.io"):
            docker_ref = f"docker://{repository}:{tag}"
        else:
            docker_ref = f"docker://{registry}/{repository}:{tag}"
        
        try:
            return self.skopeo.inspect(docker_ref, raw=True)
        except SkopeoError as e:
            raise RuntimeError(f"Failed to get manifest: {e}") from e
    
    def get_config_blob(
        self,
        image: str,
    ) -> Dict[str, Any]:
        """Get the config blob for an image.
        
        Uses skopeo inspect --config to get config data.
        
        Args:
            image: Image reference
            
        Returns:
            Config dictionary
        """
        registry, repository, tag = parse_image_reference(image)
        
        if registry in ("registry-1.docker.io", "docker.io"):
            docker_ref = f"docker://{repository}:{tag}"
        else:
            docker_ref = f"docker://{registry}/{repository}:{tag}"
        
        try:
            return self.skopeo.inspect(docker_ref, config=True)
        except SkopeoError as e:
            raise RuntimeError(f"Failed to get config: {e}") from e
    
    def image_exists_locally(self, image: str) -> bool:
        """Check if an image exists in local OCI storage.
        
        Args:
            image: Image reference
            
        Returns:
            True if image exists locally
        """
        oci_path = self._get_oci_path(image)
        index_path = oci_path / "index.json"
        return index_path.exists()
    
    def get_local_oci_path(self, image: str) -> Optional[Path]:
        """Get the local OCI path for an image if it exists.
        
        Args:
            image: Image reference
            
        Returns:
            Path to OCI image or None
        """
        oci_path = self._get_oci_path(image)
        if (oci_path / "index.json").exists():
            return oci_path
        return None
