"""Base execution engine interface."""

import os
import subprocess
from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any


class ExecutionMode(Enum):
    """Available execution modes."""
    
    PROOT = "proot"      # PRoot (ptrace-based)
    FAKECHROOT = "fakechroot"  # Fakechroot (LD_PRELOAD-based)


class BaseEngine(ABC):
    """Base class for container execution engines."""
    
    mode: ExecutionMode
    
    def __init__(self, config=None):
        """Initialize the execution engine.
        
        Args:
            config: Optional configuration object
        """
        from prooter.config import get_config
        self.config = config or get_config()
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if this execution engine is available.
        
        Returns:
            True if the engine can be used
        """
        pass
    
    @abstractmethod
    def run(
        self,
        rootfs: Path,
        command: List[str],
        env: Dict[str, str],
        working_dir: str = "/",
        volumes: Optional[List[tuple]] = None,
        interactive: bool = False,
        tty: bool = False,
        user: Optional[str] = None,
        stdout_path: Optional[Path] = None,
        stderr_path: Optional[Path] = None,
    ) -> int:
        """Run a command in the container.
        
        Args:
            rootfs: Path to the root filesystem
            command: Command to execute
            env: Environment variables
            working_dir: Working directory inside container
            volumes: List of (host_path, container_path) tuples
            interactive: Keep stdin open
            tty: Allocate a pseudo-TTY
            user: User to run as (inside container)
            
        Returns:
            Exit code of the command
        """
        pass
    
    def prepare_env(
        self,
        env: Dict[str, str],
        rootfs: Path,
    ) -> Dict[str, str]:
        """Prepare environment variables for execution.
        
        Args:
            env: User-specified environment variables
            rootfs: Path to the root filesystem
            
        Returns:
            Complete environment dictionary
        """
        # Start with minimal environment
        result = {
            "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "HOME": "/root",
            "TERM": os.environ.get("TERM", "xterm"),
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "DEBIAN_FRONTEND": "noninteractive",
        }
        
        # Add user-specified environment
        result.update(env)
        
        return result
    
    def validate_volumes(
        self,
        volumes: Optional[List[tuple]],
    ) -> List[tuple]:
        """Validate and normalize volume mounts.
        
        Args:
            volumes: List of (host_path, container_path) tuples
            
        Returns:
            Validated volume list
            
        Raises:
            ValueError: If a volume specification is invalid
        """
        if not volumes:
            return []
        
        validated = []
        for vol in volumes:
            if len(vol) != 2:
                raise ValueError(f"Invalid volume specification: {vol}")
            
            host_path, container_path = vol
            host_path = Path(host_path).resolve()
            
            if not host_path.exists():
                raise ValueError(f"Host path does not exist: {host_path}")
            
            if not container_path.startswith("/"):
                raise ValueError(f"Container path must be absolute: {container_path}")
            
            validated.append((str(host_path), container_path))
        
        return validated


def get_best_engine(config=None) -> BaseEngine:
    """Get the best available execution engine.
    
    Args:
        config: Optional configuration object
        
    Returns:
        An available execution engine
        
    Raises:
        RuntimeError: If no execution engine is available
    """
    from prooter.config import get_config
    if config is None:
        config = get_config()
        
    from prooter.execution.proot import PRootEngine
    from prooter.execution.fakechroot import FakechrootEngine
    
    # Check for configured preference
    engine_pref = config.execution_engine
    if engine_pref == "proot":
        return PRootEngine(config)
    elif engine_pref == "fakechroot":
        return FakechrootEngine(config)
    
    # Try PRoot first (primary)
    proot = PRootEngine(config)
    if proot.is_available():
        return proot
    
    # Try Fakechroot second
    fakechroot = FakechrootEngine(config)
    if fakechroot.is_available():
        return fakechroot
    
    raise RuntimeError(
        "No execution engine available. Please ensure PRoot is installed in "
        "~/.prooter/bin/proot or run 'prooter setup' to download it."
    )
