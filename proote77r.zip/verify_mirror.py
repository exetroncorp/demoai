
import sys
import json
import os
from pathlib import Path
from prooter.config import init_config
from prooter.registry.client import RegistryClient

def verify_mirror():
    print("Verifying registry mirror...")
    
    # Setup paths
    home = Path.home()
    prooter_dir = home / ".prooter"
    config_file = prooter_dir / "config.json"
    
    # Ensure directory exists
    prooter_dir.mkdir(parents=True, exist_ok=True)
    
    # Test 1: No mirror configured
    print("Test 1: Default (no mirror)...", end=" ")
    if config_file.exists():
        config_file.unlink()
        
    init_config() # Reload config
    client = RegistryClient()
    url = client._get_registry_url("docker.io")
    
    if url == "https://registry-1.docker.io":
        print("PASSED")
    else:
        print(f"FAILED (Got {url})")
        return
        
    # Test 2: With mirror configured
    print("Test 2: With mirror...", end=" ")
    
    mirror_url = "https://mirror.gcr.io"
    with open(config_file, "w") as f:
        json.dump({"registry-mirror": mirror_url}, f)
        
    init_config() # Reload config
    client = RegistryClient()
    url = client._get_registry_url("docker.io")
    
    if url == mirror_url:
        print("PASSED")
    else:
        print(f"FAILED (Got {url}, expected {mirror_url})")
        return
        
    # Test 3: Other registry (should not use mirror)
    print("Test 3: Non-docker.io registry...", end=" ")
    url = client._get_registry_url("quay.io")
    if url == "https://quay.io":
        print("PASSED")
    else:
        print(f"FAILED (Got {url})")
        return

    # Clean up
    if config_file.exists():
        config_file.unlink()

if __name__ == "__main__":
    verify_mirror()
