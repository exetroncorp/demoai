

import sys
import os
sys.path.append(os.path.join(os.getcwd(), 'app'))

try:
    from saml import get_saml_settings
    from onelogin.saml2.auth import OneLogin_Saml2_Auth
    print("SAML Imports Successful")
    
    settings = get_saml_settings()
    print("Settings loaded:", settings['sp']['entityId'])
    
except Exception as e:
    import traceback
    traceback.print_exc()

