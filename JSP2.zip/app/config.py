import os
from datetime import timedelta

class Config:
    """Base configuration."""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL', 
        'postgresql://jupyterhub:jupyterhub@db:5432/jupyterhub_portal'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_recycle': 300,
        'pool_pre_ping': True
    }
    
    # Session
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Authentication mode: 'ldap', 'saml', 'dummy'
    AUTH_MODE = os.environ.get('AUTH_MODE', 'dummy')
    
    # LDAP Configuration
    LDAP_HOST = os.environ.get('LDAP_HOST', 'ldap://localhost:389')
    LDAP_BASE_DN = os.environ.get('LDAP_BASE_DN', 'dc=example,dc=com')
    LDAP_USER_DN = os.environ.get('LDAP_USER_DN', 'ou=users')
    LDAP_BIND_DN = os.environ.get('LDAP_BIND_DN', '')
    LDAP_BIND_PASSWORD = os.environ.get('LDAP_BIND_PASSWORD', '')
    LDAP_USER_SEARCH_FILTER = os.environ.get('LDAP_USER_SEARCH_FILTER', '(uid={username})')
    LDAP_ATTRIBUTES = ['uid', 'cn', 'sn', 'mail', 'manager']
    
    # SAML Configuration
    SAML_METADATA_URL = os.environ.get('SAML_METADATA_URL', '')
    SAML_ENTITY_ID = os.environ.get('SAML_ENTITY_ID', '')
    SAML_ACS_URL = os.environ.get('SAML_ACS_URL', '')
    SAML_ATTRIBUTE_USERNAME = os.environ.get('SAML_ATTRIBUTE_USERNAME', 'uid')
    SAML_ATTRIBUTE_EMAIL = os.environ.get('SAML_ATTRIBUTE_EMAIL', 'email')
    
    # JupyterHub API
    JUPYTERHUB_API_URL = os.environ.get('JUPYTERHUB_API_URL', 'http://jupyterhub:8081/hub/api')
    JUPYTERHUB_API_TOKEN = os.environ.get('JUPYTERHUB_API_TOKEN', '')
    
    # Token settings
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', SECRET_KEY)
    JWT_EXPIRATION_HOURS = int(os.environ.get('JWT_EXPIRATION_HOURS', '8'))


class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    ENV = 'development'
    FLASK_ENV = 'development'
    SQLALCHEMY_ECHO = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        'sqlite:////app/instance/jupyterhub_portal.db'
    )


class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False
    SESSION_COOKIE_SECURE = True


class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
