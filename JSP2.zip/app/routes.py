import os
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, jsonify, flash, current_app, session
from flask_login import login_required, current_user

from models import db, Entity, Machine, User
from auth import admin_required, superadmin_required, hash_password
from balancer import get_balancer
from jupyterhub_client import get_jupyterhub_client

main_bp = Blueprint('main', __name__)


# ============ PAGE ROUTES ============

@main_bp.route('/')
def index():
    """Landing page - redirect to login or dashboard."""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('auth.login'))


@main_bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard page."""
    return render_template('dashboard.html', user=current_user)


@main_bp.route('/admin')
@admin_required
def admin():
    """Admin panel page."""
    if current_user.is_superadmin:
        users = User.query.all()
        machines = Machine.query.all()
        entities = Entity.query.all()
    else:
        # Instance Admin - constrained to their Entity
        if current_user.identity:
            users = User.query.filter_by(identity=current_user.identity).all()
            machines = Machine.query.filter_by(identity=current_user.identity).all()
            entities = Entity.query.filter_by(identity=current_user.identity).all()
        else:
            users = []
            machines = []
            entities = []
            
    return render_template('admin.html', users=users, machines=machines, entities=entities)


@main_bp.route('/redirect-to-jupyter')
@login_required
def redirect_to_jupyter():
    """Redirect user to their assigned JupyterHub instance with automatic authentication."""
    # Always use JupyterHub URL for the integrated code-server
    jupyterhub_url = os.environ.get('JUPYTERHUB_PUBLIC_URL', 'http://localhost:8000')
    
    hub_client = get_jupyterhub_client()
    username = current_user.uid
    
    try:
        # Ensure user exists in JupyterHub
        try:
            hub_client.get_user(username)
        except:
            hub_client.create_user(username)
            
        # Check if server is running
        status = hub_client.get_server_status(username)
        
        # If not ready, spawn (if needed) and show loading screen
        if not status or not status.get('ready'):
            if not status.get('pending'):
                hub_client.spawn_server(username)
            return render_template('loading.html')
        
        # If ready, generate token and redirect immediately
        token_response = hub_client.get_token(username, expires_in=3600, note='Portal auto-login')
        user_token = token_response.get('token')
        
        if not user_token:
            raise Exception("Failed to generate user token")
            
    except Exception as e:
        current_app.logger.error(f"Error ensuring JupyterHub server: {e}")
        flash(f"Error starting your environment: {e}", 'error')
        return redirect(url_for('main.dashboard'))

    # Build target URL with token for automatic authentication
    if current_user.interface == 'codeserver':
        target_path = f"/user/{username}/vscode/"
    else:
        target_path = f"/user/{username}/lab"
    
    # Redirect to JupyterHub with the token as a query parameter
    target_url = f"{jupyterhub_url}{target_path}?token={user_token}"
    
    return redirect(target_url)


@main_bp.route('/launch-vscode')
@login_required
def launch_vscode():
    """Explicitly launch VS Code (code-server)."""
    current_user.interface = 'codeserver'
    db.session.commit()
    return redirect(url_for('main.redirect_to_jupyter'))


# ============ API ROUTES ============

@main_bp.route('/api/users', methods=['GET'])
@admin_required
def api_get_users():
    """Get all users (filtered by permissions)."""
    if current_user.is_superadmin:
        users = User.query.all()
    elif current_user.identity:
        users = User.query.filter_by(identity=current_user.identity).all()
    else:
        users = []
        
    return jsonify([u.to_dict() for u in users])


@main_bp.route('/api/users', methods=['POST'])
@admin_required
def api_create_user():
    """Create a new user."""
    data = request.get_json()
    
    if not data.get('uid'):
        return jsonify({'error': 'UID is required'}), 400
    
    # Permission Checks
    if not current_user.is_superadmin:
        # Admins can only create users in their entity
        data['identity'] = current_user.identity
        # Admins cannot create superadmins
        if data.get('role') == 'superadmin':
             return jsonify({'error': 'Insufficient permissions to create Superadmin'}), 403
    
    if User.query.filter_by(uid=data['uid']).first():
        return jsonify({'error': 'User with this UID already exists'}), 400
    
    user = User(
        uid=data['uid'],
        name=data.get('name'),
        last_name=data.get('last_name'),
        email=data.get('email'),
        manager_uid=data.get('manager_uid'),
        identity=data.get('identity'),
        role=data.get('role', 'dev'),
        interface=data.get('interface', 'jupyterlab'),
        auto_connect=data.get('auto_connect', False),
        date_creation=datetime.utcnow()
    )
    
    # Set password if provided (for dummy auth)
    if data.get('password'):
        user.password_hash = hash_password(data['password'])
    
    # Auto-assign to machine if requested
    if data.get('auto_assign', True):
        balancer = get_balancer(user.identity)
        balancer.assign_user(
            user,
            required_cpu=data.get('cpu', 1),
            required_ram=data.get('ram', 1024),
            required_storage=data.get('storage', 10)
        )
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify(user.to_dict()), 201


@main_bp.route('/api/users/<int:user_id>', methods=['GET'])
@admin_required
def api_get_user(user_id):
    """Get a specific user."""
    user = User.query.get_or_404(user_id)
    if not current_user.is_superadmin and user.identity != current_user.identity:
        return jsonify({'error': 'Access denied'}), 403
    return jsonify(user.to_dict())


@main_bp.route('/api/users/<int:user_id>', methods=['PUT'])
@admin_required
def api_update_user(user_id):
    """Update a user."""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if 'name' in data:
        user.name = data['name']
    if 'last_name' in data:
        user.last_name = data['last_name']
    if 'email' in data:
        user.email = data['email']
    if 'manager_uid' in data:
        user.manager_uid = data['manager_uid']
    if 'identity' in data:
        user.identity = data['identity']
    if 'role' in data:
        user.role = data['role']
    if 'interface' in data:
        user.interface = data['interface']
    if 'auto_connect' in data:
        user.auto_connect = data['auto_connect']
    if 'id_machine' in data:
        user.id_machine = data['id_machine']
    if 'password' in data and data['password']:
        user.password_hash = hash_password(data['password'])
    
    db.session.commit()
    return jsonify(user.to_dict())


@main_bp.route('/api/users/<int:user_id>', methods=['DELETE'])
@admin_required
def api_delete_user(user_id):
    """Delete a user."""
    user = User.query.get_or_404(user_id)
    
    # Release resources before deleting
    balancer = get_balancer()
    balancer.release_user(user)
    
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': 'User deleted'})


@main_bp.route('/api/users/<int:user_id>/assign', methods=['POST'])
@admin_required
def api_assign_user(user_id):
    """Assign a user to a machine using smart balancer."""
    user = User.query.get_or_404(user_id)
    data = request.get_json() or {}
    
    balancer = get_balancer(user.identity)
    machine = balancer.assign_user(
        user,
        required_cpu=data.get('cpu', 1),
        required_ram=data.get('ram', 1024),
        required_storage=data.get('storage', 10)
    )
    
    if machine:
        return jsonify({'message': 'User assigned', 'machine': machine.to_dict()})
    return jsonify({'error': 'No suitable machine found'}), 400


# ============ MACHINE API ============

@main_bp.route('/api/machines', methods=['GET'])
@admin_required
def api_get_machines():
    """Get all machines (filtered)."""
    if current_user.is_superadmin:
        machines = Machine.query.all()
    elif current_user.identity:
        machines = Machine.query.filter_by(identity=current_user.identity).all()
    else:
        machines = []
    return jsonify([m.to_dict() for m in machines])


@main_bp.route('/api/machines', methods=['POST'])
@superadmin_required
def api_create_machine():
    """Create a new machine."""
    data = request.get_json()
    
    machine = Machine(
        url=data.get('url'),
        name=data.get('name'),
        cluster=data.get('cluster'),
        namespace=data.get('namespace'),
        ram_total=data.get('ram_total', 0),
        ram_available=data.get('ram_available', data.get('ram_total', 0)),
        cpu_total=data.get('cpu_total', 0),
        cpu_available=data.get('cpu_available', data.get('cpu_total', 0)),
        storage_total=data.get('storage_total', 0),
        storage_available=data.get('storage_available', data.get('storage_total', 0)),
        identity=data.get('identity')
    )
    
    db.session.add(machine)
    db.session.commit()
    
    return jsonify(machine.to_dict()), 201


@main_bp.route('/api/machines/<int:machine_id>', methods=['PUT'])
@superadmin_required
def api_update_machine(machine_id):
    """Update a machine."""
    machine = Machine.query.get_or_404(machine_id)
    data = request.get_json()
    
    for field in ['url', 'name', 'cluster', 'namespace', 'ram_total', 'ram_available',
                  'cpu_total', 'cpu_available', 'storage_total', 'storage_available', 'identity']:
        if field in data:
            setattr(machine, field, data[field])
    
    db.session.commit()
    return jsonify(machine.to_dict())


@main_bp.route('/api/machines/<int:machine_id>', methods=['DELETE'])
@superadmin_required
def api_delete_machine(machine_id):
    """Delete a machine."""
    machine = Machine.query.get_or_404(machine_id)
    
    # Check if any users are assigned
    if machine.users.count() > 0:
        return jsonify({'error': 'Cannot delete machine with assigned users'}), 400
    
    db.session.delete(machine)
    db.session.commit()
    
    return jsonify({'message': 'Machine deleted'})


@main_bp.route('/api/server/status', methods=['GET'])
@login_required
def api_server_status():
    """Get the status of the current user's notebook server from JupyterHub."""
    try:
        client = get_jupyterhub_client()
        username = current_user.uid
        
        # Get server status from JupyterHub
        status = client.get_server_status(username)
        
        if status and status.get('ready'):
            return jsonify({
                'status': 'running',
                'ready': True,
                'url': status.get('url', '')
            })
        elif status and status.get('pending'):
            return jsonify({
                'status': 'starting',
                'ready': False,
                'message': 'Server is starting...'
            })
        else:
            return jsonify({
                'status': 'stopped',
                'ready': False,
                'message': 'Server is not running'
            })
    except Exception as e:
        current_app.logger.error(f"Error checking server status: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@main_bp.route('/api/server/stop', methods=['POST'])
@login_required
def api_server_stop():
    """Stop the current user's notebook server via JupyterHub API."""
    try:
        client = get_jupyterhub_client()
        username = current_user.uid
        
        # Stop the server via JupyterHub API
        client.stop_server(username)
        return jsonify({'message': 'Server stopping', 'success': True})
    except Exception as e:
        current_app.logger.error(f"Error stopping server: {e}")
        return jsonify({'error': str(e), 'success': False}), 500


@main_bp.route('/api/server/connect')
@login_required
def api_server_connect():
    """Check server status and return redirect URL with token if ready."""
    try:
        client = get_jupyterhub_client()
        username = current_user.uid
        
        status = client.get_server_status(username)
        
        # If ready, generate token and return URL
        if status and status.get('ready'):
            token_response = client.get_token(username, expires_in=3600, note='Portal auto-login')
            user_token = token_response.get('token')
            
            jupyterhub_url = os.environ.get('JUPYTERHUB_PUBLIC_URL', 'http://localhost:8000')
            
            if current_user.interface == 'codeserver':
                target_path = f"/user/{username}/vscode/"
            else:
                target_path = f"/user/{username}/lab"
                
            return jsonify({
                'ready': True,
                'status': 'running',
                'url': f"{jupyterhub_url}{target_path}?token={user_token}"
            })
            
        # If not ready, return status
        state = 'stopped'
        if status:
            if status.get('pending'): state = 'pending'
            elif status.get('ready'): state = 'running' # Should be caught above
        
        return jsonify({
            'ready': False,
            'status': state,
            'message': 'Waiting for server...'
        })
        
    except Exception as e:
        current_app.logger.error(f"Error in connect API: {e}")
        return jsonify({'error': str(e)}), 500

@main_bp.route('/api/server/progress')
@login_required
def api_server_progress():
    """Get spawn progress from JupyterHub."""
    try:
        import requests
        username = current_user.uid
        api_url = current_app.config.get('JUPYTERHUB_API_URL', 'http://jupyterhub:8081/hub/api')
        api_token = current_app.config.get('JUPYTERHUB_API_TOKEN', '')
        
        # Get progress from JupyterHub's progress endpoint
        headers = {
            'Authorization': f'token {api_token}',
            'Content-Type': 'application/json'
        }
        
        # First get server status
        status_url = f"{api_url}/users/{username}"
        status_resp = requests.get(status_url, headers=headers, timeout=5)
        
        if status_resp.status_code == 404:
            return jsonify({
                'progress': 0,
                'message': 'User not found in JupyterHub, creating...',
                'log_messages': []
            })
        
        if status_resp.ok:
            user_data = status_resp.json()
            servers = user_data.get('servers', {})
            default_server = servers.get('', {})
            
            if default_server.get('ready'):
                return jsonify({
                    'progress': 100,
                    'message': 'Server is ready!',
                    'log_messages': ['Server startup complete']
                })
            elif default_server.get('pending'):
                progress_url = default_server.get('progress_url', '')
                return jsonify({
                    'progress': 50,
                    'message': f"Server spawn pending: {default_server.get('pending', 'unknown')}",
                    'log_messages': [f"Spawn state: {default_server.get('pending', 'unknown')}"],
                    'progress_url': progress_url
                })
            else:
                return jsonify({
                    'progress': 10,
                    'message': 'Server not started yet',
                    'log_messages': []
                })
        
        return jsonify({
            'progress': 0,
            'message': 'Checking server status...',
            'log_messages': []
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching progress: {e}")
        return jsonify({
            'progress': 0,
            'message': f'Error: {str(e)}',
            'log_messages': [str(e)]
        })


# ============ ENTITY API ============

@main_bp.route('/api/entities', methods=['GET'])
@admin_required
def api_get_entities():
    """Get all entities."""
    entities = Entity.query.all()
    return jsonify([e.to_dict() for e in entities])


@main_bp.route('/api/entities', methods=['POST'])
@admin_required
def api_create_entity():
    """Create a new entity."""
    data = request.get_json()
    
    entity = Entity(
        name=data.get('name'),
        quota=data.get('quota')
    )
    
    db.session.add(entity)
    db.session.commit()
    
    return jsonify(entity.to_dict()), 201
