"""Smart balancer for assigning users to JupyterHub machines based on available resources."""
from models import db, Machine, User


class SmartBalancer:
    """Load balancer that assigns users to machines based on available resources."""
    
    def __init__(self, entity_id=None):
        """Initialize balancer, optionally filtering by entity."""
        self.entity_id = entity_id
    
    def get_available_machines(self):
        """Get all machines with available resources, optionally filtered by entity."""
        query = Machine.query.filter(
            Machine.ram_available > 0,
            Machine.cpu_available > 0
        )
        
        if self.entity_id:
            query = query.filter(Machine.identity == self.entity_id)
        
        return query.all()
    
    def calculate_score(self, machine, required_cpu=1, required_ram=1024, required_storage=10):
        """
        Calculate a score for a machine based on its available resources.
        Higher score = better choice.
        
        Args:
            machine: Machine instance
            required_cpu: CPU cores needed
            required_ram: RAM in MB needed
            required_storage: Storage in GB needed
        
        Returns:
            float: Score from 0-100, or -1 if machine can't fulfill requirements
        """
        # Check if machine can fulfill requirements
        if (machine.cpu_available or 0) < required_cpu:
            return -1
        if (machine.ram_available or 0) < required_ram:
            return -1
        if (machine.storage_available or 0) < required_storage:
            return -1
        
        # Calculate utilization percentages (lower is better for assignment)
        cpu_util = 1 - ((machine.cpu_available or 0) / max(machine.cpu_total or 1, 1))
        ram_util = 1 - ((machine.ram_available or 0) / max(machine.ram_total or 1, 1))
        storage_util = 1 - ((machine.storage_available or 0) / max(machine.storage_total or 1, 1))
        
        # Score: prefer less utilized machines (weighted average)
        avg_util = (cpu_util * 0.4 + ram_util * 0.4 + storage_util * 0.2)
        score = (1 - avg_util) * 100
        
        return score
    
    def select_best_machine(self, required_cpu=1, required_ram=1024, required_storage=10):
        """
        Select the best machine for a new user based on available resources.
        
        Args:
            required_cpu: CPU cores needed
            required_ram: RAM in MB needed  
            required_storage: Storage in GB needed
        
        Returns:
            Machine instance or None if no suitable machine found
        """
        machines = self.get_available_machines()
        
        if not machines:
            return None
        
        best_machine = None
        best_score = -1
        
        for machine in machines:
            score = self.calculate_score(machine, required_cpu, required_ram, required_storage)
            if score > best_score:
                best_score = score
                best_machine = machine
        
        return best_machine
    
    def assign_user(self, user, required_cpu=1, required_ram=1024, required_storage=10):
        """
        Assign a user to the best available machine.
        
        Args:
            user: User instance
            required_cpu: CPU cores needed
            required_ram: RAM in MB needed
            required_storage: Storage in GB needed
        
        Returns:
            Machine instance if assigned, None if no suitable machine
        """
        # Use user's entity if set, otherwise use balancer's entity
        entity_id = user.identity or self.entity_id
        if entity_id:
            self.entity_id = entity_id
        
        machine = self.select_best_machine(required_cpu, required_ram, required_storage)
        
        if machine:
            # Assign user to machine
            user.id_machine = machine.id_machine
            user.cpu = required_cpu
            user.ram = required_ram
            user.stockage = required_storage
            
            # Update machine's available resources
            machine.cpu_available = (machine.cpu_available or 0) - required_cpu
            machine.ram_available = (machine.ram_available or 0) - required_ram
            machine.storage_available = (machine.storage_available or 0) - required_storage
            
            db.session.commit()
        
        return machine
    
    def release_user(self, user):
        """
        Release a user's resources from their assigned machine.
        
        Args:
            user: User instance
        """
        if user.id_machine and user.machine:
            machine = user.machine
            
            # Return resources to machine
            machine.cpu_available = (machine.cpu_available or 0) + (user.cpu or 0)
            machine.ram_available = (machine.ram_available or 0) + (user.ram or 0)
            machine.storage_available = (machine.storage_available or 0) + (user.stockage or 0)
            
            # Clear user assignment
            user.id_machine = None
            user.cpu = None
            user.ram = None
            user.stockage = None
            
            db.session.commit()


def get_balancer(entity_id=None):
    """Factory function to create a balancer instance."""
    return SmartBalancer(entity_id=entity_id)
