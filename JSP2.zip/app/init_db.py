import os
from app import app
from models import db, Entity, Machine, User
from auth import hash_password

def init_db():
    print("Initializing database...")
    with app.app_context():
        # Ensure tables exist
        db.create_all()
        
        # 1. Create Entities (Organizations)
        print("Creating Entities...")
        eng = Entity.query.filter_by(name='Engineering').first()
        if not eng:
            eng = Entity(name='Engineering', quota=20)
            db.session.add(eng)
        
        research = Entity.query.filter_by(name='Research').first()
        if not research:
            research = Entity(name='Research', quota=10)
            db.session.add(research)
        
        db.session.commit()
        
        # 2. Create Machines
        print("Creating Machines...")
        # Note: In a real setup, URL might be the external URL of the Hub or specific spawn URL
        mach1 = Machine.query.filter_by(name='CPU Cluster 1').first()
        if not mach1:
            mach1 = Machine(
                name='CPU Cluster 1', 
                url='http://localhost:8000', 
                cluster='us-east-1',
                identity=eng.identity,
                cpu_total=64, cpu_available=60,
                ram_total=128000, ram_available=120000,
                storage_total=1000, storage_available=900
            )
            db.session.add(mach1)

        mach2 = Machine.query.filter_by(name='GPU Cluster A').first()
        if not mach2:
            mach2 = Machine(
                name='GPU Cluster A', 
                url='http://localhost:8000', 
                cluster='us-west-2',
                identity=research.identity,
                cpu_total=32, cpu_available=32,
                ram_total=64000, ram_available=64000,
                storage_total=500, storage_available=500
            )
            db.session.add(mach2)
            
        db.session.commit()
        
        # 3. Create Users
        print("Creating Users...")
        
        # Superadmin
        if not User.query.filter_by(uid='superadmin').first():
            u = User(
                uid='superadmin',
                name='System', last_name='Admin',
                email='admin@example.com',
                role='superadmin',
                password_hash=hash_password('admin123'),
                interface='jupyterlab'
            )
            db.session.add(u)
            print("  Created user: superadmin / admin123")

        # Entity Admin (Engineering)
        if not User.query.filter_by(uid='eng_manager').first():
            u = User(
                uid='eng_manager',
                name='Engineering', last_name='Manager',
                email='manager@eng.com',
                role='admin',
                identity=eng.identity,
                password_hash=hash_password('manager123'),
                interface='jupyterlab'
            )
            db.session.add(u)
            print("  Created user: eng_manager / manager123")

        # Developer (assigned to CPU Cluster)
        if not User.query.filter_by(uid='dev_user').first():
            u = User(
                uid='dev_user',
                name='Jane', last_name='Dev',
                email='jane@eng.com',
                role='dev',
                identity=eng.identity,
                id_machine=mach1.id_machine,
                password_hash=hash_password('dev123'),
                interface='codeserver',
                auto_connect=False,
                cpu=2, ram=4096, stockage=20
            )
            db.session.add(u)
            print("  Created user: dev_user / dev123")

        db.session.commit()
        print("Database initialization complete!")

if __name__ == '__main__':
    init_db()
