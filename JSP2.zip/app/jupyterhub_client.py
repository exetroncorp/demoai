"""JupyterHub API client for spawning and managing user notebooks."""
import requests
from flask import current_app


class JupyterHubClient:
    """Client for interacting with JupyterHub API."""
    
    def __init__(self, api_url=None, api_token=None):
        """
        Initialize JupyterHub client.
        
        Args:
            api_url: JupyterHub API base URL
            api_token: API token for authentication
        """
        self.api_url = api_url or current_app.config.get('JUPYTERHUB_API_URL')
        self.api_token = api_token or current_app.config.get('JUPYTERHUB_API_TOKEN')
        self.timeout = 30
    
    @property
    def headers(self):
        """Get request headers with authentication."""
        return {
            'Authorization': f'token {self.api_token}',
            'Content-Type': 'application/json'
        }
    
    def _request(self, method, endpoint, **kwargs):
        """Make an API request."""
        url = f"{self.api_url.rstrip('/')}/{endpoint.lstrip('/')}"
        kwargs.setdefault('headers', self.headers)
        kwargs.setdefault('timeout', self.timeout)
        
        try:
            response = requests.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else {}
        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"JupyterHub API error: {e}")
            raise
    
    def get_user(self, username):
        """Get user information from JupyterHub."""
        return self._request('GET', f'/users/{username}')
    
    def create_user(self, username):
        """Create a user in JupyterHub."""
        return self._request('POST', '/users', json={'usernames': [username]})
    
    def delete_user(self, username):
        """Delete a user from JupyterHub."""
        return self._request('DELETE', f'/users/{username}')
    
    def spawn_server(self, username, server_name='', options=None):
        """
        Spawn a notebook server for a user.
        
        Args:
            username: User's username
            server_name: Named server (empty for default)
            options: Spawn options (profile, resources, etc.)
        """
        endpoint = f'/users/{username}/servers/{server_name}' if server_name else f'/users/{username}/server'
        return self._request('POST', endpoint, json=options or {})
    
    def stop_server(self, username, server_name=''):
        """Stop a user's notebook server."""
        endpoint = f'/users/{username}/servers/{server_name}' if server_name else f'/users/{username}/server'
        return self._request('DELETE', endpoint)
    
    def get_server_status(self, username, server_name=''):
        """Get the status of a user's server."""
        user = self.get_user(username)
        servers = user.get('servers', {})
        
        if server_name:
            return servers.get(server_name, {})
        return servers.get('', {})
    
    def get_all_users(self):
        """Get all users from JupyterHub."""
        return self._request('GET', '/users')
    
    def get_hub_info(self):
        """Get JupyterHub information."""
        return self._request('GET', '/info')
    
    def get_token(self, username, expires_in=3600, note='Portal generated token'):
        """
        Generate an API token for a user.
        
        Args:
            username: User's username
            expires_in: Token expiration in seconds
            note: Description for the token
        """
        return self._request('POST', f'/users/{username}/tokens', json={
            'expires_in': expires_in,
            'note': note
        })


def get_jupyterhub_client():
    """Factory function to create a JupyterHub client."""
    return JupyterHubClient()
