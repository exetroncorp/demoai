import os
import dockerspawner

c = get_config()

# Use DockerSpawner
c.JupyterHub.spawner_class = 'dockerspawner.DockerSpawner'

# The image to use for single-user servers
c.DockerSpawner.image = 'jupyterhub-user-vscode'

# JupyterHub needs to be accessible from the spawned containers
network_name = os.environ.get('DOCKER_NETWORK_NAME', 'jupyterhub_network')
c.DockerSpawner.network_name = network_name

# Tell the single-user containers where to find the hub
# Since they are on the same docker network, they can use the hub's container name
c.DockerSpawner.hub_connect_ip = 'jupyterhub'

# The hub's IP address inside the container
c.JupyterHub.hub_ip = '0.0.0.0'

# Increase header limits for Configurable HTTP Proxy and Tornado
# This prevents HTTP 431 (Request Header Fields Too Large)

# Also increase header limits for the spawned single-user servers
# AND DISABLE AUTHENTICATION on the single-user server to prevent OAuth loops

# Authentication - Dummy for now
# Authentication - Dummy for now
c.JupyterHub.authenticator_class = 'dummy'

# DISABLE authentication on the single-user server to prevent OAuth loops
# Using empty strings without extra quotes, and setting IP
c.DockerSpawner.args = [
    '--ServerApp.token=', 
    '--ServerApp.password=', 
    '--ServerApp.disable_check_xsrf=True',
    '--ServerApp.ip=0.0.0.0'
]


# OAuth state cookie cleanup - prevents cookie explosion causing HTTP 431
# Reduce the OAuth state TTL to clean up cookies faster
c.JupyterHub.oauth_state_ttl = 600  # 10 minutes
c.JupyterHub.cookie_max_age_days = 1 # Expire cookies daily
# Configure Authenticator to clean up state
c.Authenticator.delete_invalid_users = True

# Set up the UI to include VS Code
# This is handled by jupyter-vscode-proxy in the user image.

# Persistent storage for users
notebook_dir = os.environ.get('DOCKER_NOTEBOOK_DIR', '/home/jovyan/work')
c.DockerSpawner.notebook_dir = notebook_dir
c.DockerSpawner.volumes = { 'jupyterhub-user-{username}': notebook_dir }

# Remove containers when they stop - disable for debugging 500
c.DockerSpawner.remove = False

# Debugging
c.JupyterHub.log_level = 'DEBUG'
c.DockerSpawner.debug = True

# Service API token for the portal
c.JupyterHub.services = [
    {
        'name': 'portal',
        'api_token': 'portal-api-token',
        'admin': True,
    }
]

