# End-to-End Workflow Scenario: Launching Code Server

This diagram details the exact sequence of events when a user logs in and launches their VS Code environment.

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant Browser
    participant Portal as Management Portal (Flask)
    participant DB as Portal DB
    participant Hub as JupyterHub API
    participant Spawner as DockerSpawner
    participant Container as User Container (Code Server)

    %% PHASE 1: AUTHENTICATION
    Note over User, DB: Phase 1: Authentication
    
    User->>Browser: Access Portal URL
    Browser->>Portal: GET /
    Portal-->>Browser: Redirect to /login
    
    User->>Browser: Enter Credentials
    Browser->>Portal: POST /login
    Portal->>DB: query.filter_by(uid=...)
    DB-->>Portal: User Found (Role: Dev)
    Portal-->>Browser: Set Session Cookie & Redirect to /dashboard
    
    Browser->>Portal: GET /dashboard
    Portal->>Hub: Check Server Status (Background)
    Portal-->>Browser: Render Dashboard with "Launch" button

    %% PHASE 2: SPAWNING
    Note over User, Spawner: Phase 2: Spawning Environment
    
    User->>Browser: Click "Launch VS Code"
    Browser->>Portal: GET /launch-vscode
    Portal->>DB: Set interface='codeserver'
    Portal-->>Browser: Redirect to /redirect-to-jupyter
    
    Browser->>Portal: GET /redirect-to-jupyter
    Portal->>Hub: GET /users/{user}/server (Check Status)
    
    alt Server is STOPPED
        Hub-->>Portal: Status: Ready=False, Pending=False
        Portal->>Hub: POST /users/{user}/server (Spawn)
        Hub->>Spawner: Create & Start Container
        Portal-->>Browser: Render loading.html (Starting Screen)
        
        loop Adaptive Polling (Client-Side)
            Browser->>Portal: GET /api/server/connect
            Portal->>Hub: GET /users/{user}/server
            Hub-->>Portal: Status: Pending/Ready
            
            alt Still Pending
                Portal-->>Browser: {ready: false, status: "starting"}
                Browser->>Browser: Wait 2s
            else Ready
                Portal->>Hub: POST /users/{user}/tokens (Generate One-Time Token)
                Hub-->>Portal: {token: "abc-123-xyz"}
                Portal-->>Browser: {ready: true, url: "...?token=abc-123"}
            end
        end
    else Server is RUNNING
        Hub-->>Portal: Status: Ready=True
        Portal->>Hub: POST /users/{user}/tokens
        Hub-->>Portal: {token: "abc-123-xyz"}
        Portal-->>Browser: Redirect directly to Hub URL
    end

    %% PHASE 3: HANDOFF
    Note over Browser, Container: Phase 3: Connection & Proxy
    
    Browser->>Hub: GET /user/{user}/vscode/?token=abc-123
    Hub->>Hub: Validate Token & Authorize
    Hub->>Container: Proxy Connection to Port 80
    Container-->>Browser: Load VS Code Interface
```

![Workflow Diagram (PNG)](file:///d:/WhatsApp%20Unknown%202026-01-08%20at%2018.12.40/workflow.png)
![Workflow Diagram (SVG)](file:///d:/WhatsApp%20Unknown%202026-01-08%20at%2018.12.40/workflow.svg)

## Key Technical Steps

1.  **Portal Authentication**: The Portal handles the primary login (DB check). JupyterHub is configured with `DummyAuthenticator` (or similar) but we bypass its login screen.
2.  **Smart Spawning**: The Portal checks status first. If stopped, it triggers the spawn and serves a custom waiting screen (`loading.html`) which polls the backend.
3.  **Proxy Registration**: As the Spawner starts the container, JupyterHub automatically registers a new route (e.g., `/user/dave`) with the **Configurable HTTP Proxy**. This maps the public URL to the internal container IP.
4.  **Token Generation**: Once the route is active, the Portal uses its service token to request a session token for the user.
5.  **Seamless Handoff**: The user is redirected to the Hub URL. The Proxy intercepts the request, checks the token (via Hub), and forwards traffic to the user's specific container.
