import * as vscode from 'vscode';
import { TargetPlatform } from '../types/openVsx';

/**
 * Get the Open VSX registry base URL from settings
 */
export function getRegistryUrl(): string {
    const config = vscode.workspace.getConfiguration('openVsx');
    return config.get<string>('registryUrl', 'https://open-vsx.org');
}

/**
 * Get the page size from settings
 */
export function getPageSize(): number {
    const config = vscode.workspace.getConfiguration('openVsx');
    return config.get<number>('pageSize', 20);
}

/**
 * Detect the current target platform based on OS and architecture
 */
export function detectTargetPlatform(): TargetPlatform {
    const platform = process.platform;
    const arch = process.arch;

    switch (platform) {
        case 'win32':
            switch (arch) {
                case 'x64': return 'win32-x64';
                case 'ia32': return 'win32-ia32';
                case 'arm64': return 'win32-arm64';
                default: return 'win32-x64';
            }
        case 'linux':
            switch (arch) {
                case 'x64': return 'linux-x64';
                case 'arm64': return 'linux-arm64';
                case 'arm': return 'linux-armhf';
                default: return 'linux-x64';
            }
        case 'darwin':
            switch (arch) {
                case 'x64': return 'darwin-x64';
                case 'arm64': return 'darwin-arm64';
                default: return 'darwin-x64';
            }
        default:
            return 'universal';
    }
}

/**
 * Build URL with query parameters
 */
export function buildUrl(baseUrl: string, path: string, params?: Record<string, string | number | boolean | undefined>): string {
    const url = new URL(path, baseUrl);

    if (params) {
        Object.entries(params).forEach(([key, value]) => {
            if (value !== undefined && value !== null) {
                url.searchParams.append(key, String(value));
            }
        });
    }

    return url.toString();
}

/**
 * Format download count for display
 */
export function formatDownloadCount(count: number | undefined): string {
    if (count === undefined) return '0';
    if (count >= 1000000) {
        return `${(count / 1000000).toFixed(1)}M`;
    }
    if (count >= 1000) {
        return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
}

/**
 * Format rating for display (stars)
 */
export function formatRating(rating: number | undefined): string {
    if (rating === undefined) return '☆☆☆☆☆';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating - fullStars >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

    return '★'.repeat(fullStars) + (hasHalfStar ? '½' : '') + '☆'.repeat(emptyStars);
}

/**
 * Get extension identifier in format namespace.name
 */
export function getExtensionId(namespace: string, name: string): string {
    return `${namespace}.${name}`.toLowerCase();
}

/**
 * Parse extension identifier
 */
export function parseExtensionId(extensionId: string): { namespace: string; name: string } | null {
    const parts = extensionId.split('.');
    if (parts.length < 2) return null;

    const namespace = parts[0];
    const name = parts.slice(1).join('.');
    return { namespace, name };
}

/**
 * Check if an error is an API error with specific status
 */
export function isApiError(error: unknown): error is { status: number; message: string } {
    return typeof error === 'object' && error !== null && 'status' in error && 'message' in error;
}

/**
 * Create a debounced function
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
    func: T,
    wait: number
): (...args: Parameters<T>) => void {
    let timeout: ReturnType<typeof setTimeout> | undefined;

    return (...args: Parameters<T>) => {
        if (timeout) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(() => func(...args), wait);
    };
}

/**
 * Escape HTML for safe display
 */
export function escapeHtml(text: string): string {
    const htmlEscapes: Record<string, string> = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    };
    return text.replace(/[&<>"']/g, char => htmlEscapes[char]);
}

/**
 * Get a nonce for webview security
 */
export function getNonce(): string {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < 32; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}
