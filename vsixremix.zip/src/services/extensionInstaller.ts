import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { OpenVsxClient } from '../api/openVsxClient';
import { Extension } from '../types/openVsx';
import { detectTargetPlatform } from '../utils/helpers';

/**
 * Service for installing extensions from Open VSX
 */
export class ExtensionInstaller {
    private client: OpenVsxClient;
    private outputChannel: vscode.OutputChannel;

    constructor(client: OpenVsxClient) {
        this.client = client;
        this.outputChannel = vscode.window.createOutputChannel('Open VSX Installer');
    }

    /**
     * Install an extension by downloading and installing the .vsix file
     */
    async installExtension(ext: Extension): Promise<boolean> {
        const extensionId = `${ext.namespace}.${ext.name}`;

        return vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: `Installing ${ext.displayName || ext.name}...`,
            cancellable: false
        }, async (progress) => {
            try {
                // Step 1: Get download URL
                progress.report({ message: 'Finding download URL...' });

                let downloadUrl = this.client.getDownloadUrl(ext);

                // If no direct download URL, try to get it from the extension metadata
                if (!downloadUrl) {
                    this.outputChannel.appendLine(`No direct download URL found for ${extensionId}`);

                    // Try to fetch with platform-specific version
                    const platform = detectTargetPlatform();
                    try {
                        const platformExt = await this.client.getExtensionByPlatform(
                            ext.namespace,
                            ext.name,
                            platform
                        );
                        downloadUrl = this.client.getDownloadUrl(platformExt);
                    } catch {
                        this.outputChannel.appendLine(`No platform-specific version for ${platform}, using universal`);
                    }
                }

                if (!downloadUrl) {
                    throw new Error(`No download URL available for ${extensionId}`);
                }

                this.outputChannel.appendLine(`Download URL: ${downloadUrl}`);

                // Step 2: Download the .vsix file
                progress.report({ message: 'Downloading extension...' });

                const vsixData = await this.client.downloadFile(downloadUrl);
                this.outputChannel.appendLine(`Downloaded ${vsixData.length} bytes`);

                // Step 3: Save to temp file
                const tempDir = os.tmpdir();
                const vsixFileName = `${extensionId}-${ext.version}.vsix`;
                const vsixPath = path.join(tempDir, vsixFileName);

                fs.writeFileSync(vsixPath, vsixData);
                this.outputChannel.appendLine(`Saved to: ${vsixPath}`);

                // Step 4: Install using VS Code API
                progress.report({ message: 'Installing extension...' });

                await vscode.commands.executeCommand(
                    'workbench.extensions.installExtension',
                    vscode.Uri.file(vsixPath)
                );

                // Step 5: Cleanup
                try {
                    fs.unlinkSync(vsixPath);
                } catch {
                    // Ignore cleanup errors
                }

                this.outputChannel.appendLine(`Successfully installed ${extensionId}`);
                vscode.window.showInformationMessage(
                    `Successfully installed ${ext.displayName || ext.name} v${ext.version}`
                );

                return true;

            } catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                this.outputChannel.appendLine(`Failed to install ${extensionId}: ${errorMessage}`);
                this.outputChannel.show();

                vscode.window.showErrorMessage(
                    `Failed to install ${ext.displayName || ext.name}: ${errorMessage}`
                );

                return false;
            }
        });
    }

    /**
     * Install extension by ID (namespace.name)
     */
    async installExtensionById(extensionId: string): Promise<boolean> {
        const parts = extensionId.split('.');
        if (parts.length < 2) {
            vscode.window.showErrorMessage(`Invalid extension ID: ${extensionId}`);
            return false;
        }

        const namespace = parts[0];
        const name = parts.slice(1).join('.');

        try {
            const ext = await this.client.getExtension(namespace, name);
            return this.installExtension(ext);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            vscode.window.showErrorMessage(`Failed to find extension ${extensionId}: ${errorMessage}`);
            return false;
        }
    }

    /**
     * Install a specific version of an extension
     */
    async installExtensionVersion(
        namespace: string,
        name: string,
        version: string
    ): Promise<boolean> {
        try {
            const ext = await this.client.getExtensionVersion(namespace, name, version);
            return this.installExtension(ext);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            vscode.window.showErrorMessage(
                `Failed to find ${namespace}.${name}@${version}: ${errorMessage}`
            );
            return false;
        }
    }

    /**
     * Show output channel
     */
    showOutput(): void {
        this.outputChannel.show();
    }

    /**
     * Dispose resources
     */
    dispose(): void {
        this.outputChannel.dispose();
    }
}
