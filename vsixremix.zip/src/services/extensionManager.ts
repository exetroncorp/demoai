import * as vscode from 'vscode';
import { OpenVsxClient } from '../api/openVsxClient';
import { Extension } from '../types/openVsx';
import { getExtensionId } from '../utils/helpers';

/**
 * Represents an installed extension with Open VSX metadata
 */
export interface InstalledExtension {
    id: string;
    name: string;
    displayName: string;
    version: string;
    publisher: string;
    installedVersion: string;
    latestVersion?: string;
    hasUpdate: boolean;
    openVsxData?: Extension;
    iconPath?: vscode.Uri | string;
}

/**
 * Service for managing installed extensions and checking updates
 */
export class ExtensionManager {
    private client: OpenVsxClient;
    public pendingUninstalls: Set<string> = new Set();

    constructor(client: OpenVsxClient) {
        this.client = client;
    }

    /**
     * Get all installed extensions
     */
    getInstalledExtensions(): vscode.Extension<unknown>[] {
        return vscode.extensions.all.filter(ext => {
            // Filter out built-in extensions and pending uninstalls
            return !ext.packageJSON.isBuiltin && !this.pendingUninstalls.has(ext.id.toLowerCase());
        });
    }

    /**
     * Check if an extension is installed
     */
    isInstalled(namespace: string, name: string): boolean {
        const id = getExtensionId(namespace, name);
        if (this.pendingUninstalls.has(id.toLowerCase())) {
            return false;
        }
        return vscode.extensions.getExtension(id) !== undefined;
    }

    /**
     * Get installed version of an extension
     */
    getInstalledVersion(namespace: string, name: string): string | null {
        const id = getExtensionId(namespace, name);
        const ext = vscode.extensions.getExtension(id);
        return ext?.packageJSON.version || null;
    }

    /**
     * Get icon path from extension
     */
    getIconPath(ext: vscode.Extension<unknown>): vscode.Uri | string | undefined {
        if (ext.packageJSON.icon) {
            return vscode.Uri.joinPath(ext.extensionUri, ext.packageJSON.icon);
        }
        return undefined;
    }

    /**
     * Check for updates for all installed extensions
     */
    async checkAllUpdates(): Promise<InstalledExtension[]> {
        const installedExtensions = this.getInstalledExtensions();
        const results: InstalledExtension[] = [];

        await vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: 'Checking for updates...',
            cancellable: true
        }, async (progress, token) => {
            const total = installedExtensions.length;
            let current = 0;

            for (const ext of installedExtensions) {
                if (token.isCancellationRequested) {
                    break;
                }

                current++;
                progress.report({
                    message: `${current}/${total}: ${ext.packageJSON.displayName || ext.id}`,
                    increment: 100 / total
                });

                const result = await this.checkExtensionUpdate(ext);
                results.push(result);
            }
        });

        return results;
    }

    /**
     * Check for update for a single extension
     */
    private async checkExtensionUpdate(ext: vscode.Extension<unknown>): Promise<InstalledExtension> {
        const parts = ext.id.split('.');
        const namespace = parts[0];
        const name = parts.slice(1).join('.');
        const installedVersion = ext.packageJSON.version;

        const result: InstalledExtension = {
            id: ext.id,
            name: name,
            displayName: ext.packageJSON.displayName || name,
            version: installedVersion,
            publisher: namespace,
            installedVersion: installedVersion,
            hasUpdate: false,
            iconPath: this.getIconPath(ext)
        };

        try {
            const openVsxExt = await this.client.getExtension(namespace, name);
            result.openVsxData = openVsxExt;
            result.latestVersion = openVsxExt.version;
            result.hasUpdate = this.compareVersions(installedVersion, openVsxExt.version) < 0;
        } catch {
            // Extension not found in Open VSX
        }

        return result;
    }

    /**
     * Get extensions with available updates
     */
    async getExtensionsWithUpdates(): Promise<InstalledExtension[]> {
        const all = await this.checkAllUpdates();
        return all.filter(ext => ext.hasUpdate);
    }

    /**
     * Compare two version strings
     * Returns: -1 if v1 < v2, 0 if v1 == v2, 1 if v1 > v2
     */
    public compareVersions(v1: string, v2: string): number {
        const parts1 = v1.split('.').map(p => parseInt(p, 10) || 0);
        const parts2 = v2.split('.').map(p => parseInt(p, 10) || 0);

        const maxLength = Math.max(parts1.length, parts2.length);

        for (let i = 0; i < maxLength; i++) {
            const p1 = parts1[i] || 0;
            const p2 = parts2[i] || 0;

            if (p1 < p2) return -1;
            if (p1 > p2) return 1;
        }

        return 0;
    }

    /**
     * Uninstall an extension
     */
    async uninstallExtension(extensionId: string): Promise<boolean> {
        console.log(`ExtensionManager: Uninstalling ${extensionId}`);
        try {
            await vscode.commands.executeCommand(
                'workbench.extensions.uninstallExtension',
                extensionId
            );

            this.pendingUninstalls.add(extensionId.toLowerCase());

            const reload = 'Reload Now';
            vscode.window.showInformationMessage(
                `Uninstalled ${extensionId}. Please reload the window to complete the process.`,
                reload
            ).then(selection => {
                if (selection === reload) {
                    vscode.commands.executeCommand('workbench.action.reloadWindow');
                }
            });

            return true;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            vscode.window.showErrorMessage(`Failed to uninstall ${extensionId}: ${errorMessage}`);
            return false;
        }
    }
}
