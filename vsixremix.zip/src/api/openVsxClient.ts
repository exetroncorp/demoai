import * as https from 'https';
import * as http from 'http';
import { URL } from 'url';
import {
    SearchResult,
    SearchParams,
    QueryResult,
    QueryParams,
    Extension,
    Namespace,
    NamespaceDetails,
    Versions,
    VersionReferences,
    ReviewList,
    RegistryVersion
} from '../types/openVsx';
import { buildUrl } from '../utils/helpers';

/**
 * Open VSX Registry API Client
 * Implements only GET endpoints (no POST operations)
 */
export class OpenVsxClient {
    private baseUrl: string;

    constructor(baseUrl: string = 'https://open-vsx.org') {
        this.baseUrl = baseUrl.replace(/\/$/, ''); // Remove trailing slash
    }

    /**
     * Update the base URL
     */
    setBaseUrl(url: string): void {
        this.baseUrl = url.replace(/\/$/, '');
    }

    /**
     * Make a GET request to the API
     */
    private async get<T>(url: string): Promise<T> {
        return new Promise((resolve, reject) => {
            const parsedUrl = new URL(url);
            const protocol = parsedUrl.protocol === 'https:' ? https : http;

            const options: https.RequestOptions = {
                hostname: parsedUrl.hostname,
                port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
                path: parsedUrl.pathname + parsedUrl.search,
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'User-Agent': 'VSCode-OpenVSX-Extension/1.0.0'
                }
            };

            const req = protocol.request(options, (res) => {
                let data = '';

                res.on('data', (chunk) => {
                    data += chunk;
                });

                res.on('end', () => {
                    if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                        try {
                            resolve(JSON.parse(data) as T);
                        } catch {
                            reject(new Error('Failed to parse response JSON'));
                        }
                    } else if (res.statusCode === 404) {
                        reject({ status: 404, message: 'Not found' });
                    } else if (res.statusCode === 429) {
                        const retryAfter = res.headers['x-rate-limit-retry-after-seconds'];
                        reject({
                            status: 429,
                            message: `Rate limit exceeded. Retry after ${retryAfter || 'some'} seconds`
                        });
                    } else {
                        reject({
                            status: res.statusCode || 500,
                            message: `Request failed with status ${res.statusCode}`
                        });
                    }
                });
            });

            req.on('error', (error) => {
                reject(error);
            });

            req.end();
        });
    }

    /**
     * Download a file (e.g., .vsix) to a buffer
     */
    async downloadFile(url: string): Promise<Buffer> {
        return new Promise((resolve, reject) => {
            const parsedUrl = new URL(url);
            const protocol = parsedUrl.protocol === 'https:' ? https : http;

            const options: https.RequestOptions = {
                hostname: parsedUrl.hostname,
                port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
                path: parsedUrl.pathname + parsedUrl.search,
                method: 'GET',
                headers: {
                    'User-Agent': 'VSCode-OpenVSX-Extension/1.0.0'
                }
            };

            const handleResponse = (res: http.IncomingMessage) => {
                // Handle redirects
                if (res.statusCode === 302 || res.statusCode === 301) {
                    const redirectUrl = res.headers.location;
                    if (redirectUrl) {
                        this.downloadFile(redirectUrl)
                            .then(resolve)
                            .catch(reject);
                        return;
                    }
                }

                if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                    const chunks: Buffer[] = [];
                    res.on('data', (chunk) => chunks.push(chunk));
                    res.on('end', () => resolve(Buffer.concat(chunks)));
                } else {
                    reject({
                        status: res.statusCode || 500,
                        message: `Download failed with status ${res.statusCode}`
                    });
                }
            };

            const req = protocol.request(options, handleResponse);
            req.on('error', reject);
            req.end();
        });
    }

    // ==================== Search API ====================

    /**
     * Search extensions via text query
     * GET /api/-/search
     */
    async search(params: SearchParams): Promise<SearchResult> {
        const url = buildUrl(this.baseUrl, '/api/-/search', params as Record<string, string | number | boolean>);
        return this.get<SearchResult>(url);
    }

    // ==================== Query API ====================

    /**
     * Query extensions by various parameters
     * GET /api/-/query
     */
    async query(params: QueryParams): Promise<QueryResult> {
        const url = buildUrl(this.baseUrl, '/api/-/query', params as Record<string, string | number | boolean>);
        return this.get<QueryResult>(url);
    }

    /**
     * Query extensions (v2 API)
     * GET /api/v2/-/query
     */
    async queryV2(params: QueryParams): Promise<QueryResult> {
        const url = buildUrl(this.baseUrl, '/api/v2/-/query', params as Record<string, string | number | boolean>);
        return this.get<QueryResult>(url);
    }

    // ==================== Namespace API ====================

    /**
     * Get namespace metadata
     * GET /api/{namespace}
     */
    async getNamespace(namespace: string): Promise<Namespace> {
        const url = `${this.baseUrl}/api/${encodeURIComponent(namespace)}`;
        return this.get<Namespace>(url);
    }

    /**
     * Get namespace details with extensions
     * GET /api/{namespace}/details
     */
    async getNamespaceDetails(namespace: string): Promise<NamespaceDetails> {
        const url = `${this.baseUrl}/api/${encodeURIComponent(namespace)}/details`;
        return this.get<NamespaceDetails>(url);
    }

    // ==================== Extension API ====================

    /**
     * Get latest version of an extension
     * GET /api/{namespace}/{extension}
     */
    async getExtension(namespace: string, extension: string): Promise<Extension> {
        const url = `${this.baseUrl}/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}`;
        return this.get<Extension>(url);
    }

    /**
     * Get specific version of an extension
     * GET /api/{namespace}/{extension}/{version}
     */
    async getExtensionVersion(namespace: string, extension: string, version: string): Promise<Extension> {
        const url = `${this.baseUrl}/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}/${encodeURIComponent(version)}`;
        return this.get<Extension>(url);
    }

    /**
     * Get extension for specific target platform
     * GET /api/{namespace}/{extension}/{targetPlatform}
     */
    async getExtensionByPlatform(namespace: string, extension: string, targetPlatform: string): Promise<Extension> {
        const url = `${this.baseUrl}/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}/${encodeURIComponent(targetPlatform)}`;
        return this.get<Extension>(url);
    }

    /**
     * Get extension for specific target platform and version
     * GET /api/{namespace}/{extension}/{targetPlatform}/{version}
     */
    async getExtensionByPlatformVersion(
        namespace: string,
        extension: string,
        targetPlatform: string,
        version: string
    ): Promise<Extension> {
        const url = `${this.baseUrl}/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}/${encodeURIComponent(targetPlatform)}/${encodeURIComponent(version)}`;
        return this.get<Extension>(url);
    }

    // ==================== Versions API ====================

    /**
     * Get all versions of an extension
     * GET /api/{namespace}/{extension}/versions
     */
    async getVersions(namespace: string, extension: string, size?: number, offset?: number): Promise<Versions> {
        const url = buildUrl(
            this.baseUrl,
            `/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}/versions`,
            { size, offset }
        );
        return this.get<Versions>(url);
    }

    /**
     * Get all versions of an extension with full metadata (including timestamps)
     * Uses GET /api/-/query?extensionId=...&includeAllVersions=true
     */
    async getVersionsFromQuery(namespace: string, extension: string, size: number = 500): Promise<Extension[]> {
        const params: QueryParams = {
            extensionId: `${namespace}.${extension}`,
            includeAllVersions: true,
            size: size
        };

        // Note: We use query (v1) instead of queryV2 or specific endpoints because it supports includeAllVersions nicely
        const result = await this.query(params);
        return result.extensions || [];
    }

    /**
     * Get version references of an extension
     * GET /api/{namespace}/{extension}/version-references
     */
    async getVersionReferences(namespace: string, extension: string, size?: number, offset?: number): Promise<VersionReferences> {
        const url = buildUrl(
            this.baseUrl,
            `/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}/version-references`,
            { size, offset }
        );
        return this.get<VersionReferences>(url);
    }

    /**
     * Get versions for specific target platform
     * GET /api/{namespace}/{extension}/{targetPlatform}/versions
     */
    async getVersionsByPlatform(
        namespace: string,
        extension: string,
        targetPlatform: string,
        size?: number,
        offset?: number
    ): Promise<Versions> {
        const url = buildUrl(
            this.baseUrl,
            `/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}/${encodeURIComponent(targetPlatform)}/versions`,
            { size, offset }
        );
        return this.get<Versions>(url);
    }

    // ==================== Reviews API ====================

    /**
     * Get reviews for an extension
     * GET /api/{namespace}/{extension}/reviews
     */
    async getReviews(namespace: string, extension: string): Promise<ReviewList> {
        const url = `${this.baseUrl}/api/${encodeURIComponent(namespace)}/${encodeURIComponent(extension)}/reviews`;
        return this.get<ReviewList>(url);
    }

    // ==================== Registry API ====================

    /**
     * Get registry version
     * GET /api/version
     */
    async getRegistryVersion(): Promise<RegistryVersion> {
        const url = `${this.baseUrl}/api/version`;
        return this.get<RegistryVersion>(url);
    }

    // ==================== Helper Methods ====================

    /**
     * Get download URL for an extension's .vsix file
     */
    getDownloadUrl(ext: Extension): string | null {
        if (ext.files && ext.files['download']) {
            return ext.files['download'];
        }
        if (ext.downloads) {
            // Try to find a platform-specific download
            const platforms = Object.keys(ext.downloads);
            if (platforms.length > 0) {
                return ext.downloads[platforms[0]];
            }
        }
        return null;
    }

    /**
     * Get README URL for an extension
     */
    getReadmeUrl(ext: Extension): string | null {
        return ext.files?.['readme'] || null;
    }

    /**
     * Get icon URL for an extension
     */
    getIconUrl(ext: Extension): string | null {
        return ext.files?.['icon'] || null;
    }

    /**
     * Get changelog URL for an extension
     */
    getChangelogUrl(ext: Extension): string | null {
        return ext.files?.['changelog'] || null;
    }

    /**
     * Get license URL for an extension
     */
    getLicenseUrl(ext: Extension): string | null {
        return ext.files?.['license'] || null;
    }
}
