/**
 * Open VSX Registry API Types
 * Based on the OpenAPI 3.1.0 specification
 * Only includes types for GET endpoints (no publish/create operations)
 */

// Base result type
export interface Result {
    success?: string;
    warning?: string;
    error?: string;
}

// User data
export interface User extends Result {
    loginName: string;
    fullName?: string;
    avatarUrl?: string;
    homepage?: string;
    provider?: string;
}

// Badge for extension
export interface Badge {
    url?: string;
    href?: string;
    description?: string;
}

// Extension reference
export interface ExtensionReference {
    url: string;
    namespace: string;
    extension: string;
}

// Extension replacement (for deprecated extensions)
export interface ExtensionReplacement {
    url?: string;
    displayName?: string;
}

// Target platforms
export type TargetPlatform =
    | 'win32-x64'
    | 'win32-ia32'
    | 'win32-arm64'
    | 'linux-x64'
    | 'linux-arm64'
    | 'linux-armhf'
    | 'alpine-x64'
    | 'alpine-arm64'
    | 'darwin-x64'
    | 'darwin-arm64'
    | 'web'
    | 'universal';

// Version target platforms
export interface VersionTargetPlatformsJson {
    version?: string;
    targetPlatforms?: string[];
}

// Full extension metadata
export interface Extension extends Result {
    namespaceUrl?: string;
    reviewsUrl?: string;
    files?: Record<string, string>;
    name: string;
    namespace: string;
    targetPlatform?: TargetPlatform;
    version: string;
    preRelease?: boolean;
    publishedBy?: User;
    verified: boolean;
    /** @deprecated Use verified instead */
    unrelatedPublisher?: boolean;
    /** @deprecated Namespaces are now always restricted */
    namespaceAccess?: 'public' | 'restricted';
    /** @deprecated Use allVersionsUrl instead */
    allVersions?: Record<string, string>;
    allVersionsUrl?: string;
    averageRating?: number;
    downloadCount?: number;
    reviewCount?: number;
    versionAlias?: string[];
    timestamp: string;
    preview?: boolean;
    displayName?: string;
    namespaceDisplayName: string;
    description?: string;
    engines?: Record<string, string>;
    categories?: string[];
    extensionKind?: string[];
    tags?: string[];
    license?: string;
    homepage?: string;
    repository?: string;
    sponsorLink?: string;
    bugs?: string;
    markdown?: 'standard' | 'github';
    galleryColor?: string;
    galleryTheme?: 'light' | 'dark';
    localizedLanguages?: string[];
    qna?: string;
    badges?: Badge[];
    dependencies?: ExtensionReference[];
    bundledExtensions?: ExtensionReference[];
    downloads?: Record<string, string>;
    allTargetPlatformVersions?: VersionTargetPlatformsJson[];
    url?: string;
    deprecated?: boolean;
    replacement?: ExtensionReplacement;
    downloadable?: boolean;
}

// Search entry (summary of extension)
export interface SearchEntry {
    url: string;
    files: Record<string, string>;
    name: string;
    namespace: string;
    version: string;
    timestamp: string;
    verified: boolean;
    /** @deprecated Use allVersionsUrl instead */
    allVersions?: VersionReference[];
    allVersionsUrl?: string;
    averageRating?: number;
    reviewCount?: number;
    downloadCount?: number;
    displayName?: string;
    description?: string;
    deprecated?: boolean;
}

// Search result
export interface SearchResult extends Result {
    offset: number;
    totalSize: number;
    extensions: SearchEntry[];
}

// Query result
export interface QueryResult extends Result {
    offset: number;
    totalSize: number;
    extensions?: Extension[];
}

// Version reference
export interface VersionReference {
    url?: string;
    files?: Record<string, string>;
    version?: string;
    targetPlatform?: TargetPlatform;
    engines?: Record<string, string>;
}

// Version references list
export interface VersionReferences extends Result {
    offset: number;
    totalSize: number;
    versions: VersionReference[];
}

// Versions map
export interface Versions extends Result {
    offset: number;
    totalSize: number;
    versions: Record<string, string>;
}

// Namespace
export interface Namespace extends Result {
    name: string;
    extensions?: Record<string, string>;
    verified: boolean;
    /** @deprecated Namespaces are now always restricted */
    access?: 'public' | 'restricted';
}

// Namespace details
export interface NamespaceDetails extends Result {
    name: string;
    displayName: string;
    description?: string;
    logo?: string;
    website?: string;
    supportLink?: string;
    socialLinks?: Record<string, string>;
    extensions?: SearchEntry[];
    verified: boolean;
}

// Review
export interface Review {
    user: User;
    timestamp: string;
    comment?: string;
    rating: number;
}

// Review list
export interface ReviewList extends Result {
    reviews: Review[];
}

// Registry version
export interface RegistryVersion extends Result {
    version: string;
}

// Search parameters
export interface SearchParams {
    query?: string;
    category?: string;
    targetPlatform?: TargetPlatform;
    size?: number;
    offset?: number;
    sortOrder?: 'asc' | 'desc';
    sortBy?: 'relevance' | 'timestamp' | 'rating' | 'downloadCount';
    includeAllVersions?: boolean;
}

// Query parameters
export interface QueryParams {
    namespaceName?: string;
    extensionName?: string;
    extensionVersion?: string;
    extensionId?: string;
    extensionUuid?: string;
    namespaceUuid?: string;
    includeAllVersions?: boolean | 'links';
    targetPlatform?: TargetPlatform;
    size?: number;
    offset?: number;
}
