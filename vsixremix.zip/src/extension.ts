import * as vscode from 'vscode';
import { OpenVsxClient } from './api/openVsxClient';
import { ExtensionInstaller } from './services/extensionInstaller';
import { ExtensionManager } from './services/extensionManager';
import { MarketplaceViewProvider } from './views/marketplaceView';
import { ExtensionDetailsPanel } from './views/extensionDetailsPanel';
import { InstalledExtensionsProvider } from './views/installedExtensionsView';
import { getRegistryUrl } from './utils/helpers';

// Global instances
let client: OpenVsxClient;
let installer: ExtensionInstaller;
let extensionManager: ExtensionManager;
let marketplaceProvider: MarketplaceViewProvider;
let installedProvider: InstalledExtensionsProvider;

/**
 * Extension activation
 */
export function activate(context: vscode.ExtensionContext) {
    console.log('Open VSX Marketplace extension is now active');

    // Initialize API client with configured URL
    client = new OpenVsxClient(getRegistryUrl());
    installer = new ExtensionInstaller(client);
    extensionManager = new ExtensionManager(client);

    // Listen for configuration changes
    context.subscriptions.push(
        vscode.workspace.onDidChangeConfiguration(e => {
            if (e.affectsConfiguration('openVsx.registryUrl')) {
                client.setBaseUrl(getRegistryUrl());
                marketplaceProvider?.refresh();
            }
        })
    );

    // Register the marketplace search webview provider
    marketplaceProvider = new MarketplaceViewProvider(
        context.extensionUri,
        client,
        installer,
        extensionManager
    );
    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider(
            MarketplaceViewProvider.viewType,
            marketplaceProvider
        )
    );

    // Register the installed extensions tree provider
    installedProvider = new InstalledExtensionsProvider(extensionManager);
    context.subscriptions.push(
        vscode.window.registerTreeDataProvider('openVsxInstalled', installedProvider)
    );

    // Refresh installed view when extensions change (install/uninstall/enable/disable)
    context.subscriptions.push(
        vscode.extensions.onDidChange(() => {
            installedProvider.refresh();
            marketplaceProvider.refresh();
        })
    );


    // Register commands
    context.subscriptions.push(
        vscode.commands.registerCommand('openVsx.searchExtensions', async () => {
            const query = await vscode.window.showInputBox({
                prompt: 'Search for extensions',
                placeHolder: 'e.g., python, javascript, theme...'
            });
            if (query !== undefined) {
                marketplaceProvider.performSearch(query);
                // Focus on the marketplace view
                vscode.commands.executeCommand('openVsxSearch.focus');
            }
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('openVsx.viewExtension', async (namespace?: string, name?: string) => {
            if (!namespace || !name) {
                const input = await vscode.window.showInputBox({
                    prompt: 'Enter extension ID',
                    placeHolder: 'e.g., ms-python.python'
                });
                if (!input) return;

                const parts = input.split('.');
                if (parts.length < 2) {
                    vscode.window.showErrorMessage('Invalid extension ID. Use format: namespace.name');
                    return;
                }
                namespace = parts[0];
                name = parts.slice(1).join('.');
            }

            await ExtensionDetailsPanel.createOrShow(
                context.extensionUri,
                client,
                installer,
                extensionManager,
                namespace,
                name
            );
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('openVsx.installExtension', async (namespace?: string, name?: string) => {
            if (!namespace || !name) {
                const input = await vscode.window.showInputBox({
                    prompt: 'Enter extension ID to install',
                    placeHolder: 'e.g., ms-python.python'
                });
                if (!input) return;

                await installer.installExtensionById(input);
            } else {
                const ext = await client.getExtension(namespace, name);
                await installer.installExtension(ext);
            }

            const reload = 'Reload Now';
            vscode.window.showInformationMessage(
                `Installation complete. Please reload the window to apply changes.`,
                reload
            ).then(selection => {
                if (selection === reload) {
                    vscode.commands.executeCommand('workbench.action.reloadWindow');
                }
            });
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('openVsx.checkUpdates', async () => {
            await installedProvider.checkUpdates();
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('openVsx.refresh', () => {
            marketplaceProvider.refresh();
            installedProvider.refresh();
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('openVsx.updateExtension', async (item: any) => {
            // item is InstalledExtensionItem, but we use any to avoid circular imports if strictly typed
            if (item && item.ext && item.ext.openVsxData) {
                await installer.installExtension(item.ext.openVsxData);
                installedProvider.refresh();

                const reload = 'Reload Now';
                vscode.window.showInformationMessage(
                    `Updated ${item.ext.displayName}. Please reload the window to complete the process.`,
                    reload
                ).then(selection => {
                    if (selection === reload) {
                        vscode.commands.executeCommand('workbench.action.reloadWindow');
                    }
                });
            }
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('openVsx.uninstallExtension', async (item: any) => {
            console.log('Uninstall command triggered', item);
            if (item && item.ext) {
                console.log('Uninstalling extension:', item.ext.id);
                const confirm = await vscode.window.showWarningMessage(
                    `Are you sure you want to uninstall ${item.ext.displayName}?`,
                    { modal: true },
                    'Uninstall'
                );
                if (confirm === 'Uninstall') {
                    await extensionManager.uninstallExtension(item.ext.id);
                    installedProvider.refresh();
                }
            }
        })
    );

    // Register installer for disposal
    context.subscriptions.push({
        dispose: () => installer.dispose()
    });
}

/**
 * Extension deactivation
 */
export function deactivate() {
    console.log('Open VSX Marketplace extension is now deactivated');
}
