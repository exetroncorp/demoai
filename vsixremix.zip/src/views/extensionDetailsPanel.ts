import * as vscode from 'vscode';
import { OpenVsxClient } from '../api/openVsxClient';
import { ExtensionInstaller } from '../services/extensionInstaller';
import { ExtensionManager } from '../services/extensionManager';
import { Extension, Review } from '../types/openVsx';
import { getNonce, formatDownloadCount, formatRating, escapeHtml } from '../utils/helpers';

/**
 * Panel for displaying extension details
 */
export class ExtensionDetailsPanel {
    public static currentPanel: ExtensionDetailsPanel | undefined;
    public static readonly viewType = 'openVsxExtensionDetails';

    private readonly _panel: vscode.WebviewPanel;
    private readonly _extensionUri: vscode.Uri;
    private _disposables: vscode.Disposable[] = [];
    private client: OpenVsxClient;
    private installer: ExtensionInstaller;
    private extensionManager: ExtensionManager;

    private constructor(
        panel: vscode.WebviewPanel,
        extensionUri: vscode.Uri,
        client: OpenVsxClient,
        installer: ExtensionInstaller,
        extensionManager: ExtensionManager
    ) {
        this._panel = panel;
        this._extensionUri = extensionUri;
        this.client = client;
        this.installer = installer;
        this.extensionManager = extensionManager;

        this._panel.onDidDispose(() => this.dispose(), null, this._disposables);

        this._panel.webview.onDidReceiveMessage(
            async (message) => {
                switch (message.command) {
                    case 'install':
                        await this.installExtension(message.namespace, message.name, message.version);
                        break;
                    case 'uninstall':
                        await this.uninstallExtension(message.extensionId);
                        break;
                    case 'openUrl':
                        vscode.env.openExternal(vscode.Uri.parse(message.url));
                        break;
                    case 'installVersion':
                        await this.installSpecificVersion(message.namespace, message.name);
                        break;
                }
            },
            null,
            this._disposables
        );
    }

    /**
     * Create or show the extension details panel
     */
    public static async createOrShow(
        extensionUri: vscode.Uri,
        client: OpenVsxClient,
        installer: ExtensionInstaller,
        extensionManager: ExtensionManager,
        namespace: string,
        name: string
    ): Promise<void> {
        const column = vscode.ViewColumn.One;

        // If panel exists, dispose it to create fresh
        if (ExtensionDetailsPanel.currentPanel) {
            ExtensionDetailsPanel.currentPanel._panel.dispose();
        }

        const panel = vscode.window.createWebviewPanel(
            ExtensionDetailsPanel.viewType,
            `${namespace}.${name}`,
            column,
            {
                enableScripts: true,
                localResourceRoots: [extensionUri],
                retainContextWhenHidden: true
            }
        );

        ExtensionDetailsPanel.currentPanel = new ExtensionDetailsPanel(
            panel,
            extensionUri,
            client,
            installer,
            extensionManager
        );

        await ExtensionDetailsPanel.currentPanel.loadExtension(namespace, name);
    }

    /**
     * Load extension details
     */
    private async loadExtension(namespace: string, name: string): Promise<void> {
        this._panel.webview.html = this.getLoadingHtml();

        try {
            const ext = await this.client.getExtension(namespace, name);
            let reviews: Review[] = [];
            let readme = '';

            // Fetch reviews
            try {
                const reviewList = await this.client.getReviews(namespace, name);
                reviews = reviewList.reviews || [];
            } catch {
                // Reviews not available
            }

            // Fetch README
            const readmeUrl = this.client.getReadmeUrl(ext);
            if (readmeUrl) {
                try {
                    const readmeResponse = await this.client.downloadFile(readmeUrl);
                    readme = readmeResponse.toString('utf-8');
                } catch {
                    // README not available
                }
            }

            const isInstalled = this.extensionManager.isInstalled(namespace, name);
            const installedVersion = this.extensionManager.getInstalledVersion(namespace, name);

            this._panel.title = ext.displayName || ext.name;
            this._panel.webview.html = this.getExtensionHtml(ext, reviews, readme, isInstalled, installedVersion);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            this._panel.webview.html = this.getErrorHtml(errorMessage);
        }
    }

    private async installExtension(namespace: string, name: string, version?: string): Promise<void> {
        if (version) {
            await this.installer.installExtensionVersion(namespace, name, version);
        } else {
            await this.installer.installExtensionById(`${namespace}.${name}`);
        }

        // Reload to update install status
        await this.loadExtension(namespace, name);

        const reload = 'Reload Now';
        vscode.window.showInformationMessage(
            `Installed ${namespace}.${name}${version ? ` v${version}` : ''}. Please reload the window to complete the process.`,
            reload
        ).then(selection => {
            if (selection === reload) {
                vscode.commands.executeCommand('workbench.action.reloadWindow');
            }
        });
    }

    private async uninstallExtension(extensionId: string): Promise<void> {
        await this.extensionManager.uninstallExtension(extensionId);

        const parts = extensionId.split('.');
        if (parts.length >= 2) {
            const namespace = parts[0];
            const name = parts.slice(1).join('.');
            await this.loadExtension(namespace, name);
        }
    }

    private async installSpecificVersion(namespace: string, name: string): Promise<void> {
        try {
            // Using search query to get versions with timestamps
            const extensions = await this.client.getVersionsFromQuery(namespace, name, 100);

            if (!extensions || extensions.length === 0) {
                vscode.window.showInformationMessage('No versions found for this extension.');
                return;
            }

            // Deduplicate versions (keeping the one with timestamp if duplicates exist, though query returns per platform)
            // We want unique version numbers.
            const uniqueVersions = new Map<string, Extension>();
            for (const ext of extensions) {
                if (!uniqueVersions.has(ext.version)) {
                    uniqueVersions.set(ext.version, ext);
                }
            }

            const sortedVersions = Array.from(uniqueVersions.values()).sort((a, b) =>
                this.extensionManager.compareVersions(b.version, a.version)
            );

            const items: vscode.QuickPickItem[] = sortedVersions.map((ext) => ({
                label: ext.version,
                description: ext.timestamp ? new Date(ext.timestamp).toLocaleDateString() : undefined,
                detail: ext.targetPlatform ? `Platform: ${ext.targetPlatform}` : undefined
            }));

            const selected = await vscode.window.showQuickPick(items, {
                placeHolder: `Select version to install for ${namespace}.${name}`
            });

            if (selected) {
                await this.installExtension(namespace, name, selected.label);
            }
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            console.error('Failed to fetch versions:', error);
            vscode.window.showErrorMessage(`Failed to fetch versions: ${errorMessage}`);
        }
    }

    private getLoadingHtml(): string {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loading...</title>
    <style>
        body {
            font-family: var(--vscode-font-family);
            background: var(--vscode-editor-background);
            color: var(--vscode-foreground);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
    </style>
</head>
<body>
    <div>Loading extension details...</div>
</body>
</html>`;
    }

    private getErrorHtml(message: string): string {
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <style>
        body {
            font-family: var(--vscode-font-family);
            background: var(--vscode-editor-background);
            color: var(--vscode-foreground);
            padding: 20px;
        }
        .error {
            background: var(--vscode-inputValidation-errorBackground);
            border: 1px solid var(--vscode-inputValidation-errorBorder);
            padding: 15px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="error">
        <h2>Error Loading Extension</h2>
        <p>${escapeHtml(message)}</p>
    </div>
</body>
</html>`;
    }

    private getExtensionHtml(
        ext: Extension,
        reviews: Review[],
        readme: string,
        isInstalled: boolean,
        installedVersion: string | null
    ): string {
        const nonce = getNonce();
        const iconUrl = this.client.getIconUrl(ext) || '';
        const hasUpdate = installedVersion && installedVersion !== ext.version;

        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}'; img-src https: data:;">
    <title>${escapeHtml(ext.displayName || ext.name)}</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: var(--vscode-font-family);
            background: var(--vscode-editor-background);
            color: var(--vscode-foreground);
            line-height: 1.5;
        }
        .header {
            display: flex;
            gap: 20px;
            padding: 24px;
            border-bottom: 1px solid var(--vscode-panel-border);
            background: var(--vscode-sideBar-background);
        }
        .icon {
            width: 128px;
            height: 128px;
            border-radius: 8px;
            object-fit: contain;
            background: var(--vscode-editor-background);
        }
        .icon-placeholder {
            width: 128px;
            height: 128px;
            border-radius: 8px;
            background: var(--vscode-editor-background);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
        }
        .header-info { flex: 1; }
        .title {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 4px;
        }
        .publisher {
            font-size: 14px;
            color: var(--vscode-descriptionForeground);
            margin-bottom: 8px;
        }
        .verified-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: var(--vscode-badge-background);
            color: var(--vscode-badge-foreground);
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            margin-left: 8px;
        }
        .description {
            font-size: 14px;
            margin-bottom: 12px;
            opacity: 0.9;
        }
        .stats {
            display: flex;
            gap: 20px;
            font-size: 13px;
            margin-bottom: 16px;
        }
        .stat { display: flex; align-items: center; gap: 4px; }
        .actions { display: flex; gap: 10px; }
        .btn {
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
        }
        .btn-primary {
            background: var(--vscode-button-background);
            color: var(--vscode-button-foreground);
        }
        .btn-primary:hover {
            background: var(--vscode-button-hoverBackground);
        }
        .btn-secondary {
            background: var(--vscode-button-secondaryBackground);
            color: var(--vscode-button-secondaryForeground);
        }
        .btn-installed {
            background: var(--vscode-button-secondaryBackground);
            color: var(--vscode-charts-green);
        }
        .content {
            display: flex;
            padding: 24px;
            gap: 24px;
        }
        .main { flex: 1; min-width: 0; }
        .sidebar { width: 280px; flex-shrink: 0; }
        .section {
            margin-bottom: 24px;
        }
        .section-title {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 12px;
            text-transform: uppercase;
            color: var(--vscode-descriptionForeground);
        }
        .readme {
            background: var(--vscode-editor-background);
            padding: 16px;
            border-radius: 4px;
            overflow-x: auto;
        }
        .readme pre {
            background: var(--vscode-textBlockQuote-background);
            padding: 12px;
            border-radius: 4px;
            overflow-x: auto;
        }
        .readme code {
            font-family: var(--vscode-editor-font-family);
            font-size: 13px;
        }
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid var(--vscode-panel-border);
            font-size: 13px;
        }
        .info-label { color: var(--vscode-descriptionForeground); }
        .info-value { text-align: right; }
        .info-value a {
            color: var(--vscode-textLink-foreground);
            text-decoration: none;
        }
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }
        .tag {
            background: var(--vscode-badge-background);
            color: var(--vscode-badge-foreground);
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
        }
        .review {
            padding: 12px;
            background: var(--vscode-list-hoverBackground);
            border-radius: 4px;
            margin-bottom: 8px;
        }
        .review-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }
        .review-user { font-weight: 500; }
        .review-rating { color: var(--vscode-charts-yellow); }
        .review-comment { font-size: 13px; opacity: 0.9; }
    </style>
</head>
<body>
    <div class="header">
        ${iconUrl
                ? `<img class="icon" src="${iconUrl}" alt="">`
                : '<div class="icon-placeholder">📦</div>'
            }
        <div class="header-info">
            <h1 class="title">
                ${escapeHtml(ext.displayName || ext.name)}
                ${ext.verified ? '<span class="verified-badge">✓ Verified</span>' : ''}
            </h1>
            <div class="publisher">${escapeHtml(ext.namespace)}</div>
            <div class="description">${escapeHtml(ext.description || '')}</div>
            <div class="stats">
                <span class="stat">⬇ ${formatDownloadCount(ext.downloadCount)} downloads</span>
                ${ext.averageRating ? `<span class="stat">${formatRating(ext.averageRating)} (${ext.reviewCount} reviews)</span>` : ''}
                <span class="stat">v${escapeHtml(ext.version)}</span>
            </div>
            <div class="actions">
                ${isInstalled
                ? hasUpdate
                    ? `<button class="btn btn-primary" data-action="install" data-namespace="${ext.namespace}" data-name="${ext.name}" data-version="${ext.version}">Update to v${ext.version}</button>
                           <button class="btn btn-secondary" data-action="uninstall" data-id="${ext.namespace}.${ext.name}">Uninstall</button>`
                    : `<button class="btn btn-installed" disabled>✓ Installed v${installedVersion}</button>
                           <button class="btn btn-secondary" data-action="uninstall" data-id="${ext.namespace}.${ext.name}">Uninstall</button>`
                : `<button class="btn btn-primary" data-action="install" data-namespace="${ext.namespace}" data-name="${ext.name}">Install</button>`
            }
                <button class="btn btn-secondary" data-action="installVersion" data-namespace="${ext.namespace}" data-name="${ext.name}">Install Specific Version</button>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="main">
            <div class="section">
                <h2 class="section-title">Details</h2>
                <div class="readme">
                    ${readme ? this.simpleMarkdown(readme) : '<p>No README available</p>'}
                </div>
            </div>
            ${reviews.length > 0 ? `
            <div class="section">
                <h2 class="section-title">Reviews (${reviews.length})</h2>
                ${reviews.slice(0, 10).map(r => `
                    <div class="review">
                        <div class="review-header">
                            <span class="review-user">${escapeHtml(r.user.fullName || r.user.loginName)}</span>
                            <span class="review-rating">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</span>
                        </div>
                        ${r.comment ? `<div class="review-comment">${escapeHtml(r.comment)}</div>` : ''}
                    </div>
                `).join('')}
            </div>
            ` : ''}
        </div>
        <div class="sidebar">
            <div class="section">
                <h2 class="section-title">Information</h2>
                <div class="info-item">
                    <span class="info-label">Version</span>
                    <span class="info-value">${escapeHtml(ext.version)}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Published</span>
                    <span class="info-value">${new Date(ext.timestamp).toLocaleDateString()}</span>
                </div>
                ${ext.license ? `
                <div class="info-item">
                    <span class="info-label">License</span>
                    <span class="info-value">${escapeHtml(ext.license)}</span>
                </div>
                ` : ''}
                ${ext.repository ? `
                <div class="info-item">
                    <span class="info-label">Repository</span>
                    <span class="info-value"><a href="#" data-action="openUrl" data-url="${ext.repository}">GitHub</a></span>
                </div>
                ` : ''}
                ${ext.homepage ? `
                <div class="info-item">
                    <span class="info-label">Homepage</span>
                    <span class="info-value"><a href="#" data-action="openUrl" data-url="${ext.homepage}">Link</a></span>
                </div>
                ` : ''}
            </div>
            ${ext.categories && ext.categories.length > 0 ? `
            <div class="section">
                <h2 class="section-title">Categories</h2>
                <div class="tags">
                    ${ext.categories.map(c => `<span class="tag">${escapeHtml(c)}</span>`).join('')}
                </div>
            </div>
            ` : ''}
            ${ext.tags && ext.tags.length > 0 ? `
            <div class="section">
                <h2 class="section-title">Tags</h2>
                <div class="tags">
                    ${ext.tags.slice(0, 15).map(t => `<span class="tag">${escapeHtml(t)}</span>`).join('')}
                </div>
            </div>
            ` : ''}
        </div>
    </div>
    <script nonce="${nonce}">
        const vscode = acquireVsCodeApi();
        
        document.body.addEventListener('click', (e) => {
            const target = e.target;
            const actionElement = target.closest('[data-action]');
            
            if (!actionElement) return;
            
            e.preventDefault();
            const action = actionElement.dataset.action;
            
            switch (action) {
                case 'install':
                    vscode.postMessage({
                        command: 'install',
                        namespace: actionElement.dataset.namespace,
                        name: actionElement.dataset.name,
                        version: actionElement.dataset.version
                    });
                    if (target.tagName === 'BUTTON') {
                        target.textContent = 'Installing...';
                        target.disabled = true;
                    }
                    break;
                case 'uninstall':
                    vscode.postMessage({
                        command: 'uninstall',
                        extensionId: actionElement.dataset.id
                    });
                    if (target.tagName === 'BUTTON') {
                        target.textContent = 'Uninstalling...';
                        target.disabled = true;
                    }
                    break;
                case 'openUrl':
                    vscode.postMessage({
                        command: 'openUrl',
                        url: actionElement.dataset.url
                    });
                    break;
                case 'installVersion':
                    vscode.postMessage({
                        command: 'installVersion',
                        namespace: actionElement.dataset.namespace,
                        name: actionElement.dataset.name
                    });
                    break;
            }
        });
    </script>
</body>
</html>`;
    }

    /**
     * Simple markdown to HTML converter
     */
    private simpleMarkdown(text: string): string {
        return escapeHtml(text)
            // Headers
            .replace(/^### (.+)$/gm, '<h3>$1</h3>')
            .replace(/^## (.+)$/gm, '<h2>$1</h2>')
            .replace(/^# (.+)$/gm, '<h1>$1</h1>')
            // Bold and italic
            .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.+?)\*/g, '<em>$1</em>')
            // Code blocks
            .replace(/```[\s\S]*?```/g, match => {
                const code = match.slice(3, -3).replace(/^\w+\n/, '');
                return `<pre><code>${code}</code></pre>`;
            })
            // Inline code
            .replace(/`([^`]+)`/g, '<code>$1</code>')
            // Line breaks
            .replace(/\n\n/g, '</p><p>')
            .replace(/\n/g, '<br>')
            // Wrap in paragraph
            .replace(/^/, '<p>')
            .replace(/$/, '</p>');
    }

    public dispose(): void {
        ExtensionDetailsPanel.currentPanel = undefined;
        this._panel.dispose();
        while (this._disposables.length) {
            const disposable = this._disposables.pop();
            if (disposable) {
                disposable.dispose();
            }
        }
    }
}
