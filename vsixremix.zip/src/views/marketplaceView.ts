import * as vscode from 'vscode';
import { OpenVsxClient } from '../api/openVsxClient';
import { ExtensionInstaller } from '../services/extensionInstaller';
import { SearchEntry, Extension } from '../types/openVsx';
import { ExtensionManager } from '../services/extensionManager';
import { getNonce, formatDownloadCount, formatRating, getRegistryUrl } from '../utils/helpers';

/**
 * Webview provider for the main marketplace search view
 */
export class MarketplaceViewProvider implements vscode.WebviewViewProvider {
    public static readonly viewType = 'openVsxSearch';

    private _view?: vscode.WebviewView;
    private client: OpenVsxClient;
    private installer: ExtensionInstaller;
    private extensionManager: ExtensionManager;
    private searchResults: SearchEntry[] = [];
    private currentQuery: string = '';
    private currentOffset: number = 0;
    private totalSize: number = 0;
    private pageSize: number = 20;

    constructor(
        private readonly _extensionUri: vscode.Uri,
        client: OpenVsxClient,
        installer: ExtensionInstaller,
        extensionManager: ExtensionManager
    ) {
        this.client = client;
        this.installer = installer;
        this.extensionManager = extensionManager;
    }

    public resolveWebviewView(
        webviewView: vscode.WebviewView,
        _context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken
    ): void {
        this._view = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this._extensionUri]
        };

        webviewView.webview.html = this._getHtmlContent(webviewView.webview);

        // Handle messages from the webview
        webviewView.webview.onDidReceiveMessage(async (message) => {
            switch (message.command) {
                case 'ready':
                    // Webview is ready, perform initial search or restore state
                    await this.performSearch(this.currentQuery);
                    break;
                case 'search':
                    await this.performSearch(message.query);
                    break;
                case 'loadMore':
                    await this.loadMore();
                    break;
                case 'viewExtension':
                    await this.viewExtension(message.namespace, message.name);
                    break;
                case 'installExtension':
                    await this.installExtension(message.namespace, message.name);
                    break;
            }
        });
    }

    /**
     * Perform a search and update the view
     */
    public async performSearch(query: string): Promise<void> {
        this.currentQuery = query;
        this.currentOffset = 0;
        this.searchResults = [];

        try {
            const result = await this.client.search({
                query: query || undefined,
                size: this.pageSize,
                offset: 0,
                sortBy: query ? 'relevance' : 'downloadCount',
                sortOrder: 'desc'
            });

            this.searchResults = result.extensions;
            this.totalSize = result.totalSize;

            const extensionsWithStatus = this.searchResults.map(ext => {
                const isInstalled = this.extensionManager.isInstalled(ext.namespace, ext.name);
                const installedVersion = this.extensionManager.getInstalledVersion(ext.namespace, ext.name);
                const hasUpdate = isInstalled && installedVersion && installedVersion !== ext.version;

                return {
                    ...ext,
                    isInstalled,
                    installedVersion,
                    hasUpdate
                };
            });

            this._view?.webview.postMessage({
                command: 'searchResults',
                extensions: extensionsWithStatus,
                totalSize: this.totalSize,
                hasMore: this.searchResults.length < this.totalSize
            });
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            this._view?.webview.postMessage({
                command: 'error',
                message: `Search failed: ${errorMessage}`
            });
        }
    }

    /**
     * Load more results
     */
    private async loadMore(): Promise<void> {
        if (this.searchResults.length >= this.totalSize) {
            return;
        }

        this.currentOffset += this.pageSize;

        try {
            const result = await this.client.search({
                query: this.currentQuery || undefined,
                size: this.pageSize,
                offset: this.currentOffset,
                sortBy: this.currentQuery ? 'relevance' : 'downloadCount',
                sortOrder: 'desc'
            });

            this.searchResults = [...this.searchResults, ...result.extensions];

            this._view?.webview.postMessage({
                command: 'moreResults',
                extensions: result.extensions,
                hasMore: this.searchResults.length < this.totalSize
            });
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            this._view?.webview.postMessage({
                command: 'error',
                message: `Failed to load more: ${errorMessage}`
            });
        }
    }

    /**
     * View extension details
     */
    private async viewExtension(namespace: string, name: string): Promise<void> {
        vscode.commands.executeCommand('openVsx.viewExtension', namespace, name);
    }

    /**
     * Install an extension
     */
    private async installExtension(namespace: string, name: string): Promise<void> {
        try {
            const ext = await this.client.getExtension(namespace, name);
            await this.installer.installExtension(ext);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            vscode.window.showErrorMessage(`Failed to install extension: ${errorMessage}`);
        }
    }

    /**
     * Refresh the view
     */
    public refresh(): void {
        this.performSearch(this.currentQuery);
    }

    /**
     * Generate HTML content for the webview
     */
    private _getHtmlContent(webview: vscode.Webview): string {
        const nonce = getNonce();

        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}'; img-src ${webview.cspSource} https:;">
    <title>Open VSX Marketplace</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: var(--vscode-font-family);
            font-size: var(--vscode-font-size);
            color: var(--vscode-foreground);
            background-color: var(--vscode-sideBar-background);
            padding: 8px;
        }
        .search-container {
            position: sticky;
            top: 0;
            background: var(--vscode-sideBar-background);
            padding-bottom: 8px;
            z-index: 100;
        }
        .search-box {
            width: 100%;
            padding: 6px 10px;
            border: 1px solid var(--vscode-input-border);
            background: var(--vscode-input-background);
            color: var(--vscode-input-foreground);
            border-radius: 4px;
            font-size: 13px;
        }
        .search-box:focus {
            outline: 1px solid var(--vscode-focusBorder);
            border-color: var(--vscode-focusBorder);
        }
        .results-info {
            font-size: 11px;
            color: var(--vscode-descriptionForeground);
            padding: 4px 0;
        }
        .extension-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .extension-item {
            display: flex;
            gap: 10px;
            padding: 8px;
            background: var(--vscode-list-hoverBackground);
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.1s;
        }
        .extension-item:hover {
            background: var(--vscode-list-activeSelectionBackground);
        }
        .extension-icon {
            width: 42px;
            height: 42px;
            border-radius: 4px;
            object-fit: contain;
            background: var(--vscode-editor-background);
            flex-shrink: 0;
        }
        .extension-icon.placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: var(--vscode-descriptionForeground);
        }
        .extension-info {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .extension-header {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .extension-name {
            font-weight: 600;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .extension-verified {
            color: var(--vscode-charts-blue);
            font-size: 12px;
        }
        .extension-publisher {
            font-size: 11px;
            color: var(--vscode-descriptionForeground);
        }
        .extension-description {
            font-size: 12px;
            color: var(--vscode-foreground);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            opacity: 0.8;
        }
        .extension-stats {
            display: flex;
            gap: 10px;
            font-size: 11px;
            color: var(--vscode-descriptionForeground);
        }
        .extension-actions {
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .install-btn {
            padding: 4px 10px;
            background: var(--vscode-button-background);
            color: var(--vscode-button-foreground);
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 11px;
            white-space: nowrap;
        }
        .install-btn:hover {
            background: var(--vscode-button-hoverBackground);
        }
        .install-btn.installed {
            background: var(--vscode-button-secondaryBackground);
            color: var(--vscode-button-secondaryForeground);
        }
        .load-more {
            text-align: center;
            padding: 10px;
        }
        .load-more-btn {
            padding: 6px 16px;
            background: var(--vscode-button-secondaryBackground);
            color: var(--vscode-button-secondaryForeground);
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .loading {
            text-align: center;
            padding: 20px;
            color: var(--vscode-descriptionForeground);
        }
        .error-message {
            padding: 10px;
            background: var(--vscode-inputValidation-errorBackground);
            border: 1px solid var(--vscode-inputValidation-errorBorder);
            border-radius: 4px;
            color: var(--vscode-errorForeground);
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="search-container">
        <input type="text" class="search-box" placeholder="Search extensions..." id="searchInput">
    </div>
    <div class="results-info" id="resultsInfo"></div>
    <div class="extension-list" id="extensionList">
        <div class="loading">Loading popular extensions...</div>
    </div>
    <div class="load-more" id="loadMore" style="display: none;">
        <button class="load-more-btn" id="loadMoreBtn">Load More</button>
    </div>

    <script nonce="${nonce}">
        const vscode = acquireVsCodeApi();
        const searchInput = document.getElementById('searchInput');
        const extensionList = document.getElementById('extensionList');
        const resultsInfo = document.getElementById('resultsInfo');
        const loadMoreDiv = document.getElementById('loadMore');
        const loadMoreBtn = document.getElementById('loadMoreBtn');

        let searchTimeout;

        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                vscode.postMessage({ command: 'search', query: e.target.value });
                extensionList.innerHTML = '<div class="loading">Searching...</div>';
            }, 300);
        });

        loadMoreBtn.addEventListener('click', () => {
            loadMoreBtn.textContent = 'Loading...';
            vscode.postMessage({ command: 'loadMore' });
        });

        function formatCount(count) {
            if (count >= 1000000) return (count / 1000000).toFixed(1) + 'M';
            if (count >= 1000) return (count / 1000).toFixed(1) + 'K';
            return count.toString();
        }

        function formatRating(rating) {
            if (!rating) return '';
            return '★'.repeat(Math.round(rating)) + '☆'.repeat(5 - Math.round(rating));
        }

        function renderExtension(ext) {
            const iconUrl = ext.files?.icon || '';
            const iconHtml = iconUrl 
                ? '<img class="extension-icon" src="' + iconUrl + '" alt="">'
                : '<div class="extension-icon placeholder">📦</div>';

            let actionButton;
            if (ext.isInstalled) {
                if (ext.hasUpdate) {
                    actionButton = '<button class="install-btn" data-action="install" title="Update to v' + ext.version + '">Update</button>';
                } else {
                    actionButton = '<button class="install-btn installed" disabled>Installed</button>';
                }
            } else {
                actionButton = '<button class="install-btn" data-action="install">Install</button>';
            }

            // IMPORTANT: data attributes for event delegation
            return '<div class="extension-item" data-namespace="' + ext.namespace + '" data-name="' + ext.name + '">' +
                iconHtml +
                '<div class="extension-info">' +
                    '<div class="extension-header">' +
                        '<span class="extension-name">' + (ext.displayName || ext.name) + '</span>' +
                        (ext.verified ? '<span class="extension-verified" title="Verified">✓</span>' : '') +
                    '</div>' +
                    '<div class="extension-publisher">' + ext.namespace + '</div>' +
                    '<div class="extension-description">' + (ext.description || '') + '</div>' +
                    '<div class="extension-stats">' +
                        '<span>⬇ ' + formatCount(ext.downloadCount || 0) + '</span>' +
                        (ext.averageRating ? '<span>' + formatRating(ext.averageRating) + '</span>' : '') +
                    '</div>' +
                '</div>' +
                '<div class="extension-actions">' +
                    actionButton +
                '</div>' +
            '</div>';
        }

        // Use event delegation for all clicks
        extensionList.addEventListener('click', (e) => {
            const installBtn = e.target.closest('.install-btn');
            const item = e.target.closest('.extension-item');
            
            if (installBtn && item && !installBtn.disabled) {
                // Handle install click
                e.stopPropagation();
                const namespace = item.dataset.namespace;
                const name = item.dataset.name;
                vscode.postMessage({ command: 'installExtension', namespace, name });
                installBtn.textContent = 'Installing...';
                installBtn.disabled = true;
            } else if (item) {
                // Handle item click (view details)
                const namespace = item.dataset.namespace;
                const name = item.dataset.name;
                vscode.postMessage({ 
                    command: 'viewExtension', 
                    namespace, 
                    name 
                });
            }
        });

        window.addEventListener('message', (event) => {
            const message = event.data;
            switch (message.command) {
                case 'searchResults':
                    extensionList.innerHTML = message.extensions.map(renderExtension).join('');
                    resultsInfo.textContent = message.totalSize + ' extensions found';
                    loadMoreDiv.style.display = message.hasMore ? 'block' : 'none';
                    loadMoreBtn.textContent = 'Load More';
                    break;
                case 'moreResults':
                    extensionList.innerHTML += message.extensions.map(renderExtension).join('');
                    loadMoreDiv.style.display = message.hasMore ? 'block' : 'none';
                    loadMoreBtn.textContent = 'Load More';
                    break;
                case 'error':
                    extensionList.innerHTML = '<div class="error-message">' + message.message + '</div>';
                    break;
            }
        });

        // Notify that webview is ready to receive data
        vscode.postMessage({ command: 'ready' });
    </script>
</body>
</html>`;
    }
}
