import * as vscode from 'vscode';
import { OpenVsxClient } from '../api/openVsxClient';
import { ExtensionManager, InstalledExtension } from '../services/extensionManager';

/**
 * Tree item for installed extension
 */
export class InstalledExtensionItem extends vscode.TreeItem {
    constructor(
        public readonly ext: InstalledExtension
    ) {
        super(ext.displayName || ext.name, vscode.TreeItemCollapsibleState.None);

        this.description = `v${ext.installedVersion}`;
        this.tooltip = `${ext.id}\nInstalled: v${ext.installedVersion}${ext.latestVersion ? `\nLatest: v${ext.latestVersion}` : ''}`;



        if (ext.iconPath) {
            this.iconPath = ext.iconPath;
        } else if (ext.hasUpdate) {
            // Keep arrow-up for update, or maybe overlay it? 
            // Standard behavior: show extension icon, maybe decoration for update.
            // But here we set iconPath.
            // If we have iconPath, we use it. If not, we use theme icon.
            // Wait, if it has update, we wanted to show arrow-up. 
            // User asked for "logo of extension". Logo is more important than status icon (status can be in description or decoration).
            // But let's stick to what user wants: "logo of extension".
            // I'll prioritize iconPath.
            this.iconPath = ext.iconPath;
        } else {
            this.iconPath = new vscode.ThemeIcon('extensions');
        }

        // If has update, we might want to indicate it.
        // But TreeItem only has one iconPath.
        // We can use description for update status.
        if (ext.hasUpdate) {
            this.description += ` → v${ext.latestVersion}`;
            // If we didn't have a logo, we would have used arrow-up.
            // If we DO have a logo, we should probably keep the logo.
            // But let's check my logic above.
            if (!this.iconPath) {
                this.iconPath = new vscode.ThemeIcon('arrow-up', new vscode.ThemeColor('charts.yellow'));
            }
        }

        this.contextValue = ext.hasUpdate ? 'installedExtensionWithUpdate' : 'installedExtension';

        // Click to view details
        this.command = {
            command: 'openVsx.viewExtension',
            title: 'View Extension',
            arguments: [ext.publisher, ext.name]
        };
    }
}

/**
 * Tree data provider for installed extensions
 */
export class InstalledExtensionsProvider implements vscode.TreeDataProvider<InstalledExtensionItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<InstalledExtensionItem | undefined | null | void> =
        new vscode.EventEmitter<InstalledExtensionItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<InstalledExtensionItem | undefined | null | void> =
        this._onDidChangeTreeData.event;

    private extensionManager: ExtensionManager;
    private cachedExtensions: InstalledExtension[] = [];
    private isLoading: boolean = false;

    constructor(extensionManager: ExtensionManager) {
        this.extensionManager = extensionManager;
    }

    refresh(): void {
        this.cachedExtensions = [];
        this._onDidChangeTreeData.fire();
    }

    async checkUpdates(): Promise<void> {
        if (this.isLoading) {
            return;
        }

        this.isLoading = true;
        try {
            this.cachedExtensions = await this.extensionManager.checkAllUpdates();
            this._onDidChangeTreeData.fire();

            const updatesCount = this.cachedExtensions.filter(e => e.hasUpdate).length;
            if (updatesCount > 0) {
                vscode.window.showInformationMessage(
                    `${updatesCount} extension${updatesCount > 1 ? 's have' : ' has'} updates available.`
                );
            } else {
                vscode.window.showInformationMessage('All extensions are up to date.');
            }
        } finally {
            this.isLoading = false;
        }
    }

    getTreeItem(element: InstalledExtensionItem): vscode.TreeItem {
        return element;
    }

    async getChildren(_element?: InstalledExtensionItem): Promise<InstalledExtensionItem[]> {
        // Only show top-level items (no children)
        if (_element) {
            return [];
        }

        // If we have cached data, use it
        if (this.cachedExtensions.length > 0) {
            return this.cachedExtensions
                .sort((a, b) => {
                    // Sort: updates first, then alphabetically
                    if (a.hasUpdate !== b.hasUpdate) {
                        return a.hasUpdate ? -1 : 1;
                    }
                    return a.displayName.localeCompare(b.displayName);
                })
                .map(ext => new InstalledExtensionItem(ext));
        }

        // Otherwise, just list installed extensions without update check
        const installed = this.extensionManager.getInstalledExtensions();
        return installed
            .map(ext => {
                const parts = ext.id.split('.');
                return new InstalledExtensionItem({
                    id: ext.id,
                    name: parts.slice(1).join('.'),
                    displayName: ext.packageJSON.displayName || ext.id,
                    version: ext.packageJSON.version,
                    publisher: parts[0],
                    installedVersion: ext.packageJSON.version,
                    hasUpdate: false,
                    iconPath: ext.packageJSON.icon ? vscode.Uri.joinPath(ext.extensionUri, ext.packageJSON.icon) : undefined
                });
            })
            .sort((a, b) => a.ext.displayName.localeCompare(b.ext.displayName));
    }
}
