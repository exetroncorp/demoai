# Open VSX Marketplace

A VS Code extension that lets you browse and install extensions from the [Open VSX Registry](https://open-vsx.org) - an open-source alternative to the Visual Studio Code Marketplace.

## Features

- 🔍 **Search Extensions**: Search the Open VSX Registry directly from VS Code
- 📋 **View Details**: See full extension information including README, reviews, and versions
- ⬇️ **Install Extensions**: Download and install extensions from Open VSX
- 🔄 **Check for Updates**: Compare installed extensions with Open VSX versions
- ⚙️ **Configurable**: Use the default Open VSX server or configure your own

## Usage

### Search Extensions
1. Click on the Open VSX icon in the Activity Bar
2. Type in the search box to find extensions
3. Click on an extension to view details
4. Click "Install" to install the extension

### Commands

| Command | Description |
|---------|-------------|
| `Open VSX: Search Extensions` | Open search dialog |
| `Open VSX: View Extension Details` | View details of a specific extension |
| `Open VSX: Install Extension` | Install an extension by ID |
| `Open VSX: Check for Updates` | Check installed extensions for updates |
| `Open VSX: Refresh` | Refresh the marketplace view |

### Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `openVsx.registryUrl` | `https://open-vsx.org` | Base URL of the Open VSX Registry |
| `openVsx.pageSize` | `20` | Number of extensions per page |

## Open VSX API

This extension uses only **GET endpoints** from the Open VSX Registry API:

- `/api/-/search` - Search extensions
- `/api/-/query` - Query extensions by various parameters
- `/api/{namespace}` - Get namespace metadata
- `/api/{namespace}/{extension}` - Get extension metadata
- `/api/{namespace}/{extension}/reviews` - Get extension reviews
- `/api/{namespace}/{extension}/versions` - Get available versions

## Development

```bash
# Install dependencies
npm install

# Compile TypeScript
npm run compile

# Watch for changes
npm run watch

# Package extension
npm run package
```

## License

MIT
