"""Configuration and path management for Prooter."""

import os
from pathlib import Path
from typing import Optional


class Config:
    """Prooter configuration management."""
    
    def __init__(self, base_dir: Optional[Path] = None):
        """Initialize configuration.
        
        Args:
            base_dir: Base directory for prooter data. Defaults to ~/.prooter
        """
        self.base_dir = base_dir or Path.home() / ".prooter"
        self._ensure_directories()
    
    def _ensure_directories(self) -> None:
        """Create required directories if they don't exist."""
        for directory in [
            self.base_dir,
            self.images_dir,
            self.layers_dir,
            self.containers_dir,
            self.bin_dir,
            self.tmp_dir,
        ]:
            directory.mkdir(parents=True, exist_ok=True)
    
    @property
    def images_dir(self) -> Path:
        """Directory for storing image metadata."""
        return self.base_dir / "images"
    
    @property
    def layers_dir(self) -> Path:
        """Directory for storing extracted layers."""
        return self.base_dir / "layers"
    
    @property
    def containers_dir(self) -> Path:
        """Directory for container instances."""
        return self.base_dir / "containers"
    
    @property
    def bin_dir(self) -> Path:
        """Directory for binary tools (proot, etc.)."""
        return self.base_dir / "bin"
    
    @property
    def tmp_dir(self) -> Path:
        """Temporary directory for downloads and extraction."""
        return self.base_dir / "tmp"
    
    @property
    def proot_binary(self) -> Path:
        """Path to PRoot binary."""
        return self.bin_dir / "proot"
    
    @property
    def fakechroot_lib(self) -> Path:
        """Path to fakechroot library."""
        return self.bin_dir / "libfakechroot.so"


# Global configuration instance
_config: Optional[Config] = None


def get_config() -> Config:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = Config()
    return _config


def init_config(base_dir: Optional[Path] = None) -> Config:
    """Initialize configuration with custom base directory."""
    global _config
    _config = Config(base_dir)
    return _config
