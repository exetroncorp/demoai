"""Prooter CLI - Docker-compatible command line interface."""

import argparse
import sys
from pathlib import Path
from typing import List, Optional

from prooter import __version__
from prooter.config import get_config, init_config
from prooter.registry import RegistryClient
from prooter.image.store import ImageStore
from prooter.container.manager import ContainerManager
from prooter.execution.base import get_best_engine
from prooter.execution.base import get_best_engine
from prooter.execution.proot import PRootEngine
from prooter.compose.parser import ComposeParser
from prooter.compose.manager import ComposeManager



def parse_volume(volume_str: str) -> tuple:
    """Parse a volume specification.
    
    Args:
        volume_str: Volume string in format HOST:CONTAINER[:ro]
        
    Returns:
        Tuple of (host_path, container_path)
    """
    parts = volume_str.split(":")
    if len(parts) < 2:
        raise ValueError(f"Invalid volume format: {volume_str}")
    
    host_path = parts[0]
    container_path = parts[1]
    # TODO: Handle :ro for read-only
    
    return (host_path, container_path)


def parse_env(env_str: str) -> tuple:
    """Parse an environment variable specification.
    
    Args:
        env_str: Environment string in format KEY=VALUE
        
    Returns:
        Tuple of (key, value)
    """
    if "=" in env_str:
        key, value = env_str.split("=", 1)
        return (key, value)
    else:
        # Use value from current environment
        import os
        return (env_str, os.environ.get(env_str, ""))


def cmd_pull(args) -> int:
    """Pull an image from a registry."""
    # Pass verify_ssl from args (not currently exposed in pull but good practice if added)
    client = RegistryClient(verify_ssl=not args.insecure if hasattr(args, "insecure") else True)
    
    try:
        manifest, image_dir = client.pull_image(args.image)
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_login(args) -> int:
    """Log in to a registry."""
    import getpass
    from prooter.registry.auth import AuthConfig
    
    registry = args.server
    username = args.username
    password = args.password
    
    if not username:
        username = input("Username: ")
    
    if not password:
        if args.password_stdin:
            password = sys.stdin.read().strip()
        else:
            password = getpass.getpass("Password: ")
            
    try:
        auth_config = AuthConfig()
        auth_config.set_credentials(registry, username, password)
        print("Login Succeeded")
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_build(args) -> int:
    """Build an image from a Dockerfile."""
    from prooter.build.dockerfile import DockerfileBuilder
    
    context_dir = Path(args.context).resolve()
    if not context_dir.exists():
        print(f"Error: Build context not found: {context_dir}", file=sys.stderr)
        return 1
    
    # Parse build args
    build_args = {}
    if args.build_arg:
        for arg in args.build_arg:
            if "=" in arg:
                key, value = arg.split("=", 1)
                build_args[key] = value
    
    builder = DockerfileBuilder()
    
    try:
        image_id = builder.build(
            context_dir=context_dir,
            dockerfile=args.file,
            tag=args.tag,
            build_args=build_args,
        )
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_images(args) -> int:
    """List local images."""
    store = ImageStore()
    images = store.list_images()
    
    if not images:
        print("No images found.")
        return 0
    
    # Print header
    print(f"{'REPOSITORY':<40} {'TAG':<15} {'IMAGE ID':<15} {'SIZE'}")
    
    for image in images:
        repo = image.repository
        if repo.startswith("library/"):
            repo = repo[8:]
        
        # Calculate size (approximate from layers)
        size = "N/A"
        
        print(f"{repo:<40} {image.tag:<15} {image.short_id:<15} {size}")
    
    return 0


def cmd_run(args) -> int:
    """Run a container."""
    store = ImageStore()
    manager = ContainerManager()
    
    # Parse the image and command
    image_ref = args.image
    command = args.command if args.command else None
    
    # Check if image exists locally
    image = store.get_image(image_ref)
    if not image:
        # Try to pull it
        print(f"Unable to find image '{image_ref}' locally")
        client = RegistryClient()
        try:
            client.pull_image(image_ref)
            image = store.get_image(image_ref)
        except Exception as e:
            print(f"Error pulling image: {e}", file=sys.stderr)
            return 1
    
    if not image:
        print(f"Error: Image '{image_ref}' not found", file=sys.stderr)
        return 1
    
    # Parse volumes
    volumes = []
    if args.volume:
        for vol_str in args.volume:
            try:
                volumes.append(parse_volume(vol_str))
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                return 1
    
    # Parse environment
    env = {}
    if args.env:
        for env_str in args.env:
            key, value = parse_env(env_str)
            env[key] = value
    
    # Create container
    try:
        container = manager.create(
            image_ref=image_ref,
            name=args.name,
            command=command,
            env=env,
            volumes=volumes,
            working_dir=args.workdir,
        )
    except Exception as e:
        print(f"Error creating container: {e}", file=sys.stderr)
        return 1
    
    # Get execution engine
    try:
        engine = get_best_engine()
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    
    # Get rootfs
    rootfs = manager.get_rootfs(container)
    
    # Update status
    manager.update_status(container, "running")
    
    # Run the container
    try:
        exit_code = engine.run(
            rootfs=rootfs,
            command=container.command,
            env=container.env,
            working_dir=container.working_dir,
            volumes=container.volumes,
            interactive=args.interactive,
            tty=args.tty,
        )
    finally:
        manager.update_status(container, "exited")
        
        # Remove container if --rm was specified
        if args.rm:
            manager.remove(container.name, force=True)
    
    return exit_code


def cmd_ps(args) -> int:
    """List containers."""
    manager = ContainerManager()
    containers = manager.list_containers(all=args.all)
    
    if not containers:
        print("No containers found.")
        return 0
    
    # Print header
    print(f"{'CONTAINER ID':<15} {'IMAGE':<25} {'COMMAND':<20} {'STATUS':<12} {'NAME'}")
    
    for container in containers:
        cmd_str = " ".join(container.command)[:17]
        if len(container.command) > 0 and len(" ".join(container.command)) > 17:
            cmd_str += "..."
        
        print(f"{container.short_id:<15} {container.image:<25} {cmd_str:<20} {container.status:<12} {container.name}")
    
    return 0


def cmd_rm(args) -> int:
    """Remove containers."""
    manager = ContainerManager()
    
    errors = 0
    for container_ref in args.containers:
        try:
            if manager.remove(container_ref, force=args.force):
                print(container_ref)
            else:
                print(f"Error: Container '{container_ref}' not found", file=sys.stderr)
                errors += 1
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            errors += 1
    
    return 1 if errors > 0 else 0


def cmd_rmi(args) -> int:
    """Remove images."""
    store = ImageStore()
    
    errors = 0
    for image_ref in args.images:
        if store.remove_image(image_ref):
            print(f"Untagged: {image_ref}")
        else:
            print(f"Error: Image '{image_ref}' not found", file=sys.stderr)
            errors += 1
    
    return 1 if errors > 0 else 0


def cmd_setup(args) -> int:
    """Setup prooter (download PRoot, check skopeo/umoci)."""
    config = get_config()
    
    print(f"Prooter data directory: {config.base_dir}")
    
    # Check/setup PRoot
    print("\n[1/3] Checking PRoot execution engine...")
    engine = PRootEngine(config)
    
    if engine.is_available():
        print(f"  ✓ PRoot is available: {engine.proot_binary}")
    else:
        try:
            engine.download_proot()
            print("  ✓ PRoot setup complete!")
        except Exception as e:
            print(f"  ✗ Error: {e}", file=sys.stderr)
            return 1
    
    # Check skopeo
    print("\n[2/3] Checking skopeo (image operations)...")
    from prooter.tools.skopeo import Skopeo
    skopeo = Skopeo(config)
    
    if skopeo.is_available():
        print(f"  ✓ skopeo is available: {skopeo.binary}")
    else:
        print("  ✗ skopeo not found")
        print("    Install with: apt-get install skopeo")
        print("    Or on Debian 12: sudo apt install skopeo")
    
    # Check umoci
    print("\n[3/3] Checking umoci (image unpacking)...")
    from prooter.tools.umoci import Umoci
    umoci = Umoci(config)
    
    if umoci.is_available():
        print(f"  ✓ umoci is available: {umoci.binary}")
    else:
        print("  ✗ umoci not found")
        print("    Install with: apt-get install umoci")
        print("    Or on Debian 12: sudo apt install umoci")
    
    # Set proot as the default engine
    print("\nSetting PRoot as default execution engine...")
    config.set_execution_engine("proot")
    print(f"  Configuration saved to: {config.base_dir / 'config.json'}")
    
    # Summary
    all_available = engine.is_available() and skopeo.is_available() and umoci.is_available()
    if all_available:
        print("\n✓ Setup complete! All tools are available.")
    else:
        print("\n⚠ Setup partially complete. Some tools need to be installed manually.")
    
    return 0


def cmd_version(args) -> int:
    """Show version information."""
    print(f"Prooter version {__version__}")
    
    # Show tool status
    config = get_config()
    
    print("\nExecution engines:")
    
    proot = PRootEngine(config)
    proot_status = "available" if proot.is_available() else "not installed"
    print(f"  PRoot: {proot_status}")
    
    from prooter.execution.fakechroot import FakechrootEngine
    fakechroot = FakechrootEngine(config)
    fakechroot_status = "available" if fakechroot.is_available() else "not installed"
    print(f"  Fakechroot: {fakechroot_status}")
    
    print("\nOCI tools:")
    
    from prooter.tools.skopeo import Skopeo
    skopeo = Skopeo(config)
    skopeo_status = "available" if skopeo.is_available() else "not installed"
    print(f"  skopeo: {skopeo_status}")
    
    from prooter.tools.umoci import Umoci
    umoci = Umoci(config)
    umoci_status = "available" if umoci.is_available() else "not installed"
    print(f"  umoci: {umoci_status}")
    
    return 0


def cmd_compose(args) -> int:
    """Manage compose services."""
    file_path = Path(args.file).resolve()
    
    try:
        parser = ComposeParser()
        config = parser.parse(file_path)
    except Exception as e:
        print(f"Error parsing compose file: {e}", file=sys.stderr)
        return 1
        
    project_name = args.project_name
    if not project_name:
        # Default to directory name
        project_name = file_path.parent.name
        
    manager = ComposeManager(config, project_name=project_name)
    
    if args.subcommand == "up":
        try:
            manager.up(detached=args.detach)
        except Exception as e:
            print(f"Error starting services: {e}", file=sys.stderr)
            return 1
    elif args.subcommand == "down":
        try:
            manager.down()
        except Exception as e:
            print(f"Error stopping services: {e}", file=sys.stderr)
            return 1
            
    return 0


def cmd_inspect(args) -> int:
    """Inspect an image using skopeo."""
    import json as json_module
    from prooter.tools.skopeo import Skopeo, SkopeoError
    
    config = get_config()
    skopeo = Skopeo(config)
    
    if not skopeo.is_available():
        print("Error: skopeo not found. Install with: apt install skopeo", file=sys.stderr)
        return 1
    
    image = args.image
    
    # Normalize image reference
    if not image.startswith(("docker://", "oci:", "dir:")):
        if "/" not in image.split(":")[0]:
            image = f"library/{image}"
        image = f"docker://{image}"
    
    try:
        if args.config:
            data = skopeo.inspect(image, config=True)
        elif args.raw:
            data = skopeo.inspect(image, raw=True)
        else:
            data = skopeo.inspect(image)
        
        print(json_module.dumps(data, indent=2))
        return 0
        
    except SkopeoError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="prooter",
        description="Rootless container runtime using PRoot and Fakechroot",
    )
    
    parser.add_argument(
        "-v", "--version",
        action="store_true",
        help="Show version information",
    )
    
    parser.add_argument(
        "-D", "--debug",
        action="store_true",
        help="Enable debug output",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # pull command
    pull_parser = subparsers.add_parser("pull", help="Pull an image from a registry")
    pull_parser.add_argument("image", help="Image to pull (e.g., alpine:latest)")
    pull_parser.add_argument("--insecure", action="store_true", help="Do not verify SSL certificates")
    pull_parser.set_defaults(func=cmd_pull)
    
    # login command
    login_parser = subparsers.add_parser("login", help="Log in to a registry")
    login_parser.add_argument(
        "server",
        default="docker.io",
        nargs="?",
        help="Registry server (default: docker.io)"
    )
    login_parser.add_argument("-u", "--username", help="Username")
    login_parser.add_argument("-p", "--password", help="Password")
    login_parser.add_argument(
        "--password-stdin",
        action="store_true",
        help="Read password from STDIN"
    )
    login_parser.set_defaults(func=cmd_login)
    
    # images command
    images_parser = subparsers.add_parser("images", help="List images")
    images_parser.set_defaults(func=cmd_images)
    
    # build command
    build_parser = subparsers.add_parser("build", help="Build an image from a Dockerfile")
    build_parser.add_argument(
        "context",
        default=".",
        nargs="?",
        help="Build context directory (default: .)"
    )
    build_parser.add_argument(
        "-f", "--file",
        default="Dockerfile",
        help="Name of the Dockerfile (default: Dockerfile)"
    )
    build_parser.add_argument(
        "-t", "--tag",
        help="Name and optionally a tag in the 'name:tag' format"
    )
    build_parser.add_argument(
        "--build-arg",
        action="append",
        help="Set build-time variables"
    )
    build_parser.set_defaults(func=cmd_build)
    
    # run command
    run_parser = subparsers.add_parser("run", help="Run a container")
    run_parser.add_argument("image", help="Image to run")
    run_parser.add_argument("command", nargs=argparse.REMAINDER, help="Command to run")
    run_parser.add_argument(
        "-i", "--interactive",
        action="store_true",
        help="Keep STDIN open",
    )
    run_parser.add_argument(
        "-t", "--tty",
        action="store_true",
        help="Allocate a pseudo-TTY",
    )
    run_parser.add_argument(
        "--rm",
        action="store_true",
        help="Remove container after exit",
    )
    run_parser.add_argument(
        "--name",
        help="Container name",
    )
    run_parser.add_argument(
        "-v", "--volume",
        action="append",
        help="Bind mount a volume (HOST:CONTAINER)",
    )
    run_parser.add_argument(
        "-e", "--env",
        action="append",
        help="Set environment variable (KEY=VALUE)",
    )
    run_parser.add_argument(
        "-w", "--workdir",
        help="Working directory inside the container",
    )
    run_parser.set_defaults(func=cmd_run)
    
    # ps command
    ps_parser = subparsers.add_parser("ps", help="List containers")
    ps_parser.add_argument(
        "-a", "--all",
        action="store_true",
        help="Show all containers (including stopped)",
    )
    ps_parser.set_defaults(func=cmd_ps)
    
    # rm command
    rm_parser = subparsers.add_parser("rm", help="Remove containers")
    rm_parser.add_argument("containers", nargs="+", help="Containers to remove")
    rm_parser.add_argument(
        "-f", "--force",
        action="store_true",
        help="Force removal",
    )
    rm_parser.set_defaults(func=cmd_rm)
    
    # rmi command
    rmi_parser = subparsers.add_parser("rmi", help="Remove images")
    rmi_parser.add_argument("images", nargs="+", help="Images to remove")
    rmi_parser.set_defaults(func=cmd_rmi)
    
    # setup command
    setup_parser = subparsers.add_parser("setup", help="Setup prooter")
    setup_parser.set_defaults(func=cmd_setup)
    
    # version command
    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.set_defaults(func=cmd_version)
    
    # inspect command
    inspect_parser = subparsers.add_parser("inspect", help="Inspect an image")
    inspect_parser.add_argument("image", help="Image to inspect (e.g., alpine:latest)")
    inspect_parser.add_argument(
        "--raw",
        action="store_true",
        help="Show raw manifest",
    )
    inspect_parser.add_argument(
        "--config",
        action="store_true",
        help="Show config blob",
    )
    inspect_parser.set_defaults(func=cmd_inspect)
    
    # compose command
    compose_parser = subparsers.add_parser("compose", help="Define and run multi-container applications")
    compose_parser.add_argument(
        "-f", "--file",
        default="prooter-compose.yml",
        help="Specify an alternate compose file",
    )
    compose_parser.add_argument(
        "-p", "--project-name",
        help="Specify an alternate project name",
    )
    
    compose_subparsers = compose_parser.add_subparsers(dest="subcommand", help="Commands")
    
    # compose up
    up_parser = compose_subparsers.add_parser("up", help="Create and start containers")
    up_parser.add_argument(
        "-d", "--detach",
        action="store_true",
        help="Detached mode: Run containers in the background",
    )
    
    # compose down
    down_parser = compose_subparsers.add_parser("down", help="Stop and remove containers")
    
    compose_parser.set_defaults(func=cmd_compose)
    
    return parser

    
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """Main entry point.
    
    Args:
        argv: Command line arguments (defaults to sys.argv[1:])
        
    Returns:
        Exit code
    """
    parser = create_parser()
    args = parser.parse_args(argv)
    
    # Handle -v flag at top level
    if args.version:
        return cmd_version(args)
    
    # Initialize configuration
    init_config()
    
    # Run command
    if args.command is None:
        parser.print_help()
        return 0
    
    if hasattr(args, "func"):
        return args.func(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
