"""Docker Registry authentication handling."""

import requests
from typing import Optional, Dict, Tuple
from urllib.parse import urlparse


class RegistryAuth:
    """Handle authentication with Docker registries."""
    
    # Docker Hub auth endpoint
    DOCKER_HUB_AUTH = "https://auth.docker.io/token"
    DOCKER_HUB_SERVICE = "registry.docker.io"
    
    def __init__(self, username: Optional[str] = None, password: Optional[str] = None):
        """Initialize authentication.
        
        Args:
            username: Registry username (optional for public images)
            password: Registry password or token
        """
        self.username = username
        self.password = password
        self._tokens: Dict[str, str] = {}
    
    def get_token(self, registry: str, repository: str) -> Optional[str]:
        """Get authentication token for a repository.
        
        Args:
            registry: Registry hostname
            repository: Repository name (e.g., 'library/alpine')
            
        Returns:
            Bearer token or None if authentication fails
        """
        cache_key = f"{registry}/{repository}"
        if cache_key in self._tokens:
            return self._tokens[cache_key]
        
        token = self._fetch_token(registry, repository)
        if token:
            self._tokens[cache_key] = token
        return token
    
    def _fetch_token(self, registry: str, repository: str) -> Optional[str]:
        """Fetch a new authentication token.
        
        Args:
            registry: Registry hostname
            repository: Repository name
            
        Returns:
            Bearer token or None
        """
        if registry in ("registry-1.docker.io", "docker.io", ""):
            return self._fetch_docker_hub_token(repository)
        else:
            return self._fetch_generic_token(registry, repository)
    
    def _fetch_docker_hub_token(self, repository: str) -> Optional[str]:
        """Fetch token from Docker Hub.
        
        Args:
            repository: Repository name
            
        Returns:
            Bearer token or None
        """
        params = {
            "service": self.DOCKER_HUB_SERVICE,
            "scope": f"repository:{repository}:pull",
        }
        
        auth = None
        if self.username and self.password:
            auth = (self.username, self.password)
        
        try:
            response = requests.get(
                self.DOCKER_HUB_AUTH,
                params=params,
                auth=auth,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            return data.get("token") or data.get("access_token")
        except requests.RequestException as e:
            print(f"Warning: Failed to get Docker Hub token: {e}")
            return None
    
    def _fetch_generic_token(self, registry: str, repository: str) -> Optional[str]:
        """Fetch token from a generic registry.
        
        Args:
            registry: Registry hostname
            repository: Repository name
            
        Returns:
            Bearer token or None
        """
        # Try to discover auth endpoint from WWW-Authenticate header
        try:
            test_url = f"https://{registry}/v2/"
            response = requests.get(test_url, timeout=10)
            
            if response.status_code == 401:
                auth_header = response.headers.get("WWW-Authenticate", "")
                auth_info = self._parse_www_authenticate(auth_header)
                
                if auth_info:
                    realm, service = auth_info
                    params = {
                        "service": service,
                        "scope": f"repository:{repository}:pull",
                    }
                    
                    auth = None
                    if self.username and self.password:
                        auth = (self.username, self.password)
                    
                    token_response = requests.get(
                        realm,
                        params=params,
                        auth=auth,
                        timeout=30
                    )
                    token_response.raise_for_status()
                    data = token_response.json()
                    return data.get("token") or data.get("access_token")
            
            return None
        except requests.RequestException:
            return None
    
    def _parse_www_authenticate(self, header: str) -> Optional[Tuple[str, str]]:
        """Parse WWW-Authenticate header to extract realm and service.
        
        Args:
            header: WWW-Authenticate header value
            
        Returns:
            Tuple of (realm, service) or None
        """
        if not header.startswith("Bearer "):
            return None
        
        parts = header[7:].split(",")
        params = {}
        
        for part in parts:
            part = part.strip()
            if "=" in part:
                key, value = part.split("=", 1)
                params[key.strip()] = value.strip().strip('"')
        
        realm = params.get("realm")
        service = params.get("service")
        
        if realm and service:
            return (realm, service)
        return None
    
    def get_auth_headers(self, registry: str, repository: str) -> Dict[str, str]:
        """Get authentication headers for API requests.
        
        Args:
            registry: Registry hostname
            repository: Repository name
            
        Returns:
            Dictionary of headers to include in requests
        """
        token = self.get_token(registry, repository)
        if token:
            return {"Authorization": f"Bearer {token}"}
        return {}
