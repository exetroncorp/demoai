"""OCI/Docker manifest parsing."""

import json
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class LayerDescriptor:
    """Describes a single layer in an image."""
    
    digest: str
    size: int
    media_type: str
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LayerDescriptor":
        """Create from dictionary."""
        return cls(
            digest=data["digest"],
            size=data.get("size", 0),
            media_type=data.get("mediaType", "application/vnd.oci.image.layer.v1.tar+gzip"),
        )


@dataclass
class ImageConfig:
    """Image configuration metadata."""
    
    digest: str
    size: int
    media_type: str
    
    # Parsed config data
    architecture: str = "amd64"
    os: str = "linux"
    cmd: List[str] = field(default_factory=list)
    entrypoint: List[str] = field(default_factory=list)
    env: List[str] = field(default_factory=list)
    working_dir: str = "/"
    user: str = ""
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ImageConfig":
        """Create from config descriptor dictionary."""
        return cls(
            digest=data["digest"],
            size=data.get("size", 0),
            media_type=data.get("mediaType", "application/vnd.oci.image.config.v1+json"),
        )
    
    def update_from_config_blob(self, config_data: Dict[str, Any]) -> None:
        """Update with parsed config blob data."""
        self.architecture = config_data.get("architecture", "amd64")
        self.os = config_data.get("os", "linux")
        
        container_config = config_data.get("config", {})
        self.cmd = container_config.get("Cmd", []) or []
        self.entrypoint = container_config.get("Entrypoint", []) or []
        self.env = container_config.get("Env", []) or []
        self.working_dir = container_config.get("WorkingDir", "/") or "/"
        self.user = container_config.get("User", "") or ""


@dataclass
class ImageManifest:
    """Represents an OCI/Docker image manifest."""
    
    schema_version: int
    media_type: str
    config: ImageConfig
    layers: List[LayerDescriptor]
    
    # Original manifest data
    raw_data: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def total_size(self) -> int:
        """Calculate total size of all layers."""
        return sum(layer.size for layer in self.layers)
    
    def get_layer_digests(self) -> List[str]:
        """Get list of layer digests in order."""
        return [layer.digest for layer in self.layers]


@dataclass  
class ManifestList:
    """Represents a multi-arch manifest list."""
    
    schema_version: int
    media_type: str
    manifests: List[Dict[str, Any]]
    
    def get_manifest_for_platform(
        self, 
        os: str = "linux", 
        architecture: str = "amd64",
        variant: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Get manifest descriptor for a specific platform.
        
        Args:
            os: Target OS (default: linux)
            architecture: Target architecture (default: amd64)
            variant: Architecture variant (e.g., v8 for arm64)
            
        Returns:
            Manifest descriptor or None if not found
        """
        for manifest in self.manifests:
            platform = manifest.get("platform", {})
            if platform.get("os") == os and platform.get("architecture") == architecture:
                if variant is None or platform.get("variant") == variant:
                    return manifest
        return None


def parse_manifest(data: Dict[str, Any]) -> ImageManifest | ManifestList:
    """Parse a manifest from JSON data.
    
    Args:
        data: Parsed JSON manifest data
        
    Returns:
        ImageManifest or ManifestList depending on manifest type
        
    Raises:
        ValueError: If manifest format is not recognized
    """
    schema_version = data.get("schemaVersion", 2)
    media_type = data.get("mediaType", "")
    
    # Check if this is a manifest list (multi-arch)
    if media_type in (
        "application/vnd.docker.distribution.manifest.list.v2+json",
        "application/vnd.oci.image.index.v1+json",
    ) or "manifests" in data:
        return ManifestList(
            schema_version=schema_version,
            media_type=media_type,
            manifests=data.get("manifests", []),
        )
    
    # Parse as single image manifest
    config_data = data.get("config", {})
    layers_data = data.get("layers", [])
    
    # Handle Docker manifest v2 schema 1 (legacy)
    if schema_version == 1:
        # Schema 1 has fsLayers instead of layers
        fs_layers = data.get("fsLayers", [])
        layers = [
            LayerDescriptor(
                digest=layer.get("blobSum", ""),
                size=0,
                media_type="application/vnd.docker.image.rootfs.diff.tar.gzip",
            )
            for layer in reversed(fs_layers)  # Schema 1 has layers in reverse order
        ]
        
        return ImageManifest(
            schema_version=schema_version,
            media_type=media_type or "application/vnd.docker.distribution.manifest.v1+json",
            config=ImageConfig(
                digest="",
                size=0,
                media_type="",
            ),
            layers=layers,
            raw_data=data,
        )
    
    # Schema 2 or OCI manifest
    config = ImageConfig.from_dict(config_data)
    layers = [LayerDescriptor.from_dict(layer) for layer in layers_data]
    
    return ImageManifest(
        schema_version=schema_version,
        media_type=media_type or "application/vnd.docker.distribution.manifest.v2+json",
        config=config,
        layers=layers,
        raw_data=data,
    )


def parse_image_reference(reference: str) -> tuple[str, str, str]:
    """Parse an image reference into registry, repository, and tag.
    
    Args:
        reference: Image reference (e.g., 'alpine:3.18', 'docker.io/library/nginx:latest')
        
    Returns:
        Tuple of (registry, repository, tag)
    """
    # Default values
    registry = "registry-1.docker.io"
    tag = "latest"
    
    # Split tag
    if "@" in reference:
        # Digest reference
        reference, tag = reference.rsplit("@", 1)
    elif ":" in reference and "/" not in reference.split(":")[-1]:
        reference, tag = reference.rsplit(":", 1)
    
    # Split registry and repository
    parts = reference.split("/")
    
    if len(parts) == 1:
        # Just image name (e.g., 'alpine')
        repository = f"library/{parts[0]}"
    elif len(parts) == 2:
        # Could be registry/image or namespace/image
        if "." in parts[0] or ":" in parts[0] or parts[0] == "localhost":
            # It's a registry
            registry = parts[0]
            repository = f"library/{parts[1]}"
        else:
            # It's namespace/image on Docker Hub
            repository = reference
    else:
        # Full reference with registry
        registry = parts[0]
        repository = "/".join(parts[1:])
    
    return registry, repository, tag
