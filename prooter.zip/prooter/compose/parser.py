"""Prooter Compose parser."""

import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Any

@dataclass
class ServiceConfig:
    name: str
    image: str
    command: Optional[List[str]] = None
    volumes: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    ports: List[str] = field(default_factory=list)

@dataclass
class ComposeConfig:
    services: Dict[str, ServiceConfig] = field(default_factory=dict)
    version: str = "1.0"

class ComposeParser:
    """Parser for prooter-compose.yml files."""
    
    def parse(self, file_path: Path) -> ComposeConfig:
        """Parse a compose file.
        
        Args:
            file_path: Path to prooter-compose.yml
            
        Returns:
            ComposeConfig object
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Compose file not found: {file_path}")
            
        with open(file_path, 'r') as f:
            try:
                data = yaml.safe_load(f)
            except yaml.YAMLError as e:
                raise ValueError(f"Error parsing YAML: {e}")
        
        if not data or 'services' not in data:
            raise ValueError("Invalid compose file: 'services' not found")
            
        config = ComposeConfig()
        if 'version' in data:
            config.version = str(data['version'])
            
        for name, svc_data in data['services'].items():
            if 'image' not in svc_data:
                raise ValueError(f"Service '{name}' missing 'image' field")
                
            service = ServiceConfig(
                name=name,
                image=svc_data['image']
            )
            
            if 'command' in svc_data:
                cmd = svc_data['command']
                if isinstance(cmd, str):
                    service.command = cmd.split()
                else:
                    service.command = cmd
                    
            if 'volumes' in svc_data:
                service.volumes = svc_data['volumes']
                
            if 'environment' in svc_data:
                env_data = svc_data['environment']
                if isinstance(env_data, list):
                    # Handle ["KEY=VAL"] format
                    for item in env_data:
                        if "=" in item:
                            k, v = item.split("=", 1)
                            service.env[k] = v
                elif isinstance(env_data, dict):
                    # Handle {KEY: VAL} format
                    for k, v in env_data.items():
                        service.env[str(k)] = str(v)
                        
            if 'ports' in svc_data:
                # Ports are parsed but mostly informational in Prooter (host net)
                service.ports = [str(p) for p in svc_data['ports']]
                
            config.services[name] = service
            
        return config
