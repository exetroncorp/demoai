"""Local image storage management."""

import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any

from prooter.config import get_config
from prooter.image.layer import apply_layers, get_layer_path


@dataclass
class LocalImage:
    """Represents a locally stored image."""
    
    image_id: str
    repository: str
    tag: str
    registry: str
    layers: List[str]
    config: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def full_name(self) -> str:
        """Get the full image name with tag."""
        if self.registry in ("registry-1.docker.io", "docker.io"):
            # Docker Hub - don't show registry
            if self.repository.startswith("library/"):
                return f"{self.repository[8:]}:{self.tag}"
            return f"{self.repository}:{self.tag}"
        return f"{self.registry}/{self.repository}:{self.tag}"
    
    @property
    def short_id(self) -> str:
        """Get short image ID."""
        return self.image_id[:12]
    
    @classmethod
    def from_metadata(cls, metadata: Dict[str, Any], config: Dict[str, Any]) -> "LocalImage":
        """Create from metadata dictionary."""
        return cls(
            image_id=metadata["image_id"],
            repository=metadata["repository"],
            tag=metadata["tag"],
            registry=metadata["registry"],
            layers=metadata["layers"],
            config=config,
        )


class ImageStore:
    """Manages local image storage."""
    
    def __init__(self, config=None):
        """Initialize the image store.
        
        Args:
            config: Optional configuration object
        """
        self.config = config or get_config()
    
    def list_images(self) -> List[LocalImage]:
        """List all locally stored images.
        
        Returns:
            List of LocalImage objects
        """
        images = []
        
        if not self.config.images_dir.exists():
            return images
        
        for image_dir in self.config.images_dir.iterdir():
            if not image_dir.is_dir():
                continue
            
            metadata_path = image_dir / "metadata.json"
            config_path = image_dir / "config.json"
            
            if not metadata_path.exists():
                continue
            
            try:
                with open(metadata_path) as f:
                    metadata = json.load(f)
                
                config_data = {}
                if config_path.exists():
                    with open(config_path) as f:
                        config_data = json.load(f)
                
                images.append(LocalImage.from_metadata(metadata, config_data))
            except (json.JSONDecodeError, KeyError) as e:
                print(f"Warning: Failed to load image {image_dir.name}: {e}")
        
        return images
    
    def get_image(self, reference: str) -> Optional[LocalImage]:
        """Get a locally stored image by reference.
        
        Args:
            reference: Image reference (name:tag or ID)
            
        Returns:
            LocalImage or None if not found
        """
        images = self.list_images()
        
        # Normalize reference
        search_ref = reference
        if ":" not in reference and not (len(reference) >= 12 and all(c in "0123456789abcdef" for c in reference)):
            search_ref = f"{reference}:latest"
            
        for image in images:
            # Match by full name
            if image.full_name == search_ref or image.full_name == reference:
                return image
            
            # Match by repository:tag
            repo_tag = f"{image.repository}:{image.tag}"
            if repo_tag == search_ref or repo_tag == reference:
                return image
            
            # Match by short name:tag (for Docker Hub)
            if image.repository.startswith("library/"):
                short_name = f"{image.repository[8:]}:{image.tag}"
                if short_name == reference:
                    return image
            
            # Match by ID
            if reference.startswith(image.image_id) or image.image_id.startswith(reference):
                return image
        
        return None
    
    def get_image_dir(self, image: LocalImage) -> Path:
        """Get the directory for an image.
        
        Args:
            image: LocalImage object
            
        Returns:
            Path to image directory
        """
        return self.config.images_dir / image.image_id[:12]
    
    def create_rootfs(self, image: LocalImage, container_dir: Path) -> Path:
        """Create a root filesystem for a container from an image.
        
        Args:
            image: LocalImage to create rootfs from
            container_dir: Container directory
            
        Returns:
            Path to the rootfs directory
        """
        rootfs = container_dir / "rootfs"
        
        if rootfs.exists():
            # Already exists
            return rootfs

        # Check for pre-built rootfs in image directory (e.g. from prooter build)
        image_dir = self.get_image_dir(image)
        image_rootfs = image_dir / "rootfs"
        if image_rootfs.exists() and image_rootfs.is_dir():
            print(f"Creating rootfs from image directory...")
            shutil.copytree(image_rootfs, rootfs, symlinks=True)
            return rootfs
        
        print(f"Creating rootfs from {len(image.layers)} layers...")
        
        # Get layer paths in order
        layer_paths = [
            get_layer_path(self.config.layers_dir, digest)
            for digest in image.layers
        ]
        
        # Verify all layers exist
        for i, path in enumerate(layer_paths):
            if not path.exists():
                raise FileNotFoundError(f"Layer not found: {image.layers[i]}")
        
        # Apply layers
        def progress(current: int, total: int) -> None:
            if current < total:
                print(f"  Extracting layer {current + 1}/{total}...")
        
        apply_layers(layer_paths, rootfs, progress)
        print("  Rootfs created successfully")
        
        return rootfs
    
    def remove_image(self, reference: str) -> bool:
        """Remove a locally stored image.
        
        Args:
            reference: Image reference
            
        Returns:
            True if removed, False if not found
        """
        image = self.get_image(reference)
        if not image:
            return False
        
        image_dir = self.get_image_dir(image)
        if image_dir.exists():
            shutil.rmtree(image_dir)
        
        return True
    
    def get_image_config(self, image: LocalImage) -> Dict[str, Any]:
        """Get the config for an image.
        
        Args:
            image: LocalImage object
            
        Returns:
            Config dictionary
        """
        if image.config:
            return image.config
        
        config_path = self.get_image_dir(image) / "config.json"
        if config_path.exists():
            with open(config_path) as f:
                return json.load(f)
        
        return {}
