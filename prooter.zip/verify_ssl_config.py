
import json
import os
from pathlib import Path
from prooter.config import init_config
from prooter.registry.client import RegistryClient

def verify_ssl_config():
    print("Verifying SSL config...")
    
    # Setup paths
    home = Path.home()
    prooter_dir = home / ".prooter"
    config_file = prooter_dir / "config.json"
    
    # Ensure directory exists
    prooter_dir.mkdir(parents=True, exist_ok=True)
    
    # Test 1: Default (verify-ssl: True/Missing)
    print("Test 1: Default (verify-ssl implicit)...", end=" ")
    if config_file.exists():
        config_file.unlink()
        
    init_config() # Reload config
    client = RegistryClient()
    
    if client.verify_ssl is True and client.auth.verify_ssl is True:
        print("PASSED")
    else:
        print(f"FAILED (Client: {client.verify_ssl}, Auth: {client.auth.verify_ssl})")
        return
        
    # Test 2: Disable verify-ssl
    print("Test 2: verify-ssl: false...", end=" ")
    
    with open(config_file, "w") as f:
        json.dump({"verify-ssl": False}, f)
        
    init_config() # Reload config
    client = RegistryClient()
    
    if client.verify_ssl is False and client.auth.verify_ssl is False:
        print("PASSED")
    else:
        print(f"FAILED (Client: {client.verify_ssl}, Auth: {client.auth.verify_ssl})")
        return
    
    # Test 3: Override via arg (if supported effectively, though cmd_run doesn't expose it yet)
    print("Test 3: Override in constructor...", end=" ")
    client = RegistryClient(verify_ssl=True) # Even with config false
    if client.verify_ssl is True:
        print("PASSED")
    else:
        print(f"FAILED (Got {client.verify_ssl})")
        return

    # Clean up
    if config_file.exists():
        config_file.unlink()

if __name__ == "__main__":
    verify_ssl_config()
