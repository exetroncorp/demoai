# Prooter

A rootless Docker alternative for constrained environments using PRoot (ptrace) and Fakechroot execution modes.

## Features

- Run Docker containers without root privileges or namespaces
- Docker-compatible CLI (`prooter pull`, `prooter run`, etc.)
- PRoot-based execution using ptrace syscall interception
- Fakechroot fallback for better performance

## Installation

```bash
pip install -e .
```

## Usage

```bash
# Pull an image
prooter pull alpine:latest

# Run a container
prooter run alpine:latest echo "Hello World"

# Interactive shell
prooter run -it debian:latest /bin/bash

# With volume mount
prooter run -v /host/path:/container/path alpine:latest ls /container/path

# List images
prooter images

# List containers
prooter ps
```

## Requirements

- Python 3.8+
- Linux x86_64
- No root privileges required
- No namespace support required

## Execution Modes

- **PRoot (P)**: Primary mode using ptrace syscall interception
- **Fakechroot (F)**: Secondary mode using LD_PRELOAD (faster but less compatible)

## License

Apache-2.0
