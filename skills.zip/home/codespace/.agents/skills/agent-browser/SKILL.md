---
name: agent-browser
description: "Browser automation CLI for AI agents. Use when the user needs to interact with websites, including navigating pages, filling forms, clicking buttons, taking screenshots, extracting data, testing web apps, or automating any browser task. Triggers include requests to open a website, fill out a form, click a button, take a screenshot, scrape data from a page, test this web app, login to a site, automate browser actions, or any task requiring programmatic web interaction."
allowed-tools: Bash(npx agent-browser:*), Bash(agent-browser:*)
risk: medium
source: community
date_added: "2026-03-15"
---

# Browser Automation with agent-browser

> Browser automation CLI for AI agents. Automate web interactions including navigation, forms, scraping, and testing.

## Installation

```bash
npm i -g agent-browser
# or
brew install agent-browser
# or
cargo install agent-browser
```

Run `agent-browser install` to download Chrome.

## Core Workflow

1. **Navigate**: `agent-browser open <url>`
2. **Snapshot**: `agent-browser snapshot -i` (get element refs like `@e1`, `@e2`)
3. **Interact**: Use refs to click, fill, select
4. **Re-snapshot**: After navigation or DOM changes, get fresh refs

```bash
agent-browser open https://example.com/form
agent-browser snapshot -i
# Output: @e1 [input type="email"], @e2 [input type="password"], @e3 [button] "Submit"

agent-browser fill @e1 "user@example.com"
agent-browser fill @e2 "password123"
agent-browser click @e3
agent-browser wait --load networkidle
agent-browser snapshot -i  # Check result
```

## Command Chaining

Commands can be chained with `&&` in a single shell invocation:

```bash
# Chain open + wait + snapshot
agent-browser open https://example.com && agent-browser wait --load networkidle && agent-browser snapshot -i

# Chain multiple interactions
agent-browser fill @e1 "user@example.com" && agent-browser fill @e2 "password123" && agent-browser click @e3
```

## Essential Commands

### Navigation
- `agent-browser open <url>` - Navigate to URL
- `agent-browser close` - Close browser

### Snapshot
- `agent-browser snapshot -i` - Interactive elements with refs
- `agent-browser snapshot -i -C` - Include cursor-interactive elements

### Interaction (use @refs from snapshot)
- `agent-browser click @e1` - Click element
- `agent-browser fill @e2 "text"` - Clear and type text
- `agent-browser type @e2 "text"` - Type without clearing
- `agent-browser select @e1 "option"` - Select dropdown option
- `agent-browser check @e1` - Check checkbox

### Get Information
- `agent-browser get text @e1` - Get element text
- `agent-browser get url` - Get current URL
- `agent-browser get title` - Get page title

### Wait
- `agent-browser wait @e1` - Wait for element
- `agent-browser wait --load networkidle` - Wait for network idle
- `agent-browser wait --url "**/page"` - Wait for URL pattern

### Capture
- `agent-browser screenshot` - Screenshot to temp dir
- `agent-browser screenshot --full` - Full page screenshot
- `agent-browser screenshot --annotate` - Annotated screenshot with numbered element labels

## Authentication Options

### Option 1: Import from user's browser
```bash
agent-browser --auto-connect state save ./auth.json
agent-browser --state ./auth.json open https://app.example.com/dashboard
```

### Option 2: Persistent profile
```bash
agent-browser --profile ~/.myapp open https://app.example.com/login
# ... login ...
agent-browser --profile ~/.myapp open https://app.example.com/dashboard
```

### Option 3: Auth vault (recommended)
```bash
echo "$PASSWORD" | agent-browser auth save myapp --url https://app.example.com/login --username user --password-stdin
agent-browser auth login myapp
```

## Common Patterns

### Form Submission
```bash
agent-browser open https://example.com/signup
agent-browser snapshot -i
agent-browser fill @e1 "Jane Doe"
agent-browser fill @e2 "jane@example.com"
agent-browser click @e5
agent-browser wait --load networkidle
```

### Data Extraction
```bash
agent-browser open https://example.com/products
agent-browser snapshot -i
agent-browser get text @e5
agent-browser get text body > page.txt
```

## Ref Lifecycle (Important)

Refs (`@e1`, `@e2`, etc.) are invalidated when the page changes. Always re-snapshot after:
- Clicking links or buttons that navigate
- Form submissions
- Dynamic content loading

```bash
agent-browser click @e5              # Navigates to new page
agent-browser snapshot -i            # MUST re-snapshot
agent-browser click @e1              # Use new refs
```

## Viewport & Device Emulation
```bash
agent-browser set viewport 1920 1080
agent-browser set device "iPhone 14"
```

## Visual Browser (Debugging)
```bash
agent-browser --headed open https://example.com
agent-browser highlight @e1
agent-browser inspect
```

## Security Features

- `--content-boundaries` - Wrap page content in markers
- Domain allowlist via `AGENT_BROWSER_ALLOWED_DOMAINS`
- Action policy via `AGENT_BROWSER_ACTION_POLICY`
- Output limits via `AGENT_BROWSER_MAX_OUTPUT`

## When to Use

This skill should be used when:
- User asks to open a website
- User asks to fill out a form
- User asks to click a button
- User asks to take a screenshot
- User asks to scrape data from a page
- User asks to test a web app
- User asks to login to a site
- User asks to automate browser actions
- Any task requiring programmatic web interaction