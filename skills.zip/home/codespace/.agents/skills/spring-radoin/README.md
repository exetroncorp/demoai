# skill-bank-spring

Lightweight, token-efficient agent skill for scaffolding **production-ready Spring Boot** applications with:

- **Architecture**: DDD + Hexagonal (Ports & Adapters)
- **Database**: PostgreSQL (production) / H2 (development)
- **Testing**: TDD (JUnit 5, Mockito, AssertJ) + BDD (Cucumber 7)
- **Frontend**: Shadcn/UI-inspired dark mode, Roboto font
- **Environment**: Rootless Debian pods, pre-installed Maven — no Docker, no sudo

## Who is this for?

Teams using browser-based IDEs (code-server) with open-source AI coding CLIs:
- Mistral VIEB, OpenCode CLI, Kilo Code CLI, or any tool that reads `SKILL.md`

## How it works

```
Phase 1 — SCAFFOLD (deterministic script)
  node scripts/scaffold.mjs com.acme todo-app com.acme.todo

Phase 2 — CUSTOMIZE (AI agent)
  Agent reads SKILL.md and fills in domain-specific code
```

The script generates the entire project structure, pom.xml, configs, BDD setup, and frontend. The agent only needs to add domain logic — even 7B models can handle this.

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| Java | 21 LTS | Pre-installed in pod |
| Maven | 3.8+ | Pre-installed in pod |
| Node.js | 18+ | For scaffold script only |

## Quick Start

```bash
node scripts/scaffold.mjs com.acme todo-app com.acme.todo
cd todo-app
mvn clean verify        # compile + run all tests
mvn spring-boot:run     # start dev server on :8080
```

## Files

| File | Purpose |
|------|---------|
| `SKILL.md` | Complete architecture guide + code examples for the AI agent |
| `AGENTS.md` | Guard-rails (no Lombok, no Docker, etc.) |
| `scripts/scaffold.mjs` | Project skeleton generator (zero npm deps) |

## License

MIT
