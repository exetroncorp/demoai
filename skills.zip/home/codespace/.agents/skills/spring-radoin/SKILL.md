---
name: skill-bank-spring
description: "Scaffolds production-ready Spring Boot apps with DDD/Hexagonal architecture, PostgreSQL+H2, TDD+BDD (Cucumber), and Shadcn/UI dark-mode frontend. Run the scaffold script first, then customize for any business domain."
---

# Spring Boot DDD/Hexagonal Skill

## Quick Start

```bash
# 1. Scaffold the project skeleton
node scripts/scaffold.mjs <groupId> <artifactId> <basePackage>

# Example:
node scripts/scaffold.mjs com.acme todo-app com.acme.todo

# 2. Compile & test
cd todo-app
mvn clean verify

# 3. Run dev server (H2 in-memory, port 8080)
mvn spring-boot:run
```

## Prerequisites

- Java 21 (pre-installed in pod)
- Maven 3.8+ (pre-installed in pod)
- Node.js 18+ (for running scaffold script only)
- **No Docker, no sudo required**

## Architecture: DDD + Hexagonal (Ports & Adapters)

```
src/main/java/<basePackage>/
├── domain/                        # Pure business logic (no framework imports)
│   ├── model/                     # Entities, Value Objects, Domain Events
│   └── port/
│       ├── in/                    # DRIVING ports (use case interfaces)
│       └── out/                   # DRIVEN ports (repository interfaces)
├── application/
│   └── service/                   # Use case implementations (orchestration)
└── infrastructure/
    ├── adapter/
    │   ├── in/web/                # REST controllers (driving adapters)
    │   └── out/persistence/       # JPA repositories (driven adapters)
    └── config/                    # Spring config, CORS, exception handling
```

### Layer Rules

| Layer | Depends on | Never depends on |
|-------|-----------|-----------------|
| `domain` | nothing | application, infrastructure |
| `application` | domain ports | infrastructure |
| `infrastructure` | domain ports, application | — |

## Domain Layer

### Entity

```java
package com.acme.todo.domain.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.Instant;

@Entity
@Table(name = "todos")
public class Todo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String title;

    private boolean completed;

    @Column(name = "created_at")
    private Instant createdAt = Instant.now();

    protected Todo() {} // JPA

    public Todo(String title) {
        this.title = title;
        this.completed = false;
    }

    // Getters and setters
    public Long getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public boolean isCompleted() { return completed; }
    public void complete() { this.completed = true; }
    public Instant getCreatedAt() { return createdAt; }
}
```

### Driving Port (use case interface)

```java
package com.acme.todo.domain.port.in;

import com.acme.todo.domain.model.Todo;
import java.util.List;

public interface ManageTodoUseCase {
    Todo create(String title);
    List<Todo> listAll();
    Todo getById(Long id);
    Todo complete(Long id);
    void delete(Long id);
}
```

### Driven Port (repository interface)

```java
package com.acme.todo.domain.port.out;

import com.acme.todo.domain.model.Todo;
import java.util.List;
import java.util.Optional;

public interface TodoRepository {
    Todo save(Todo todo);
    Optional<Todo> findById(Long id);
    List<Todo> findAll();
    void deleteById(Long id);
}
```

## Application Layer

```java
package com.acme.todo.application.service;

import com.acme.todo.domain.model.Todo;
import com.acme.todo.domain.port.in.ManageTodoUseCase;
import com.acme.todo.domain.port.out.TodoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class TodoService implements ManageTodoUseCase {

    private final TodoRepository repository;

    public TodoService(TodoRepository repository) {
        this.repository = repository;
    }

    @Override
    public Todo create(String title) {
        return repository.save(new Todo(title));
    }

    @Override
    public List<Todo> listAll() {
        return repository.findAll();
    }

    @Override
    public Todo getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Todo not found: " + id));
    }

    @Override
    public Todo complete(Long id) {
        Todo todo = getById(id);
        todo.complete();
        return repository.save(todo);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
}
```

## Infrastructure Layer

### Driven Adapter — JPA Repository

```java
package com.acme.todo.infrastructure.adapter.out.persistence;

import com.acme.todo.domain.model.Todo;
import com.acme.todo.domain.port.out.TodoRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JpaTodoRepository extends JpaRepository<Todo, Long>, TodoRepository {
    // Spring Data JPA auto-implements all methods declared in TodoRepository
}
```

### Driving Adapter — REST Controller

```java
package com.acme.todo.infrastructure.adapter.in.web;

import com.acme.todo.domain.model.Todo;
import com.acme.todo.domain.port.in.ManageTodoUseCase;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/todos")
public class TodoController {

    private final ManageTodoUseCase useCase;

    public TodoController(ManageTodoUseCase useCase) {
        this.useCase = useCase;
    }

    record CreateRequest(@NotBlank String title) {}

    @GetMapping
    public List<Todo> list() { return useCase.listAll(); }

    @GetMapping("/{id}")
    public Todo get(@PathVariable Long id) { return useCase.getById(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Todo create(@RequestBody CreateRequest req) { return useCase.create(req.title()); }

    @PatchMapping("/{id}/complete")
    public Todo complete(@PathVariable Long id) { return useCase.complete(id); }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { useCase.delete(id); }
}
```

## Testing

### TDD — Unit Test (Mockito)

```java
package com.acme.todo.application.service;

import com.acme.todo.domain.model.Todo;
import com.acme.todo.domain.port.out.TodoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TodoServiceTest {

    @Mock
    private TodoRepository repository;

    @InjectMocks
    private TodoService service;

    @Test
    void shouldCreateTodo() {
        Todo todo = new Todo("Buy milk");
        when(repository.save(any(Todo.class))).thenReturn(todo);

        Todo result = service.create("Buy milk");

        assertThat(result.getTitle()).isEqualTo("Buy milk");
        verify(repository).save(any(Todo.class));
    }

    @Test
    void shouldThrowWhenNotFound() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getById(99L))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("not found");
    }
}
```

### BDD — Cucumber Feature

```gherkin
# src/test/resources/features/todo.feature
Feature: Todo management
  Users can create and complete todos.

  Scenario: Create a new todo
    Given no todos exist
    When I create a todo with title "Buy milk"
    Then the todo list should contain 1 item
    And the todo "Buy milk" should not be completed

  Scenario: Complete a todo
    Given a todo exists with title "Read book"
    When I complete the todo "Read book"
    Then the todo "Read book" should be completed
```

### BDD — Step Definitions

```java
package com.acme.todo.bdd.steps;

import com.acme.todo.domain.model.Todo;
import io.cucumber.java.en.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.assertj.core.api.Assertions.assertThat;

public class TodoSteps {

    @Autowired
    private MockMvc mockMvc;

    private MvcResult lastResult;

    @Given("no todos exist")
    public void noTodosExist() { /* H2 starts empty */ }

    @Given("a todo exists with title {string}")
    public void aTodoExistsWithTitle(String title) throws Exception {
        mockMvc.perform(post("/api/todos")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"" + title + "\"}"))
                .andExpect(status().isCreated());
    }

    @When("I create a todo with title {string}")
    public void iCreateATodoWithTitle(String title) throws Exception {
        lastResult = mockMvc.perform(post("/api/todos")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"" + title + "\"}"))
                .andExpect(status().isCreated())
                .andReturn();
    }

    @When("I complete the todo {string}")
    public void iCompleteTheTodo(String title) throws Exception {
        // Get all, find by title, then PATCH complete
        String body = mockMvc.perform(get("/api/todos"))
                .andReturn().getResponse().getContentAsString();
        // Simple parse — production code would use ObjectMapper
        int idx = body.indexOf(title);
        assertThat(idx).isGreaterThan(-1);
        // Extract id (simplified)
        String before = body.substring(0, idx);
        int idStart = before.lastIndexOf("\"id\":") + 5;
        int idEnd = before.indexOf(",", idStart);
        String id = before.substring(idStart, idEnd).trim();
        mockMvc.perform(patch("/api/todos/" + id + "/complete"))
                .andExpect(status().isOk());
    }

    @Then("the todo list should contain {int} item(s)")
    public void theTodoListShouldContain(int count) throws Exception {
        mockMvc.perform(get("/api/todos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(count));
    }

    @Then("the todo {string} should not be completed")
    public void theTodoShouldNotBeCompleted(String title) throws Exception {
        mockMvc.perform(get("/api/todos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.title=='" + title + "')].completed").value(false));
    }

    @Then("the todo {string} should be completed")
    public void theTodoShouldBeCompleted(String title) throws Exception {
        mockMvc.perform(get("/api/todos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[?(@.title=='" + title + "')].completed").value(true));
    }
}
```

## Configuration

| Profile | Database | `ddl-auto` | H2 Console |
|---------|----------|-----------|------------|
| default (dev) | H2 in-memory | `update` | enabled at `/h2-console` |
| `prod` | PostgreSQL | `validate` | disabled |

Activate prod: `java -jar app.jar --spring.profiles.active=prod`

## Frontend (Vite + React + Tailwind + Shadcn/UI)

The scaffold generates a standalone `frontend/` directory with a complete modern toolchain.
It is pre-configured with a proxy (`/api` routes to backend `localhost:8080`) and Shadcn/UI dark mode tokens.

**To implement the UI:**
1. Navigate to `frontend/` and run `npm install`.
2. Install necessary Shadcn/UI components: `npx -y shadcn@latest add button card input checkbox -y` (etc).
3. Update `src/App.tsx` and create components to fetch from the `/api/` endpoints.
4. Run `npm run dev` to start the Vite server.

## Agent Workflow (post-scaffold)

1. **Run scaffold**: `node scripts/scaffold.mjs <groupId> <artifactId> <basePackage>`
2. **Define domain model**: Create entities in `domain/model/`
3. **Define ports**: Use case interfaces in `port/in/`, repository interfaces in `port/out/`
4. **Implement services**: Add logic in `application/service/`
5. **Wire adapters**: JPA repo in `adapter/out/persistence/`, controller in `adapter/in/web/`
6. **Write tests**: Unit tests (Mockito) in `application/service/`, BDD features in `src/test/resources/features/`
7. **Update frontend**: Navigate to `frontend/`, run `npm install`, add shadcn components, and edit React views.
8. **Validate**: `mvn clean verify`

## Validation

| # | What | Command |
|---|------|---------|
| 1 | Compile | `mvn clean compile` |
| 2 | Unit tests | `mvn test` |
| 3 | All tests (unit + BDD + integration) | `mvn clean verify` |
| 4 | Run dev server | `mvn spring-boot:run` |
