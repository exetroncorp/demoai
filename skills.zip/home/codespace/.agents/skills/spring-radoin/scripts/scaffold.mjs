import fs from "node:fs";
import { join } from "node:path";
import { execSync } from "node:child_process";

const args = process.argv.slice(2);
if (args.length < 3) {
  console.error("Usage: node scaffold.mjs <groupId> <artifactId> <basePackage>");
  console.error("Example: node scaffold.mjs com.acme lending-app com.acme.lending");
  process.exit(1);
}

const [groupId, artifactId, basePackage] = args;
const root = join(process.cwd(), artifactId);

if (!/^[a-z0-9.]+$/.test(groupId) || !/^[a-z0-9-]+$/.test(artifactId) || !/^[a-z0-9.]+$/.test(basePackage)) {
  console.error("❌ Invalid naming format.");
  process.exit(1);
}

const { mkdirSync, writeFileSync } = fs;

console.log(`\n🚀 Scaffolding ${artifactId} in ${root}...\n`);

const srcJava = join(root, "src/main/java", basePackage.replace(/\./g, "/"));
const srcRes = join(root, "src/main/resources");
const testJava = join(root, "src/test/java", basePackage.replace(/\./g, "/"));
const testRes = join(root, "src/test/resources");
const frontend = join(root, "frontend");

const dirs = [
  join(srcJava, "domain/model"),
  join(srcJava, "domain/port/in"),
  join(srcJava, "domain/port/out"),
  join(srcJava, "application/service"),
  join(srcJava, "infrastructure/adapter/in/web"),
  join(srcJava, "infrastructure/adapter/out/persistence"),
  join(srcJava, "infrastructure/config"),
  srcRes,
  join(testJava, "domain/model"),
  join(testJava, "application/service"),
  join(testJava, "infrastructure/adapter/in/web"),
  join(testJava, "bdd/steps"),
  join(testRes, "features"),
  join(frontend, "src/components"),
  join(frontend, "src/lib")
];

dirs.forEach(dir => mkdirSync(dir, { recursive: true }));

function file(path, content) {
  writeFileSync(path, content.trim() + "\n");
}

file(
  join(root, "pom.xml"),
  `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.4.5</version>
    <relativePath/> <!-- lookup parent from repository -->
  </parent>
  <groupId>${groupId}</groupId>
  <artifactId>${artifactId}</artifactId>
  <version>0.0.1-SNAPSHOT</version>
  <name>${artifactId}</name>
  <description>Auto-generated DDD Spring Boot project</description>

  <properties>
    <java.version>17</java.version>
    <cucumber.version>7.15.0</cucumber.version>
  </properties>

  <dependencies>
    <!-- Web & Data -->
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>

    <!-- DevTools & DB -->
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-devtools</artifactId>
      <scope>runtime</scope>
      <optional>true</optional>
    </dependency>
    <dependency>
      <groupId>com.h2database</groupId>
      <artifactId>h2</artifactId>
      <scope>runtime</scope>
    </dependency>
    <dependency>
      <groupId>org.postgresql</groupId>
      <artifactId>postgresql</artifactId>
      <scope>runtime</scope>
    </dependency>

    <!-- Test -->
    <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-test</artifactId>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>io.cucumber</groupId>
      <artifactId>cucumber-java</artifactId>
      <version>\${cucumber.version}</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>io.cucumber</groupId>
      <artifactId>cucumber-spring</artifactId>
      <version>\${cucumber.version}</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>io.cucumber</groupId>
      <artifactId>cucumber-junit-platform-engine</artifactId>
      <version>\${cucumber.version}</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>org.junit.platform</groupId>
      <artifactId>junit-platform-suite</artifactId>
      <scope>test</scope>
    </dependency>
  </dependencies>

  <build>
    <plugins>
      <plugin>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-maven-plugin</artifactId>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-compiler-plugin</artifactId>
        <configuration>
          <compilerArgs>
            <arg>-parameters</arg>
          </compilerArgs>
        </configuration>
      </plugin>
    </plugins>
  </build>
</project>`
);

file(
  join(srcJava, "Application.java"),
  `package ${basePackage};

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}`
);

file(
  join(srcRes, "application.properties"),
  `# Default profile (DEV/TEST) - H2 In-Memory
spring.application.name=${artifactId}
spring.datasource.url=jdbc:h2:mem:devdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.jpa.hibernate.ddl-auto=update
spring.h2.console.enabled=true
`
);

file(
  join(srcRes, "application-prod.properties"),
  `# PROD profile - PostgreSQL
spring.datasource.url=\${POSTGRES_URL:jdbc:postgresql://localhost:5432/${artifactId}}
spring.datasource.username=\${POSTGRES_USER:postgres}
spring.datasource.password=\${POSTGRES_PASSWORD:postgres}
spring.jpa.hibernate.ddl-auto=validate
`
);

file(
  join(srcJava, "infrastructure/config/CorsConfig.java"),
  `package ${basePackage}.infrastructure.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**").allowedOrigins("*").allowedMethods("*");
    }
}`
);

file(
  join(root, "Dockerfile"),
  `# Stage 1: Build React Frontend
FROM node:20-alpine AS frontend-build
WORKDIR /app
COPY frontend/package*.json ./
RUN npm install
COPY frontend ./
RUN npm run build

# Stage 2: Build Spring Boot Backend
FROM maven:3.9.6-eclipse-temurin-21-jammy AS backend-build
WORKDIR /app
COPY pom.xml ./
# Download dependencies to cache them
RUN mvn dependency:go-offline -B
COPY src ./src
# Copy frontend build into static resources folder
COPY --from=frontend-build /app/dist ./src/main/resources/static
RUN mvn clean package -DskipTests

# Stage 3: Run
FROM eclipse-temurin:21-jre-jammy
WORKDIR /app
COPY --from=backend-build /app/target/${artifactId}-0.0.1-SNAPSHOT.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar", "--spring.profiles.active=prod"]`
);

file(
  join(root, "docker-compose.yml"),
  `services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: ${artifactId}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 10s
      timeout: 5s
      retries: 5

  app:
    build: .
    ports:
      - "8080:8080"
    environment:
      POSTGRES_URL: jdbc:postgresql://postgres:5432/${artifactId}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    depends_on:
      postgres:
        condition: service_healthy

volumes:
  postgres_data:`
);

file(
  join(frontend, "package.json"),
  `{
  "name": "${artifactId}-frontend",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "lint": "eslint .",
    "preview": "vite preview"
  },
  "dependencies": {
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.1",
    "lucide-react": "^0.441.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "tailwind-merge": "^2.5.2",
    "tailwindcss-animate": "^1.0.7"
  },
  "devDependencies": {
    "@eslint/js": "^9.9.0",
    "@types/node": "^22.5.5",
    "@types/react": "^18.3.3",
    "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.3.1",
    "autoprefixer": "^10.4.20",
    "eslint": "^9.9.0",
    "eslint-plugin-react-hooks": "^5.1.0-rc.0",
    "eslint-plugin-react-refresh": "^0.4.9",
    "globals": "^15.9.0",
    "postcss": "^8.4.47",
    "tailwindcss": "^3.4.11",
    "typescript": "^5.5.3",
    "typescript-eslint": "^8.0.1",
    "vite": "^5.4.1"
  }
}`
);

file(
  join(frontend, "vite.config.ts"),
  `import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true
      }
    }
  }
})`
);

file(
  join(frontend, "tailwind.config.js"),
  `/** @type {import('tailwindcss').Config} */
import tailwindcssAnimate from "tailwindcss-animate";
export default {
    darkMode: ["class"],
    content: ["./index.html", "./src/**/*.{ts,tsx,js,jsx}"],
  theme: {
  	extend: {
  		borderRadius: {
  			lg: 'var(--radius)',
  			md: 'calc(var(--radius) - 2px)',
  			sm: 'calc(var(--radius) - 4px)'
  		},
  		colors: {
  			background: 'hsl(var(--background))',
  			foreground: 'hsl(var(--foreground))',
  			card: {
  				DEFAULT: 'hsl(var(--card))',
  				foreground: 'hsl(var(--card-foreground))'
  			},
  			popover: {
  				DEFAULT: 'hsl(var(--popover))',
  				foreground: 'hsl(var(--popover-foreground))'
  			},
  			primary: {
  				DEFAULT: 'hsl(var(--primary))',
  				foreground: 'hsl(var(--primary-foreground))'
  			},
  			secondary: {
  				DEFAULT: 'hsl(var(--secondary))',
  				foreground: 'hsl(var(--secondary-foreground))'
  			},
  			muted: {
  				DEFAULT: 'hsl(var(--muted))',
  				foreground: 'hsl(var(--muted-foreground))'
  			},
  			accent: {
  				DEFAULT: 'hsl(var(--accent))',
  				foreground: 'hsl(var(--accent-foreground))'
  			},
  			destructive: {
  				DEFAULT: 'hsl(var(--destructive))',
  				foreground: 'hsl(var(--destructive-foreground))'
  			},
  			border: 'hsl(var(--border))',
  			input: 'hsl(var(--input))',
  			ring: 'hsl(var(--ring))',
  			chart: {
  				'1': 'hsl(var(--chart-1))',
  				'2': 'hsl(var(--chart-2))',
  				'3': 'hsl(var(--chart-3))',
  				'4': 'hsl(var(--chart-4))',
  				'5': 'hsl(var(--chart-5))'
  			}
  		}
  	}
  },
  plugins: [tailwindcssAnimate],
}`
);

file(
  join(frontend, "tsconfig.json"),
  `{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}`
);

file(
  join(frontend, "tsconfig.node.json"),
  `{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true,
    "strict": true
  },
  "include": ["vite.config.ts"]
}`
);

file(
  join(frontend, "components.json"),
  `{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "rsc": false,
  "tailwind": {
    "config": "tailwind.config.js",
    "css": "src/index.css",
    "baseColor": "zinc",
    "cssVariables": true,
    "prefix": ""
  },
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  }
}`
);

file(
  join(frontend, "postcss.config.js"),
  `export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}`
);

file(
  join(frontend, "index.html"),
  `<!doctype html>
<html lang="en" class="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${artifactId}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`
);

file(
  join(frontend, "src/index.css"),
  `@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 240 10% 3.9%;
    --card: 0 0% 100%;
    --card-foreground: 240 10% 3.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 240 10% 3.9%;
    --primary: 240 5.9% 10%;
    --primary-foreground: 0 0% 98%;
    --secondary: 240 4.8% 95.9%;
    --secondary-foreground: 240 5.9% 10%;
    --muted: 240 4.8% 95.9%;
    --muted-foreground: 240 3.8% 46.1%;
    --accent: 240 4.8% 95.9%;
    --accent-foreground: 240 5.9% 10%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 0 0% 98%;
    --border: 240 5.9% 90%;
    --input: 240 5.9% 90%;
    --ring: 240 10% 3.9%;
    --radius: 0.5rem;
  }

  .dark {
    --background: 240 10% 3.9%;
    --foreground: 0 0% 98%;
    --card: 240 10% 3.9%;
    --card-foreground: 0 0% 98%;
    --popover: 240 10% 3.9%;
    --popover-foreground: 0 0% 98%;
    --primary: 0 0% 98%;
    --primary-foreground: 240 5.9% 10%;
    --secondary: 240 3.7% 15.9%;
    --secondary-foreground: 0 0% 98%;
    --muted: 240 3.7% 15.9%;
    --muted-foreground: 240 5% 64.9%;
    --accent: 240 3.7% 15.9%;
    --accent-foreground: 0 0% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 0 0% 98%;
    --border: 240 3.7% 15.9%;
    --input: 240 3.7% 15.9%;
    --ring: 240 4.9% 83.9%;
  }

  .theme-rose {
    --primary: 346.8 77.2% 49.8%;
    --primary-foreground: 355.7 100% 97.3%;
    --ring: 346.8 77.2% 49.8%;
  }
  .theme-rose.dark {
    --primary: 346.8 77.2% 49.8%;
    --primary-foreground: 355.7 100% 97.3%;
    --ring: 346.8 77.2% 49.8%;
  }

  .theme-blue {
    --primary: 221.2 83.2% 53.3%;
    --primary-foreground: 210 40% 98%;
    --ring: 221.2 83.2% 53.3%;
  }
  .theme-blue.dark {
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 47.4% 11.2%;
    --ring: 224.3 76.3% 48%;
  }

  .theme-green {
    --primary: 142.1 76.2% 36.3%;
    --primary-foreground: 355.7 100% 97.3%;
    --ring: 142.1 76.2% 36.3%;
  }
  .theme-green.dark {
    --primary: 142.1 70.6% 45.3%;
    --primary-foreground: 144.9 80.4% 10%;
    --ring: 142.4 71.8% 29.2%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}`
);

file(
  join(frontend, "src/components/theme-provider.tsx"),
  `import React, { createContext, useContext, useEffect, useState } from "react"

export type Theme = "dark" | "light"
export type Color = "zinc" | "rose" | "blue" | "green"

type ThemeProviderProps = {
  children: React.ReactNode
  defaultTheme?: Theme
  defaultColor?: Color
}

type ThemeProviderState = {
  theme: Theme
  color: Color
  setTheme: (theme: Theme) => void
  setColor: (color: Color) => void
}

const initialState: ThemeProviderState = {
  theme: "dark",
  color: "zinc",
  setTheme: () => null,
  setColor: () => null,
}

const ThemeProviderContext = createContext<ThemeProviderState>(initialState)

export function ThemeProvider({
  children,
  defaultTheme = "dark",
  defaultColor = "zinc",
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(defaultTheme)
  const [color, setColor] = useState<Color>(defaultColor)

  useEffect(() => {
    const root = window.document.documentElement
    root.classList.remove("light", "dark", "theme-zinc", "theme-rose", "theme-blue", "theme-green")
    
    if (theme === "dark") {
      root.classList.add("dark")
    } else {
      root.classList.add("light")
    }
    
    if (color !== 'zinc') {
      root.classList.add(\`theme-\${color}\`)
    }
  }, [theme, color])

  return (
    <ThemeProviderContext.Provider value={{ theme, color, setTheme, setColor }}>
      {children}
    </ThemeProviderContext.Provider>
  )
}

export const useTheme = () => useContext(ThemeProviderContext)`
);

file(
  join(frontend, "src/components/theme-switcher.tsx"),
  `import { useTheme } from "./theme-provider"

export function ThemeSwitcher() {
  const { theme, color, setTheme, setColor } = useTheme()

  return (
    <div className="flex items-center gap-2">
      <select 
        value={theme} 
        onChange={(e) => setTheme(e.target.value as any)}
        className="bg-transparent border border-border text-foreground rounded p-1 text-sm outline-none focus:ring-1 focus:ring-ring"
      >
        <option value="dark">Dark</option>
        <option value="light">Light</option>
      </select>
      <select 
        value={color} 
        onChange={(e) => setColor(e.target.value as any)}
        className="bg-transparent border border-border text-foreground rounded p-1 text-sm outline-none focus:ring-1 focus:ring-ring"
      >
        <option value="zinc">Zinc</option>
        <option value="rose">Rose</option>
        <option value="blue">Blue</option>
        <option value="green">Green</option>
      </select>
    </div>
  )
}
`
);

file(
  join(frontend, "src/lib/utils.ts"),
  `import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}`
);

file(
  join(frontend, "src/main.tsx"),
  `import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { ThemeProvider } from './components/theme-provider'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ThemeProvider defaultTheme="dark" defaultColor="zinc">
      <App />
    </ThemeProvider>
  </React.StrictMode>,
)`
);

file(
  join(frontend, "src/App.tsx"),
  `import { ThemeSwitcher } from "./components/theme-switcher"

export default function App() {
  return (
    <div className="container mx-auto p-8 max-w-2xl">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">${artifactId}</h1>
        <ThemeSwitcher />
      </div>
      <p className="text-muted-foreground">
        App scaffolded. Add your domain UI here.
      </p>
    </div>
  )
}`
);

file(
  join(testJava, "bdd/CucumberTest.java"),
  `package ${basePackage}.bdd;

import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.IncludeEngines;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;

import static io.cucumber.junit.platform.engine.Constants.GLUE_PROPERTY_NAME;
import static io.cucumber.junit.platform.engine.Constants.PLUGIN_PROPERTY_NAME;

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "${basePackage}.bdd.steps")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "pretty")
public class CucumberTest {
}`
);

file(
  join(testJava, "bdd/steps/SpringIntegrationTest.java"),
  `package ${basePackage}.bdd.steps;

import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

@CucumberContextConfiguration
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class SpringIntegrationTest {
}`
);

file(
  join(testRes, "features/placeholder.feature"),
  `Feature: Application health check
  The application should be running and healthy.

  Scenario: Health endpoint returns UP
    Given the application is running
    When I check the health endpoint
    Then the status should be "UP"`
);

file(
  join(testJava, "bdd/steps/HealthSteps.java"),
  `package ${basePackage}.bdd.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.assertj.core.api.Assertions.assertThat;

public class HealthSteps {

    @Autowired
    private MockMvc mockMvc;

    private MvcResult result;

    @Given("the application is running")
    public void theApplicationIsRunning() {
        // Spring context is already started by CucumberContextConfiguration
    }

    @When("I check the health endpoint")
    public void iCheckTheHealthEndpoint() throws Exception {
        result = mockMvc.perform(get("/actuator/health"))
                .andExpect(status().isOk())
                .andReturn();
    }

    @Then("the status should be {string}")
    public void theStatusShouldBe(String expected) throws Exception {
        String body = result.getResponse().getContentAsString();
        assertThat(body).contains(expected);
    }
}`
);

file(
  join(testJava, "ApplicationTest.java"),
  `package ${basePackage};

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTest {
    @Test
    void contextLoads() {
    }
}`
);

file(
  join(root, ".gitignore"),
  `target/
!.mvn/wrapper/maven-wrapper.jar
*.class
*.jar
*.war
*.log
.idea/
*.iml
.vscode/
.DS_Store
*.swp
.env
application-local.properties`
);

console.log(`\n✅ Project scaffolded: ${root}`);
console.log(`\nNext steps:`);
console.log(`  cd ${artifactId}`);
console.log(`  mvn clean verify`);
