# Agent Guard-Rails for skill-bank-spring

- **Always scaffold first**: Run `node scripts/scaffold.mjs <groupId> <artifactId> <basePackage>` before writing any Java code.
- **No Lombok** — use explicit constructors and getters/setters.
- **No Flyway / Liquibase** — use `spring.jpa.hibernate.ddl-auto` for schema management.
- **No Docker required** for development — H2 in-memory is the dev database.
- **Maven only** — no Gradle.
- **`.properties` format only** — no YAML config files.
- **DDD layer discipline** — the `domain` package must never import from `infrastructure` or `application`.
- **Ports & Adapters** — business logic depends on interfaces (ports), never on implementations (adapters).
- **No Lombok, no MapStruct** — keep dependencies minimal and explicit.
- **Test naming**: unit tests end with `Test`, integration tests end with `IT`.
- **Cucumber features** go in `src/test/resources/features/`, step defs in `<basePackage>.bdd.steps`.
- **Ask the user** before running `git init` or any git commands.
- **Never hard-code a domain** — the skill is domain-agnostic. Parameterize everything.
- **No `sudo`** — all commands must work in a rootless container.
